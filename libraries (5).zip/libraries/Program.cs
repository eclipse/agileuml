﻿using System;

namespace ocliter
{
    using System;
    using System.Collections;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Linq;
    using System.Reflection;
    using System.Diagnostics;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using System.Text.Json;
    using System.Text.Json.Serialization;

    using System.Data; 
    using System.Data.Common;
    using System.Data.SqlClient;
    using System.Net.Sockets;
    using System.Net.Http;

    // Requires SystemTypes OCL library class. 

    public class OclDate
    {
        long time;
        static long systemTime;
        int year;
        int month;
        int day;
        int weekday;
        int hour;
        int minute;
        int second;

        public static OclDate newOclDate()
        {
            DateTime dd = DateTime.Now;
            OclDate d = new OclDate();
            d.time = SystemTypes.getTime(dd);
            d.year = dd.Year;
            d.month = dd.Month;
            d.day = dd.Day;
            d.weekday = (int)dd.DayOfWeek;
            d.hour = dd.Hour;
            d.minute = dd.Minute;
            d.second = dd.Second;
            OclDate.systemTime = d.time;
            return d;
        }

        public static OclDate newOclDate_Time(long t)
        {
            DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(t).DateTime;
            OclDate d = new OclDate();
            d.time = t;
            d.year = dd.Year;
            d.month = dd.Month;
            d.day = dd.Day;
            d.weekday = (int)dd.DayOfWeek;
            d.hour = dd.Hour;
            d.minute = dd.Minute;
            d.second = dd.Second;

            return d;
        }

        public void setTime(long t)
        {
            DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(t).DateTime;
            time = t;
            year = dd.Year;
            month = dd.Month;
            day = dd.Day;
            weekday = (int)dd.DayOfWeek;
            hour = dd.Hour;
            minute = dd.Minute;
            second = dd.Second;
        }

        public long getTime()
        { return time; }

        public static long getSystemTime()
        {
            DateTime dd = DateTime.Now;
            OclDate.systemTime = SystemTypes.getTime(dd);
            return OclDate.systemTime;
        }


        public int getYear()
        { return year; }

        public int getMonth()
        { return month; }

        public int getDate()
        { return day; }

        public int getDay()
        { return weekday; }

        public int getHours()
        { return hour; }

        public int getHour()
        { return hour; }

        public int getMinutes()
        { return minute; }

        public int getMinute()
        { return minute; }

        public int getSeconds()
        { return second; }

        public int getSecond()
        { return second; }

        public bool dateBefore(OclDate d)
        {
            bool result = false;
            if (time < d.time)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }


        public bool dateAfter(OclDate d)
        {
            bool result = false;
            if (time > d.time)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public override string ToString()
        {
            DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(time).DateTime;
            return dd.ToString();
        }
    }


    class OclDatasource
    { protected SqlConnection connection;
      public String url = ""; 
      public String protocol = ""; 
      public String host = ""; 
      public String file = ""; 
      public int port = 0;
      public Uri address = null;
      static readonly HttpClient client = new HttpClient();
      string requestMethod = "GET"; 

      public String name = ""; 
      public String passwd = ""; 
      public String schema = "";
      public TcpClient socket = null;
      public Socket clientSocket = null; 
      public TcpListener serverSocket = null;
      public int connectionLimit = 0; 

        public static OclDatasource createOclDatasource()
        { return new OclDatasource(); }

        public static OclDatasource newOclDatasource()
        { return new OclDatasource(); }

        public static OclDatasource getConnection(String url,
            String name, String passwd)
        { OclDatasource res = createOclDatasource();
            res.url = url;
            res.name = name;
            res.passwd = passwd;
            res.connection = new SqlConnection(url);
            try { res.connection.Open(); }
            catch (Exception ex) { } 

            return res; 
        }

        public SQLStatement prepare(string stat)
        { if (connection != null)
            {
                SqlCommand command = new SqlCommand(null, connection);
                command.CommandText = stat;
                command.Prepare();
                SQLStatement res = new SQLStatement();
                res.text = stat;
                res.command = command;
                res.connection = connection;
                res.database = this; 
                return res; 
            }
            return null; 
        }

        public SQLStatement createStatement()
        {
            if (connection != null)
            {
                SqlCommand command = new SqlCommand(null, connection);
                SQLStatement res = new SQLStatement();
                res.text = "";
                res.command = command;
                res.connection = connection;
                res.database = this;
                return res;
            }
            return null;
        }

        public OclIterator queryString(string stat)
        {
            SQLStatement sql = prepare(stat);
            if (sql != null)
            { return sql.executeQuery(); }
            return null;
        }

        public OclIterator rawQuery(string stat, ArrayList pos)
        {
            SQLStatement sql = prepare(stat);
            if (sql != null)
            { return sql.executeQuery(); }
            return null;
        }

        public OclIterator query_String_Sequence(string stat, ArrayList cols)
        {
            SQLStatement sql = prepare(stat);
            if (sql != null)
            { return sql.executeQuery(); }
            return null;
        }

        public SQLStatement prepareStatement(string stat)
        { return prepare(stat); }

        public SQLStatement prepareCall(string stat)
        { return prepare(stat); }

        public String nativeSQL(string stat)
        {
            if (connection != null)
            {
                SqlCommand command = new SqlCommand(stat, connection);
                command.CommandType = CommandType.Text;
                connection.Open();
                return "" + command.ExecuteScalar();
            }
            return null; 
        }
        
        public void execSQL(string stat)
        {
            if (connection != null)
            {
              SqlCommand command = new SqlCommand(stat, connection);
              command.CommandType = CommandType.Text;
              connection.Open();
              command.ExecuteNonQuery();
              return;
            }
        }

        void abort() { }

        void close()
        {
            if (clientSocket != null)
            { clientSocket.Close(); }
        } 

        void commit() { }

        void rollback() { } 

        public void setRequestMethod(string met)
        { requestMethod = met;  }

        public static OclDatasource newSocket(string host, int port)
        {
            OclDatasource res = createOclDatasource();
            res.name = host;
            res.host = host; 
            res.port = port;
            try
            {
                TcpClient client = new TcpClient(host, port);
                res.socket = client; 
            }
            catch { } 

            return res; 
        }

        public static OclDatasource newServerSocket(int port, int limit)
        {
            OclDatasource res = createOclDatasource();
            
            res.port = port;
            res.connectionLimit = limit; 

            try
            {
                byte[] localhost = { 127, 0, 0, 1 }; 
                TcpListener server = new TcpListener(new System.Net.IPAddress(localhost), port);
                res.serverSocket = server;
            }
            catch { }

            return res;
        }

        public OclDatasource accept()
        {  if (serverSocket != null)
            { Socket client = serverSocket.AcceptSocket(); 
              if (client.Connected)
                {
                    OclDatasource ds = new OclDatasource(); 
                    ds.clientSocket = client;
                    return ds; 
                }
            }
            return this; 
        }

        public static OclDatasource newURL(string s)
        { Uri uri = new Uri(s);
            OclDatasource res = new OclDatasource();
            res.url = s;
            res.address = uri;
            res.protocol = uri.Scheme;
            res.host = uri.Host;
            res.file = uri.PathAndQuery;
            res.port = uri.Port; 
            return res; 
        }

        public static OclDatasource newURL_PHF(string p, string h, string f)
        {
            string s = p + "://" + h + "/" + f; 
            Uri uri = new Uri(s);
            OclDatasource res = new OclDatasource();
            res.url = s;
            res.address = uri;
            res.protocol = p;
            res.host = h;
            res.file = f;
            res.port = 0;
            return res;
        }

        public static OclDatasource newURL_PHNF(string p, string h, int n, string f)
        {
            string s = p + "://" + h + ":" + n + "/" + f;
            Uri uri = new Uri(s);
            OclDatasource res = new OclDatasource();
            res.url = s;
            res.address = uri;
            res.protocol = p;
            res.host = h;
            res.file = f;
            res.port = n;
            return res;
        }

        string getURL() 
        { return url; }

        async Task<object> getContent()
        {
            try
            {
                HttpResponseMessage response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                return responseBody;
            }
            catch (Exception _ex) { return null; }
        }

    // getInputStream() public System.Threading.Tasks.Task<System.IO.Stream> GetStreamAsync (Uri? requestUri);

    string getFile()
    { return file; }

    string getHost() 
    { return host; }

    int getPort() 
    { return port; }

    string getProtocol() 
    { return protocol; }

    void setSchema(string s)
    { schema = s; }

    string getSchema()
    { return schema; }

        /* 
        operation connect() : void
pre: true post: true; 

    operation openConnection() : OclDatasource
    pre: true post: result = self; 

    operation getInputStream() : OclFile
    pre: true post: true; 

    operation getOutputStream() : OclFile
    pre: true post: true; */ 


  }

    class SQLStatement
    { public String text = "";
        public SqlCommand command = null;
        public SqlConnection connection = null;
        public OclDatasource database = null;
        public OclIterator resultSet = null; 

        public void close()
        {  if (command != null)
            { command.Cancel();  }
        }


        public void closeOnCompletion() { }

        public void setString(int field, String value)
        {
            if (command != null)
            { command.Parameters[field].Value = value; }
        }

        public void setInt(int field, int value)
        {
            if (command != null)
            { command.Parameters[field].Value = value; }
        }

        public void setByte(int field, int value)
        {
            if (command != null)
            { command.Parameters[field].Value = value; }
        }

        public void setShort(int field, int value)
        {
            if (command != null)
            { command.Parameters[field].Value = value; }
        }

        public void setBoolean(int field, bool value)
        {
            if (command != null)
            { command.Parameters[field].Value = value; }
        }

        public void setLong(int field, long value)
        {
            if (command != null)
            { command.Parameters[field].Value = value; }
        }

        public void setDouble(int field, double value)
        {
            if (command != null)
            { command.Parameters[field].Value = value; }
        }

        public void setTimestamp(int field, OclDate value)
        {
            if (command != null)
            { command.Parameters[field].Value = value.getTime(); }
        }

        public void executeUpdate()
        { if (command != null)
          { command.ExecuteNonQuery(); }
          else if (text != null && connection != null)
          { command = new SqlCommand(text, connection);
            command.CommandType = CommandType.Text;
            connection.Open();
            command.ExecuteNonQuery(); 
          }
        }

       public void execute(String stat)
        {
            if (stat != null && connection != null)
            {
                command = new SqlCommand(stat, connection);
                command.CommandType = CommandType.Text;
                connection.Open();
                command.ExecuteNonQuery();
            }
            else if (command != null)
            { command.ExecuteNonQuery(); }
        }

        public void execute()
        { executeUpdate(); }
 
        public OclIterator executeQuery(String stat)
        { OclIterator res = null;
            ArrayList records = new ArrayList();
            ArrayList columnNames = new ArrayList();

            if (command == null && connection != null)
            { command = new SqlCommand(stat, connection);
                command.CommandType = CommandType.Text;
                connection.Open();
            } 
            
            if (command != null)
            { SqlDataReader rdr = command.ExecuteReader();

                while (rdr.Read())
                {
                    columnNames = new ArrayList(); 

                    int n = rdr.FieldCount;
                    Hashtable record = new Hashtable();

                    for (int i = 0; i < n; i++)
                    {
                        String fname = rdr.GetName(i);
                        columnNames.Add(fname); 
                        record[fname] = rdr.GetValue(i);
                    }
                    records.Add(record); 
                } 
                rdr.Close();
                res = OclIterator.newOclIterator_Sequence(records);
                res.columnNames = columnNames; 
            }
            return res; 
        }

        public OclIterator executeQuery()
        { return executeQuery(text); }

        public OclDatasource getConnection()
        { return database; }

        public OclIterator getResultSet()
        { return resultSet; }

    }

    class OclIteratorResult
    {
        static OclIteratorResult createOclIteratorResult()
        {
            OclIteratorResult result = new OclIteratorResult();
            return result;
        }

        bool done = false;
        object value = null;

        public static OclIteratorResult newOclIteratorResult(object v)
        {
            OclIteratorResult res = createOclIteratorResult();
            res.value = v;
            if (v == null)
            { res.done = true; }
            else
            { res.done = false; }
            return res;
        }

    }


    class OclIterator
    {
        private int position; // internal
        private int markedPosition; // internal
        private Func<int, object> generatorFunction; 

        public ArrayList elements; // internal
        public ArrayList columnNames; 

        public OclIterator()
        {
            position = 0;
            markedPosition = 0; 
            elements = (new ArrayList());
            generatorFunction = null;
            columnNames = (new ArrayList());
        }

        public override string ToString()
        {
            string _res_ = "(OclIterator) ";
            _res_ = _res_ + position + ",";
            _res_ = _res_ + elements;
            return _res_;
        }

        public void setPosition(int position_x) { position = position_x; }

        public void markPosition() { markedPosition = position; }

        public void movePosition(int i)
        { position = i + position; }

        void moveToMarkedPosition()
        { position = markedPosition; } 

        public void setelements(ArrayList elements_x) { elements = elements_x; }

        public void setelements(int _ind, object elements_x) { elements[_ind] = elements_x; }

        public void addelements(object elements_x)
        { elements.Add(elements_x); }

        public void removeelements(object elements_x)
        { elements = SystemTypes.subtract(elements, elements_x); }

        public int getPosition() { return position; }

        public ArrayList getelements() { return elements; }

        public bool isAfterLast()
        { if (position > elements.Count)
           { return true; }
           else
           { return false; }
        }

        public bool isBeforeFirst()
        { if (position <= 0) 
            { return true; } 
            else 
            { return false; }
        }

        public bool hasNext()
        {
            bool result = false;

            if (position >= 0 && position < elements.Count) { result = true; }
            else { result = false; }
            return result;
        }


        public bool hasPrevious()
        {
            bool result = false;

            if (position > 1 && position <= elements.Count + 1) { result = true; }
            else { result = false; }
            return result;
        }


        public int nextIndex()
        { return position + 1; }


        public int previousIndex()
        {
            return position - 1;
        }


        public void moveForward()
        {
            position++;
        }

        public void moveBackward()
        {
            position--;
        }

        public void moveTo(int i)
        {   position = i;
        }

        public void moveToStart()
        { position = 0; }

        public void moveToEnd()
        {
            position = this.getelements().Count + 1;
        }

        public void moveToFirst()
        { position = 1; }

        public void moveToLast()
        {
            position = this.getelements().Count;
        }

        public static OclIterator newOclIterator_Sequence(ArrayList sq)
        {
            OclIterator ot = new OclIterator();
            ot.setelements(sq);
            ot.setPosition(0);
            return ot;
        }


        public static OclIterator newOclIterator_Set(ArrayList st)
        {
            OclIterator ot = new OclIterator();
            ot.setelements(SystemTypes.sort(st));
            ot.setPosition(0);
            return ot;
        }

        public static OclIterator newOclIterator_String(string str)
        {
            OclIterator ot = new OclIterator();
            ot.elements = SystemTypes.split(str, "[ \n\t\r]+");
            ot.position = 0;
            return ot;
        }

        public static OclIterator newOclIterator_String_String(string str, String chrs)
        {
            OclIterator ot = new OclIterator();
            ot.elements = SystemTypes.split(str, "[" + chrs + "]+");
            ot.position = 0;
            return ot;
        }

        public static OclIterator newOclIterator_Function(Func<int,object> f)
        {
            OclIterator ot = new OclIterator();
            ot.setelements(new ArrayList());
            ot.generatorFunction = f; 
            ot.setPosition(0);
            return ot;
        }

        public object getCurrent()
        {
            object result = null;
            if (position < 1 || position > elements.Count)
            { return result; }

            result = ((object)elements[position - 1]);
            return result;
        }


        public void set(object x)
        {
            if (position < 1 || position > elements.Count)
            { return; }
            elements[position - 1] = x;
        }

        public void insert(object x)
        {
            if (position < 1 || position > elements.Count)
            { return; }

            elements.Insert(position - 1, x);
        }


        public void remove()
        {
            if (position < 1 || position > elements.Count)
            { return; }

            elements.RemoveAt(position - 1);
        }

        public OclIteratorResult nextResult()
        {
            if (generatorFunction == null)
            {
                Object v = next();
                return OclIteratorResult.newOclIteratorResult(v);
            }

            object res = generatorFunction(position);
            position++;
            if (position <= elements.Count)
            { set(res); }
            else
            { elements.Add(res); }
            return OclIteratorResult.newOclIteratorResult(res);
        }


        public object next()
        {
            this.moveForward();
            return this.getCurrent();
        }


        public object previous()
        {
            this.moveBackward();
            return this.getCurrent();
        }

        public object at(int i)
        { return elements[i - 1]; }

        public int length()
        { return elements.Count; }

        public void close()
        {
            position = 0;
            markedPosition = 0;
            elements = new ArrayList();
            columnNames = new ArrayList();
        } 

        public int getColumnCount()
        { return columnNames.Count; }

        public String getColumnName(int i)
        {
            if (columnNames.Count >= i & i >= 1)
            { return (String) columnNames[i-1]; }
            return null;
        }

        public object getCurrentFieldByIndex(int i)
        {
            if (columnNames.Count >= i & i >= 1)
            {
                Hashtable mm = (Hashtable)getCurrent();
                String fld = (String)columnNames[i - 1];
                if (mm != null && fld != null)
                { return mm[fld]; }
            }
            return null;
        }

        public void setCurrentFieldByIndex(int i, object v)
        {
            if (columnNames.Count >= i & i >= 1)
            {
                Hashtable mm = (Hashtable)getCurrent();
                String fld = (String)columnNames[i - 1];
                if (mm != null && fld != null)
                { mm[fld] = v; }
            }
        }
    }








    public class SystemTypes
    {
        public static long getTime()
        {
            DateTimeOffset d = new DateTimeOffset(DateTime.Now);
            return d.ToUnixTimeMilliseconds();
        }

        public static long getTime(DateTime d)
        {
            DateTimeOffset doff = new DateTimeOffset(d);
            return doff.ToUnixTimeMilliseconds();
        }









        public static bool isSubset(ArrayList a, ArrayList b)
        {
            bool res = true;
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i] != null && b.Contains(a[i])) { }
                else { return false; }
            }
            return res;
        }

        public static bool equalsSet(ArrayList a, ArrayList b)
        { return isSubset(a, b) && isSubset(b, a); }


        public static ArrayList addSet(ArrayList a, object x)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a); if (x != null) { res.Add(x); }
            return res;
        }

        public static ArrayList makeSet(object x)
        {
            ArrayList res = new ArrayList();
            if (x != null) { res.Add(x); }
            return res;
        }

        public static ArrayList removeSet(ArrayList a, object x)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            while (res.Contains(x)) { res.Remove(x); }
            return res;
        }


        public static object max(ArrayList l)
        {
            IComparable res = null;
            if (l.Count == 0) { return res; }
            res = (IComparable)l[0];
            for (int i = 1; i < l.Count; i++)
            {
                IComparable e = (IComparable)l[i];
                if (res.CompareTo(e) < 0) { res = e; }
            }
            return res;
        }


        public static object min(ArrayList l)
        {
            IComparable res = null;
            if (l.Count == 0) { return res; }
            res = (IComparable)l[0];
            for (int i = 1; i < l.Count; i++)
            {
                IComparable e = (IComparable)l[i];
                if (res.CompareTo(e) > 0) { res = e; }
            }
            return res;
        }


        public static ArrayList copyCollection(ArrayList a)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            return res;
        }

        public static Hashtable copyMap(Hashtable m)
        {
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry pair in m)
            { res.Add(pair.Key, pair.Value); }
            return res;
        }

        public static ArrayList collectSequence(ArrayList col, Func<object, object> f)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < col.Count; i++)
            { res.Add(f(col[i])); }
            return res;
        }

        public unsafe static T* resizeTo<T>(T* arr, int n) where T : unmanaged
        {
            T* tmp = stackalloc T[n];
            for (int i = 0; i < n; i++)
            { tmp[i] = arr[i]; }
            return tmp;
        }

        public unsafe static ArrayList sequenceRange<T>(T* arr, int n) where T : unmanaged
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < n; i++)
            { res.Add(arr[i]); }
            return res;
        }

        public static int sequenceCompare(ArrayList sq1, ArrayList sq2)
        {
            int res = 0;
            for (int i = 0; i < sq1.Count && i < sq2.Count; i++)
            {
                object elem1 = sq1[i];
                if (((IComparable)elem1).CompareTo(sq2[i]) < 0)
                { return -1; }
                else if (((IComparable)elem1).CompareTo(sq2[i]) > 0)
                { return 1; }
            }

            if (sq1.Count > sq2.Count)
            { return 1; }
            if (sq2.Count > sq1.Count)
            { return -1; }
            return res;
        }



        public static ArrayList union(ArrayList a, ArrayList b)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count; i++)
            { if (a[i] == null || res.Contains(a[i])) { } else { res.Add(a[i]); } }
            for (int j = 0; j < b.Count; j++)
            { if (b[j] == null || res.Contains(b[j])) { } else { res.Add(b[j]); } }
            return res;
        }


        public static ArrayList subtract(ArrayList a, ArrayList b)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i] == null || b.Contains(a[i])) { }
                else { res.Add(a[i]); }
            }
            return res;
        }

        public static ArrayList subtract(ArrayList a, object b)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count; i++)
            {
                if (a[i] == null || b == a[i]) { }
                else { res.Add(a[i]); }
            }
            return res;
        }

        public static string subtract(string a, string b)
        {
            string res = "";
            for (int i = 0; i < a.Length; i++)
            { if (b.IndexOf(a[i]) < 0) { res = res + a[i]; } }
            return res;
        }



        public static ArrayList intersection(ArrayList a, ArrayList b)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count; i++)
            { if (a[i] != null && b.Contains(a[i])) { res.Add(a[i]); } }
            return res;
        }



        public static ArrayList symmetricDifference(ArrayList a, ArrayList b)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count; i++)
            {
                object _a = a[i];
                if (b.Contains(_a) || res.Contains(_a)) { }
                else { res.Add(_a); }
            }
            for (int j = 0; j < b.Count; j++)
            {
                object _b = b[j];
                if (a.Contains(_b) || res.Contains(_b)) { }
                else { res.Add(_b); }
            }
            return res;
        }



        public static bool isUnique(ArrayList evals)
        {
            ArrayList vals = new ArrayList();
            for (int i = 0; i < evals.Count; i++)
            {
                object ob = evals[i];
                if (vals.Contains(ob)) { return false; }
                vals.Add(ob);
            }
            return true;
        }


        public static long gcd(long xx, long yy)
        {
            long x = Math.Abs(xx);
            long y = Math.Abs(yy);
            while (x != 0 && y != 0)
            {
                long z = y;
                y = x % y;
                x = z;
            }
            if (y == 0)
            { return x; }
            if (x == 0)
            { return y; }
            return 0;
        }

        public static bool toBoolean(String sx)
        {
            if ("true".Equals(sx) || "True".Equals(sx))
            { return true; }
            return false;
        }

        public static int toInteger(String sx)
        {
            if (sx.StartsWith("0x"))
            { return Convert.ToInt32(sx, 16); }
            if (sx.StartsWith("0b"))
            { return Convert.ToInt32(sx, 2); }
            if (sx.StartsWith("0") && sx.Length > 1)
            { return Convert.ToInt32(sx, 8); }
            return int.Parse(sx);
        }

        public static long toLong(String sx)
        {
            if (sx.StartsWith("0x"))
            { return Convert.ToInt64(sx, 16); }
            if (sx.StartsWith("0b"))
            { return Convert.ToInt64(sx, 2); }
            if (sx.StartsWith("0") && sx.Length > 1)
            { return Convert.ToInt64(sx, 8); }
            return long.Parse(sx);
        }

        public static int char2byte(string qf)
        {
            if (qf.Length < 1) { return -1; }
            return Char.ConvertToUtf32(qf, 0);
        }

        public static string byte2char(int qf)
        {
            if (qf < 0) { return ""; }
            return Char.ConvertFromUtf32(qf);
        }



        public static int sumint(ArrayList a)
        {
            int sum = 0;
            for (int i = 0; i < a.Count; i++)
            {
                int x = (int)a[i];
                sum += x;
            }
            return sum;
        }

        public static double sumdouble(ArrayList a)
        {
            double sum = 0.0;
            for (int i = 0; i < a.Count; i++)
            {
                double x = (double)a[i];
                sum += x;
            }
            return sum;
        }

        public static long sumlong(ArrayList a)
        {
            long sum = 0;
            for (int i = 0; i < a.Count; i++)
            {
                long x = (long)a[i];
                sum += x;
            }
            return sum;
        }

        public static string sumString(ArrayList a)
        {
            string sum = "";
            for (int i = 0; i < a.Count; i++)
            {
                object x = a[i];
                sum = sum + x;
            }
            return sum;
        }



        public static int prdint(ArrayList a)
        {
            int _prd = 1;
            for (int i = 0; i < a.Count; i++)
            {
                int x = (int)a[i];
                _prd *= x;
            }
            return _prd;
        }

        public static double prddouble(ArrayList a)
        {
            double _prd = 1;
            for (int i = 0; i < a.Count; i++)
            {
                double x = (double)a[i];
                _prd *= x;
            }
            return _prd;
        }

        public static long prdlong(ArrayList a)
        {
            long _prd = 1;
            for (int i = 0; i < a.Count; i++)
            {
                long x = (long)a[i];
                _prd *= x;
            }
            return _prd;
        }



        public static ArrayList concatenate(ArrayList a, ArrayList b)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            res.AddRange(b);
            return res;
        }
        public static ArrayList prepend(ArrayList a, object x)
        {
            ArrayList res = new ArrayList();
            res.Add(x);
            res.AddRange(a);
            return res;
        }

        public static ArrayList append(ArrayList a, object x)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            res.Add(x);
            return res;
        }





        public static ArrayList asSet(ArrayList a)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count; i++)
            {
                object obj = a[i];
                if (res.Contains(obj)) { }
                else { res.Add(obj); }
            }
            return res;
        }

        public static ArrayList asOrderedSet(ArrayList a)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count; i++)
            {
                object obj = a[i];
                if (res.Contains(obj)) { }
                else { res.Add(obj); }
            }
            return res;
        }

        public static T[] asReference<T>(ArrayList sq, T[] r)
        {
            for (int i = 0; i < sq.Count && i < r.Length; i++)
            { r[i] = (T)sq[i]; }
            return r;
        }

        public static ArrayList asSequence<T>(T[] r)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < r.Length; i++)
            { res.Add(r[i]); }
            return res;
        }



        public static ArrayList reverse(ArrayList a)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            res.Reverse();
            return res;
        }

        public static string reverse(string a)
        {
            string res = "";
            for (int i = a.Length - 1; i >= 0; i--)
            { res = res + a[i]; }
            return res;
        }



        public static ArrayList front(ArrayList a)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < a.Count - 1; i++)
            { res.Add(a[i]); }
            return res;
        }


        public static ArrayList tail(ArrayList a)
        {
            ArrayList res = new ArrayList();
            for (int i = 1; i < a.Count; i++)
            { res.Add(a[i]); }
            return res;
        }


        public static ArrayList sort(ArrayList a)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            res.Sort();
            return res;
        }



        public static ArrayList sortedBy(ArrayList a, ArrayList f)
        {
            int i = a.Count - 1;
            Hashtable f_map = new Hashtable();
            for (int j = 0; j < a.Count; j++)
            { f_map[a[j]] = f[j]; }
            return mergeSort(a, f_map, 0, i);
        }

        static ArrayList mergeSort(ArrayList a, Hashtable f, int ind1, int ind2)
        {
            ArrayList res = new ArrayList();
            if (ind1 > ind2)
            { return res; }
            if (ind1 == ind2)
            {
                res.Add(a[ind1]);
                return res;
            }
            if (ind2 == ind1 + 1)
            {
                IComparable e1 = (IComparable)f[a[ind1]];
                IComparable e2 = (IComparable)f[a[ind2]];
                if (e1.CompareTo(e2) < 0) // e1 < e2
                { res.Add(a[ind1]); res.Add(a[ind2]); return res; }
                else
                { res.Add(a[ind2]); res.Add(a[ind1]); return res; }
            }
            int mid = (ind1 + ind2) / 2;
            ArrayList a1;
            ArrayList a2;
            if (mid == ind1)
            {
                a1 = new ArrayList();
                a1.Add(a[ind1]);
                a2 = mergeSort(a, f, mid + 1, ind2);
            }
            else
            {
                a1 = mergeSort(a, f, ind1, mid - 1);
                a2 = mergeSort(a, f, mid, ind2);
            }
            int i = 0;
            int j = 0;
            while (i < a1.Count && j < a2.Count)
            {
                IComparable e1 = (IComparable)f[a1[i]];
                IComparable e2 = (IComparable)f[a2[j]];
                if (e1.CompareTo(e2) < 0) // e1 < e2
                {
                    res.Add(a1[i]);
                    i++; // get next e1
                }
                else
                {
                    res.Add(a2[j]);
                    j++;
                }
            }
            if (i == a1.Count)
            {
                for (int k = j; k < a2.Count; k++)
                { res.Add(a2[k]); }
            }
            else
            {
                for (int k = i; k < a1.Count; k++)
                { res.Add(a1[k]); }
            }
            return res;
        }


        public static ArrayList integerSubrange(int i, int j)
        {
            ArrayList tmp = new ArrayList();
            for (int k = i; k <= j; k++)
            { tmp.Add(k); }
            return tmp;
        }

        public static string subrange(string s, int i, int j)
        {
            if (i < 1)
            { i = 1; }
            if (j > s.Length)
            { j = s.Length; }
            if (i > s.Length || i > j)
            { return ""; }
            return s.Substring(i - 1, j - i + 1);
        }

        public static ArrayList subrange(ArrayList l, int i, int j)
        {
            ArrayList tmp = new ArrayList();
            if (i < 1) { i = 1; }
            for (int k = i - 1; k < j; k++)
            { tmp.Add(l[k]); }
            return tmp;
        }

        public static int indexOfSubList(ArrayList a, ArrayList b)
        { /* Index of a subsequence a of sequence b in b */
            if (a.Count == 0 || b.Count == 0)
            { return 0; }

            int i = 0;
            while (i < b.Count && b[i] != a[0])
            { i++; }

            if (i >= b.Count)
            { return 0; }

            int j = 0;
            while (j < a.Count && i + j < b.Count && b[i + j] == a[j])
            { j++; }

            if (j >= a.Count)
            { return i + 1; }

            ArrayList subr = subrange(b, i + 2, b.Count);
            int res1 = indexOfSubList(a, subr);
            if (res1 == 0)
            { return 0; }
            return res1 + i + 1;
        }

        public static int lastIndexOfSubList(ArrayList a, ArrayList b)
        {
            int res = 0;
            if (a.Count == 0 || b.Count == 0)
            { return res; }

            ArrayList arev = reverse(a);
            ArrayList brev = reverse(b);
            int i = indexOfSubList(arev, brev);
            if (i == 0)
            { return res; }
            res = b.Count - i - a.Count + 2;
            return res;
        }



        public static int count(ArrayList l, object obj)
        {
            int res = 0;
            for (int _i = 0; _i < l.Count; _i++)
            {
                if (obj == l[_i]) { res++; }
                else if (obj != null && obj.Equals(l[_i])) { res++; }
            }
            return res;
        }

        public static int count(string s, string x)
        {
            int res = 0;
            if ("".Equals(s)) { return res; }
            int ind = s.IndexOf(x);
            if (ind == -1) { return res; }
            string ss = s.Substring(ind + 1, s.Length - ind - 1);
            res++;
            while (ind >= 0)
            {
                ind = ss.IndexOf(x);
                if (ind == -1 || ss.Equals("")) { return res; }
                res++;
                ss = ss.Substring(ind + 1, ss.Length - ind - 1);
            }
            return res;
        }



        public static ArrayList characters(string str)
        {
            ArrayList _res = new ArrayList();
            for (int i = 0; i < str.Length; i++)
            { _res.Add("" + str[i]); }
            return _res;
        }



        public static object any(ArrayList v)
        {
            if (v.Count == 0) { return null; }
            return v[0];
        }


        public static object first(ArrayList v)
        {
            if (v.Count == 0) { return null; }
            return v[0];
        }


        public static object last(ArrayList v)
        {
            if (v.Count == 0) { return null; }
            return v[v.Count - 1];
        }



        public static ArrayList subcollections(ArrayList v)
        {
            ArrayList res = new ArrayList();
            if (v.Count == 0)
            {
                res.Add(new ArrayList());
                return res;
            }
            if (v.Count == 1)
            {
                res.Add(new ArrayList());
                res.Add(v);
                return res;
            }
            ArrayList s = new ArrayList();
            object x = v[0];
            s.AddRange(v);
            s.RemoveAt(0);
            ArrayList scs = subcollections(s);
            res.AddRange(scs);
            for (int i = 0; i < scs.Count; i++)
            {
                ArrayList sc = (ArrayList)scs[i];
                ArrayList scc = new ArrayList();
                scc.Add(x);
                scc.AddRange(sc);
                res.Add(scc);
            }
            return res;
        }


        public static ArrayList maximalElements(ArrayList s, ArrayList v)
        {
            ArrayList res = new ArrayList();
            if (s.Count == 0) { return res; }
            IComparable largest = (IComparable)v[0];
            res.Add(s[0]);

            for (int i = 1; i < s.Count; i++)
            {
                IComparable next = (IComparable)v[i];
                if (largest.CompareTo(next) < 0)
                {
                    largest = next;
                    res.Clear();
                    res.Add(s[i]);
                }
                else if (largest.CompareTo(next) == 0)
                { res.Add(s[i]); }
            }
            return res;
        }

        public static ArrayList minimalElements(ArrayList s, ArrayList v)
        {
            ArrayList res = new ArrayList();
            if (s.Count == 0) { return res; }
            IComparable smallest = (IComparable)v[0];
            res.Add(s[0]);

            for (int i = 1; i < s.Count; i++)
            {
                IComparable next = (IComparable)v[i];
                if (next.CompareTo(smallest) < 0)
                {
                    smallest = next;
                    res.Clear();
                    res.Add(s[i]);
                }
                else if (smallest.CompareTo(next) == 0)
                { res.Add(s[i]); }
            }
            return res;
        }


        public static ArrayList intersectAll(ArrayList se)
        {
            ArrayList res = new ArrayList();
            if (se.Count == 0) { return res; }
            res.AddRange((ArrayList)se[0]);
            for (int i = 1; i < se.Count; i++)
            { res = SystemTypes.intersection(res, (ArrayList)se[i]); }
            return res;
        }



        public static ArrayList unionAll(ArrayList se)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < se.Count; i++)
            {
                ArrayList b = (ArrayList)se[i];
                for (int j = 0; j < b.Count; j++)
                { if (b[j] == null || res.Contains(b[j])) { } else { res.Add(b[j]); } }
            }
            return res;
        }



        public static ArrayList insertAt(ArrayList l, int ind, object ob)
        {
            ArrayList res = new ArrayList();
            for (int i = 0; i < ind - 1 && i < l.Count; i++)
            { res.Add(l[i]); }
            if (ind <= l.Count + 1) { res.Add(ob); }
            for (int i = ind - 1; i < l.Count; i++)
            { res.Add(l[i]); }
            return res;
        }
        public static string insertAt(string l, int ind, object ob)
        {
            string res = "";
            for (int i = 0; i < ind - 1 && i < l.Length; i++)
            { res = res + l[i]; }
            if (ind <= l.Length + 1) { res = res + ob; }
            for (int i = ind - 1; i < l.Length; i++)
            { res = res + l[i]; }
            return res;
        }


        public static ArrayList removeFirst(ArrayList a, object x)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            res.Remove(x);
            return res;
        }

        public static ArrayList removeAt(ArrayList a, int i)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            if (i <= res.Count && i >= 1)
            { res.RemoveAt(i - 1); }
            return res;
        }

        public static string removeAtString(string a, int i)
        {
            string res = "";
            for (int x = 0; x < i - 1 && x < a.Length; x++)
            { res = res + a[x]; }
            for (int x = i; x >= 0 && x < a.Length; x++)
            { res = res + a[x]; }
            return res;
        }

        public static ArrayList setAt(ArrayList a, int i, object x)
        {
            ArrayList res = new ArrayList();
            res.AddRange(a);
            if (i <= res.Count && i >= 1)
            { res[i - 1] = x; }
            return res;
        }

        public static string setAt(string a, int i, string x)
        {
            string res = "";
            for (int j = 0; j < i - 1 && j < a.Length; j++)
            { res = res + a[j]; }
            if (i <= a.Length && i >= 1)
            { res = res + x; }
            for (int j = i; j >= 0 && j < a.Length; j++)
            { res = res + a[j]; }
            return res;
        }



        public static bool isInteger(string str)
        {
            try { int.Parse(str); return true; }
            catch (Exception _e) { return false; }
        }


        public static bool isReal(string str)
        {
            try
            {
                double d = double.Parse(str);
                if (Double.IsNaN(d)) { return false; }
                return true;
            }
            catch (Exception __e) { return false; }
        }


        public static bool isLong(string str)
        {
            try { long.Parse(str); return true; }
            catch (Exception _e) { return false; }
        }


        public static string before(string s, string sep)
        {
            if (sep.Length == 0) { return s; }
            int ind = s.IndexOf(sep);
            if (ind < 0) { return s; }
            return s.Substring(0, ind);
        }


        public static string after(string s, string sep)
        {
            int ind = s.IndexOf(sep);
            int seplength = sep.Length;
            if (ind < 0) { return ""; }
            if (seplength == 0) { return ""; }
            return s.Substring(ind + seplength, s.Length - (ind + seplength));
        }


        public static bool hasMatch(string s, string patt)
        {
            Regex r = new Regex(patt);
            return r.IsMatch(s);
        }


        public static bool isMatch(string s, string patt)
        {
            Regex r = new Regex(patt);
            Match m = r.Match(s);
            return (m + "").Equals(s);
        }


        public static ArrayList allMatches(string s, string patt)
        {
            Regex r = new Regex(patt);
            MatchCollection col = r.Matches(s);
            ArrayList res = new ArrayList();
            foreach (Match mm in col)
            { res.Add(mm.Value + ""); }
            return res;
        }


        public static string replace(string str, string delim, string rep)
        {
            String result = "";
            String s = str + "";
            int i = (s.IndexOf(delim) + 1);
            if (i == 0)
            { return s; }

            int sublength = delim.Length;
            if (sublength == 0)
            { return s; }

            while (i > 0)
            {
                result = result + SystemTypes.subrange(s, 1, i - 1) + rep;
                s = SystemTypes.subrange(s, i + delim.Length, s.Length);
                i = (s.IndexOf(delim) + 1);
            }
            result = result + s;
            return result;
        }


        public static string replaceAll(string s, string patt, string rep)
        {
            Regex r = new Regex(patt);
            return "" + r.Replace(s, rep);
        }


        public static string replaceFirstMatch(string s, string patt, string rep)
        {
            Regex r = new Regex(patt);
            return "" + r.Replace(s, rep, 1);
        }


        public static string firstMatch(string s, string patt)
        {
            Regex r = new Regex(patt);
            Match m = r.Match(s);
            if (m.Success)
            { return m.Value + ""; }
            return null;
        }


        public static ArrayList split(string s, string patt)
        {
            Regex r = new Regex(patt);
            ArrayList res = new ArrayList();
            string[] wds = r.Split(s);
            for (int x = 0; x < wds.Length; x++)
            {
                if (wds[x].Length > 0)
                { res.Add(wds[x]); }
            }
            return res;
        }


        public static bool includesAllMap(Hashtable sup, Hashtable sub)
        {
            foreach (DictionaryEntry pair in sub)
            {
                if (sup.ContainsKey(pair.Key))
                {
                    if (sup[pair.Key].Equals(pair.Value)) { }
                    else
                    { return false; }
                }
                else
                { return false; }
            }
            return true;
        }


        public static bool excludesAllMap(Hashtable sup, Hashtable sub)
        {
            foreach (DictionaryEntry pair in sub)
            {
                if (sup.ContainsKey(pair.Key))
                {
                    if (pair.Value.Equals(sup[pair.Key]))
                    { return false; }
                }
            }
            return true;
        }


        public static Hashtable includingMap(Hashtable m, object src, object trg)
        {
            Hashtable copy = new Hashtable(m);
            copy.Add(src, trg);
            return copy;
        }


        public static Hashtable excludeAllMap(Hashtable m1, Hashtable m2)
        { // m1 - m2 
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry x in m1)
            {
                object key = x.Key;
                if (m2.ContainsKey(key)) { }
                else
                { res[key] = m1[key]; }
            }
            return res;
        }


        public static Hashtable excludingMapKey(Hashtable m, object k)
        { // m - { k |-> m(k) }  
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry pair in m)
            {
                if (pair.Key.Equals(k)) { }
                else
                { res.Add(pair.Key, pair.Value); }
            }
            return res;
        }


        public static Hashtable excludingMapValue(Hashtable m, object v)
        { // m - { k |-> v }    
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry pair in m)
            {
                if (pair.Value.Equals(v)) { }
                else
                { res.Add(pair.Key, pair.Value); }
            }
            return res;
        }


        public static Hashtable unionMap(Hashtable m1, Hashtable m2)
        { /* Overrides m1 by m2 if they have pairs in common */
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry pair in m2)
            { res.Add(pair.Key, pair.Value); }
            foreach (DictionaryEntry pair in m1)
            {
                if (res.ContainsKey(pair.Key)) { }
                else { res.Add(pair.Key, pair.Value); }
            }
            return res;
        }


        public static Hashtable intersectionMap(Hashtable m1, Hashtable m2)
        {
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry pair in m1)
            {
                object key = pair.Key;
                if (m2.ContainsKey(key) && pair.Value != null && pair.Value.Equals(m2[key]))
                { res.Add(key, pair.Value); }
            }
            return res;
        }

        public static Hashtable restrictMap(Hashtable m1, ArrayList ks)
        {
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry pair in m1)
            {
                object key = pair.Key;
                if (ks.Contains(key))
                { res.Add(key, pair.Value); }
            }
            return res;
        }

        public static Hashtable antirestrictMap(Hashtable m1, ArrayList ks)
        {
            Hashtable res = new Hashtable();
            foreach (DictionaryEntry pair in m1)
            {
                object key = pair.Key;
                if (ks.Contains(key)) { }
                else
                { res.Add(key, pair.Value); }
            }
            return res;
        }

        public static ArrayList mapKeys(Hashtable m)
        {
            ArrayList res = new ArrayList();
            res.AddRange(m.Keys);
            return res;
        }

        public static ArrayList mapValues(Hashtable m)
        {
            ArrayList res = new ArrayList();
            res.AddRange(m.Values);
            return res;
        }


    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
