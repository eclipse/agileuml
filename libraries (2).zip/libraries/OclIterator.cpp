  template<class T>
  bool OclIterator<T>::hasNext()
  { bool result = false;
    if (position >= 0 && position < elements->size()) 
    { result = true; }
    else 
    { result = false; } 
    return result;
  }

  template<class T>
  bool OclIterator<T>::hasPrevious()
  { bool result = false;
    if (position > 1 && position <= elements->size() + 1) 
    { result = true; }
    else 
    { result = false; } 
    return result;
  }

  template<class T>
  bool OclIterator<T>::isAfterLast()
  { bool result = false;
    if (position > elements->size()) 
    { result = true; }
    else 
    { result = false; } 
    return result;
  }

  template<class T>
  bool OclIterator<T>::isBeforeFirst()
  { bool result = false;
    if (position < 1) 
    { result = true; }
    else 
    { result = false; } 
    return result;
  }

  template<class T>
  int OclIterator<T>::nextIndex()
  { int result = 0;
    result = position + 1; 
    return result;
  }

  template<class T>
  int OclIterator<T>::previousIndex()
  { int result = 0;
    result = position - 1; 
    return result;
  }

  template<class T>
  void OclIterator<T>::moveForward()
  { int pre_position0 = position;
  //  if (position + 1 > elements->size())) { return; } 
    this->setPosition(pre_position0 + 1);
  }

  template<class T>
  void OclIterator<T>::moveBackward()
  { int pre_position1 = position;
  //  if (position <= 1)) { return; } 
    this->setPosition(pre_position1 - 1);
  }

  template<class T>
  void OclIterator<T>::moveTo(int i)
  { //  if ((!(0 <= i) || i > elements->size() + 1))) { return; } 
    this->setPosition(i);
  }

  template<class T>
  void OclIterator<T>::movePosition(int i)
  { int pos = this->getPosition(); 
    this->setPosition(i+pos);
  }

  template<class T>
  void OclIterator<T>::moveToStart()
  { this->setPosition(0); }

  template<class T>
  void OclIterator<T>::moveToEnd()
  { this->setPosition(this->elements->size() + 1); }

  template<class T>
  void OclIterator<T>::moveToFirst()
  { this->setPosition(1); }

  template<class T>
  void OclIterator<T>::moveToLast()
  { this->setPosition(this->elements->size()); }

   template<class T>
   OclIterator<T>* OclIterator<T>::newOclIterator_Sequence(vector<T>* sq)
   { OclIterator<T>* result = NULL;
     OclIterator<T>* ot = new OclIterator<T>();
     ot->setelements(sq);
     ot->setPosition(0);
     ot->markedPosition = 0; 
     result = ot; 
     return result;
   }

  template<class T>
  OclIterator<T>* OclIterator<T>::newOclIterator_Set(std::set<T>* st)
  { OclIterator<T>* ot = new OclIterator<T>();
    vector<T>* elems = UmlRsdsLib<T>::concatenate((new vector<T>()), st);
	
    ot->elements = UmlRsdsLib<T>::sort(elems); 
    ot->setPosition(0);
    ot->markedPosition = 0; 
    return ot;
  } // sort the elements, to account for sorted sets

  template<class T>
  OclIterator<T>* OclIterator<T>::newOclIterator_String(string st)
  { OclIterator<string>* res = new OclIterator<string>(); 
    res->elements = UmlRsdsLib<string>::split(st, "[ \n\t\r]"); 
    res->position = 0; 
    res->markedPosition = 0; 
    return res;
  }

  template<class T>
  OclIterator<T>* OclIterator<T>::newOclIterator_String_String(string st, string sep)
  { OclIterator<string>* res = new OclIterator<string>(); 
    res->elements = 
      UmlRsdsLib<string>::split(st, 
        string("[").append(sep).append(string("]"))); 
    res->position = 0; 
    res->markedPosition = 0; 
    return res;
  }

  template<class T>
  T OclIterator<T>::getCurrent()
  { T result;
    if (position < 1 || position > elements->size())
    { return result; } 
    result = ((T) elements->at(position - 1)); 
    return result;
  }

  template<class T>
  void OclIterator<T>::set(T x)
  { this->setelements(this->getPosition() - 1,x); }

  template<class T>
  void OclIterator<T>::insert(T x)
  { elements->insert(elements->begin() + (position - 1), x); }

  template<class T>
  void OclIterator<T>::remove()
  { elements->erase(elements->begin() + (position-1)); }

  template<class T>
  T OclIterator<T>::next()
  {  OclIterator<T>* ocliteratorx = this;
     ocliteratorx->moveForward();
     return ocliteratorx->getCurrent();
  }


  template<class T>
  T OclIterator<T>::previous()
  {  OclIterator<T>* ocliteratorx = this;
     ocliteratorx->moveBackward();
     return ocliteratorx->getCurrent();
  }

  template<class T>
  T OclIterator<T>::at(int i)
  { return elements->at(i-1); }

  template<class T>
  int OclIterator<T>::length()
  { return elements->size(); }

  template<class T>
  void OclIterator<T>::close()
  { position = 0;
    markedPosition = 0;
    elements = (new vector<T>());
  }


