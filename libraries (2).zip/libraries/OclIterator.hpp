template<class T>
class OclIterator
{ 
 private:
  int position;
  int markedPosition;
  vector<T>* elements;

  public:
 OclIterator() 
  {
    position = 0;
    markedPosition = 0;
    elements = (new vector<T>());
  }

 void setPosition(int position_x) 
 { position = position_x; }

 void markPosition() 
 { markedPosition = position; }

 void moveToMarkedPosition() 
 { position = markedPosition; }

 void setelements(vector<T>* elements_x) 
 { elements = elements_x; }

  void setelements(int _ind, void* elements_x) 
  { (*elements)[_ind] = elements_x; }

  void addelements(T elements_x)
  { elements->push_back(elements_x); }

  int getPosition() 
  { return position; }

  vector<T>* getelements() 
  { return elements; }

  bool hasNext();

  bool hasPrevious();

  bool isAfterLast();

  bool isBeforeFirst();

  int nextIndex();

  int previousIndex();

  void moveForward();

  void moveBackward();

  void moveTo(int i);

  void moveToStart();

  void moveToEnd();

  void moveToFirst();

  void moveToLast();

  void movePosition(int i);

  static OclIterator* newOclIterator_Sequence(vector<T>* sq);

  static OclIterator* newOclIterator_Set(set<T>* st);

  static OclIterator* newOclIterator_String(string st);

  static OclIterator* newOclIterator_String_String(string st, string sep);

  T getCurrent();

  void set(T x);

  void insert(T x);

  void remove();

  T next();

  T previous();

  T at(int i); 

  int length(); 

  void close(); 

  ~OclIterator() {
  }

};
