#include <stdlib.h>
#include <process.h>


/* C header for OclProcess library */

struct Runnable {
 void (*runMethod)(void*); 
}; 

struct Runnable* newRunnable(void (*f)(void*))
{ struct Runnable* res = (struct Runnable*) malloc(sizeof(struct Runnable));
  res->runMethod = f; 
  return res; 
}

struct OclProcess {
 int pid;
 int threadid;  
 char* name;
 void (*actualThread)(void*);
 void* executes; 
 unsigned char active;  
 long long period; 
 long long delay; 
 long long deadline; 
};

struct OclProcess* newOclProcess(void* obj, char* s)
{ struct OclProcess* res = (struct OclProcess*) malloc(sizeof(struct OclProcess));
  res->name = s; 
  res->executes = obj; /* could itself be an OclProcess */ 
  if (obj == NULL)
  { res->pid = system(s); 
    res->active = TRUE;
  }  /* Or: res->pid = spawnv(P_NOWAIT, s, NULL); */ 
  else 
  { res->actualThread = ((struct Runnable*) obj)->runMethod;
    res->active = FALSE;
  }
  res->deadline = 0LL; 
  res->delay = 0LL; 
  res->period = 0LL; 
  return res; 
}

void setDeadline_OclProcess(struct OclProcess* self, long long d)
{ self->deadline = d; } 

void setPeriod_OclProcess(struct OclProcess* self, long long p)
{ self->period = p; } 

void setDelay_OclProcess(struct OclProcess* self, long long d)
{ self->delay = d; } 


void sleep_OclProcess(long t)
{ sleep(t); }

char* getEnvironmentProperty_OclProcess(char* v)
{ return getenv(v); }

struct ocltnode* getEnvironmentProperties_OclProcess(void)
{ char* vars[] = 
    { "OS", "COMPUTERNAME", "PATH", "HOMEPATH", "NUMBER_OF_PROCESSORS",
      "PROCESSOR_ARCHITECTURE", "SYSTEMROOT", "USERNAME" }; 

  struct ocltnode* res = NULL;
  int i = 0; 
  for ( ; i < 8; i++)
  { char* val = getenv(vars[i]); 
    if (val != NULL)
    { res = insertIntoMap(res,vars[i],val); }
  }
  return res; 
} 

struct OclProcess* currentThread_OclProcess(void)
{ int p = _getpid(); 
  struct OclProcess* res = (struct OclProcess*) malloc(sizeof(struct OclProcess));
  res->name = "main thread";
  res->pid = p; 
  return res; 
} 

struct OclProcess** allActiveThreads_OclProcess(void)
{ struct OclProcess** res = (struct OclProcess**) calloc(2, sizeof(struct OclProcess*));
  res[0] = currentThread_OclProcess(); 
  res[1] = NULL; 
  return res;
} 

int activeCount_OclProcess(void)
{ return 1; }  

int getPriority_OclProcess(void)
{ return 5; }  

char* getName_OclProcess(struct OclProcess* self)
{ return self->name; } 

void setName_OclProcess(struct OclProcess* self, char* nme)
{ self->name = nme; } 

void run_OclProcess(struct OclProcess* self)
{ if (self->actualThread != NULL)
  { beginthread(self->actualThread, 0, NULL); 
    self->active = TRUE; 
  } 
}

void start_OclProcess(struct OclProcess* self)
{ if (self->actualThread != NULL)
  { /* wait until deadline + delay */ 
    /* if period > 0 repeat at period ms intervals */

    long long now = getTime(); 
    if (self->deadline > now)
    { sleep(self->deadline - now); } 
    if (self->delay > 0)
    { sleep(self->delay); } 
    if (self->period <= 0)
    { beginthread(self->actualThread, 0, NULL); 
      self->active = TRUE;
    } 
    else 
    { long long next = now + self->period; 
      while (TRUE)
      { beginthread(self->actualThread, 0, NULL); 
        self->active = TRUE;
        now = getTime();
        next += self->period;  
        if (next > now)
        { sleep(next - now); }
      } 
    } 
  } 
}

void exit_OclProcess(int n)
{ exit(n); } 

 
void interrupt_OclProcess(struct OclProcess* self)
{ self->active = FALSE; 
  /* endthread(); */ 
} 

void destroy_OclProcess(struct OclProcess* self)
{ self->active = FALSE; 
  /* endthread(); */  
} 

void join_OclProcess(struct OclProcess* self, double ms)
{ /* endthread(); */ } 

unsigned char isAlive_OclProcess(struct OclProcess* self)
{ return self->active; }  

unsigned char isDaemon_OclProcess(struct OclProcess* self)
{ return FALSE; }  
