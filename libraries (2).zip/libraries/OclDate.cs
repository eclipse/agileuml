    public class OclDate
    { long time;
        static long systemTime; 
        int year;
        int month;
        int day;
        int weekday;
        int hour;
        int minute;
        int second; 

        public static OclDate newOclDate()
        { DateTime dd = DateTime.Now;
          OclDate d = new OclDate();
          d.time = SystemTypes.getTime(dd);
          d.year = dd.Year;
          d.month = dd.Month;
          d.day = dd.Day;
          d.weekday = (int) dd.DayOfWeek;
          d.hour = dd.Hour;
          d.minute = dd.Minute;
          d.second = dd.Second;
          OclDate.systemTime = d.time; 
          return d; 
        }

        public static OclDate newOclDate_Time(long t)
        {
            DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(t).DateTime;
            OclDate d = new OclDate();
            d.time = t;
            d.year = dd.Year;
            d.month = dd.Month;
            d.day = dd.Day;
            d.weekday = (int)dd.DayOfWeek;
            d.hour = dd.Hour;
            d.minute = dd.Minute;
            d.second = dd.Second;

            return d;
        }

        public void setTime(long t)
        { DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(t).DateTime;
          time = t;
          year = dd.Year;
          month = dd.Month;
          day = dd.Day;
          weekday = (int)dd.DayOfWeek;
          hour = dd.Hour;
          minute = dd.Minute;
          second = dd.Second;
        }

        public long getTime()
        { return time; }

        public static long getSystemTime()
        {
            DateTime dd = DateTime.Now;
            OclDate.systemTime = SystemTypes.getTime(dd);
            return OclDate.systemTime;
        }


        public int getYear()
        { return year; }

        public int getMonth()
        { return month; }

        public int getDate()
        { return day; }

        public int getDay()
        { return weekday; }

        public int getHours()
        { return hour; }

        public int getHour()
        { return hour; }

        public int getMinutes()
        { return minute; }

        public int getMinute()
        { return minute; }

        public int getSeconds()
        { return second; }

        public int getSecond()
        { return second; }

        public bool dateBefore(OclDate d)
        {
            bool result = false;
            if (time < d.time)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }


        public bool dateAfter(OclDate d)
        {
            bool result = false;
            if (time > d.time)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public override string ToString()
        {
          DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(time).DateTime;    
          return dd.ToString();  
        }
    }
