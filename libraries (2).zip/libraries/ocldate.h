#include <time.h>


/* C header for OclDate library */


struct OclDate {
  long long time; 
  long long systemTime; 
  int year;
  int month;
  int day; 
  int weekday; 
  int hour; 
  int minute; 
  int second; 
};

struct OclDate* newOclDate(void)
{ struct OclDate* res = (struct OclDate*) malloc(sizeof(struct OclDate));
  time_t tp = time(NULL); 
  res->systemTime = (long long) tp*1000;
  res->time = res->systemTime; 
  struct tm* dd = localtime(&tp); 
  res->year = dd->tm_year;  
  res->month = dd->tm_mon;
  res->day = dd->tm_mday;  
  res->weekday = dd->tm_wday; 
  res->hour = dd->tm_hour;  
  res->minute = dd->tm_min;  
  res->second = dd->tm_sec;  
  
  return res; 
}


void setTime_OclDate(struct OclDate* self, long long t)
{ self->time = t;
  time_t secs = (time_t) (t/1000); 
  struct tm* dd = localtime(&secs); 
  self->year = dd->tm_year;  
  self->month = dd->tm_mon;
  self->day = dd->tm_mday;  
  self->weekday = dd->tm_wday; 
  self->hour = dd->tm_hour;  
  self->minute = dd->tm_min;  
  self->second = dd->tm_sec;  
} 

char* toString_OclDate(struct OclDate* self)
{ const time_t secs = (const time_t) (self->time/1000); 
  return ctime(&secs); 
} 

long long getTime_OclDate(struct OclDate* self)
{ return self->time; } 

long long getSystemTime_OclDate(void)
{ return (long long) time(NULL)*1000; } 

unsigned char dateBefore_OclDate(struct OclDate* self, struct OclDate* d)
{ if (self->time < d->time)
  { return TRUE; }
  return FALSE; 
}

unsigned char dateAfter_OclDate(struct OclDate* self, struct OclDate* d)
{ if (self->time > d->time)
  { return TRUE; }
  return FALSE; 
} 

int getYear_OclDate(struct OclDate* self)
{ return self->year; }

int getMonth_OclDate(struct OclDate* self)
{ return self->month; }

int getDate_OclDate(struct OclDate* self)
{ return self->day; }

int getDay_OclDate(struct OclDate* self)
{ return self->weekday; }

int getHour_OclDate(struct OclDate* self)
{ return self->hour; }

int getMinute_OclDate(struct OclDate* self)
{ return self->minute; }

int getMinutes_OclDate(struct OclDate* self)
{ return self->minute; }

int getSecond_OclDate(struct OclDate* self)
{ return self->second; }

int getSeconds_OclDate(struct OclDate* self)
{ return self->second; }


