import Foundation
import Darwin

class OclIterator
{ static var instance : OclIterator? = nil

  init() { }

  init(copyFrom: OclIterator) {
    self.position = copyFrom.position
    self.markedPosition = copyFrom.markedPosition
    self.elements = Ocl.copySequence(s: copyFrom.elements)
  }

  func copy() -> OclIterator
  { let res : OclIterator = OclIterator(copyFrom: self)
    OclIterator_allInstances.append(res)
    return res
  }

  static func defaultInstance() -> OclIterator
  { if (instance == nil)
    { instance = createOclIterator() }
    return instance!
  }

  var position : Int = 0
  var markedPosition : Int = 0
  var elements : [Any] = []

  func hasNext() -> Bool
  {
    var result : Bool = false
    if position >= 0 && position < elements.count
    {
      result = true
    }
    else {
      result = false
    }
    return result

  }


  func hasPrevious() -> Bool
  {
    var result : Bool = false
    if position > 1 && position <= elements.count + 1
    {
      result = true
    }
    else {
      result = false
    }
    return result

  }

  func isAfterLast() -> Bool
  {
    if position > elements.count
    {
      return true
    }
    return false
  }

  func isBeforeFirst() -> Bool
  {
    if position <= 0
    {
      return true
    }
    return false
  }

  func nextIndex() -> Int
  {
    var result : Int = 0
    result = position + 1
    return result
  }


  func previousIndex() -> Int
  {
    var result : Int = 0
    result = position - 1
    return result
  }


  func moveForward() -> Void
  {
    position = position + 1
  }


  func moveBackward() -> Void
  {
    position = position - 1
  }


  func moveTo(i : Int) -> Void
  {
    position = i
  }

  func moveToFirst()
  {
    position = 1
  }

  func moveToLast()
  {
    position = elements.count
  }
  
  func moveToStart()
  {
    position = 0
  }

  func moveToEnd()
  {
    position = elements.count + 1
  }
  
  func getPosition() -> Int
  { return position }
  
  func setPosition(i : Int)
  { position = i }
 
  func markPosition()
  { markedPosition = position }

  func moveToMarkedPosition()
  { position = markedPosition }
  
  func movePosition(i : Int)
  { position = position + i } 

  static func newOclIterator_Sequence(sq : [Any]) -> OclIterator
  {
    let ot : OclIterator = createOclIterator()
    ot.elements = sq
    ot.position = 0
    ot.markedPosition = 0
    return ot
  }


  static func newOclIterator_Set<T : Hashable>(st : Set<T>) -> OclIterator
  {
    let ot : OclIterator = createOclIterator()
    ot.elements = Ocl.toSequence(s: st)
    ot.position = 0
    ot.markedPosition = 0
    return ot
  }

  static func newOclIterator_String(ss : String) -> OclIterator
  { let ot : OclIterator = createOclIterator()
    ot.elements = Ocl.split(str: ss, pattern: "[ \n\t\r]+")
    ot.position = 0
    ot.markedPosition = 0
    return ot
  }


  static func newOclIterator_String_String(ss : String, seps : String) -> OclIterator
  { let ot : OclIterator = createOclIterator()
    ot.elements = Ocl.split(str: ss, pattern: "[" + seps + "]+")
    ot.position = 0
    ot.markedPosition = 0
    return ot
  }


  func getCurrent() -> Any
  {
    var result : Any? = nil
    result = elements[position - 1]
    return result!
  }


  func set(x : Any) -> Void
  {
    elements[position-1] = x
  }


  func insert(x : Any) -> Void
  { elements.insert(x, at: position-1) }


  func remove() -> Void
  { elements.remove(at: position) }


  func next() -> Any
  {
    moveForward()
    return getCurrent()
  }


  func previous() -> Any
  {
    moveBackward()
    return getCurrent()
  }

  func at(i : Int) -> Any
  {
    var result : Any? = nil
    result = elements[i - 1]
    return result!
  }

  func length() -> Int
  { return elements.count }


  func close()
  { elements = []
    position = 0
    markedPosition = 0
  } 
}

var OclIterator_allInstances : [OclIterator] = [OclIterator]()

func createOclIterator() -> OclIterator
{ let result : OclIterator = OclIterator()
  OclIterator_allInstances.append(result)
  return result
}

func killOclIterator(obj: OclIterator)
{ OclIterator_allInstances = OclIterator_allInstances.filter{ $0 !== obj } }


