import ocl
import math
import re
import copy

from mathlib import *
from oclfile import *
from ocltype import *
from ocldate import *
from oclprocess import *
from ocliterator import *
from ocldatasource import *
from enum import Enum

def free(x):
  del x


class SpreadsheetFont : 
  spreadsheetfont_instances = []
  spreadsheetfont_index = dict({})

  def __init__(self):
    self.Name = ""
    self.Size = 0
    self.Color = None
    self.Bold = False
    self.Italic = False
    SpreadsheetFont.spreadsheetfont_instances.append(self)



  def killSpreadsheetFont(spreadsheetfont_x) :
    spreadsheetfont_instances = ocl.excludingSet(spreadsheetfont_instances, spreadsheetfont_x)
    free(spreadsheetfont_x)

class SpreadsheetCell : 
  spreadsheetcell_instances = []
  spreadsheetcell_index = dict({})

  def __init__(self):
    self.Name = ""
    self.RowNumber = 0
    self.ColumnName = ""
    self.Value = None
    self.Font = None
    SpreadsheetCell.spreadsheetcell_instances.append(self)



  def newSpreadsheetCell(nme,val) :
    result = None
    c = createSpreadsheetCell()
    c.Name = nme
    c.RowNumber = ocl.toInteger(ocl.firstMatch(nme, "[0-9]+"))
    c.ColumnName = ocl.firstMatch(nme, "[A-Z]+")
    c.Value = val
    result = c
    return result

  def precedes(self, c) :
    result = False
    if self.ColumnName <= c.ColumnName and ((self.RowNumber < c.RowNumber) if (self.ColumnName == c.ColumnName) else (True)) :
      result = True
    return result

  def killSpreadsheetCell(spreadsheetcell_x) :
    spreadsheetcell_instances = ocl.excludingSet(spreadsheetcell_instances, spreadsheetcell_x)
    free(spreadsheetcell_x)

class SpreadsheetRange : 
  spreadsheetrange_instances = []
  spreadsheetrange_index = dict({})

  def __init__(self):
    self.Visible = False
    self.ColumnNames = []
    self.AllCells = []
    self.Range = dict({})
    SpreadsheetRange.spreadsheetrange_instances.append(self)



  def Activate(self) :
    self.Visible = True

  def getOneCell(self, s) :
    result = None
    result = ocl.any((self.Range)[s])
    return result

  def getCellRange(self, s) :
    result = []
    result = (self.Range)[s]
    return result

  def getRow(self, j) :
    result = []
    result = sorted([c for c in self.AllCells if c.RowNumber == j], key = lambda cx : cx.ColumnName)
    return result

  def getColumn(self, i) :
    result = []
    result = sorted([c for c in self.AllCells if c.ColumnName == (self.ColumnNames)[i - 1]], key = lambda cx : cx.RowNumber)
    return result

  def getCell(self, i) :
    result = None
    result = (self.AllCells)[i - 1]
    return result

  def getCell(self, i, j) :
    result = None
    result = ocl.any([c for c in self.AllCells if c.ColumnName == (self.ColumnNames)[j - 1] and c.RowNumber == i])
    return result

  def killSpreadsheetRange(spreadsheetrange_x) :
    spreadsheetrange_instances = ocl.excludingSet(spreadsheetrange_instances, spreadsheetrange_x)

  def killAbstractSpreadsheetRange(spreadsheetrange_x) :
    if spreadsheetrange_x in allInstances_Worksheet() :
      killWorksheet(spreadsheetrange_x)
    else :
      pass

class Worksheet(SpreadsheetRange) : 
  worksheet_instances = []
  worksheet_index = dict({})

  def __init__(self):
    self.Visible = False
    self.ColumnNames = []
    self.AllCells = []
    self.Range = dict({})
    Worksheet.worksheet_instances.append(self)



  def killWorksheet(worksheet_x) :
    worksheet_instances = ocl.excludingSet(worksheet_instances, worksheet_x)
    SpreadsheetRange.killSpreadsheetRange(super())
    SpreadsheetRange.killSpreadsheetRange(worksheet_x)
    free(worksheet_x)

  def Activate(self) :
    self.Visible = True

  def getOneCell(self, s) :
    result = None
    result = ocl.any((self.Range)[s])
    return result

  def getCellRange(self, s) :
    result = []
    result = (self.Range)[s]
    return result

  def getRow(self, j) :
    result = []
    result = sorted([c for c in self.AllCells if c.RowNumber == j], key = lambda cx : cx.ColumnName)
    return result

  def getColumn(self, i) :
    result = []
    result = sorted([c for c in self.AllCells if c.ColumnName == (self.ColumnNames)[i - 1]], key = lambda cx : cx.RowNumber)
    return result

  def getCell(self, i) :
    result = None
    result = (self.AllCells)[i - 1]
    return result

  def getCell(self, i, j) :
    result = None
    result = ocl.any([c for c in self.AllCells if c.ColumnName == (self.ColumnNames)[j - 1] and c.RowNumber == i])
    return result

  def killSpreadsheetRange(spreadsheetrange_x) :
    spreadsheetrange_instances = ocl.excludingSet(spreadsheetrange_instances, spreadsheetrange_x)

  def killAbstractSpreadsheetRange(spreadsheetrange_x) :
    if spreadsheetrange_x in allInstances_Worksheet() :
      killWorksheet(spreadsheetrange_x)
    else :
      pass

class Excel : 
  excel_instances = []
  excel_index = dict({})
  Worksheets = dict({})

  def __init__(self):
    Excel.excel_instances.append(self)



  def killExcel(excel_x) :
    excel_instances = ocl.excludingSet(excel_instances, excel_x)
    free(excel_x)


def createSpreadsheetFont():
  spreadsheetfont = SpreadsheetFont()
  return spreadsheetfont

def allInstances_SpreadsheetFont():
  return SpreadsheetFont.spreadsheetfont_instances


spreadsheetfont_OclType = createByPKOclType("SpreadsheetFont")
spreadsheetfont_OclType.instance = createSpreadsheetFont()
spreadsheetfont_OclType.actualMetatype = type(spreadsheetfont_OclType.instance)


def createSpreadsheetCell():
  spreadsheetcell = SpreadsheetCell()
  return spreadsheetcell

def allInstances_SpreadsheetCell():
  return SpreadsheetCell.spreadsheetcell_instances


spreadsheetcell_OclType = createByPKOclType("SpreadsheetCell")
spreadsheetcell_OclType.instance = createSpreadsheetCell()
spreadsheetcell_OclType.actualMetatype = type(spreadsheetcell_OclType.instance)


def createSpreadsheetRange():
  spreadsheetrange = SpreadsheetRange()
  return spreadsheetrange

def allInstances_SpreadsheetRange():
  return allInstances_Worksheet()

spreadsheetrange_OclType = createByPKOclType("SpreadsheetRange")
spreadsheetrange_OclType.instance = createSpreadsheetRange()
spreadsheetrange_OclType.actualMetatype = type(spreadsheetrange_OclType.instance)


def createWorksheet():
  worksheet = Worksheet()
  return worksheet

def allInstances_Worksheet():
  return Worksheet.worksheet_instances


worksheet_OclType = createByPKOclType("Worksheet")
worksheet_OclType.instance = createWorksheet()
worksheet_OclType.actualMetatype = type(worksheet_OclType.instance)


def createExcel():
  excel = Excel()
  return excel

def allInstances_Excel():
  return Excel.excel_instances


excel_OclType = createByPKOclType("Excel")
excel_OclType.instance = createExcel()
excel_OclType.actualMetatype = type(excel_OclType.instance)


# cell1 = SpreadsheetCell.newSpreadsheetCell("A1", 1.0)
# cell2 = SpreadsheetCell.newSpreadsheetCell("A2", 2.0)
# cell3 = SpreadsheetCell.newSpreadsheetCell("A2", 0.0000001)

# print(cell1.Name)
# print(cell1.RowNumber)
# print(cell1.ColumnName)
# print(cell1.Value)

# ws = createWorksheet()
# ws.AllCells = [cell1,cell2]
# ws.Range = dict({"A1" : cell1, "A2" : cell2, "A1:D10" : [cell1,cell2,cell3] })

# Excel.Worksheets = dict({"Sheet1" : ws})

