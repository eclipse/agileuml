import java.util.ArrayList; 

public class StringLib
{ public static String format(String s, ArrayList sq)
  { Object[] args = new Object[sq.size()]; 
    for (int i = 0; i < sq.size(); i++) 
    { args[i] = sq.get(i); }
    String formattedString = String.format(s,args);  
    return formattedString; 
  } 
} 
