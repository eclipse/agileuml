
map<string, OclFile*>* OclFile::oclfilenameindex = new map<string, OclFile*>();

OclFile* OclFile::newOclFile(string nme)
{
    OclFile* res = new OclFile(); 
    res->name = nme;
    (*oclfilenameindex)[nme] = res;
    res->readable = false; 
    res->writable = false; 
    res->position = 0;
    res->lastRead = "";  
    return res;
}

OclFile* OclFile::newOclFile_Write(OclFile* f)
{
    f->openWrite(); 
    return f;
}

OclFile* OclFile::newOclFile_Read(OclFile* f)
{
    f->openRead();
    return f;
}

OclFile* OclFile::newOclFile_WriteB(OclFile* f)
{
    f->openWriteB();
    return f;
}

OclFile* OclFile::newOclFile_ReadB(OclFile* f)
{
    f->openReadB();
    return f;
}

OclFile* OclFile::getOclFileByPK(string nme)
{
    OclFile* res = oclfilenameindex->at(nme);
    return res; 
}


OclFile* OclFile::getInputStream()
{
    return OclFile::newOclFile_Read(this);
}

OclFile* OclFile::getOutputStream()
{
    return OclFile::newOclFile_Write(this);
}

string OclFile::getName()
{
    return name; 
}

string OclFile::toString()
{
    return "(OclFile) " + name;
}

string OclFile::getPath()
{
    return name;
}

string OclFile::getInetAddress()
{
    return name; 
}

string OclFile::getLocalAddress()
{
    return name;
}

int OclFile::getPort()
{
    return port;
}

int OclFile::getLocalPort()
{
    return port;
}

void OclFile::setPort(int p)
{
    port = p; 
}

int OclFile::compareTo(OclFile* f)
{ if (name < f->name) { return -1; }
  else if (name > f->name) { return 1; }
  return 0; 
}

bool OclFile::canRead()
{
    return readable; 
}

bool OclFile::canWrite()
{
    return writable;
}

void OclFile::openWrite()
{
    outFileStream = ofstream(name);
    if (!outFileStream) 
    {
        writable = false; 
    }
    else
    {
       writable = true;
    }
}

void OclFile::openRead()
{
    inFileStream = ifstream(name);
    if (!inFileStream) 
    {
        readable = false; 
    }
    else
    {
        readable = true;
    }
}

void OclFile::openWriteB()
{
    outFileStream = ofstream(name, ios::binary);
    if (!outFileStream) 
    {
        writable = false; 
    }
    else
    {
        writable = true;
    }
}

void OclFile::openReadB()
{
    inFileStream = ifstream(name, ios::binary);
    if (!inFileStream) 
    { readable = false; }
    else
    {
        readable = true;
    }
}

void OclFile::closeFile()
{ if (readable)
  {
    inFileStream.close();
  }
  if (writable)
  {
    outFileStream.close();
  }
}

void OclFile::flush()
{
    if (writable)
    {
        outFileStream.flush();
    }
}

bool OclFile::isFile()
{
    struct stat stbuf;
    
    if (stat(name.c_str(), &stbuf) != 0)
    {
        return false;
    }

    if ((S_IFREG & stbuf.st_mode) > 0)
    {
        return true;
    }
    return false; 
}

bool OclFile::isDirectory()
{
    struct stat stbuf;

    if (stat(name.c_str(), &stbuf) != 0)
    {
        return false;
    }

    if ((S_IFREG & stbuf.st_mode) > 0)
    {
        return false;
    }
    else if ((S_IFDIR & stbuf.st_mode) > 0)
    {
        return true;
    }
    return false;
}

bool OclFile::exists()
{
    struct stat stbuf;

    if (stat(name.c_str(), &stbuf) != 0)
    {
        return false;
    }
    return true;
}

long OclFile::lastModified()
{
    struct stat stbuf;

    if (stat(name.c_str(), &stbuf) == 0)
    {
        return stbuf.st_mtime;
    }
    return 0;
}

bool OclFile::isHidden()
{ if (name.length() == 0)
  {
    return false;
  }
  if ('.' == name[0])
  {
      return true;
  }
  return false; 
}

bool OclFile::isAbsolute()
{
    if (name.length() == 0)
    {
        return false;
    }
    if ('\\' == name[0])
    {
        return true;
    }
    if (name.length() > 1 && ':' == name[1])
    {
        return true;
    }
    return false;
}

string OclFile::getParent()
{
    char* buff;
    buff = _getcwd(NULL, 0);
    if (buff == 0)
    {
        return string("");
    }
    return string(buff); 
}

OclFile* OclFile::getParentFile()
{
    char* buff;
    buff = _getcwd(NULL, 0);
    if (buff == 0)
    {
        return NULL;
    }
    OclFile* res = OclFile::newOclFile(string(buff));
    return res; 
}

long OclFile::length()
{
    struct stat stbuf;

    if (stat(name.c_str(), &stbuf) != 0)
    {
        return 0;
    }

    return stbuf.st_size; 
}

bool OclFile::deleteFile()
{
    if (remove(name.c_str()) != 0)
    {
        return false;
    }
    else
    {
        return true;
    }
}

vector<string>* OclFile::list()
{
    vector<string>* res = new vector<string>();

    char* buff;
    buff = _getcwd(NULL, 0);
    if (buff == 0)
    {
        return res;
    }
    
    char* completePath = concatenateStrings(buff, (char*) "\\*.*");
    WIN32_FIND_DATAA data;
    HANDLE h;
    
    h = FindFirstFileA(completePath, &data);
    
    if (h != INVALID_HANDLE_VALUE)
    {
       
        res->push_back(string(data.cFileName));
        while (FindNextFileA(h, &data))
        {
            res->push_back(string(data.cFileName));
        }
        FindClose(h);
    }
    return res;
} 

vector<OclFile*>* OclFile::listFiles()
{
    vector<OclFile*>* res = new vector<OclFile*>(); 
    vector<string>* fnames = list(); 
    for (int i = 0; i < fnames->size(); i++)
    {
        string fname = fnames->at(i); 
        OclFile* f = OclFile::newOclFile(fname); 
        res->push_back(f); 
    }
    return res; 
}

void OclFile::writeln(string s)
{
    if ("System.out" == name)
    {
        cout << s << endl;
    }
    else if ("System.err" == name)
    {
        cerr << s << endl;
    }
    else if (writable)
    {
        outFileStream << s << endl;
    }
}

void OclFile::println(string s)
{
    OclFile::writeln(s);
}

void OclFile::write(string s)
{
    if ("System.out" == name)
    {
        cout << s;
    }
    else if ("System.err" == name)
    {
        cerr << s;
    }
    else if (writable)
    {
        outFileStream << s;
    }
}

void OclFile::print(string s)
{
    OclFile::write(s);
} 

string OclFile::readLine()
{ string res = "";
  char buff[312]; 
  if ("System.in" == name)
  {
      cin.getline(buff, 312); 
      res = string(buff); 
  }
  else if (readable)
  {
      inFileStream.getline(buff,312);
      res = string(buff); 
  }
  return res; 
}

string OclFile::readAll()
{
    string res = "";
    ostringstream contents; 

    if ("System.in" == name)
    {
        char c;
        while ( ( c = cin.get() ) != EOF )
        {
            contents << c; 
        }
        res = contents.str(); 
    }
    else if (readable)
    { char c;
      inFileStream.seekg(0); 
      while ((c = inFileStream.get()) != EOF)
      {
        contents << c;
      }
      res = contents.str();
   }
   return res;
}

string OclFile::read()
{
    string res = ""; 
    if ("System.in" == name)
    {
        char buff[] = { ' ', '\0' }; 
        buff[0] = cin.get(); 
        res = string(buff);
    }
    else if (readable)
    {
        char buff[] = { ' ', '\0' };
        buff[0] = inFileStream.get();
        res = string(buff);
    }
    return res;
}

void OclFile::skipBytes(int n)
{
    if ("System.in" == name)
    {
        cin.ignore(n); 
    }
    else if (readable)
    { inFileStream.ignore(n); }
}

void OclFile::mark()
{
    if ("System.in" == name || "System.out" == name ||
        "System.err" == name) {
    }
    else if (readable)
    {
        position = inFileStream.tellg(); 
    }
    else if (writable)
    {
        position = outFileStream.tellp();
    }
}

void OclFile::reset()
{
    if ("System.in" == name || "System.out" == name ||
        "System.err" == name) {
    }
    else if (readable)
    {
        inFileStream.seekg(position);
    }
    else if (writable)
    {
        outFileStream.seekp(position);
    }
}

bool OclFile::mkdir()
{
    int rc = _mkdir(name.c_str()); 
    if (rc == 0)
    {
        return true;
    }
    return false; 
}

void OclFile::printf(string f, vector<void*>* sq)
{
    int n = sq->size();
    int flength = f.length();
    if (n == 0 || flength == 0)
    {
        return;
    }

    const char* format = f.c_str(); 
    void* ap;
    char* p = (char*) format;
    int i = 0;

    char* sval;
    int ival;
    unsigned int uval;
    double dval;

    ostringstream buff; 
    ap = sq->at(0);
    for (; *p != '\0'; p++)
    {
        if (*p != '%')
        {
            buff << *p;
            continue;
        }

        char* tmp = (char*)calloc(flength + 1, sizeof(char));
        tmp[0] = '%';
        int k = 1;
        p++;

        while (*p != 'i' && *p != 'd' && *p != 'g' && *p != 'e' &&
            *p != 'o' && *p != 'x' && *p != 'X' && *p != 'E' &&
            *p != 'G' && *p != 's' && *p != '%' &&
            *p != 'u' && *p != 'c' && *p != 'f' && *p != 'p')
        {
            tmp[k] = *p;
            k++;
            p++;
        }  /* Now p points to flag after % */

        tmp[k] = *p;
        tmp[k + 1] = '\0';

        if (i >= n)
        {
            continue;
        }

        switch (*p)
        {
        case 'i':
            ival = *((int*) sq->at(i));
            i++;
            { char* ibuff0 = 
                (char*) calloc(int(log10(abs(ival) + 1)) + 2, sizeof(char));
              sprintf(ibuff0, tmp, ival);
              buff << ibuff0;
            }
            break;
        case 'o':
        case 'x':
        case 'X':
        case 'u':
            uval = *((unsigned int*) sq->at(i));
            i++;
            { char* ubuff = 
                (char*) calloc(int(log10(uval+1)) + 2, sizeof(char));
              sprintf(ubuff, tmp, uval);
              buff << ubuff;
            }
            break;
        case 'c':
        case 'd':
            ival = *((int*) sq->at(i));
            i++;
            { char* ibuff1 = 
                (char*) calloc(int(log10(abs(ival) + 1)) + 2, sizeof(char));
              sprintf(ibuff1, tmp, ival);
              buff << ibuff1;
            }
            break;
        case 'f':
        case 'e':
        case 'E':
        case 'g':
        case 'G':
            dval = *((double*) sq->at(i));
            i++;
            { char* dbuff = 
                (char*) calloc(int(log10(fabs(dval) + 1)) + 2, sizeof(char));
              sprintf(dbuff, tmp, dval);
              buff << dbuff;
            }
            break;
        case 's':
            sval = ((char*) sq->at(i));
            i++;
            { char* sbuff = (char*) calloc(strlen(sval) + 1, sizeof(char));
              sprintf(sbuff, tmp, sval);
              buff << sbuff;
            }
            break;
        case 'p':
            i++;
            { char* pbuff = (char*)calloc(9, sizeof(char));
              sprintf(pbuff, tmp, sq->at(i));
              buff << pbuff;
            }
            break;
        default:
            buff << *p; 
            break;
        }
    }
    string res = buff.str(); 
    write(res); 
}

bool OclFile::hasNext()
{
    char buff[312];
    if ("System.in" == name)
    {
        if (cin.eof()) { return false; }

        cin.getline(buff, 312);
        if (buff != NULL && strlen(buff) > 0)
        {
            lastRead = string(buff);
            return true;
        }
    }
    else if (readable)
    {
        if (inFileStream.eof()) { return false; }

        inFileStream.getline(buff, 312);
        if (buff != NULL && strlen(buff) > 0)
        {
            lastRead = string(buff);
            return true;
        }
    }
    return false;
}

string OclFile::getCurrent()
{
    return lastRead; 
}

template<class E>
void OclFile::writeObject(E* obj)
{
    string text = obj->toString();
    write(text); 
}

