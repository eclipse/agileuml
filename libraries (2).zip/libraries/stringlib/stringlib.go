package stringlib

import "fmt"
import "container/list"
import "../ocl"


func Format(f string, args *list.List) string {
  arglist := ocl.AsArray(args)
  return fmt.Sprintf(f, arglist...)
} 


  



