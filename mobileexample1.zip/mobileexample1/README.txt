This is an elementary example of a mobile app and generated code in Android and iOS. 

