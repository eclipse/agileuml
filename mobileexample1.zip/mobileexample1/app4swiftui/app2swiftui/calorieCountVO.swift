//
//  calorieCountVO.swift
//  app2swiftui
//
//  Created by Kevin Lano on 01/12/2020.
//

import Foundation
import Darwin

class calorieCountVO
{
  var gender : Gender = Gender.male
  var exercise : Exercise = Exercise.walking
  var time : Double = 0.0
  static var defaultInstance : calorieCountVO? = nil
  var errorlist : [String] = [String]()

  var result : Double = 0.0


  init() {}


  static func defaultcalorieCountVO() -> calorieCountVO
  { if defaultInstance == nil
    { defaultInstance = calorieCountVO() }
    return defaultInstance!
  }

  init(genderx : Gender,exercisex : Exercise,timex : Double)  {
    gender = genderx
    exercise = exercisex
    time = timex
  }

  func toString() -> String
  { return "" + "gender= " + gender.rawValue + ", " + "exercise= " + exercise.rawValue + ", " + "time= " + String(time) }

  func getgender() -> Gender
  { return gender }

  func getexercise() -> Exercise
  { return exercise }

  func gettime() -> Double
  { return time }

  func setgender(_x : Gender)
  { gender = _x }

  func setexercise(_x : Exercise)
  { exercise = _x }

  func settime(_x : Double)
  { time = _x }

  func setresult(_x : Double)
  { result = _x }

  func resetData()
  { errorlist = [String]() }

  func iscalorieCounterror() -> Bool
  { resetData()
    if time >= 0 { }
    else { errorlist.append("calorieCount invariant 1 failed") }
    if errorlist.count > 0
    { return true }
    return false
  }

  func errors() -> String
  { var res : String = ""
    for (_,x) in errorlist.enumerated()
    { res = res + x + ", " }
    return res
  }

}
