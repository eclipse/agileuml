//
//  ComputeBMIVO.swift
//  app2swiftui
//
//  Created by Kevin Lano on 30/11/2020.
//

import Foundation

import Darwin

class ComputeBMIVO
{
  var height : Double = 0.0
  var weight : Double = 0.0
  static var defaultInstance : ComputeBMIVO? = nil
  var errorlist : [String] = [String]()

  var result : Double = 0.0


  init() {}


  static func defaultcomputeBMIVO() -> ComputeBMIVO
  { if defaultInstance == nil
    { defaultInstance = ComputeBMIVO() }
    return defaultInstance!
  }

  init(heightx : Double,weightx : Double)  {
    height = heightx
    weight = weightx
  }

  func toString() -> String
  { return "" + "height= " + String(height) + ", " + "weight= " + String(weight) }

  func getheight() -> Double
  { return height }

  func getweight() -> Double
  { return weight }

  func setheight(_x : Double)
  { height = _x }

  func setweight(_x : Double)
  { weight = _x }

  func setresult(_x : Double)
  { result = _x }

  func resetData()
  { errorlist = [String]() }

  func iscomputeBMIerror() -> Bool
  { resetData()
    if height > 0 && height <= 3 { }
    else { errorlist.append("computeBMI invariant 1 failed") }
    if weight > 0 && weight <= 300 { }
    else { errorlist.append("computeBMI invariant 2 failed") }
    if errorlist.count > 0
    { return true }
    return false
  }

  func errors() -> String
  { var res : String = ""
    for (_,x) in errorlist.enumerated()
    { res = res + x + ", " }
    return res
  }

}
