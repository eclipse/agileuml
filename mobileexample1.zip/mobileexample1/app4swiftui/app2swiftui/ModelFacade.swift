//
//  ModelFacade.swift
//  app2swiftui
//
//  Created by Kevin Lano on 30/11/2020.
//

import Foundation

import Darwin
import Combine
import SwiftUI
import CoreLocation

class ModelFacade : ObservableObject
{ static var instance : ModelFacade? = nil
  // var fileSystem : FileAccessor = FileAccessor()


  static func getInstance() -> ModelFacade
  { if instance == nil
    { instance = ModelFacade() }
    return instance! }


  init() { }

  func cancelcomputeBMI() { }

  func computeBMI(_x : ComputeBMIVO) -> Double
  {
    var result : Double = 0.0
    if _x.iscomputeBMIerror()
    { return result }
    let height : Double = _x.getheight()
    let weight : Double = _x.getweight()

    result = weight / ( height*height)

    _x.setresult(_x: result)
    return result
  }

  func cancelcalorieCount() { }

  func calorieCount(_x : calorieCountVO) -> Double
  {
    var result : Double = 0.0
    if _x.iscalorieCounterror()
    { return result }
    let gender : Gender = _x.getgender()
    let exercise : Exercise = _x.getexercise()
    let time : Double = _x.gettime()

    var factor : Double = 0
    factor = 1
    if exercise == Exercise.walking
    {
      factor = 100
    }
    else {
      if exercise == Exercise.running
    {
      factor = 300
    }
    else {
      if exercise == Exercise.jogging
    {
      factor = 200
    }
    else {
      factor = 250
    }
    }
    }
    result =  factor*(time/Double(60))

    _x.setresult(_x: result)
    return result
  } 


}
