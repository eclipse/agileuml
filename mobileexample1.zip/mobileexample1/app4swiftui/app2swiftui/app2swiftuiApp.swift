//
//  app2swiftuiApp.swift
//  app2swiftui
//
//  Created by Kevin Lano on 30/11/2020.
//

import SwiftUI

@main
struct app2swiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(model: ModelFacade.getInstance())
        }
    }
}
