//
//  computeBMIScreen.swift
//  app2swiftui
//
//  Created by Kevin Lano on 01/12/2020.
//

import SwiftUI

struct computeBMIScreen: View {
    
    @State var bean : ComputeBMIVO = ComputeBMIVO()
    @ObservedObject var model : ModelFacade
    @State var res : Double = 0.0
    
    
    var body: some View {
        VStack(alignment: .leading)
        {
          HStack {
            Text("Height:").bold()
            Divider()
            TextField("Height", value: $bean.height, formatter: NumberFormatter()).keyboardType(.decimalPad)
          }.frame(width:150, height: 30).border(Color.gray)
      
        HStack {
          Text("Weight:").bold()
          Divider()
          TextField("Weight", value: $bean.weight, formatter: NumberFormatter()).keyboardType(.decimalPad)
        }.frame(width:150, height: 30).border(Color.gray)
          
          HStack(spacing: 20)
          { Button(action: { self.model.cancelcomputeBMI() } ) { Text("Cancel") }
            Button(action: { res = self.model.computeBMI(_x: bean) } ) { Text("ComputeBMI") }
          }.buttonStyle(DefaultButtonStyle())
          HStack(spacing: 20) {
            Text("Result:")
            Text(String(res))
          }
        }.padding(.top)
    }
}

struct computeBMIScreen_Previews: PreviewProvider {
    static var previews: some View {
        computeBMIScreen(model: ModelFacade.getInstance())
    }
}
