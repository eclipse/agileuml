package oclfile

import "strings"
import "container/list"
import "os"
import "io"
import "io/fs"
import "fmt"
import "path"
import "path/filepath"
import "bufio"
import "ocl"
import "encoding/json"
import "net"



type OclFile struct {
  name string
  position int64
  markedPosition int64
  actualFile *os.File
  reader *bufio.Reader
  writer *bufio.Writer
  readable bool
  writable bool
  eof bool
  currentItem string
  inputStream string
}

var OclFile_Index map[string]*OclFile = map[string]*OclFile{}


func NewOclFile(nme string) *OclFile { 
  res := &OclFile{}
  res.name = nme
  OclFile_Index[nme] = res

  if "System.in" == nme { 
    res.actualFile = os.Stdin
  } else { 
    if "System.out" == nme { 
      res.actualFile = os.Stdout
    } else { 
      if "System.err" == nme { 
        res.actualFile = os.Stderr
      } 
    } 
  } 

  res.position = 0
  res.markedPosition = 0
  res.readable = false
  res.writable = false
  res.currentItem = ""
  res.inputStream = ""
  res.reader = nil
  res.writer = nil
  return res
} 

var System_in = NewOclFile("System.in")
var System_out = NewOclFile("System.out")
var System_err = NewOclFile("System.err")

func GetByPKOclFile(nme string) *OclFile { 
  return OclFile_Index[nme]
} 

func (self *OclFile) SetInputStream(s string) { 
  self.inputStream = s
} 

func (self *OclFile) GetName() string { 
  return self.name
} 

func (self *OclFile) GetParent() string { 
  return path.Dir(self.name)
} 

func (self *OclFile) GetParentFile() *OclFile { 
  return NewOclFile(path.Dir(self.name))
} 

func (self *OclFile) GetAbsolutePath() string { 
  pth, err := filepath.Abs(self.name)
  if err == nil { 
    return pth
  }
  return self.name
} 


func NewOclFile_Read(fle *OclFile) *OclFile {
  // special case for System.in
  if "System.in" == fle.name { 
    fle.actualFile = os.Stdin
    fle.readable = true
    fle.writable = false
    fle.eof = false
    fle.reader = bufio.NewReader(os.Stdin)
    return fle
  } 

  if len(fle.inputStream) > 0 { 
    fle.actualFile = nil
    fle.readable = true
    fle.writable = false
    fle.eof = false
    fle.reader = bufio.NewReader(
                    strings.NewReader(fle.inputStream))
    return fle    
  } 
 
  f, err := os.Open(fle.name)
  if err == nil { 
    fle.actualFile = f
    fle.readable = true
    fle.writable = false
    fle.eof = false
    fle.reader = bufio.NewReader(f)
  } 
  return fle
}

func NewOclFile_ReadB(fle *OclFile) *OclFile {
  return NewOclFile_Read(fle)
} 

func NewOclFile_Remote(fle *OclFile, conn net.Conn) *OclFile {
  fle.actualFile = nil
  fle.readable = true
  fle.writable = true
  fle.eof = false
  fle.reader = bufio.NewReader(conn)
  fle.writer = bufio.NewWriter(conn)
  return fle    
} 


func NewOclFile_Write(fle *OclFile) *OclFile {
  // Special case for System.out, System.err

  if "System.out" == fle.name { 
    fle.actualFile = os.Stdout
    fle.writable = true
    fle.eof = false
    return fle
  } 

  if "System.err" == fle.name { 
    fle.actualFile = os.Stderr
    fle.writable = true
    fle.eof = false
    return fle
  } 

  if fle.writer != nil { 
    return fle
  } 
 
  f, err := os.Create(fle.name)
  if err == nil { 
    fle.actualFile = f
    fle.writable = true
    fle.eof = false
  } 
  return fle
}

func NewOclFile_WriteB(fle *OclFile) *OclFile {
  return NewOclFile_Write(fle)
} 

func (self *OclFile) CanRead() bool { 
  if "System.in" == self.name { 
    return true
  } 

  if self.readable { 
    return true
  } 

  _, err := os.Open(self.name)
  if err == nil { 
    return true
  } 
  return false
} 

func (self *OclFile) Exists() bool { 
  if "System.in" == self.name { 
    return true
  } 

  if self.readable { 
    return true
  } 

  _, err := os.Open(self.name)
  if err == nil { 
    return true
  } 
  return false
} 

func (self *OclFile) IsOpen() bool { 
  if self.readable { 
    return true
  } 
  
  if self.writable { 
    return true
  } 
  
  return false
}

func (self *OclFile) IsFile() bool { 
  finfo, err := os.Lstat(self.name)
  if err != nil { 
    return false
  } 

  mde := finfo.Mode()
  if mde.IsRegular() { 
    return true
  } 
  return false
} 

func (self *OclFile) IsDirectory() bool { 
  finfo, err := os.Lstat(self.name)
  if err != nil { 
    return false
  } 

  mde := finfo.Mode()
  if mde.IsDir() { 
    return true
  } 
  return false
} 

func (self *OclFile) LastModified() int64 { 
  finfo, err := os.Lstat(self.name)
  if err != nil { 
    return 0
  } 

  mde := finfo.ModTime()
  return mde.Unix()
} 


func (self *OclFile) CloseFile() {
  if self.actualFile != nil { 
    self.actualFile.Close()
  } 
  self.readable = false
  self.writable = false
  self.reader = nil
  self.writer = nil
}

func (self *OclFile) Length() int64 { 
  if self.actualFile == nil { 
    return int64(len(self.inputStream))
  } 

  finfo, err := os.Lstat(self.name)
  if err != nil { 
    return 0
  } 
  return finfo.Size()
}

func (self *OclFile) SetPosition(pos int64) { 
  if self.actualFile != nil { 
    self.actualFile.Seek(pos,0)
  } 
  self.position = pos
} 

func (self *OclFile) GetPosition() int64 { 
  return self.position 
} 

func (self *OclFile) SkipBytes(n int) { 
  if self.actualFile != nil { 
    self.actualFile.Seek(int64(n),1)
  } 
  self.position = self.position + int64(n)
} 

func (self *OclFile) Mark(p int64) { 
  self.markedPosition = p 
} 

func (self *OclFile) Reset() { 
  if self.actualFile != nil { 
    self.actualFile.Seek(self.markedPosition,0)
  } 
  self.position = self.markedPosition
} 



func (self *OclFile) IsAbsolute() bool {
  return path.IsAbs(self.name)
}

func (self *OclFile) GetEof() bool { 
  return self.eof 
} 

func (self *OclFile) HasNext() bool { 
  if self.name == "System.in" { 
    var res string = ""
    var sptr *string = &res
    n, err := fmt.Scanf("%s\n", sptr)

    if n == 0 { 
      self.currentItem = ""
      return false
    } 
    if err != nil { 
      self.currentItem = ""
      return false
    } 

    self.currentItem = *sptr
    return true
  } 

  if self.readable && self.actualFile != nil { 
    b := make([]byte, 1)
    n, err := self.actualFile.Read(b)
    if n > 0 && err == nil { 
      self.position = self.position + int64(n)
      self.currentItem = string(b[0])
      return true
    } else { 
      self.eof = true
      self.currentItem = ""
      return false
    } 
  }
  return false
}

func (self *OclFile) GetCurrent() string { 
  return self.currentItem
} 

 
func (self *OclFile) Read() string {
  if self.name == "System.in" { 
    var res string = ""
    var sptr *string = &res
    fmt.Scanf("%s", sptr)
    return *sptr
  } 

  if self.readable && self.actualFile != nil { 
    b := make([]byte, 1)
    n, err := self.actualFile.Read(b)
    if n > 0 && err == nil { 
      self.position = self.position + int64(n)
      return string(b[0])
    } else { 
      self.eof = true
    } 
  }

  if self.readable && self.reader != nil { 
    b := make([]byte, 1)
    n, err := self.reader.Read(b)
    if n > 0 && err == nil { 
      self.position = self.position + int64(n)
      return string(b[0])
    } else { 
      self.eof = true
    } 
  }

  return ""
}

func (self *OclFile) ReadByte() int {
  if self.readable && self.actualFile != nil { 
    b := make([]byte, 1)
    n, err := self.actualFile.Read(b)
    if n > 0 && err == nil { 
      self.position = self.position + int64(n)
      return int(b[0])
    } else { 
      self.eof = true
    } 
  }

  if self.readable && self.reader != nil { 
    b := make([]byte, 1)
    n, err := self.reader.Read(b)
    if n > 0 && err == nil { 
      self.position = self.position + int64(n)
      return int(b[0])
    } else { 
      self.eof = true
    } 
  }

  return -1
}

func (self *OclFile) ReadN(n int) *list.List {
  res := list.New()

  if self.readable && self.actualFile != nil { 
    b := make([]byte, n)
    readbytes, err := self.actualFile.Read(b)
    if err == nil { 
    } else { 
      self.eof = true
    } 

    self.position = self.position + int64(readbytes)
    for i := 0; i < readbytes; i++ { 
      res.PushBack(string(b[i]))
    } 
     
  }
  return res
}

func (self *OclFile) ReadNbytes(n int) *list.List {
  res := list.New()

  if self.readable && self.actualFile != nil { 
    b := make([]byte, n)
    readbytes, err := self.actualFile.Read(b)
    if err == nil { 
    } else { 
      self.eof = true
    } 

    self.position = self.position + int64(readbytes)
    for i := 0; i < readbytes; i++ { 
      res.PushBack(int(b[i]))
    } 
     
  }
  return res
}

func (self *OclFile) ReadAllBytes() *list.List {
  res := list.New()
  n := self.Length()

  if self.readable && self.actualFile != nil { 
    b := make([]byte, n)
    readbytes, err := self.actualFile.Read(b)
    if err == nil { 
    } else { 
      self.eof = true
    } 

    self.position = self.position + int64(readbytes)
    for i := 0; i < readbytes; i++ { 
      res.PushBack(int(b[i]))
    } 
     
  }
  return res
}

func (self *OclFile) ReadLine() string {
  if self.name == "System.in" { 
    rdr := bufio.NewReader(os.Stdin)
    res, err := rdr.ReadBytes('\n')
    if err != nil { 
      self.eof = true
      return ""
    }
    return string(res)
  } 

  if self.readable && self.reader != nil { 
    b := make([]byte, 512)
    b, err := self.reader.ReadBytes('\n')
    if err == nil { 
      self.position = self.position + int64(len(b))
      return string(b)
    } else { 
      self.eof = true
    } 
  }
  return ""
}

func (self *OclFile) ReadAllLines() *list.List {
  res := list.New()
  if self.name == "System.in" { 
    rdr := bufio.NewReader(os.Stdin)
    lne, err := rdr.ReadBytes('\n')
    for err == nil { 
      res.PushBack(string(lne))
      lne, err = rdr.ReadBytes('\n')
    }
    self.eof = true
    return res
  } 

  if self.readable && self.reader != nil { 
    b := make([]byte, 512)
    b, err := self.reader.ReadBytes('\n')
    for err == nil { 
      self.position = self.position + int64(len(b))
      res.PushBack(string(b))
      b, err = self.reader.ReadBytes('\n')
	} 
    self.eof = true
    return res 
  }

  return res
}


func (self *OclFile) ReadAll() string {
  if self.readable && self.actualFile != nil { 
    contents, _ := io.ReadAll(self.actualFile)
    return string(contents)
  } 
  return ""
} 


func (self *OclFile) Flush() { 
  if self.writable && self.actualFile != nil { 
    self.actualFile.Sync()
  } 
}

func (self *OclFile) Print(s string) { 
  if self.name == "System.out" { 
    fmt.Printf("%s", s)
  } else {
    if self.writable && self.actualFile != nil { 
      self.actualFile.Write([]byte(s))
    } else { 
      if self.writer != nil { 
        self.writer.Write([]byte(s))
      }
    }  
  } 
}

func (self *OclFile) Write(s string) { 
  if self.name == "System.out" { 
    fmt.Printf("%s", s)
  } else {
    if self.writable && self.actualFile != nil { 
      self.actualFile.Write([]byte(s))
    } else { 
      if self.writer != nil { 
        self.writer.Write([]byte(s))
      }
    } 
  } 
}

func (self *OclFile) WriteN(sq *list.List, n int) { 
  if self.name == "System.out" { 
    ind := 0
    for e := sq.Front(); e != nil && ind < n; e = e.Next() {
      x := e.Value.(string)
      fmt.Printf("%s", x)
      ind++
    } 
  } else {
    if self.writable && self.actualFile != nil { 
      ind := 0
      for e := sq.Front(); e != nil && ind < n; e = e.Next() {
        x := e.Value.(string)
        self.actualFile.Write([]byte(x))
        ind++
      } 
    } else { 
      if self.writer != nil { 
        ind := 0
        for e := sq.Front(); e != nil && ind < n; e = e.Next() {
          x := e.Value.(string)
          self.writer.Write([]byte(x))
          ind++
        } 
      } 
    }  
  } 
}

func CopyFromTo(source *OclFile, target *OclFile) {
  lns := source.ReadAllLines()
  for lne := lns.Front(); lne != nil; lne = lne.Next() {
    target.Write(lne.Value.(string))
  } 
}

func (self *OclFile) WriteByte(x int) { 
  if self.name == "System.out" { 
    fmt.Printf("%d", x)
  } else {
    if self.writable && self.actualFile != nil { 
      b := byte(x % 256)
      var bb []byte = make([]byte,1)
      bb[0] = b
      self.actualFile.Write(bb)
    } else { 
      if self.writable && self.writer != nil { 
        b := byte(x % 256)
        var bb []byte = make([]byte,1)
        bb[0] = b
        self.writer.Write(bb)
      } 
    }  
  } 
}

func (self *OclFile) WriteNbytes(sq *list.List, n int) { 
  if self.name == "System.out" { 
    ind := 0
    for e := sq.Front(); e != nil && ind < n; e = e.Next() {
      x := e.Value.(int)
      fmt.Printf("%d", x)
      ind++
    } 
  } else {
    if self.writable && self.actualFile != nil { 
      ind := 0
      for e := sq.Front(); e != nil && ind < n; e = e.Next() {
        x := e.Value.(int)
        b := byte(x % 256)
        var bb []byte = make([]byte,1)
        bb[0] = b
        self.actualFile.Write(bb)
        ind++
      } 
    } else {
      if self.writable && self.writer != nil { 
        ind := 0
        for e := sq.Front(); e != nil && ind < n; e = e.Next() {
          x := e.Value.(int)
          b := byte(x % 256)
          var bb []byte = make([]byte,1)
          bb[0] = b
          self.writer.Write(bb)
          ind++
        }
      }  
    }
  } 
}

func (self *OclFile) WriteAllBytes(sq *list.List) { 
  if self.name == "System.out" { 
    for e := sq.Front(); e != nil; e = e.Next() {
      x := e.Value.(int)
      fmt.Printf("%d", x)
    } 
  } else {
    if self.writable && self.actualFile != nil { 
      for e := sq.Front(); e != nil; e = e.Next() {
        x := e.Value.(int)
        b := byte(x % 256)
        var bb []byte = make([]byte,1)
        bb[0] = b
        self.actualFile.Write(bb)
      } 
    } else {
      if self.writable && self.writer != nil { 
        for e := sq.Front(); e != nil; e = e.Next() {
          x := e.Value.(int)
          b := byte(x % 256)
          var bb []byte = make([]byte,1)
          bb[0] = b
          self.writer.Write(bb)
        }
      } 
    }
  } 
}

func (self *OclFile) Println(s string) { 
  self.Writeln(s)
}

func (self *OclFile) Writeln(s string) { 
  if self.name == "System.out" { 
    fmt.Println(s)
  } else {
    if self.writable && self.actualFile != nil { 
      self.actualFile.Write([]byte(s + "\n"))
    } else {
      if self.writable && self.writer != nil { 
        self.writer.Write([]byte(s + "\n"))
      } 
    } 
  } 
}

func (self *OclFile) Printf(f string, args *list.List) {
  arglist := ocl.AsArray(args)
  if self.name == "System.out" { 
    fmt.Printf(f, arglist...)
  } else { 
    if self.writable && self.actualFile != nil { 
      fmt.Fprintf(self.actualFile, f, arglist...)
    } 
  } 
}
 
func (self *OclFile) Mkdir() bool { 
  err := os.Mkdir(self.name, fs.ModeDir)
  if err != nil { 
    return false
  } 
  return true
} 

 
func (self *OclFile) List() *list.List {
  res := list.New()
  files, err := os.ReadDir(self.name)
  if err != nil { 
    return res
  } 

  for _, fle := range files {
    res.PushBack(fle.Name())
  }
  return res
}

func (self *OclFile) ListFiles() *list.List {
  res := list.New()
  files, err := os.ReadDir(self.name)
  if err != nil { 
    return res
  } 

  for _, fle := range files {
    res.PushBack(NewOclFile(fle.Name()))
  }
  return res
}


func (self *OclFile) Delete() bool { 
  self.writable = false
  self.readable = false
  err := os.Remove(self.name)
  if err != nil { 
    return false
  } 
  return true
} 

func DeleteFile(nme string) bool { 
  err := os.Remove(nme)
  if err != nil { 
    return false
  } 
  return true
} 

func RenameFile(oldnme string, newnme string) bool { 
  err := os.Rename(oldnme, newnme)
  if err != nil { 
    return false
  } 
  return true
} 

func (self *OclFile) WriteObject(obj interface{}) {
  ss, err := json.Marshal(obj)
  if err != nil {
    return
  } 
  self.Writeln(string(ss))
} 

 
func (self *OclFile) ReadObject() interface{} { 
  xx := self.ReadLine()
  if xx == "" { 
    return nil
  } 
  var res *interface{} 
  err := json.Unmarshal([]byte(xx),res)
  if err != nil { 
    return nil
  } 
  return *res
} 


