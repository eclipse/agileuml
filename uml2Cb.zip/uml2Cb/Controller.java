package uml2Cb;


import java.util.List;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

import java.lang.*;
import java.lang.reflect.*;
import java.util.StringTokenizer;
import java.io.*;



abstract class CExpression
  implements SystemTypes
{
  protected boolean needsBracket = false; // internal
  protected String kind = ""; // internal
  protected String cexpId = ""; // internal
  protected boolean isStatic = false; // internal
  protected CType type;
  protected CType elementType;

  public CExpression(CType type,CType elementType)
  {
    this.needsBracket = false;
    this.kind = "";
    this.cexpId = "";
    this.isStatic = false;
    this.type = type;
    this.elementType = elementType;

  }

  public CExpression() { }





  public void setneedsBracket(boolean needsBracket_x) { needsBracket = needsBracket_x;  }


    public static void setAllneedsBracket(List cexpressions,boolean val)
  { for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      Controller.inst().setneedsBracket(cexpressionx,val); } }


  public void setkind(String kind_x) { kind = kind_x;  }


    public static void setAllkind(List cexpressions,String val)
  { for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      Controller.inst().setkind(cexpressionx,val); } }


  public void setcexpId(String cexpId_x) { cexpId = cexpId_x;  }


    public static void setAllcexpId(List cexpressions,String val)
  { for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      Controller.inst().setcexpId(cexpressionx,val); } }


  public void setisStatic(boolean isStatic_x) { isStatic = isStatic_x;  }


    public static void setAllisStatic(List cexpressions,boolean val)
  { for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      Controller.inst().setisStatic(cexpressionx,val); } }


  public void settype(CType type_xx) { type = type_xx;
  }

  public static void setAlltype(List cexpressions, CType _val)
  { for (int _i = 0; _i < cexpressions.size(); _i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(_i);
      Controller.inst().settype(cexpressionx, _val); } }

  public void setelementType(CType elementType_xx) { elementType = elementType_xx;
  }

  public static void setAllelementType(List cexpressions, CType _val)
  { for (int _i = 0; _i < cexpressions.size(); _i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(_i);
      Controller.inst().setelementType(cexpressionx, _val); } }

    public boolean getneedsBracket() { return needsBracket; }

    public static List getAllneedsBracket(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      if (result.contains(new Boolean(cexpressionx.getneedsBracket()))) { }
      else { result.add(new Boolean(cexpressionx.getneedsBracket())); } }
    return result; }

    public static List getAllOrderedneedsBracket(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      result.add(new Boolean(cexpressionx.getneedsBracket())); } 
    return result; }

    public String getkind() { return kind; }

    public static List getAllkind(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      if (result.contains(cexpressionx.getkind())) { }
      else { result.add(cexpressionx.getkind()); } }
    return result; }

    public static List getAllOrderedkind(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      result.add(cexpressionx.getkind()); } 
    return result; }

    public String getcexpId() { return cexpId; }

    public static List getAllcexpId(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      if (result.contains(cexpressionx.getcexpId())) { }
      else { result.add(cexpressionx.getcexpId()); } }
    return result; }

    public static List getAllOrderedcexpId(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      result.add(cexpressionx.getcexpId()); } 
    return result; }

    public boolean getisStatic() { return isStatic; }

    public static List getAllisStatic(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      if (result.contains(new Boolean(cexpressionx.getisStatic()))) { }
      else { result.add(new Boolean(cexpressionx.getisStatic())); } }
    return result; }

    public static List getAllOrderedisStatic(List cexpressions)
  { List result = new Vector();
    for (int i = 0; i < cexpressions.size(); i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(i);
      result.add(new Boolean(cexpressionx.getisStatic())); } 
    return result; }

  public CType gettype() { return type; }

  public static List getAlltype(List cexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cexpressions.size(); _i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(_i);
      if (result.contains(cexpressionx.gettype())) {}
      else { result.add(cexpressionx.gettype()); }
 }
    return result; }

  public static List getAllOrderedtype(List cexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cexpressions.size(); _i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(_i);
      if (result.contains(cexpressionx.gettype())) {}
      else { result.add(cexpressionx.gettype()); }
 }
    return result; }

  public CType getelementType() { return elementType; }

  public static List getAllelementType(List cexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cexpressions.size(); _i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(_i);
      if (result.contains(cexpressionx.getelementType())) {}
      else { result.add(cexpressionx.getelementType()); }
 }
    return result; }

  public static List getAllOrderedelementType(List cexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cexpressions.size(); _i++)
    { CExpression cexpressionx = (CExpression) cexpressions.get(_i);
      if (result.contains(cexpressionx.getelementType())) {}
      else { result.add(cexpressionx.getelementType()); }
 }
    return result; }

    public static CExpression defineCOpRef(COperation op)
  {   CExpression result = null;
 
    if (Controller.inst().getCBasicExpressionByPK(op.getname() + "_ref") != null)
    { CBasicExpression be = Controller.inst().getCBasicExpressionByPK(op.getname() + "_ref");
     be.setdata(op.getname());
    be.settype(op.getreturnType());
    result = be;
  }
    else
    { CBasicExpression be = new CBasicExpression();
    Controller.inst().addCBasicExpression(be);
    be.setcexpId(op.getname() + "_ref");
    be.setdata(op.getname());
    be.settype(op.getreturnType());
    result = be; }

      return result;
  }


    public static CBasicExpression newCBasicExpression(String d,CType t)
  {   CBasicExpression result = null;
 
    if (Controller.inst().getCBasicExpressionByPK(d + "_ref") != null)
    { CBasicExpression be = Controller.inst().getCBasicExpressionByPK(d + "_ref");
     be.setdata(d);
    be.settype(t);
    result = be;
  }
    else
    { CBasicExpression be = new CBasicExpression();
    Controller.inst().addCBasicExpression(be);
    be.setcexpId(d + "_ref");
    be.setdata(d);
    be.settype(t);
    result = be; }

      return result;
  }


    public static CExpression defineCOpRefCast(COperation op,String cst)
  {   CExpression result = null;
 
    if (Controller.inst().getCBasicExpressionByPK(op.getname() + "_ref") != null)
    { CBasicExpression be = Controller.inst().getCBasicExpressionByPK(op.getname() + "_ref");
     be.setdata(op.getname());
    be.settype(op.getreturnType());
    result = Expression.cast(cst,be);
  }
    else
    { CBasicExpression be = new CBasicExpression();
    Controller.inst().addCBasicExpression(be);
    be.setcexpId(op.getname() + "_ref");
    be.setdata(op.getname());
    be.settype(op.getreturnType());
    result = Expression.cast(cst,be); }

      return result;
  }


    public static CExpression defineCOpReference(String op,String typ)
  {   CExpression result = null;
 
    if (Controller.inst().getCBasicExpressionByPK(op + "_ref") != null)
    { CBasicExpression be = Controller.inst().getCBasicExpressionByPK(op + "_ref");
     be.setdata(op);
      if (Controller.inst().getCPrimitiveTypeByPK(op + "_" + typ) != null)
    { CPrimitiveType t = Controller.inst().getCPrimitiveTypeByPK(op + "_" + typ);
     t.setname(typ);
    be.settype(t);
    be.setelementType(t);
    result = be;
  }
    else
    { CPrimitiveType t = new CPrimitiveType();
    Controller.inst().addCPrimitiveType(t);
    t.setname(typ);
    t.setctypeId(op + "_" + typ);
    be.settype(t);
    be.setelementType(t);
    result = be; }

  }
    else
    { CBasicExpression be = new CBasicExpression();
    Controller.inst().addCBasicExpression(be);
    be.setcexpId(op + "_ref");
    be.setdata(op);
      if (Controller.inst().getCPrimitiveTypeByPK(op + "_" + typ) != null)
    { CPrimitiveType t = Controller.inst().getCPrimitiveTypeByPK(op + "_" + typ);
     t.setname(typ);
    be.settype(t);
    be.setelementType(t);
    result = be;
  }
    else
    { CPrimitiveType t = new CPrimitiveType();
    Controller.inst().addCPrimitiveType(t);
    t.setname(typ);
    t.setctypeId(op + "_" + typ);
    be.settype(t);
    be.setelementType(t);
    result = be; }
 }

      return result;
  }


    public String toString()
  {   String result = "";
 
  result = " ";
    return result;
  }



}


class CBinaryExpression
  extends CExpression
  implements SystemTypes
{
  private String operator = ""; // internal
  private CExpression left;
  private CExpression right;

  public CBinaryExpression(CExpression left,CExpression right)
  {
    this.operator = "";
    this.left = left;
    this.right = right;

  }

  public CBinaryExpression() { }



  public static CBinaryExpression parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CBinaryExpression cbinaryexpressionx = new CBinaryExpression();
    cbinaryexpressionx.operator = (String) _line1vals.get(0);
    return cbinaryexpressionx;
  }


  public void writeCSV(PrintWriter _out)
  { CBinaryExpression cbinaryexpressionx = this;
    _out.print("" + cbinaryexpressionx.operator);
    _out.println();
  }


  public void setoperator(String operator_x) { operator = operator_x;  }


    public static void setAlloperator(List cbinaryexpressions,String val)
  { for (int i = 0; i < cbinaryexpressions.size(); i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(i);
      Controller.inst().setoperator(cbinaryexpressionx,val); } }


  public void setleft(CExpression left_xx) { left = left_xx;
  }

  public static void setAllleft(List cbinaryexpressions, CExpression _val)
  { for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(_i);
      Controller.inst().setleft(cbinaryexpressionx, _val); } }

  public void setright(CExpression right_xx) { right = right_xx;
  }

  public static void setAllright(List cbinaryexpressions, CExpression _val)
  { for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(_i);
      Controller.inst().setright(cbinaryexpressionx, _val); } }

    public String getoperator() { return operator; }

    public static List getAlloperator(List cbinaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < cbinaryexpressions.size(); i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(i);
      if (result.contains(cbinaryexpressionx.getoperator())) { }
      else { result.add(cbinaryexpressionx.getoperator()); } }
    return result; }

    public static List getAllOrderedoperator(List cbinaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < cbinaryexpressions.size(); i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(i);
      result.add(cbinaryexpressionx.getoperator()); } 
    return result; }

  public CExpression getleft() { return left; }

  public static List getAllleft(List cbinaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(_i);
      if (result.contains(cbinaryexpressionx.getleft())) {}
      else { result.add(cbinaryexpressionx.getleft()); }
 }
    return result; }

  public static List getAllOrderedleft(List cbinaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(_i);
      if (result.contains(cbinaryexpressionx.getleft())) {}
      else { result.add(cbinaryexpressionx.getleft()); }
 }
    return result; }

  public CExpression getright() { return right; }

  public static List getAllright(List cbinaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(_i);
      if (result.contains(cbinaryexpressionx.getright())) {}
      else { result.add(cbinaryexpressionx.getright()); }
 }
    return result; }

  public static List getAllOrderedright(List cbinaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(_i);
      if (result.contains(cbinaryexpressionx.getright())) {}
      else { result.add(cbinaryexpressionx.getright()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  if (needsBracket == true) 
  {   result = "(" + left + " " + operator + " " + right + ")";
 
  }  else
      if (true) 
  {   result = left + " " + operator + " " + right;
 
  }       return result;
  }



}


class CUnaryExpression
  extends CExpression
  implements SystemTypes
{
  private String operator = ""; // internal
  private CExpression argument;

  public CUnaryExpression(CExpression argument)
  {
    this.operator = "";
    this.argument = argument;

  }

  public CUnaryExpression() { }



  public static CUnaryExpression parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CUnaryExpression cunaryexpressionx = new CUnaryExpression();
    cunaryexpressionx.operator = (String) _line1vals.get(0);
    return cunaryexpressionx;
  }


  public void writeCSV(PrintWriter _out)
  { CUnaryExpression cunaryexpressionx = this;
    _out.print("" + cunaryexpressionx.operator);
    _out.println();
  }


  public void setoperator(String operator_x) { operator = operator_x;  }


    public static void setAlloperator(List cunaryexpressions,String val)
  { for (int i = 0; i < cunaryexpressions.size(); i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressions.get(i);
      Controller.inst().setoperator(cunaryexpressionx,val); } }


  public void setargument(CExpression argument_xx) { argument = argument_xx;
  }

  public static void setAllargument(List cunaryexpressions, CExpression _val)
  { for (int _i = 0; _i < cunaryexpressions.size(); _i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressions.get(_i);
      Controller.inst().setargument(cunaryexpressionx, _val); } }

    public String getoperator() { return operator; }

    public static List getAlloperator(List cunaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < cunaryexpressions.size(); i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressions.get(i);
      if (result.contains(cunaryexpressionx.getoperator())) { }
      else { result.add(cunaryexpressionx.getoperator()); } }
    return result; }

    public static List getAllOrderedoperator(List cunaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < cunaryexpressions.size(); i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressions.get(i);
      result.add(cunaryexpressionx.getoperator()); } 
    return result; }

  public CExpression getargument() { return argument; }

  public static List getAllargument(List cunaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cunaryexpressions.size(); _i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressions.get(_i);
      if (result.contains(cunaryexpressionx.getargument())) {}
      else { result.add(cunaryexpressionx.getargument()); }
 }
    return result; }

  public static List getAllOrderedargument(List cunaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cunaryexpressions.size(); _i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressions.get(_i);
      if (result.contains(cunaryexpressionx.getargument())) {}
      else { result.add(cunaryexpressionx.getargument()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  result = operator + argument;
    return result;
  }



}


abstract class CType
  implements SystemTypes
{
  protected String ctypeId = ""; // internal
  protected String name = ""; // internal

  public CType()
  {
    this.ctypeId = "";
    this.name = "";

  }



  public String toString()
  { String _res_ = "(CType) ";
    _res_ = _res_ + ctypeId + ",";
    _res_ = _res_ + name;
    return _res_;
  }



  public void setctypeId(String ctypeId_x) { ctypeId = ctypeId_x;  }


    public static void setAllctypeId(List ctypes,String val)
  { for (int i = 0; i < ctypes.size(); i++)
    { CType ctypex = (CType) ctypes.get(i);
      Controller.inst().setctypeId(ctypex,val); } }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List ctypes,String val)
  { for (int i = 0; i < ctypes.size(); i++)
    { CType ctypex = (CType) ctypes.get(i);
      Controller.inst().setname(ctypex,val); } }


    public String getctypeId() { return ctypeId; }

    public static List getAllctypeId(List ctypes)
  { List result = new Vector();
    for (int i = 0; i < ctypes.size(); i++)
    { CType ctypex = (CType) ctypes.get(i);
      if (result.contains(ctypex.getctypeId())) { }
      else { result.add(ctypex.getctypeId()); } }
    return result; }

    public static List getAllOrderedctypeId(List ctypes)
  { List result = new Vector();
    for (int i = 0; i < ctypes.size(); i++)
    { CType ctypex = (CType) ctypes.get(i);
      result.add(ctypex.getctypeId()); } 
    return result; }

    public String getname() { return name; }

    public static List getAllname(List ctypes)
  { List result = new Vector();
    for (int i = 0; i < ctypes.size(); i++)
    { CType ctypex = (CType) ctypes.get(i);
      if (result.contains(ctypex.getname())) { }
      else { result.add(ctypex.getname()); } }
    return result; }

    public static List getAllOrderedname(List ctypes)
  { List result = new Vector();
    for (int i = 0; i < ctypes.size(); i++)
    { CType ctypex = (CType) ctypes.get(i);
      result.add(ctypex.getname()); } 
    return result; }


}


class CBasicExpression
  extends CExpression
  implements SystemTypes
{
  private String data = ""; // internal
  private List parameters = new Vector(); // of CExpression
  private List arrayIndex = new Vector(); // of CBasicExpression
  private List reference = new Vector(); // of CBasicExpression

  public CBasicExpression()
  {
    this.data = "";

  }



  public static CBasicExpression parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CBasicExpression cbasicexpressionx = new CBasicExpression();
    cbasicexpressionx.data = (String) _line1vals.get(0);
    return cbasicexpressionx;
  }


  public void writeCSV(PrintWriter _out)
  { CBasicExpression cbasicexpressionx = this;
    _out.print("" + cbasicexpressionx.data);
    _out.println();
  }


  public void setdata(String data_x) { data = data_x;  }


    public static void setAlldata(List cbasicexpressions,String val)
  { for (int i = 0; i < cbasicexpressions.size(); i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(i);
      Controller.inst().setdata(cbasicexpressionx,val); } }


  public void setparameters(List parameters_xx) { parameters = parameters_xx;
    }
 
  public void setparameters(int ind_x, CExpression parameters_xx) { if (ind_x >= 0 && ind_x < parameters.size()) { parameters.set(ind_x, parameters_xx); } }

 public void addparameters(CExpression parameters_xx) { parameters.add(parameters_xx);
    }
 
  public void removeparameters(CExpression parameters_xx) { Vector _removedparametersparameters_xx = new Vector();
  _removedparametersparameters_xx.add(parameters_xx);
  parameters.removeAll(_removedparametersparameters_xx);
    }

  public static void setAllparameters(List cbasicexpressions, List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().setparameters(cbasicexpressionx, _val); } }

  public static void setAllparameters(List cbasicexpressions, int _ind,CExpression _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().setparameters(cbasicexpressionx,_ind,_val); } }

  public static void addAllparameters(List cbasicexpressions, CExpression _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().addparameters(cbasicexpressionx,  _val); } }


  public static void removeAllparameters(List cbasicexpressions,CExpression _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().removeparameters(cbasicexpressionx, _val); } }


  public static void unionAllparameters(List cbasicexpressions, List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().unionparameters(cbasicexpressionx, _val); } }


  public static void subtractAllparameters(List cbasicexpressions,  List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().subtractparameters(cbasicexpressionx,  _val); } }


  public void setarrayIndex(List arrayIndex_xx) { if (arrayIndex_xx.size() > 1) { return; } 
    arrayIndex = arrayIndex_xx;
  }
 
  public void addarrayIndex(CBasicExpression arrayIndex_xx) { if (arrayIndex.size() > 0) { arrayIndex.clear(); } 
    if (arrayIndex.contains(arrayIndex_xx)) {} else { arrayIndex.add(arrayIndex_xx); }
    }
 
  public void removearrayIndex(CBasicExpression arrayIndex_xx) { Vector _removedarrayIndexarrayIndex_xx = new Vector();
  _removedarrayIndexarrayIndex_xx.add(arrayIndex_xx);
  arrayIndex.removeAll(_removedarrayIndexarrayIndex_xx);
    }

  public static void setAllarrayIndex(List cbasicexpressions, List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().setarrayIndex(cbasicexpressionx, _val); } }

  public static void addAllarrayIndex(List cbasicexpressions, CBasicExpression _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().addarrayIndex(cbasicexpressionx,  _val); } }


  public static void removeAllarrayIndex(List cbasicexpressions,CBasicExpression _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().removearrayIndex(cbasicexpressionx, _val); } }


  public static void unionAllarrayIndex(List cbasicexpressions, List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().unionarrayIndex(cbasicexpressionx, _val); } }


  public static void subtractAllarrayIndex(List cbasicexpressions,  List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().subtractarrayIndex(cbasicexpressionx,  _val); } }


  public void setreference(List reference_xx) { if (reference_xx.size() > 1) { return; } 
    reference = reference_xx;
  }
 
  public void addreference(CBasicExpression reference_xx) { if (reference.size() > 0) { reference.clear(); } 
    if (reference.contains(reference_xx)) {} else { reference.add(reference_xx); }
    }
 
  public void removereference(CBasicExpression reference_xx) { Vector _removedreferencereference_xx = new Vector();
  _removedreferencereference_xx.add(reference_xx);
  reference.removeAll(_removedreferencereference_xx);
    }

  public static void setAllreference(List cbasicexpressions, List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().setreference(cbasicexpressionx, _val); } }

  public static void addAllreference(List cbasicexpressions, CBasicExpression _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().addreference(cbasicexpressionx,  _val); } }


  public static void removeAllreference(List cbasicexpressions,CBasicExpression _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().removereference(cbasicexpressionx, _val); } }


  public static void unionAllreference(List cbasicexpressions, List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().unionreference(cbasicexpressionx, _val); } }


  public static void subtractAllreference(List cbasicexpressions,  List _val)
  { for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      Controller.inst().subtractreference(cbasicexpressionx,  _val); } }


    public String getdata() { return data; }

    public static List getAlldata(List cbasicexpressions)
  { List result = new Vector();
    for (int i = 0; i < cbasicexpressions.size(); i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(i);
      if (result.contains(cbasicexpressionx.getdata())) { }
      else { result.add(cbasicexpressionx.getdata()); } }
    return result; }

    public static List getAllOrdereddata(List cbasicexpressions)
  { List result = new Vector();
    for (int i = 0; i < cbasicexpressions.size(); i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(i);
      result.add(cbasicexpressionx.getdata()); } 
    return result; }

  public List getparameters() { return (Vector) ((Vector) parameters).clone(); }

  public static List getAllparameters(List cbasicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      result = Set.union(result, cbasicexpressionx.getparameters()); }
    return result; }

  public static List getAllOrderedparameters(List cbasicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      result.addAll(cbasicexpressionx.getparameters()); }
    return result; }

  public List getarrayIndex() { return (Vector) ((Vector) arrayIndex).clone(); }

  public static List getAllarrayIndex(List cbasicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      result = Set.union(result, cbasicexpressionx.getarrayIndex()); }
    return result; }

  public static List getAllOrderedarrayIndex(List cbasicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      result = Set.union(result, cbasicexpressionx.getarrayIndex()); }
    return result; }

  public List getreference() { return (Vector) ((Vector) reference).clone(); }

  public static List getAllreference(List cbasicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      result = Set.union(result, cbasicexpressionx.getreference()); }
    return result; }

  public static List getAllOrderedreference(List cbasicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(_i);
      result = Set.union(result, cbasicexpressionx.getreference()); }
    return result; }

    public String parameterString(List p)
  {   String result = "";
 
  if (p.size() == 0) 
  {   result = "";
 
  }  else
      {   if (p.size() == 1) 
  {   result = "" + p.get(0);
 
  }  else
      if (p.size() > 1) 
  {   result = p.get(0) + ", " + this.parameterString(Set.tail(p));
 
  }   
   }     return result;
  }


    public String parString()
  {   String result = "";
 
  if (parameters.size() == 0 && kind.equals("operation")) 
  {   result = "()";
 
  }  else
      {   if (parameters.size() == 0 && !(kind.equals("operation"))) 
  {   result = "";
 
  }  else
      if (parameters.size() > 0) 
  {   result = "(" + this.parameterString(parameters) + ")";
 
  }   
   }     return result;
  }


    public String toString()
  {   String result = "";
 
  if (arrayIndex.size() == 0 && reference.size() == 0) 
  {   result = data + this.parString();
 
  }  else
      {   if (arrayIndex.size() > 0 && (((CBasicExpression) Set.any(arrayIndex)).gettype() instanceof CPrimitiveType) && reference.size() == 0) 
  {   result = data + "[" + ((CBasicExpression) Set.any(arrayIndex)) + " -1]";
 
  }  else
      {   if (arrayIndex.size() > 0 && !(((CBasicExpression) Set.any(arrayIndex)).gettype() instanceof CPrimitiveType) && reference.size() == 0) 
  {   result = "(" + type + ") lookupInMap(" + data + "," + ((CBasicExpression) Set.any(arrayIndex)) + ")";
 
  }  else
      {   if (arrayIndex.size() == 0 && reference.size() > 0) 
  {   result = ((CBasicExpression) Set.any(reference)) + "->" + data;
 
  }  else
      {   if (arrayIndex.size() > 0 && (((CBasicExpression) Set.any(arrayIndex)).gettype() instanceof CPrimitiveType) && reference.size() > 0) 
  {   result = ((CBasicExpression) Set.any(reference)) + "->" + data + "[" + ((CBasicExpression) Set.any(arrayIndex)) + " -1]";
 
  }  else
      if (arrayIndex.size() > 0 && !(((CBasicExpression) Set.any(arrayIndex)).gettype() instanceof CPrimitiveType) && reference.size() > 0) 
  {   result = "(" + type + ") lookupInMap(" + ((CBasicExpression) Set.any(reference)) + "->" + data + "," + ((CBasicExpression) Set.any(arrayIndex)) + ")";
 
  }   
   } 
   } 
   } 
   }     return result;
  }



}


abstract class Type
  implements SystemTypes
{
  protected String typeId = ""; // internal
  protected String name = ""; // internal

  public Type()
  {
    this.typeId = "";
    this.name = "";

  }



  public String toString()
  { String _res_ = "(Type) ";
    _res_ = _res_ + typeId + ",";
    _res_ = _res_ + name;
    return _res_;
  }



  public void settypeId(String typeId_x) { typeId = typeId_x;  }


    public static void setAlltypeId(List types,String val)
  { for (int i = 0; i < types.size(); i++)
    { Type typex = (Type) types.get(i);
      Controller.inst().settypeId(typex,val); } }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List types,String val)
  { for (int i = 0; i < types.size(); i++)
    { Type typex = (Type) types.get(i);
      Controller.inst().setname(typex,val); } }


    public String gettypeId() { return typeId; }

    public static List getAlltypeId(List types)
  { List result = new Vector();
    for (int i = 0; i < types.size(); i++)
    { Type typex = (Type) types.get(i);
      if (result.contains(typex.gettypeId())) { }
      else { result.add(typex.gettypeId()); } }
    return result; }

    public static List getAllOrderedtypeId(List types)
  { List result = new Vector();
    for (int i = 0; i < types.size(); i++)
    { Type typex = (Type) types.get(i);
      result.add(typex.gettypeId()); } 
    return result; }

    public String getname() { return name; }

    public static List getAllname(List types)
  { List result = new Vector();
    for (int i = 0; i < types.size(); i++)
    { Type typex = (Type) types.get(i);
      if (result.contains(typex.getname())) { }
      else { result.add(typex.getname()); } }
    return result; }

    public static List getAllOrderedname(List types)
  { List result = new Vector();
    for (int i = 0; i < types.size(); i++)
    { Type typex = (Type) types.get(i);
      result.add(typex.getname()); } 
    return result; }


}


abstract class Classifier
  extends Type
  implements SystemTypes
{

  public Classifier()
  {

  }



  public String toString()
  { String _res_ = "(Classifier) ";
    return _res_ + super.toString();
  }




}


abstract class DataType
  extends Classifier
  implements SystemTypes
{

  public DataType()
  {

  }



  public String toString()
  { String _res_ = "(DataType) ";
    return _res_ + super.toString();
  }




}


class PrimitiveType
  extends DataType
  implements SystemTypes
{

  public PrimitiveType()
  {

  }



  public String toString()
  { String _res_ = "(PrimitiveType) ";
    return _res_ + super.toString();
  }

  public static PrimitiveType parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    PrimitiveType primitivetypex = new PrimitiveType();
    return primitivetypex;
  }


  public void writeCSV(PrintWriter _out)
  { PrimitiveType primitivetypex = this;
    _out.println();
  }



}


class Entity
  extends Classifier
  implements SystemTypes
{
  private boolean isAbstract = false; // internal
  private boolean isInterface = false; // internal
  private List ownedOperation = new Vector(); // of Operation
  private List ownedAttribute = new Vector(); // of Property

  public Entity()
  {
    this.isAbstract = false;
    this.isInterface = false;

  }



  public String toString()
  { String _res_ = "(Entity) ";
    _res_ = _res_ + isAbstract + ",";
    _res_ = _res_ + isInterface;
    return _res_ + super.toString();
  }

  public static Entity parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Entity entityx = new Entity();
    entityx.isAbstract = Boolean.parseBoolean((String) _line1vals.get(0));
    entityx.isInterface = Boolean.parseBoolean((String) _line1vals.get(1));
    return entityx;
  }


  public void writeCSV(PrintWriter _out)
  { Entity entityx = this;
    _out.print("" + entityx.isAbstract);
    _out.print(" , ");
    _out.print("" + entityx.isInterface);
    _out.println();
  }


  public void setisAbstract(boolean isAbstract_x) { isAbstract = isAbstract_x;  }


    public static void setAllisAbstract(List entitys,boolean val)
  { for (int i = 0; i < entitys.size(); i++)
    { Entity entityx = (Entity) entitys.get(i);
      Controller.inst().setisAbstract(entityx,val); } }


  public void setisInterface(boolean isInterface_x) { isInterface = isInterface_x;  }


    public static void setAllisInterface(List entitys,boolean val)
  { for (int i = 0; i < entitys.size(); i++)
    { Entity entityx = (Entity) entitys.get(i);
      Controller.inst().setisInterface(entityx,val); } }


  public void setownedOperation(List ownedOperation_xx) { ownedOperation = ownedOperation_xx;
    }
 
  public void setownedOperation(int ind_x, Operation ownedOperation_xx) { if (ind_x >= 0 && ind_x < ownedOperation.size()) { ownedOperation.set(ind_x, ownedOperation_xx); } }

 public void addownedOperation(Operation ownedOperation_xx) { ownedOperation.add(ownedOperation_xx);
    }
 
  public void removeownedOperation(Operation ownedOperation_xx) { Vector _removedownedOperationownedOperation_xx = new Vector();
  _removedownedOperationownedOperation_xx.add(ownedOperation_xx);
  ownedOperation.removeAll(_removedownedOperationownedOperation_xx);
    }

  public static void setAllownedOperation(List entitys, List _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().setownedOperation(entityx, _val); } }

  public static void setAllownedOperation(List entitys, int _ind,Operation _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().setownedOperation(entityx,_ind,_val); } }

  public static void addAllownedOperation(List entitys, Operation _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().addownedOperation(entityx,  _val); } }


  public static void removeAllownedOperation(List entitys,Operation _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().removeownedOperation(entityx, _val); } }


  public static void unionAllownedOperation(List entitys, List _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().unionownedOperation(entityx, _val); } }


  public static void subtractAllownedOperation(List entitys,  List _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().subtractownedOperation(entityx,  _val); } }


  public void setownedAttribute(List ownedAttribute_xx) { ownedAttribute = ownedAttribute_xx;
    }
 
  public void addownedAttribute(Property ownedAttribute_xx) { if (ownedAttribute.contains(ownedAttribute_xx)) {} else { ownedAttribute.add(ownedAttribute_xx); }
    }
 
  public void removeownedAttribute(Property ownedAttribute_xx) { Vector _removedownedAttributeownedAttribute_xx = new Vector();
  _removedownedAttributeownedAttribute_xx.add(ownedAttribute_xx);
  ownedAttribute.removeAll(_removedownedAttributeownedAttribute_xx);
    }

  public static void setAllownedAttribute(List entitys, List _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().setownedAttribute(entityx, _val); } }

  public static void addAllownedAttribute(List entitys, Property _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().addownedAttribute(entityx,  _val); } }


  public static void removeAllownedAttribute(List entitys,Property _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().removeownedAttribute(entityx, _val); } }


  public static void unionAllownedAttribute(List entitys, List _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().unionownedAttribute(entityx, _val); } }


  public static void subtractAllownedAttribute(List entitys,  List _val)
  { for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      Controller.inst().subtractownedAttribute(entityx,  _val); } }


    public boolean getisAbstract() { return isAbstract; }

    public static List getAllisAbstract(List entitys)
  { List result = new Vector();
    for (int i = 0; i < entitys.size(); i++)
    { Entity entityx = (Entity) entitys.get(i);
      if (result.contains(new Boolean(entityx.getisAbstract()))) { }
      else { result.add(new Boolean(entityx.getisAbstract())); } }
    return result; }

    public static List getAllOrderedisAbstract(List entitys)
  { List result = new Vector();
    for (int i = 0; i < entitys.size(); i++)
    { Entity entityx = (Entity) entitys.get(i);
      result.add(new Boolean(entityx.getisAbstract())); } 
    return result; }

    public boolean getisInterface() { return isInterface; }

    public static List getAllisInterface(List entitys)
  { List result = new Vector();
    for (int i = 0; i < entitys.size(); i++)
    { Entity entityx = (Entity) entitys.get(i);
      if (result.contains(new Boolean(entityx.getisInterface()))) { }
      else { result.add(new Boolean(entityx.getisInterface())); } }
    return result; }

    public static List getAllOrderedisInterface(List entitys)
  { List result = new Vector();
    for (int i = 0; i < entitys.size(); i++)
    { Entity entityx = (Entity) entitys.get(i);
      result.add(new Boolean(entityx.getisInterface())); } 
    return result; }

  public List getownedOperation() { return (Vector) ((Vector) ownedOperation).clone(); }

  public static List getAllownedOperation(List entitys)
  { List result = new Vector();
    for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      result = Set.union(result, entityx.getownedOperation()); }
    return result; }

  public static List getAllOrderedownedOperation(List entitys)
  { List result = new Vector();
    for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      result.addAll(entityx.getownedOperation()); }
    return result; }

  public List getownedAttribute() { return (Vector) ((Vector) ownedAttribute).clone(); }

  public static List getAllownedAttribute(List entitys)
  { List result = new Vector();
    for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      result = Set.union(result, entityx.getownedAttribute()); }
    return result; }

  public static List getAllOrderedownedAttribute(List entitys)
  { List result = new Vector();
    for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx = (Entity) entitys.get(_i);
      result = Set.union(result, entityx.getownedAttribute()); }
    return result; }


}


class CollectionType
  extends DataType
  implements SystemTypes
{
  private Type elementType;
  private Type keyType;

  public CollectionType(Type elementType,Type keyType)
  {
    this.elementType = elementType;
    this.keyType = keyType;

  }

  public CollectionType() { }



  public String toString()
  { String _res_ = "(CollectionType) ";
    return _res_ + super.toString();
  }

  public static CollectionType parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CollectionType collectiontypex = new CollectionType();
    return collectiontypex;
  }


  public void writeCSV(PrintWriter _out)
  { CollectionType collectiontypex = this;
    _out.println();
  }


  public void setelementType(Type elementType_xx) { elementType = elementType_xx;
  }

  public static void setAllelementType(List collectiontypes, Type _val)
  { for (int _i = 0; _i < collectiontypes.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) collectiontypes.get(_i);
      Controller.inst().setelementType(collectiontypex, _val); } }

  public void setkeyType(Type keyType_xx) { keyType = keyType_xx;
  }

  public static void setAllkeyType(List collectiontypes, Type _val)
  { for (int _i = 0; _i < collectiontypes.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) collectiontypes.get(_i);
      Controller.inst().setkeyType(collectiontypex, _val); } }

  public Type getelementType() { return elementType; }

  public static List getAllelementType(List collectiontypes)
  { List result = new Vector();
    for (int _i = 0; _i < collectiontypes.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) collectiontypes.get(_i);
      if (result.contains(collectiontypex.getelementType())) {}
      else { result.add(collectiontypex.getelementType()); }
 }
    return result; }

  public static List getAllOrderedelementType(List collectiontypes)
  { List result = new Vector();
    for (int _i = 0; _i < collectiontypes.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) collectiontypes.get(_i);
      if (result.contains(collectiontypex.getelementType())) {}
      else { result.add(collectiontypex.getelementType()); }
 }
    return result; }

  public Type getkeyType() { return keyType; }

  public static List getAllkeyType(List collectiontypes)
  { List result = new Vector();
    for (int _i = 0; _i < collectiontypes.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) collectiontypes.get(_i);
      if (result.contains(collectiontypex.getkeyType())) {}
      else { result.add(collectiontypex.getkeyType()); }
 }
    return result; }

  public static List getAllOrderedkeyType(List collectiontypes)
  { List result = new Vector();
    for (int _i = 0; _i < collectiontypes.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) collectiontypes.get(_i);
      if (result.contains(collectiontypex.getkeyType())) {}
      else { result.add(collectiontypex.getkeyType()); }
 }
    return result; }


}


abstract class Expression
  implements SystemTypes
{
  protected boolean needsBracket = false; // internal
  protected int umlKind = value; // internal
  protected String expId = ""; // internal
  protected boolean isStatic = false; // internal
  protected Type type;
  protected Type elementType;

  public Expression(Type type,Type elementType)
  {
    this.needsBracket = false;
    this.umlKind = value;
    this.expId = "";
    this.isStatic = false;
    this.type = type;
    this.elementType = elementType;

  }

  public Expression() { }



  public String toString()
  { String _res_ = "(Expression) ";
    _res_ = _res_ + needsBracket + ",";
    _res_ = _res_ + umlKind + ",";
    _res_ = _res_ + expId + ",";
    _res_ = _res_ + isStatic;
    return _res_;
  }



  public void setneedsBracket(boolean needsBracket_x) { needsBracket = needsBracket_x;  }


    public static void setAllneedsBracket(List expressions,boolean val)
  { for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      Controller.inst().setneedsBracket(expressionx,val); } }


  public void setumlKind(int umlKind_x) { umlKind = umlKind_x;  }


    public static void setAllumlKind(List expressions,int val)
  { for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      Controller.inst().setumlKind(expressionx,val); } }


  public void setexpId(String expId_x) { expId = expId_x;  }


    public static void setAllexpId(List expressions,String val)
  { for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      Controller.inst().setexpId(expressionx,val); } }


  public void setisStatic(boolean isStatic_x) { isStatic = isStatic_x;  }


    public static void setAllisStatic(List expressions,boolean val)
  { for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      Controller.inst().setisStatic(expressionx,val); } }


  public void settype(Type type_xx) { type = type_xx;
  }

  public static void setAlltype(List expressions, Type _val)
  { for (int _i = 0; _i < expressions.size(); _i++)
    { Expression expressionx = (Expression) expressions.get(_i);
      Controller.inst().settype(expressionx, _val); } }

  public void setelementType(Type elementType_xx) { elementType = elementType_xx;
  }

  public static void setAllelementType(List expressions, Type _val)
  { for (int _i = 0; _i < expressions.size(); _i++)
    { Expression expressionx = (Expression) expressions.get(_i);
      Controller.inst().setelementType(expressionx, _val); } }

    public boolean getneedsBracket() { return needsBracket; }

    public static List getAllneedsBracket(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      if (result.contains(new Boolean(expressionx.getneedsBracket()))) { }
      else { result.add(new Boolean(expressionx.getneedsBracket())); } }
    return result; }

    public static List getAllOrderedneedsBracket(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      result.add(new Boolean(expressionx.getneedsBracket())); } 
    return result; }

    public int getumlKind() { return umlKind; }

    public static List getAllumlKind(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      if (result.contains(new Integer(expressionx.getumlKind()))) { }
      else { result.add(new Integer(expressionx.getumlKind())); } }
    return result; }

    public static List getAllOrderedumlKind(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      result.add(new Integer(expressionx.getumlKind())); } 
    return result; }

    public String getexpId() { return expId; }

    public static List getAllexpId(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      if (result.contains(expressionx.getexpId())) { }
      else { result.add(expressionx.getexpId()); } }
    return result; }

    public static List getAllOrderedexpId(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      result.add(expressionx.getexpId()); } 
    return result; }

    public boolean getisStatic() { return isStatic; }

    public static List getAllisStatic(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      if (result.contains(new Boolean(expressionx.getisStatic()))) { }
      else { result.add(new Boolean(expressionx.getisStatic())); } }
    return result; }

    public static List getAllOrderedisStatic(List expressions)
  { List result = new Vector();
    for (int i = 0; i < expressions.size(); i++)
    { Expression expressionx = (Expression) expressions.get(i);
      result.add(new Boolean(expressionx.getisStatic())); } 
    return result; }

  public Type gettype() { return type; }

  public static List getAlltype(List expressions)
  { List result = new Vector();
    for (int _i = 0; _i < expressions.size(); _i++)
    { Expression expressionx = (Expression) expressions.get(_i);
      if (result.contains(expressionx.gettype())) {}
      else { result.add(expressionx.gettype()); }
 }
    return result; }

  public static List getAllOrderedtype(List expressions)
  { List result = new Vector();
    for (int _i = 0; _i < expressions.size(); _i++)
    { Expression expressionx = (Expression) expressions.get(_i);
      if (result.contains(expressionx.gettype())) {}
      else { result.add(expressionx.gettype()); }
 }
    return result; }

  public Type getelementType() { return elementType; }

  public static List getAllelementType(List expressions)
  { List result = new Vector();
    for (int _i = 0; _i < expressions.size(); _i++)
    { Expression expressionx = (Expression) expressions.get(_i);
      if (result.contains(expressionx.getelementType())) {}
      else { result.add(expressionx.getelementType()); }
 }
    return result; }

  public static List getAllOrderedelementType(List expressions)
  { List result = new Vector();
    for (int _i = 0; _i < expressions.size(); _i++)
    { Expression expressionx = (Expression) expressions.get(_i);
      if (result.contains(expressionx.getelementType())) {}
      else { result.add(expressionx.getelementType()); }
 }
    return result; }

    public abstract CExpression mapExpression();



    public CBasicExpression createCOpCall(String id,String name)
  {   CBasicExpression result = null;
  if (Controller.inst().getCBasicExpressionByPK(id) != null)
    { CBasicExpression cbe = Controller.inst().getCBasicExpressionByPK(id);
     Controller.inst().setdata(cbe,name);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe;
  }
    else
    { CBasicExpression cbe = new CBasicExpression();
    Controller.inst().addCBasicExpression(cbe);
    Controller.inst().setcexpId(cbe,id);
    Controller.inst().setdata(cbe,name);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe; }

  return result;

  }

    public CBasicExpression createCUnaryOpCall(String id,String name,CExpression arg)
  {   CBasicExpression result = null;
  if (Controller.inst().getCBasicExpressionByPK(id) != null)
    { CBasicExpression cbe = Controller.inst().getCBasicExpressionByPK(id);
     Controller.inst().setdata(cbe,name);
    Controller.inst().addparameters(cbe,arg);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe;
  }
    else
    { CBasicExpression cbe = new CBasicExpression();
    Controller.inst().addCBasicExpression(cbe);
    Controller.inst().setcexpId(cbe,id);
    Controller.inst().setdata(cbe,name);
    Controller.inst().addparameters(cbe,arg);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe; }

  return result;

  }

    public CBasicExpression createCBinOpCall(String id,String name,CExpression le,CExpression re)
  {   CBasicExpression result = null;
  if (Controller.inst().getCBasicExpressionByPK(id) != null)
    { CBasicExpression cbe = Controller.inst().getCBasicExpressionByPK(id);
     Controller.inst().setdata(cbe,name);
    Controller.inst().addparameters(cbe,le);
    Controller.inst().addparameters(cbe,re);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe;
  }
    else
    { CBasicExpression cbe = new CBasicExpression();
    Controller.inst().addCBasicExpression(cbe);
    Controller.inst().setcexpId(cbe,id);
    Controller.inst().setdata(cbe,name);
    Controller.inst().addparameters(cbe,le);
    Controller.inst().addparameters(cbe,re);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe; }

  return result;

  }

    public CBasicExpression createCTernaryOpCall(String id,String name,CExpression arg,CExpression le,CExpression re)
  {   CBasicExpression result = null;
  if ((re.gettype() instanceof CPrimitiveType)) 
  {   if (Controller.inst().getCBasicExpressionByPK(id) != null)
    { CBasicExpression cbe = Controller.inst().getCBasicExpressionByPK(id);
     Controller.inst().setdata(cbe,name + re.gettype().getname());
    Controller.inst().addparameters(cbe,arg);
    Controller.inst().addparameters(cbe,le);
    Controller.inst().addparameters(cbe,re);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe;
  }
    else
    { CBasicExpression cbe = new CBasicExpression();
    Controller.inst().addCBasicExpression(cbe);
    Controller.inst().setcexpId(cbe,id);
    Controller.inst().setdata(cbe,name + re.gettype().getname());
    Controller.inst().addparameters(cbe,arg);
    Controller.inst().addparameters(cbe,le);
    Controller.inst().addparameters(cbe,re);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe; }
}
      if (!(re.gettype() instanceof CPrimitiveType)) 
  {   if (Controller.inst().getCBasicExpressionByPK(id) != null)
    { CBasicExpression cbe = Controller.inst().getCBasicExpressionByPK(id);
     Controller.inst().setdata(cbe,name);
    Controller.inst().addparameters(cbe,arg);
    Controller.inst().addparameters(cbe,le);
    Controller.inst().addparameters(cbe,re);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe;
  }
    else
    { CBasicExpression cbe = new CBasicExpression();
    Controller.inst().addCBasicExpression(cbe);
    Controller.inst().setcexpId(cbe,id);
    Controller.inst().setdata(cbe,name);
    Controller.inst().addparameters(cbe,arg);
    Controller.inst().addparameters(cbe,le);
    Controller.inst().addparameters(cbe,re);
    Controller.inst().setkind(cbe,"operation");
    Controller.inst().settype(cbe,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(cbe,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = cbe; }
}
  return result;

  }

    public static CUnaryExpression cast(String typ,CExpression e)
  {   CUnaryExpression result = null;
  if (Controller.inst().getCUnaryExpressionByPK(e.getcexpId() + "_cast") != null)
    { CUnaryExpression ce = Controller.inst().getCUnaryExpressionByPK(e.getcexpId() + "_cast");
     Controller.inst().setoperator(ce,"(" + typ + ") ");
    Controller.inst().setargument(ce,e);
    Controller.inst().settype(ce,e.gettype());
    Controller.inst().setelementType(ce,e.getelementType());
    result = ce;
  }
    else
    { CUnaryExpression ce = new CUnaryExpression();
    Controller.inst().addCUnaryExpression(ce);
    Controller.inst().setcexpId(ce,e.getcexpId() + "_cast");
    Controller.inst().setoperator(ce,"(" + typ + ") ");
    Controller.inst().setargument(ce,e);
    Controller.inst().settype(ce,e.gettype());
    Controller.inst().setelementType(ce,e.getelementType());
    result = ce; }

  return result;

  }

    public CExpression clength(CExpression cexp)
  {   CExpression result = null;
 
  result = this.createCUnaryOpCall(expId + "_len","length",Expression.cast("void**",cexp));
    return result;
  }


    public CStatement mapAssignment(Statement stat,CExpression cexp)
  {   CStatement result = null;
 
    if (Controller.inst().getCAssignmentByPK(stat.getstatId()) != null)
    { CAssignment ca = Controller.inst().getCAssignmentByPK(stat.getstatId());
     ca.setleft(this.mapExpression());
    ca.setright(cexp);
    result = ca;
  }
    else
    { CAssignment ca = new CAssignment();
    Controller.inst().addCAssignment(ca);
    ca.setcstatId(stat.getstatId());
    ca.setleft(this.mapExpression());
    ca.setright(cexp);
    result = ca; }

      return result;
  }


    public static String cop(String aop)
  {   String result = "";
 
  if (aop.equals("not")) 
  {   result = "!";
 
  }  else
      {   if (aop.equals("&")) 
  {   result = "&&";
 
  }  else
      {   if (aop.equals("or")) 
  {   result = "||";
 
  }  else
      {   if (aop.equals("mod")) 
  {   result = "%";
 
  }  else
      {   if (aop.equals("=")) 
  {   result = "==";
 
  }  else
      {   if (aop.equals("/=")) 
  {   result = "!=";
 
  }  else
      if (true) 
  {   result = aop;
 
  }   
   } 
   } 
   } 
   } 
   }     return result;
  }


    public static String cfunctionName(String fname)
  {   String result = "";
 
  if (fname.equals("round")) 
  {   result = "oclRound";
 
  }  else
      {   if (fname.equals("floor")) 
  {   result = "oclFloor";
 
  }  else
      {   if (fname.equals("ceil")) 
  {   result = "oclCeil";
 
  }  else
      {   if (fname.equals("abs")) 
  {   result = "fabs";
 
  }  else
      {   if (fname.equals("->toLowerCase")) 
  {   result = "toLowerCase";
 
  }  else
      {   if (fname.equals("->toUpperCase")) 
  {   result = "toUpperCase";
 
  }  else
      {   if (fname.equals("->hasPrefix") || fname.equals("hasPrefix")) 
  {   result = "startsWith";
 
  }  else
      {   if (fname.equals("->hasSuffix") || fname.equals("hasSuffix")) 
  {   result = "endsWith";
 
  }  else
      {   if (fname.equals("->characters")) 
  {   result = "characters";
 
  }  else
      {   if (fname.equals("->toInteger")) 
  {   result = "atoi";
 
  }  else
      {   if (fname.equals("->toLong")) 
  {   result = "atol";
 
  }  else
      {   if (fname.equals("->toReal")) 
  {   result = "atof";
 
  }  else
      if (true) 
  {   result = fname;
 
  }   
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   }     return result;
  }


    public static boolean isCFunction1(String fname)
  {   boolean result = false;
 
  if (fname.equals("sqrt") || fname.equals("exp") || fname.equals("log") || fname.equals("sin") || fname.equals("cos") || fname.equals("tan") || fname.equals("pow") || fname.equals("log10") || fname.equals("cbrt") || fname.equals("tanh") || fname.equals("cosh") || fname.equals("sinh") || fname.equals("asin") || fname.equals("acos") || fname.equals("atan") || fname.equals("ceil") || fname.equals("round") || fname.equals("floor") || fname.equals("abs")) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isComparitor(String fname)
  {   boolean result = false;
 
  if (fname.equals("=") || fname.equals("/=") || fname.equals("<") || fname.equals(">") || fname.equals("<=") || fname.equals(">=")) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isInclusion(String fname)
  {   boolean result = false;
 
  if (fname.equals(":") || fname.equals("->includes") || fname.equals("<:") || fname.equals("->includesAll")) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isExclusion(String fname)
  {   boolean result = false;
 
  if (fname.equals("/:") || fname.equals("/<:") || fname.equals("->excludes") || fname.equals("->excludesAll")) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isStringOp(String fname)
  {   boolean result = false;
 
  if (fname.equals("->indexOf") || fname.equals("->count") || fname.equals("->hasPrefix") || fname.equals("->hasSuffix")) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isUnaryStringOp(String fname)
  {   boolean result = false;
 
  if (fname.equals("->size") || fname.equals("->first") || fname.equals("->last") || fname.equals("->front") || fname.equals("->tail") || fname.equals("->reverse") || fname.equals("->display") || fname.equals("->toUpperCase") || fname.equals("->toLowerCase") || fname.equals("->toInteger") || fname.equals("->toReal") || fname.equals("->toLong")) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isCollectionOp(String fname)
  {   boolean result = false;
 
  if (( fname.equals("->including") || fname.equals("->excluding") || fname.equals("->append") || fname.equals("->count") || fname.equals("->indexOf") || fname.equals("->union") || fname.equals("->intersection") || fname.equals("^") || fname.equals("->isUnique") || fname.equals("->sortedBy") || fname.equals("->at") )) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isMapOp(String fname)
  {   boolean result = false;
 
  if (( fname.equals("->includingMap") || fname.equals("->union") || fname.equals("->intersection") || fname.equals("->at") || fname.equals("->restrictMap") || fname.equals("->antirestrictMap") )) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isUnaryCollectionOp(String fname)
  {   boolean result = false;
 
  if (( fname.equals("->size") || fname.equals("->any") || fname.equals("->reverse") || fname.equals("->front") || fname.equals("->tail") || fname.equals("->first") || fname.equals("->last") || fname.equals("->sort") || fname.equals("->asSet") || fname.equals("->asSequence") )) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isUnaryMapOp(String fname)
  {   boolean result = false;
 
  if (( fname.equals("->size") || fname.equals("->keys") || fname.equals("->values") || fname.equals("->any") || fname.equals("->reverse") || fname.equals("->front") || fname.equals("->tail") )) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isIteratorOp(String fname)
  {   boolean result = false;
 
  if (( fname.equals("->forAll") || fname.equals("->exists") || fname.equals("->exists1") || fname.equals("->select") || fname.equals("->reject") )) 
  {   result = true;
 
  }    return result;
  }


    public static boolean isReduceOp(String fname)
  {   boolean result = false;
 
  if (( fname.equals("->min") || fname.equals("->max") || fname.equals("->sum") || fname.equals("->prd") )) 
  {   result = true;
 
  }    return result;
  }



}


class BinaryExpression
  extends Expression
  implements SystemTypes
{
  private String operator = ""; // internal
  private String variable = ""; // internal
  private Expression left;
  private Expression right;

  public BinaryExpression(Expression left,Expression right)
  {
    this.operator = "";
    this.variable = "";
    this.left = left;
    this.right = right;

  }

  public BinaryExpression() { }



  public String toString()
  { String _res_ = "(BinaryExpression) ";
    _res_ = _res_ + operator + ",";
    _res_ = _res_ + variable;
    return _res_ + super.toString();
  }

  public static BinaryExpression parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    BinaryExpression binaryexpressionx = new BinaryExpression();
    binaryexpressionx.operator = (String) _line1vals.get(0);
    binaryexpressionx.variable = (String) _line1vals.get(1);
    return binaryexpressionx;
  }


  public void writeCSV(PrintWriter _out)
  { BinaryExpression binaryexpressionx = this;
    _out.print("" + binaryexpressionx.operator);
    _out.print(" , ");
    _out.print("" + binaryexpressionx.variable);
    _out.println();
  }


  public void setoperator(String operator_x) { operator = operator_x;  }


    public static void setAlloperator(List binaryexpressions,String val)
  { for (int i = 0; i < binaryexpressions.size(); i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(i);
      Controller.inst().setoperator(binaryexpressionx,val); } }


  public void setvariable(String variable_x) { variable = variable_x;  }


    public static void setAllvariable(List binaryexpressions,String val)
  { for (int i = 0; i < binaryexpressions.size(); i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(i);
      Controller.inst().setvariable(binaryexpressionx,val); } }


  public void setleft(Expression left_xx) { left = left_xx;
  }

  public static void setAllleft(List binaryexpressions, Expression _val)
  { for (int _i = 0; _i < binaryexpressions.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(_i);
      Controller.inst().setleft(binaryexpressionx, _val); } }

  public void setright(Expression right_xx) { right = right_xx;
  }

  public static void setAllright(List binaryexpressions, Expression _val)
  { for (int _i = 0; _i < binaryexpressions.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(_i);
      Controller.inst().setright(binaryexpressionx, _val); } }

    public String getoperator() { return operator; }

    public static List getAlloperator(List binaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < binaryexpressions.size(); i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(i);
      if (result.contains(binaryexpressionx.getoperator())) { }
      else { result.add(binaryexpressionx.getoperator()); } }
    return result; }

    public static List getAllOrderedoperator(List binaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < binaryexpressions.size(); i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(i);
      result.add(binaryexpressionx.getoperator()); } 
    return result; }

    public String getvariable() { return variable; }

    public static List getAllvariable(List binaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < binaryexpressions.size(); i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(i);
      if (result.contains(binaryexpressionx.getvariable())) { }
      else { result.add(binaryexpressionx.getvariable()); } }
    return result; }

    public static List getAllOrderedvariable(List binaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < binaryexpressions.size(); i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(i);
      result.add(binaryexpressionx.getvariable()); } 
    return result; }

  public Expression getleft() { return left; }

  public static List getAllleft(List binaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < binaryexpressions.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(_i);
      if (result.contains(binaryexpressionx.getleft())) {}
      else { result.add(binaryexpressionx.getleft()); }
 }
    return result; }

  public static List getAllOrderedleft(List binaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < binaryexpressions.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(_i);
      if (result.contains(binaryexpressionx.getleft())) {}
      else { result.add(binaryexpressionx.getleft()); }
 }
    return result; }

  public Expression getright() { return right; }

  public static List getAllright(List binaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < binaryexpressions.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(_i);
      if (result.contains(binaryexpressionx.getright())) {}
      else { result.add(binaryexpressionx.getright()); }
 }
    return result; }

  public static List getAllOrderedright(List binaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < binaryexpressions.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(_i);
      if (result.contains(binaryexpressionx.getright())) {}
      else { result.add(binaryexpressionx.getright()); }
 }
    return result; }

    public CExpression mapIteratorExpression(String op,CExpression le,CExpression re)
  {   CExpression result = null;
result = this.createCBinOpCall(this.getexpId(),op + this.getleft().getelementType().getname(),le,CExpression.defineCOpRef(((CProgram) Set.any(Controller.inst().cprograms)).defineCOp(re,variable,le.getelementType())));
  return result;

  }

    public CExpression mapMapIteratorExpression(String op,CExpression le,CExpression re)
  {   CExpression result = null;
  if (op.equals("select")) 
  { result = this.createCBinOpCall(this.getexpId(),"oclSelectMap",le,CExpression.defineCOpRef(((CProgram) Set.any(Controller.inst().cprograms)).defineCOp(re,variable,le.getelementType())));}
      if (op.equals("reject")) 
  { result = this.createCBinOpCall(this.getexpId(),"oclRejectMap",le,CExpression.defineCOpRef(((CProgram) Set.any(Controller.inst().cprograms)).defineCOp(re,variable,le.getelementType())));}
  return result;

  }

    public CExpression mapCollectExpression(String op,CExpression le,CExpression re)
  {   CExpression result = null;
result = this.createCBinOpCall(this.getexpId(),op + this.getleft().getelementType().getname(),le,CExpression.defineCOpRefCast(((CProgram) Set.any(Controller.inst().cprograms)).defineCOp(re,variable,le.getelementType()),"void* (*)(" + le.getelementType() + ")"));
  return result;

  }

    public CExpression mapMapCollectExpression(String op,CExpression le,CExpression re)
  {   CExpression result = null;
result = this.createCBinOpCall(this.getexpId(),"oclCollectMap",le,CExpression.defineCOpRefCast(((CProgram) Set.any(Controller.inst().cprograms)).defineCOp(re,variable,le.getelementType()),"void* (*)(" + le.getelementType() + ")"));
  return result;

  }

    public CExpression mapAddExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (left.gettype().getname().equals("String") && right.gettype().getname().equals("String")) 
  {   result = this.createCBinOpCall(expId,"concatenateStrings",le,re);
 
  }  else
      if (true) 
  {     if (Controller.inst().getCBinaryExpressionByPK(expId) != null)
    { CBinaryExpression ce = Controller.inst().getCBinaryExpressionByPK(expId);
     ce.setoperator("+");
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce;
  }
    else
    { CBinaryExpression ce = new CBinaryExpression();
    Controller.inst().addCBinaryExpression(ce);
    ce.setcexpId(expId);
    ce.setoperator("+");
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce; }

   
  }       return result;
  }


    public CExpression mapSubtractExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (left.gettype().getname().equals("String") && right.gettype().getname().equals("String")) 
  {   result = this.createCBinOpCall(expId,"subtractString",le,re);
 
  }  else
      {   if (left.gettype().getname().equals("Set") || left.gettype().getname().equals("Sequence")) 
  {   result = this.createCBinOpCall(expId,"removeAll" + left.getelementType().getname(),le,re);
 
  }  else
      {   if (left.gettype().getname().equals("Map")) 
  {   result = this.createCBinOpCall(expId,"oclSubtractMap",le,re);
 
  }  else
      if (true) 
  {     if (Controller.inst().getCBinaryExpressionByPK(expId) != null)
    { CBinaryExpression ce = Controller.inst().getCBinaryExpressionByPK(expId);
     ce.setoperator("-");
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce;
  }
    else
    { CBinaryExpression ce = new CBinaryExpression();
    Controller.inst().addCBinaryExpression(ce);
    ce.setoperator("-");
    ce.setcexpId(expId);
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce; }

   
  }   
   } 
   }     return result;
  }


    public CExpression mapComparitorExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (left.gettype().getname().equals("String") && right.gettype().getname().equals("String")) 
  {     if (Controller.inst().getCBinaryExpressionByPK(expId) != null)
    { CBinaryExpression be = Controller.inst().getCBinaryExpressionByPK(expId);
     be.setoperator(Expression.cop(operator));
    be.setleft(this.createCBinOpCall(expId + "_strcmp","strcmp",le,re));
      if (Controller.inst().getCBasicExpressionByPK(expId + "_0") != null)
    { CBasicExpression zero = Controller.inst().getCBasicExpressionByPK(expId + "_0");
     zero.setdata("0");
    be.setright(zero);
  }
    else
    { CBasicExpression zero = new CBasicExpression();
    Controller.inst().addCBasicExpression(zero);
    zero.setdata("0");
    zero.setcexpId(expId + "_0");
    be.setright(zero); }

    be.setneedsBracket(true);
    result = be;
  }
    else
    { CBinaryExpression be = new CBinaryExpression();
    Controller.inst().addCBinaryExpression(be);
    be.setcexpId(expId);
    be.setoperator(Expression.cop(operator));
    be.setleft(this.createCBinOpCall(expId + "_strcmp","strcmp",le,re));
      if (Controller.inst().getCBasicExpressionByPK(expId + "_0") != null)
    { CBasicExpression zero = Controller.inst().getCBasicExpressionByPK(expId + "_0");
     zero.setdata("0");
    be.setright(zero);
  }
    else
    { CBasicExpression zero = new CBasicExpression();
    Controller.inst().addCBasicExpression(zero);
    zero.setdata("0");
    zero.setcexpId(expId + "_0");
    be.setright(zero); }

    be.setneedsBracket(true);
    result = be; }

   
  }  else
      if (true) 
  {     if (Controller.inst().getCBinaryExpressionByPK(expId) != null)
    { CBinaryExpression ce = Controller.inst().getCBinaryExpressionByPK(expId);
     ce.setoperator(operator);
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce;
  }
    else
    { CBinaryExpression ce = new CBinaryExpression();
    Controller.inst().addCBinaryExpression(ce);
    ce.setcexpId(expId);
    ce.setoperator(operator);
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce; }

   
  }       return result;
  }


    public CExpression mapEqualityExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (left.gettype().getname().equals("String") && right.gettype().getname().equals("String")) 
  {   result = this.mapComparitorExpression(le,re);
 
  }  else
      {   if (left.gettype().getname().equals("Set")) 
  {   result = this.createCBinOpCall(expId,"equalsSet",Expression.cast("void**",le),Expression.cast("void**",re));
 
  }  else
      {   if (left.gettype().getname().equals("Sequence")) 
  {   result = this.createCBinOpCall(expId,"equalsSequence",Expression.cast("void**",le),Expression.cast("void**",re));
 
  }  else
      if (true) 
  {     if (Controller.inst().getCBinaryExpressionByPK(expId) != null)
    { CBinaryExpression ce = Controller.inst().getCBinaryExpressionByPK(expId);
     ce.setoperator("==");
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce;
  }
    else
    { CBinaryExpression ce = new CBinaryExpression();
    Controller.inst().addCBinaryExpression(ce);
    ce.setcexpId(expId);
    ce.setoperator("==");
    ce.setleft(le);
    ce.setright(re);
    ce.setneedsBracket(needsBracket);
    ce.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    ce.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = ce; }

   
  }   
   } 
   }     return result;
  }


    public CExpression mapInclusionExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (operator.equals(":")) 
  {   result = this.createCBinOpCall(expId,"isIn",Expression.cast("void*",le),Expression.cast("void**",re));
 
  }  else
      {   if (operator.equals("->includes")) 
  {   result = this.createCBinOpCall(expId,"isIn",Expression.cast("void*",re),Expression.cast("void**",le));
 
  }  else
      {   if (operator.equals("->includesAll")) 
  {   result = this.createCBinOpCall(expId,"containsAll",Expression.cast("void**",le),Expression.cast("void**",re));
 
  }  else
      if (operator.equals("<:")) 
  {   result = this.createCBinOpCall(expId,"containsAll",Expression.cast("void**",re),Expression.cast("void**",le));
 
  }   
   } 
   }     return result;
  }


    public CExpression mapExclusionExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (operator.equals("/:")) 
  {     if (Controller.inst().getCUnaryExpressionByPK(expId) != null)
    { CUnaryExpression nin = Controller.inst().getCUnaryExpressionByPK(expId);
     nin.setoperator("!");
    nin.setargument(this.createCBinOpCall(expId + "_isIn","isIn",Expression.cast("void*",le),Expression.cast("void**",re)));
    nin.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    nin.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = nin;
  }
    else
    { CUnaryExpression nin = new CUnaryExpression();
    Controller.inst().addCUnaryExpression(nin);
    nin.setcexpId(expId);
    nin.setoperator("!");
    nin.setargument(this.createCBinOpCall(expId + "_isIn","isIn",Expression.cast("void*",le),Expression.cast("void**",re)));
    nin.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    nin.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = nin; }

   
  }  else
      {   if (operator.equals("->excludes")) 
  {     if (Controller.inst().getCUnaryExpressionByPK(expId) != null)
    { CUnaryExpression nin = Controller.inst().getCUnaryExpressionByPK(expId);
     nin.setoperator("!");
    nin.setargument(this.createCBinOpCall(expId + "_isIn","isIn",Expression.cast("void*",re),Expression.cast("void**",le)));
    nin.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    nin.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = nin;
  }
    else
    { CUnaryExpression nin = new CUnaryExpression();
    Controller.inst().addCUnaryExpression(nin);
    nin.setcexpId(expId);
    nin.setoperator("!");
    nin.setargument(this.createCBinOpCall(expId + "_isIn","isIn",Expression.cast("void*",re),Expression.cast("void**",le)));
    nin.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    nin.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = nin; }

   
  }  else
      {   if (operator.equals("->excludesAll")) 
  {   result = this.createCBinOpCall(expId,"disjoint",Expression.cast("void**",le),Expression.cast("void**",re));
 
  }  else
      if (operator.equals("/<:")) 
  {     if (Controller.inst().getCUnaryExpressionByPK(expId) != null)
    { CUnaryExpression nin = Controller.inst().getCUnaryExpressionByPK(expId);
     nin.setoperator("!");
    nin.setargument(this.createCBinOpCall(expId + "_containsAll","containsAll",Expression.cast("void**",re),Expression.cast("void**",le)));
    nin.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    nin.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = nin;
  }
    else
    { CUnaryExpression nin = new CUnaryExpression();
    Controller.inst().addCUnaryExpression(nin);
    nin.setcexpId(expId);
    nin.setoperator("!");
    nin.setargument(this.createCBinOpCall(expId + "_containsAll","containsAll",Expression.cast("void**",re),Expression.cast("void**",le)));
    nin.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    nin.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = nin; }

   
  }   
   } 
   }     return result;
  }


    public CExpression mapStringExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (operator.equals("->count")) 
  {   result = this.createCBinOpCall(expId,"countString",le,re);
 
  }  else
      {   if (operator.equals("->indexOf")) 
  {   result = this.createCBinOpCall(expId,"indexOfString",le,re);
 
  }  else
      if (true) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression be = Controller.inst().getCBasicExpressionByPK(expId);
     be.setdata(Expression.cfunctionName(operator));
    Controller.inst().addparameters(be,le);
    Controller.inst().addparameters(be,re);
    result = be;
  }
    else
    { CBasicExpression be = new CBasicExpression();
    Controller.inst().addCBasicExpression(be);
    be.setcexpId(expId);
    be.setdata(Expression.cfunctionName(operator));
    Controller.inst().addparameters(be,le);
    Controller.inst().addparameters(be,re);
    result = be; }

   
  }   
   }     return result;
  }


    public CExpression mapCollectionExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (operator.equals("->including") && left.gettype().getname().equals("Set")) 
  {   result = this.createCBinOpCall(expId,"insert" + left.getelementType().getname(),le,re);
 
  }  else
      {   if (operator.equals("->including") && left.gettype().getname().equals("Sequence")) 
  {   result = this.createCBinOpCall(expId,"append" + left.getelementType().getname(),le,re);
 
  }  else
      {   if (operator.equals("->excluding")) 
  {   result = this.createCBinOpCall(expId,"remove" + left.getelementType().getname(),le,re);
 
  }  else
      {   if (operator.equals("->append")) 
  {   result = this.createCBinOpCall(expId,"append" + left.getelementType().getname(),le,re);
 
  }  else
      {   if (operator.equals("->count")) 
  {   result = this.createCBinOpCall(expId,"count",Expression.cast("void*",re),Expression.cast("void**",le));
 
  }  else
      {   if (operator.equals("->at") && left.gettype().getname().equals("Sequence")) 
  {   result = Expression.cast("" + le.getelementType(),this.createCBinOpCall(expId,"at",Expression.cast("void**",le),re));
 
  }  else
      {   if (operator.equals("->indexOf")) 
  {   result = this.createCBinOpCall(expId,"indexOf",Expression.cast("void*",re),Expression.cast("void**",le));
 
  }  else
      {   if (operator.equals("->union")) 
  {   result = this.createCBinOpCall(expId,"union" + left.getelementType().getname(),le,re);
 
  }  else
      {   if (operator.equals("^")) 
  {   result = this.createCBinOpCall(expId,"concatenate" + left.getelementType().getname(),le,re);
 
  }  else
      {   if (operator.equals("->intersection")) 
  {   result = this.createCBinOpCall(expId,"intersection" + left.getelementType().getname(),le,re);
 
  }  else
      if (operator.equals("->isUnique")) 
  {   result = this.createCBinOpCall(expId,"isUnique" + left.getelementType().getname(),le,re);
 
  }   
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapMapExpression(CExpression le,CExpression re)
  {   CExpression result = null;
 
  if (operator.equals("->includingMap") && (re instanceof CBinaryExpression)) 
  {   result = this.createCTernaryOpCall(expId,"insertIntoMap",le,((CBinaryExpression) re).getleft(),((CBinaryExpression) re).getright());
 
  }  else
      {   if (operator.equals("->at")) 
  {   result = Expression.cast("" + le.getelementType(),this.createCBinOpCall(expId,"lookupInMap",Expression.cast("struct ocltnode*",le),re));
 
  }  else
      {   if (operator.equals("->union")) 
  {   result = this.createCBinOpCall(expId,"oclUnionMap",le,re);
 
  }  else
      {   if (operator.equals("->intersection")) 
  {   result = this.createCBinOpCall(expId,"oclIntersectionMap",le,re);
 
  }  else
      {   if (operator.equals("->restrict")) 
  {   result = this.createCBinOpCall(expId,"restrictMap",le,re);
 
  }  else
      if (operator.equals("->antirestrict")) 
  {   result = this.createCBinOpCall(expId,"antirestrictMap",le,re);
 
  }   
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapBinaryExpression(CExpression lexp,CExpression rexp)
  {   CExpression result = null;
 
  if (operator.equals("+")) 
  {   result = this.mapAddExpression(lexp,rexp);
 
  }  else
      {   if (operator.equals("-")) 
  {   result = this.mapSubtractExpression(lexp,rexp);
 
  }  else
      {   if (operator.equals("=")) 
  {   result = this.mapEqualityExpression(lexp,rexp);
 
  }  else
      {   if (operator.equals("->pow")) 
  {   result = this.createCBinOpCall(expId,"pow",lexp,rexp);
 
  }  else
      {   if (Expression.isComparitor(operator)) 
  {   result = this.mapComparitorExpression(lexp,rexp);
 
  }  else
      {   if (Expression.isInclusion(operator)) 
  {   result = this.mapInclusionExpression(lexp,rexp);
 
  }  else
      {   if (Expression.isExclusion(operator)) 
  {   result = this.mapExclusionExpression(lexp,rexp);
 
  }  else
      {   if (left.gettype().getname().equals("Map") && Expression.isIteratorOp(operator)) 
  {   result = this.mapMapIteratorExpression(operator.substring(1,operator.length()).substring(1,operator.substring(1,operator.length()).length()),lexp,rexp);
 
  }  else
      {   if (!(left.gettype().getname().equals("Map")) && Expression.isIteratorOp(operator)) 
  {   result = this.mapIteratorExpression(operator.substring(1,operator.length()).substring(1,operator.substring(1,operator.length()).length()),lexp,rexp);
 
  }  else
      {   if (left.gettype().getname().equals("Map") && operator.equals("->collect")) 
  {   result = Expression.cast(rexp.gettype() + "*",this.mapMapCollectExpression("collect",lexp,rexp));
 
  }  else
      {   if (!(left.gettype().getname().equals("Map")) && operator.equals("->collect")) 
  {   result = Expression.cast(rexp.gettype() + "*",this.mapCollectExpression("collect",lexp,rexp));
 
  }  else
      {   if (left.gettype().getname().equals("String") && Expression.isStringOp(operator)) 
  {   result = this.mapStringExpression(lexp,rexp);
 
  }  else
      {   if (( left.gettype().getname().equals("Set") || left.gettype().getname().equals("Sequence") ) && Expression.isCollectionOp(operator)) 
  {   result = this.mapCollectionExpression(lexp,rexp);
 
  }  else
      {   if (left.gettype().getname().equals("Map") && Expression.isMapOp(operator)) 
  {   result = this.mapMapExpression(lexp,rexp);
 
  }  else
      if (true) 
  {     if (Controller.inst().getCBinaryExpressionByPK(expId) != null)
    { CBinaryExpression c = Controller.inst().getCBinaryExpressionByPK(expId);
     c.setleft(lexp);
    c.setright(rexp);
    c.setoperator(Expression.cop(operator));
    c.setneedsBracket(needsBracket);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBinaryExpression c = new CBinaryExpression();
    Controller.inst().addCBinaryExpression(c);
    c.setcexpId(expId);
    c.setleft(lexp);
    c.setright(rexp);
    c.setoperator(Expression.cop(operator));
    c.setneedsBracket(needsBracket);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }   
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapExpression()
  {   CExpression result = null;
result = this.mapBinaryExpression(this.getleft().mapExpression(),this.getright().mapExpression());
  return result;

  }

    public CExpression clength(CExpression cexp)
  {   CExpression result = null;
 
  if (operator.equals("->collect")) 
  {   result = this.createCUnaryOpCall(expId + "_len","length",Expression.cast("void**",left.mapExpression()));
 
  }  else
      if (true) 
  {   result = this.createCUnaryOpCall(expId + "_len","length",Expression.cast("void**",cexp));
 
  }       return result;
  }



}


class UnaryExpression
  extends Expression
  implements SystemTypes
{
  private String operator = ""; // internal
  private String variable = ""; // internal
  private Expression argument;

  public UnaryExpression(Expression argument)
  {
    this.operator = "";
    this.variable = "";
    this.argument = argument;

  }

  public UnaryExpression() { }



  public String toString()
  { String _res_ = "(UnaryExpression) ";
    _res_ = _res_ + operator + ",";
    _res_ = _res_ + variable;
    return _res_ + super.toString();
  }

  public static UnaryExpression parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    UnaryExpression unaryexpressionx = new UnaryExpression();
    unaryexpressionx.operator = (String) _line1vals.get(0);
    unaryexpressionx.variable = (String) _line1vals.get(1);
    return unaryexpressionx;
  }


  public void writeCSV(PrintWriter _out)
  { UnaryExpression unaryexpressionx = this;
    _out.print("" + unaryexpressionx.operator);
    _out.print(" , ");
    _out.print("" + unaryexpressionx.variable);
    _out.println();
  }


  public void setoperator(String operator_x) { operator = operator_x;  }


    public static void setAlloperator(List unaryexpressions,String val)
  { for (int i = 0; i < unaryexpressions.size(); i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(i);
      Controller.inst().setoperator(unaryexpressionx,val); } }


  public void setvariable(String variable_x) { variable = variable_x;  }


    public static void setAllvariable(List unaryexpressions,String val)
  { for (int i = 0; i < unaryexpressions.size(); i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(i);
      Controller.inst().setvariable(unaryexpressionx,val); } }


  public void setargument(Expression argument_xx) { argument = argument_xx;
  }

  public static void setAllargument(List unaryexpressions, Expression _val)
  { for (int _i = 0; _i < unaryexpressions.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(_i);
      Controller.inst().setargument(unaryexpressionx, _val); } }

    public String getoperator() { return operator; }

    public static List getAlloperator(List unaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < unaryexpressions.size(); i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(i);
      if (result.contains(unaryexpressionx.getoperator())) { }
      else { result.add(unaryexpressionx.getoperator()); } }
    return result; }

    public static List getAllOrderedoperator(List unaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < unaryexpressions.size(); i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(i);
      result.add(unaryexpressionx.getoperator()); } 
    return result; }

    public String getvariable() { return variable; }

    public static List getAllvariable(List unaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < unaryexpressions.size(); i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(i);
      if (result.contains(unaryexpressionx.getvariable())) { }
      else { result.add(unaryexpressionx.getvariable()); } }
    return result; }

    public static List getAllOrderedvariable(List unaryexpressions)
  { List result = new Vector();
    for (int i = 0; i < unaryexpressions.size(); i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(i);
      result.add(unaryexpressionx.getvariable()); } 
    return result; }

  public Expression getargument() { return argument; }

  public static List getAllargument(List unaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < unaryexpressions.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(_i);
      if (result.contains(unaryexpressionx.getargument())) {}
      else { result.add(unaryexpressionx.getargument()); }
 }
    return result; }

  public static List getAllOrderedargument(List unaryexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < unaryexpressions.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(_i);
      if (result.contains(unaryexpressionx.getargument())) {}
      else { result.add(unaryexpressionx.getargument()); }
 }
    return result; }

    public CExpression mapReduceExpression(CExpression arg)
  {   CExpression result = null;
 
  if (("" + operator.charAt(0)).equals("-") && ("" + operator.charAt(1)).equals(">")) 
  {   result = this.createCBinOpCall(expId,operator.substring(1,operator.length()).substring(1,operator.substring(1,operator.length()).length()) + argument.getelementType().getname(),arg,argument.clength(arg));
 
  }  else
      if (true) 
  {   result = this.createCBinOpCall(expId,operator + argument.getelementType().getname(),arg,argument.clength(arg));
 
  }       return result;
  }


    public CExpression mapStringExpression(CExpression arg)
  {   CExpression result = null;
 
  if (operator.equals("->size")) 
  {   result = this.createCUnaryOpCall(expId,"strlen",arg);
 
  }  else
      {   if (operator.equals("->first")) 
  {   result = this.createCUnaryOpCall(expId,"firstString",arg);
 
  }  else
      {   if (operator.equals("->last")) 
  {   result = this.createCUnaryOpCall(expId,"lastString",arg);
 
  }  else
      {   if (operator.equals("->front")) 
  {   result = this.createCUnaryOpCall(expId,"frontString",arg);
 
  }  else
      {   if (operator.equals("->tail")) 
  {   result = this.createCUnaryOpCall(expId,"tailString",arg);
 
  }  else
      {   if (operator.equals("->reverse")) 
  {   result = this.createCUnaryOpCall(expId,"reverseString",arg);
 
  }  else
      {   if (operator.equals("->display")) 
  {   result = this.createCUnaryOpCall(expId,"displayString",arg);
 
  }  else
      if (true) 
  {   result = this.createCUnaryOpCall(expId,Expression.cfunctionName(operator),arg);
 
  }   
   } 
   } 
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapCollectionExpression(CExpression arg)
  {   CExpression result = null;
 
  if (operator.equals("->size")) 
  {   result = this.createCUnaryOpCall(expId,"length",Expression.cast("void**",arg));
 
  }  else
      {   if (operator.equals("->any")) 
  {   result = this.createCUnaryOpCall(expId,"any",Expression.cast("void**",arg));
 
  }  else
      {   if (operator.equals("->first")) 
  {   result = this.createCUnaryOpCall(expId,"first",Expression.cast("void**",arg));
 
  }  else
      {   if (operator.equals("->last")) 
  {   result = this.createCUnaryOpCall(expId,"last",Expression.cast("void**",arg));
 
  }  else
      {   if (operator.equals("->front")) 
  {   result = this.createCUnaryOpCall(expId,"front" + elementType.getname(),arg);
 
  }  else
      {   if (operator.equals("->tail")) 
  {   result = this.createCUnaryOpCall(expId,"tail" + elementType.getname(),arg);
 
  }  else
      {   if (operator.equals("->reverse")) 
  {   result = this.createCUnaryOpCall(expId,"reverse" + elementType.getname(),arg);
 
  }  else
      {   if (operator.equals("->asSet")) 
  {   result = this.createCUnaryOpCall(expId,"asSet" + elementType.getname(),arg);
 
  }  else
      {   if (operator.equals("->asSequence")) 
  {   result = arg;
 
  }  else
      if (true) 
  {   result = this.createCUnaryOpCall(expId,Expression.cfunctionName(operator),arg);
 
  }   
   } 
   } 
   } 
   } 
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapMapExpression(CExpression arg)
  {   CExpression result = null;
 
  if (operator.equals("->size")) 
  {   result = this.createCUnaryOpCall(expId,"oclSize",arg);
 
  }  else
      {   if (operator.equals("->keys")) 
  {   result = this.createCUnaryOpCall(expId,"oclKeyset",arg);
 
  }  else
      {   if (operator.equals("->values")) 
  {   result = this.createCUnaryOpCall(expId,"oclValues",arg);
 
  }  else
      {   if (operator.equals("->front")) 
  {   result = this.createCUnaryOpCall(expId,"oclFront",arg);
 
  }  else
      {   if (operator.equals("->tail")) 
  {   result = this.createCUnaryOpCall(expId,"oclTail",arg);
 
  }  else
      if (operator.equals("->reverse")) 
  {   result = this.createCUnaryOpCall(expId,"oclReverse",arg);
 
  }   
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapSortExpression(CExpression arg)
  {   CExpression result = null;
 
  if (elementType.getname().equals("String")) 
  {   result = Expression.cast("char**",this.createCBinOpCall(expId,"treesort",Expression.cast("void**",arg),CExpression.defineCOpReference("compareTo_String","int")));
 
  }  else
      if (true) 
  {   result = Expression.cast("struct " + elementType.getname() + "**",this.createCBinOpCall(expId,"treesort",Expression.cast("void**",arg),CExpression.defineCOpReference("compareTo_" + elementType.getname(),"int")));
 
  }       return result;
  }


    public static CExpression mapLambdaExpression(CExpression arg,String v,CType t)
  {   CExpression result = null;
 
  final COperation op = ((CProgram) Set.any(Controller.inst().cprograms)).defineCOp(arg,v,arg.gettype()); 
     result = CExpression.newCBasicExpression(op.getname(),t);
       return result;
  }


    public CExpression mapUnaryExpression(CExpression arg)
  {   CExpression result = null;
 
  if (operator.equals("->sort")) 
  {   result = this.mapSortExpression(arg);
 
  }  else
      {   if (operator.equals("lambda")) 
  {   result = UnaryExpression.mapLambdaExpression(arg,variable,Controller.inst().getCTypeByPK(type.gettypeId()));
 
  }  else
      {   if (Expression.isReduceOp(operator)) 
  {   result = this.mapReduceExpression(arg);
 
  }  else
      {   if (argument.gettype().getname().equals("String") && Expression.isUnaryStringOp(operator)) 
  {   result = this.mapStringExpression(arg);
 
  }  else
      {   if (operator.equals("->display")) 
  {   result = this.createCUnaryOpCall(expId,"display" + argument.gettype(),arg);
 
  }  else
      {   if (( argument.gettype().getname().equals("Set") || argument.gettype().getname().equals("Sequence") ) && Expression.isUnaryCollectionOp(operator)) 
  {   result = this.mapCollectionExpression(arg);
 
  }  else
      {   if (argument.gettype().getname().equals("Map") && Expression.isUnaryMapOp(operator)) 
  {   result = this.mapMapExpression(arg);
 
  }  else
      {   if (operator.length() > 2 && Expression.isCFunction1(operator.substring(1,operator.length()).substring(1,operator.substring(1,operator.length()).length()))) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setdata(Expression.cfunctionName(operator.substring(1,operator.length()).substring(1,operator.substring(1,operator.length()).length())));
    c.setkind("function");
    c.setparameters((new SystemTypes.Set()).add(arg).getElements());
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setdata(Expression.cfunctionName(operator.substring(1,operator.length()).substring(1,operator.substring(1,operator.length()).length())));
    c.setkind("function");
    c.setparameters((new SystemTypes.Set()).add(arg).getElements());
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }  else
      if (true) 
  {     if (Controller.inst().getCUnaryExpressionByPK(expId) != null)
    { CUnaryExpression c = Controller.inst().getCUnaryExpressionByPK(expId);
     c.setoperator(Expression.cop(operator));
    c.setargument(arg);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CUnaryExpression c = new CUnaryExpression();
    Controller.inst().addCUnaryExpression(c);
    c.setcexpId(expId);
    c.setoperator(Expression.cop(operator));
    c.setargument(arg);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }   
   } 
   } 
   } 
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapExpression()
  {   CExpression result = null;
result = this.mapUnaryExpression(this.getargument().mapExpression());
  return result;

  }


}


class CollectionExpression
  extends Expression
  implements SystemTypes
{
  private boolean isOrdered = false; // internal
  private List elements = new Vector(); // of Expression

  public CollectionExpression()
  {
    this.isOrdered = false;

  }



  public String toString()
  { String _res_ = "(CollectionExpression) ";
    _res_ = _res_ + isOrdered;
    return _res_ + super.toString();
  }

  public static CollectionExpression parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CollectionExpression collectionexpressionx = new CollectionExpression();
    collectionexpressionx.isOrdered = Boolean.parseBoolean((String) _line1vals.get(0));
    return collectionexpressionx;
  }


  public void writeCSV(PrintWriter _out)
  { CollectionExpression collectionexpressionx = this;
    _out.print("" + collectionexpressionx.isOrdered);
    _out.println();
  }


  public void setisOrdered(boolean isOrdered_x) { isOrdered = isOrdered_x;  }


    public static void setAllisOrdered(List collectionexpressions,boolean val)
  { for (int i = 0; i < collectionexpressions.size(); i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(i);
      Controller.inst().setisOrdered(collectionexpressionx,val); } }


  public void setelements(List elements_xx) { elements = elements_xx;
    }
 
  public void addelements(Expression elements_xx) { if (elements.contains(elements_xx)) {} else { elements.add(elements_xx); }
    }
 
  public void removeelements(Expression elements_xx) { Vector _removedelementselements_xx = new Vector();
  _removedelementselements_xx.add(elements_xx);
  elements.removeAll(_removedelementselements_xx);
    }

  public static void setAllelements(List collectionexpressions, List _val)
  { for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(_i);
      Controller.inst().setelements(collectionexpressionx, _val); } }

  public static void addAllelements(List collectionexpressions, Expression _val)
  { for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(_i);
      Controller.inst().addelements(collectionexpressionx,  _val); } }


  public static void removeAllelements(List collectionexpressions,Expression _val)
  { for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(_i);
      Controller.inst().removeelements(collectionexpressionx, _val); } }


  public static void unionAllelements(List collectionexpressions, List _val)
  { for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(_i);
      Controller.inst().unionelements(collectionexpressionx, _val); } }


  public static void subtractAllelements(List collectionexpressions,  List _val)
  { for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(_i);
      Controller.inst().subtractelements(collectionexpressionx,  _val); } }


    public boolean getisOrdered() { return isOrdered; }

    public static List getAllisOrdered(List collectionexpressions)
  { List result = new Vector();
    for (int i = 0; i < collectionexpressions.size(); i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(i);
      if (result.contains(new Boolean(collectionexpressionx.getisOrdered()))) { }
      else { result.add(new Boolean(collectionexpressionx.getisOrdered())); } }
    return result; }

    public static List getAllOrderedisOrdered(List collectionexpressions)
  { List result = new Vector();
    for (int i = 0; i < collectionexpressions.size(); i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(i);
      result.add(new Boolean(collectionexpressionx.getisOrdered())); } 
    return result; }

  public List getelements() { return (Vector) ((Vector) elements).clone(); }

  public static List getAllelements(List collectionexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(_i);
      result = Set.union(result, collectionexpressionx.getelements()); }
    return result; }

  public static List getAllOrderedelements(List collectionexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(_i);
      result = Set.union(result, collectionexpressionx.getelements()); }
    return result; }

    public CExpression mapCollectionMapExpression(String id,List elems)
  {   CExpression result = null;
 
  if (elems.size() == 0) 
  {   result = CExpression.newCBasicExpression("NULL",CPrimitiveType.newCPrimitiveType(id + "_type","void*"));
 
  }  else
        if (elems.size() > 0)
    {   CExpression lst = ((CExpression) Set.last(elems));
      if ((lst instanceof CBinaryExpression))
    {    result = this.createCTernaryOpCall(id,"insertIntoMap",this.mapCollectionMapExpression(id + "_f",Set.front(elems)),((CBinaryExpression) lst).getleft(),((CBinaryExpression) lst).getright()); }

 }
       return result;
  }


    public CExpression mapCollectionExpression(String id,List elems)
  {   CExpression result = null;
 
  if (elems.size() == 0) 
  {   result = this.createCOpCall(id,"new" + elementType.getname() + "List");
 
  }  else
      {   if (elems.size() > 0 && type.getname().equals("Set")) 
  {   result = this.createCBinOpCall(id,"insert" + elementType.getname(),this.mapCollectionExpression(id + "_f",Set.front(elems)),((CExpression) Set.last(elems)));
 
  }  else
      if (elems.size() > 0 && type.getname().equals("Sequence")) 
  {   result = this.createCBinOpCall(id,"append" + elementType.getname(),this.mapCollectionExpression(id + "_f",Set.front(elems)),((CExpression) Set.last(elems)));
 
  }   
   }     return result;
  }


    public CExpression clength(CExpression cexp)
  {   CExpression result = null;
 
    if (Controller.inst().getCBasicExpressionByPK(expId + "_len") != null)
    { CBasicExpression b = Controller.inst().getCBasicExpressionByPK(expId + "_len");
     b.setdata(elements.size() + "");
      if (Controller.inst().getCPrimitiveTypeByPK(expId + "_len") != null)
    { CPrimitiveType t = Controller.inst().getCPrimitiveTypeByPK(expId + "_len");
     t.setname("int");
    b.settype(t);
    b.setelementType(t);
  }
    else
    { CPrimitiveType t = new CPrimitiveType();
    Controller.inst().addCPrimitiveType(t);
    t.setname("int");
    t.setctypeId(expId + "_len");
    b.settype(t);
    b.setelementType(t); }

    result = b;
  }
    else
    { CBasicExpression b = new CBasicExpression();
    Controller.inst().addCBasicExpression(b);
    b.setcexpId(expId + "_len");
    b.setdata(elements.size() + "");
      if (Controller.inst().getCPrimitiveTypeByPK(expId + "_len") != null)
    { CPrimitiveType t = Controller.inst().getCPrimitiveTypeByPK(expId + "_len");
     t.setname("int");
    b.settype(t);
    b.setelementType(t);
  }
    else
    { CPrimitiveType t = new CPrimitiveType();
    Controller.inst().addCPrimitiveType(t);
    t.setname("int");
    t.setctypeId(expId + "_len");
    b.settype(t);
    b.setelementType(t); }

    result = b; }

      return result;
  }


    public CExpression mapExpression()
  {   CExpression result = null;
  if (this.gettype().getname().equals("Map")) 
  { result = this.mapCollectionMapExpression(this.getexpId(),  Controller.inst().AllExpressionmapExpression(this.getelements()));}
      if (!(this.gettype().getname().equals("Map"))) 
  { result = this.mapCollectionExpression(this.getexpId(),  Controller.inst().AllExpressionmapExpression(this.getelements()));}
  return result;

  }


}


class BasicExpression
  extends Expression
  implements SystemTypes
{
  private String data = ""; // internal
  private boolean prestate = false; // internal
  private List parameters = new Vector(); // of Expression
  private List referredProperty = new Vector(); // of Property
  private List context = new Vector(); // of Entity
  private List arrayIndex = new Vector(); // of BasicExpression
  private List objectRef = new Vector(); // of BasicExpression

  public BasicExpression()
  {
    this.data = "";
    this.prestate = false;

  }



  public String toString()
  { String _res_ = "(BasicExpression) ";
    _res_ = _res_ + data + ",";
    _res_ = _res_ + prestate;
    return _res_ + super.toString();
  }

  public static BasicExpression parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    BasicExpression basicexpressionx = new BasicExpression();
    basicexpressionx.data = (String) _line1vals.get(0);
    basicexpressionx.prestate = Boolean.parseBoolean((String) _line1vals.get(1));
    return basicexpressionx;
  }


  public void writeCSV(PrintWriter _out)
  { BasicExpression basicexpressionx = this;
    _out.print("" + basicexpressionx.data);
    _out.print(" , ");
    _out.print("" + basicexpressionx.prestate);
    _out.println();
  }


  public void setdata(String data_x) { data = data_x;  }


    public static void setAlldata(List basicexpressions,String val)
  { for (int i = 0; i < basicexpressions.size(); i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(i);
      Controller.inst().setdata(basicexpressionx,val); } }


  public void setprestate(boolean prestate_x) { prestate = prestate_x;  }


    public static void setAllprestate(List basicexpressions,boolean val)
  { for (int i = 0; i < basicexpressions.size(); i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(i);
      Controller.inst().setprestate(basicexpressionx,val); } }


  public void setparameters(List parameters_xx) { parameters = parameters_xx;
    }
 
  public void setparameters(int ind_x, Expression parameters_xx) { if (ind_x >= 0 && ind_x < parameters.size()) { parameters.set(ind_x, parameters_xx); } }

 public void addparameters(Expression parameters_xx) { parameters.add(parameters_xx);
    }
 
  public void removeparameters(Expression parameters_xx) { Vector _removedparametersparameters_xx = new Vector();
  _removedparametersparameters_xx.add(parameters_xx);
  parameters.removeAll(_removedparametersparameters_xx);
    }

  public static void setAllparameters(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().setparameters(basicexpressionx, _val); } }

  public static void setAllparameters(List basicexpressions, int _ind,Expression _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().setparameters(basicexpressionx,_ind,_val); } }

  public static void addAllparameters(List basicexpressions, Expression _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().addparameters(basicexpressionx,  _val); } }


  public static void removeAllparameters(List basicexpressions,Expression _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().removeparameters(basicexpressionx, _val); } }


  public static void unionAllparameters(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().unionparameters(basicexpressionx, _val); } }


  public static void subtractAllparameters(List basicexpressions,  List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().subtractparameters(basicexpressionx,  _val); } }


  public void setreferredProperty(List referredProperty_xx) { if (referredProperty_xx.size() > 1) { return; } 
    referredProperty = referredProperty_xx;
  }
 
  public void addreferredProperty(Property referredProperty_xx) { if (referredProperty.size() > 0) { referredProperty.clear(); } 
    if (referredProperty.contains(referredProperty_xx)) {} else { referredProperty.add(referredProperty_xx); }
    }
 
  public void removereferredProperty(Property referredProperty_xx) { Vector _removedreferredPropertyreferredProperty_xx = new Vector();
  _removedreferredPropertyreferredProperty_xx.add(referredProperty_xx);
  referredProperty.removeAll(_removedreferredPropertyreferredProperty_xx);
    }

  public static void setAllreferredProperty(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().setreferredProperty(basicexpressionx, _val); } }

  public static void addAllreferredProperty(List basicexpressions, Property _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().addreferredProperty(basicexpressionx,  _val); } }


  public static void removeAllreferredProperty(List basicexpressions,Property _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().removereferredProperty(basicexpressionx, _val); } }


  public static void unionAllreferredProperty(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().unionreferredProperty(basicexpressionx, _val); } }


  public static void subtractAllreferredProperty(List basicexpressions,  List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().subtractreferredProperty(basicexpressionx,  _val); } }


  public void setcontext(List context_xx) { context = context_xx;
    }
 
  public void addcontext(Entity context_xx) { if (context.contains(context_xx)) {} else { context.add(context_xx); }
    }
 
  public void removecontext(Entity context_xx) { Vector _removedcontextcontext_xx = new Vector();
  _removedcontextcontext_xx.add(context_xx);
  context.removeAll(_removedcontextcontext_xx);
    }

  public static void setAllcontext(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().setcontext(basicexpressionx, _val); } }

  public static void addAllcontext(List basicexpressions, Entity _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().addcontext(basicexpressionx,  _val); } }


  public static void removeAllcontext(List basicexpressions,Entity _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().removecontext(basicexpressionx, _val); } }


  public static void unionAllcontext(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().unioncontext(basicexpressionx, _val); } }


  public static void subtractAllcontext(List basicexpressions,  List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().subtractcontext(basicexpressionx,  _val); } }


  public void setarrayIndex(List arrayIndex_xx) { if (arrayIndex_xx.size() > 1) { return; } 
    arrayIndex = arrayIndex_xx;
  }
 
  public void addarrayIndex(BasicExpression arrayIndex_xx) { if (arrayIndex.size() > 0) { arrayIndex.clear(); } 
    if (arrayIndex.contains(arrayIndex_xx)) {} else { arrayIndex.add(arrayIndex_xx); }
    }
 
  public void removearrayIndex(BasicExpression arrayIndex_xx) { Vector _removedarrayIndexarrayIndex_xx = new Vector();
  _removedarrayIndexarrayIndex_xx.add(arrayIndex_xx);
  arrayIndex.removeAll(_removedarrayIndexarrayIndex_xx);
    }

  public static void setAllarrayIndex(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().setarrayIndex(basicexpressionx, _val); } }

  public static void addAllarrayIndex(List basicexpressions, BasicExpression _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().addarrayIndex(basicexpressionx,  _val); } }


  public static void removeAllarrayIndex(List basicexpressions,BasicExpression _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().removearrayIndex(basicexpressionx, _val); } }


  public static void unionAllarrayIndex(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().unionarrayIndex(basicexpressionx, _val); } }


  public static void subtractAllarrayIndex(List basicexpressions,  List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().subtractarrayIndex(basicexpressionx,  _val); } }


  public void setobjectRef(List objectRef_xx) { if (objectRef_xx.size() > 1) { return; } 
    objectRef = objectRef_xx;
  }
 
  public void addobjectRef(BasicExpression objectRef_xx) { if (objectRef.size() > 0) { objectRef.clear(); } 
    if (objectRef.contains(objectRef_xx)) {} else { objectRef.add(objectRef_xx); }
    }
 
  public void removeobjectRef(BasicExpression objectRef_xx) { Vector _removedobjectRefobjectRef_xx = new Vector();
  _removedobjectRefobjectRef_xx.add(objectRef_xx);
  objectRef.removeAll(_removedobjectRefobjectRef_xx);
    }

  public static void setAllobjectRef(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().setobjectRef(basicexpressionx, _val); } }

  public static void addAllobjectRef(List basicexpressions, BasicExpression _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().addobjectRef(basicexpressionx,  _val); } }


  public static void removeAllobjectRef(List basicexpressions,BasicExpression _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().removeobjectRef(basicexpressionx, _val); } }


  public static void unionAllobjectRef(List basicexpressions, List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().unionobjectRef(basicexpressionx, _val); } }


  public static void subtractAllobjectRef(List basicexpressions,  List _val)
  { for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      Controller.inst().subtractobjectRef(basicexpressionx,  _val); } }


    public String getdata() { return data; }

    public static List getAlldata(List basicexpressions)
  { List result = new Vector();
    for (int i = 0; i < basicexpressions.size(); i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(i);
      if (result.contains(basicexpressionx.getdata())) { }
      else { result.add(basicexpressionx.getdata()); } }
    return result; }

    public static List getAllOrdereddata(List basicexpressions)
  { List result = new Vector();
    for (int i = 0; i < basicexpressions.size(); i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(i);
      result.add(basicexpressionx.getdata()); } 
    return result; }

    public boolean getprestate() { return prestate; }

    public static List getAllprestate(List basicexpressions)
  { List result = new Vector();
    for (int i = 0; i < basicexpressions.size(); i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(i);
      if (result.contains(new Boolean(basicexpressionx.getprestate()))) { }
      else { result.add(new Boolean(basicexpressionx.getprestate())); } }
    return result; }

    public static List getAllOrderedprestate(List basicexpressions)
  { List result = new Vector();
    for (int i = 0; i < basicexpressions.size(); i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(i);
      result.add(new Boolean(basicexpressionx.getprestate())); } 
    return result; }

  public List getparameters() { return (Vector) ((Vector) parameters).clone(); }

  public static List getAllparameters(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getparameters()); }
    return result; }

  public static List getAllOrderedparameters(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result.addAll(basicexpressionx.getparameters()); }
    return result; }

  public List getreferredProperty() { return (Vector) ((Vector) referredProperty).clone(); }

  public static List getAllreferredProperty(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getreferredProperty()); }
    return result; }

  public static List getAllOrderedreferredProperty(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getreferredProperty()); }
    return result; }

  public List getcontext() { return (Vector) ((Vector) context).clone(); }

  public static List getAllcontext(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getcontext()); }
    return result; }

  public static List getAllOrderedcontext(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getcontext()); }
    return result; }

  public List getarrayIndex() { return (Vector) ((Vector) arrayIndex).clone(); }

  public static List getAllarrayIndex(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getarrayIndex()); }
    return result; }

  public static List getAllOrderedarrayIndex(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getarrayIndex()); }
    return result; }

  public List getobjectRef() { return (Vector) ((Vector) objectRef).clone(); }

  public static List getAllobjectRef(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getobjectRef()); }
    return result; }

  public static List getAllOrderedobjectRef(List basicexpressions)
  { List result = new Vector();
    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(_i);
      result = Set.union(result, basicexpressionx.getobjectRef()); }
    return result; }

    public CExpression clength(CExpression cexp)
  {   CExpression result = null;
 
  if (umlKind == attribute && objectRef.size() > 0) 
  {   result = this.createCUnaryOpCall(expId + "_len","length",Expression.cast("void**",Controller.inst().getCExpressionByPK(((BasicExpression) Set.any(objectRef)).getexpId())));
 
  }  else
      if (true) 
  {   result = this.createCUnaryOpCall(expId + "_len","length",Expression.cast("void**",cexp));
 
  }       return result;
  }


    public CExpression mapValueExpression(List aind)
  {   CExpression result = null;
  //  if ((new SystemTypes.Set()).add(attribute).add(role).add(variable).add(constant).add(function).add(queryop).add(operation).add(classid).getElements().contains(new Integer(umlKind)))) { return result; } 
    if (Controller.inst().getCBasicExpressionByPK(this.getexpId()) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(this.getexpId());
     Controller.inst().setkind(c,"value");
      if (this.getdata().equals("true")) 
  { Controller.inst().setdata(c,"TRUE");}
      if (this.getdata().equals("false")) 
  { Controller.inst().setdata(c,"FALSE");}
      if (!(this.getdata().equals("true")) && !(this.getdata().equals("false"))) 
  { Controller.inst().setdata(c,this.getdata());}
    Controller.inst().setarrayIndex(c,aind);
    Controller.inst().settype(c,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(c,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    Controller.inst().setcexpId(c,this.getexpId());
    Controller.inst().setkind(c,"value");
      if (this.getdata().equals("true")) 
  { Controller.inst().setdata(c,"TRUE");}
      if (this.getdata().equals("false")) 
  { Controller.inst().setdata(c,"FALSE");}
      if (!(this.getdata().equals("true")) && !(this.getdata().equals("false"))) 
  { Controller.inst().setdata(c,this.getdata());}
    Controller.inst().setarrayIndex(c,aind);
    Controller.inst().settype(c,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(c,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = c; }

  return result;

  }

    public CBasicExpression mapVariableExpression(List aind,List pars)
  {   CBasicExpression result = null;
  //  if ((new SystemTypes.Set()).add(value).add(attribute).add(role).add(constant).add(function).add(queryop).add(operation).add(classid).getElements().contains(new Integer(umlKind)))) { return result; } 
    if (this.getdata().equals("super")) 
  {   if (Controller.inst().getCBasicExpressionByPK(this.getexpId()) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(this.getexpId());
     Controller.inst().setkind(c,"attribute");
    Controller.inst().setdata(c,"super");
    Controller.inst().settype(c,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(c,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
      if (Controller.inst().getCBasicExpressionByPK(this.getexpId() + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(this.getexpId() + "_self");
     Controller.inst().setdata(s,"self");
    Controller.inst().setkind(s,"variable");
    Controller.inst().addreference(c,s);
    Controller.inst().settype(s,Controller.inst().getCTypeByPK(((Entity) Set.any(this.getcontext())).gettypeId()));
    Controller.inst().setelementType(s,s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    Controller.inst().setdata(s,"self");
    Controller.inst().setkind(s,"variable");
    Controller.inst().addreference(c,s);
    Controller.inst().setcexpId(s,this.getexpId() + "_self");
    Controller.inst().settype(s,Controller.inst().getCTypeByPK(((Entity) Set.any(this.getcontext())).gettypeId()));
    Controller.inst().setelementType(s,s.gettype()); }

    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    Controller.inst().setcexpId(c,this.getexpId());
    Controller.inst().setkind(c,"attribute");
    Controller.inst().setdata(c,"super");
    Controller.inst().settype(c,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(c,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
      if (Controller.inst().getCBasicExpressionByPK(this.getexpId() + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(this.getexpId() + "_self");
     Controller.inst().setdata(s,"self");
    Controller.inst().setkind(s,"variable");
    Controller.inst().addreference(c,s);
    Controller.inst().settype(s,Controller.inst().getCTypeByPK(((Entity) Set.any(this.getcontext())).gettypeId()));
    Controller.inst().setelementType(s,s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    Controller.inst().setdata(s,"self");
    Controller.inst().setkind(s,"variable");
    Controller.inst().addreference(c,s);
    Controller.inst().setcexpId(s,this.getexpId() + "_self");
    Controller.inst().settype(s,Controller.inst().getCTypeByPK(((Entity) Set.any(this.getcontext())).gettypeId()));
    Controller.inst().setelementType(s,s.gettype()); }

    result = c; }
}
      if (!(this.getdata().equals("super"))) 
  {   if (Controller.inst().getCBasicExpressionByPK(this.getexpId()) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(this.getexpId());
     Controller.inst().setkind(c,"variable");
    Controller.inst().setdata(c,this.getdata());
    Controller.inst().setarrayIndex(c,aind);
    Controller.inst().setparameters(c,pars);
    Controller.inst().settype(c,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(c,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    Controller.inst().setcexpId(c,this.getexpId());
    Controller.inst().setkind(c,"variable");
    Controller.inst().setdata(c,this.getdata());
    Controller.inst().setarrayIndex(c,aind);
    Controller.inst().setparameters(c,pars);
    Controller.inst().settype(c,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(c,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = c; }
}
  return result;

  }

    public CBasicExpression mapAttributeExpression(List obs,List aind,List pars)
  {   CBasicExpression result = null;
    if (umlKind == value || umlKind == role || umlKind == variable || umlKind == constant || umlKind == function || umlKind == queryop || umlKind == operation || umlKind == classid) { return result; } 
   
  if (context.size() == 0 && objectRef.size() == 0) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("attribute");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("attribute");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
    result = c; }

   
  }  else
      {   if (objectRef.size() == 0) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("attribute");
    c.setdata("get" + ((Entity) Set.any(context)).getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("attribute");
    c.setdata("get" + ((Entity) Set.any(context)).getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    result = c; }

   
  }  else
      {   if (objectRef.size() > 0 && (((BasicExpression) Set.any(objectRef)).gettype() instanceof CollectionType)) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("attribute");
    c.setdata("getAll" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("attribute");
    c.setdata("getAll" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c; }

   
  }  else
      if (objectRef.size() > 0 && !(((BasicExpression) Set.any(objectRef)).gettype() instanceof CollectionType)) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("attribute");
    c.setdata("get" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("attribute");
    c.setdata("get" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c; }

   
  }   
   } 
   }     return result;
  }


    public CBasicExpression mapRoleExpression(List obs,List aind,List pars)
  {   CBasicExpression result = null;
    if (umlKind == value || umlKind == attribute || umlKind == variable || umlKind == constant || umlKind == function || umlKind == queryop || umlKind == operation || umlKind == classid) { return result; } 
   
  if (context.size() == 0 && objectRef.size() == 0) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("role");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("role");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
    result = c; }

   
  }  else
      {   if (objectRef.size() == 0) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("role");
    c.setdata("get" + ((Entity) Set.any(context)).getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("role");
    c.setdata("get" + ((Entity) Set.any(context)).getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    result = c; }

   
  }  else
      {   if (objectRef.size() > 0 && (((BasicExpression) Set.any(objectRef)).gettype() instanceof CollectionType)) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("role");
    c.setdata("getAll" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("role");
    c.setdata("getAll" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c; }

   
  }  else
      if (objectRef.size() > 0 && !(((BasicExpression) Set.any(objectRef)).gettype() instanceof CollectionType)) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("role");
    c.setdata("get" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("role");
    c.setdata("get" + ((BasicExpression) Set.any(objectRef)).getelementType().getname() + "_" + data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    c.setarrayIndex(aind);
    result = c; }

   
  }   
   } 
   }     return result;
  }


    public CBasicExpression mapOperationExpression(List obs,List aind,List pars)
  {   CBasicExpression result = null;
    if (umlKind == value || umlKind == attribute || umlKind == role || umlKind == variable || umlKind == constant || umlKind == function || umlKind == queryop || umlKind == classid) { return result; } 
   
  if (( context.size() == 0 || isStatic == true )) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("operation");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
    c.setparameters(pars);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("operation");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
    c.setparameters(pars);
    result = c; }

   
  }  else
      {   if (objectRef.size() == 0) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("operation");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    Controller.inst().unionparameters(c,pars);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("operation");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    c.setarrayIndex(aind);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(c,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    Controller.inst().unionparameters(c,pars);
    result = c; }

   
  }  else
      if (objectRef.size() > 0) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("operation");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    Controller.inst().unionparameters(c,pars);
    c.setarrayIndex(aind);
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("operation");
    c.setdata(data);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    Controller.inst().unionparameters(c,obs);
    Controller.inst().unionparameters(c,pars);
    c.setarrayIndex(aind);
    result = c; }

   
  }   
   }     return result;
  }


    public CBasicExpression mapClassExpression(List obs,List aind,List pars)
  {   CBasicExpression result = null;
    if (umlKind == value || umlKind == attribute || umlKind == role || umlKind == variable || umlKind == constant || umlKind == function || umlKind == queryop || umlKind == operation) { return result; } 
   
  if (arrayIndex.size() > 0 && (((BasicExpression) Set.any(arrayIndex)).gettype() instanceof CollectionType)) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("classid");
    c.setdata("get" + elementType.getname() + "ByPKs");
    Controller.inst().unionparameters(c,aind);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("classid");
    c.setdata("get" + elementType.getname() + "ByPKs");
    Controller.inst().unionparameters(c,aind);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }  else
      {   if (arrayIndex.size() > 0 && !(((BasicExpression) Set.any(arrayIndex)).gettype() instanceof CollectionType)) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("classid");
    c.setdata("get" + elementType.getname() + "ByPK");
    Controller.inst().unionparameters(c,aind);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("classid");
    c.setdata("get" + elementType.getname() + "ByPK");
    Controller.inst().unionparameters(c,aind);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }  else
      if (arrayIndex.size() == 0) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("classid");
    c.setdata(data.toLowerCase() + "_instances");
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("classid");
    c.setdata(data.toLowerCase() + "_instances");
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }   
   }     return result;
  }


    public CBasicExpression mapSubrangeExpression(List obs,List pars)
  {   CBasicExpression result = null;
    if (!(data.equals("subrange"))) { return result; } 
   
  if (obs.size() > 0 && "Integer".equals(((CExpression) Set.any(obs)).toString())) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setdata("intSubrange");
    c.setkind("function");
    c.setparameters(pars);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setdata("intSubrange");
    c.setkind("function");
    c.setparameters(pars);
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }  else
      {   if (type.getname().equals("String")) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setdata("subString");
    c.setkind("function");
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setdata("subString");
    c.setkind("function");
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }  else
      if (true) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setdata("subrange" + elementType.getname());
    c.setkind("function");
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setdata("subrange" + elementType.getname());
    c.setkind("function");
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }   
   }     return result;
  }


    public CBasicExpression mapFunctionExpression(List obs,List aind,List pars)
  {   CBasicExpression result = null;
    if (umlKind == value || umlKind == attribute || umlKind == role || umlKind == variable || umlKind == constant || umlKind == queryop || umlKind == operation || umlKind == classid) { return result; } 
   
  if (data.equals("subrange")) 
  {   result = this.mapSubrangeExpression(obs,pars);
 
  }  else
      {   if (Expression.isCFunction1(data)) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setdata(Expression.cfunctionName(data));
    c.setkind("function");
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setdata(Expression.cfunctionName(data));
    c.setkind("function");
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }  else
      {   if (data.equals("allInstances")) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("function");
    c.setdata(((BasicExpression) Set.any(objectRef)).getdata().toLowerCase() + "_instances");
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("function");
    c.setdata(((BasicExpression) Set.any(objectRef)).getdata().toLowerCase() + "_instances");
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }  else
      if (true) 
  {     if (Controller.inst().getCBasicExpressionByPK(expId) != null)
    { CBasicExpression c = Controller.inst().getCBasicExpressionByPK(expId);
     c.setkind("function");
    c.setdata(Expression.cfunctionName(data));
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c;
  }
    else
    { CBasicExpression c = new CBasicExpression();
    Controller.inst().addCBasicExpression(c);
    c.setcexpId(expId);
    c.setkind("function");
    c.setdata(Expression.cfunctionName(data));
    c.setparameters(Set.concatenate(obs,pars));
    c.settype(Controller.inst().getCTypeByPK(type.gettypeId()));
    c.setelementType(Controller.inst().getCTypeByPK(elementType.gettypeId()));
    result = c; }

   
  }   
   } 
   }     return result;
  }


    public CStatement mapIndexedAssignment(Statement stat,CExpression cexp)
  {   CStatement result = null;
 
  if (arrayIndex.size() > 0 && ((BasicExpression) Set.any(arrayIndex)).gettype().getname().equals("String")) 
  {     if (Controller.inst().getCAssignmentByPK(stat.getstatId()) != null)
    { CAssignment ca = Controller.inst().getCAssignmentByPK(stat.getstatId());
     ca.setleft(CExpression.newCBasicExpression(data,CPrimitiveType.newCPrimitiveType(expId + "_type","ocltnode*")));
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata(data);
    s.setkind("variable");
    s.settype(CPrimitiveType.newCPrimitiveType(expId + "_treetype","ocltnode*"));
    ca.setright(this.createCTernaryOpCall(stat.getstatId() + "_call","insertIntoMap",s,((BasicExpression) Set.any(arrayIndex)).mapExpression(),cexp));
    result = ca;
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata(data);
    s.setkind("variable");
    s.setcexpId(expId + "_self");
    s.settype(CPrimitiveType.newCPrimitiveType(expId + "_treetype","ocltnode*"));
    ca.setright(this.createCTernaryOpCall(stat.getstatId() + "_call","insertIntoMap",s,((BasicExpression) Set.any(arrayIndex)).mapExpression(),cexp));
    result = ca; }

  }
    else
    { CAssignment ca = new CAssignment();
    Controller.inst().addCAssignment(ca);
    ca.setcstatId(stat.getstatId());
    ca.setleft(CExpression.newCBasicExpression(data,CPrimitiveType.newCPrimitiveType(expId + "_type","ocltnode*")));
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata(data);
    s.setkind("variable");
    s.settype(CPrimitiveType.newCPrimitiveType(expId + "_treetype","ocltnode*"));
    ca.setright(this.createCTernaryOpCall(stat.getstatId() + "_call","insertIntoMap",s,((BasicExpression) Set.any(arrayIndex)).mapExpression(),cexp));
    result = ca;
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata(data);
    s.setkind("variable");
    s.setcexpId(expId + "_self");
    s.settype(CPrimitiveType.newCPrimitiveType(expId + "_treetype","ocltnode*"));
    ca.setright(this.createCTernaryOpCall(stat.getstatId() + "_call","insertIntoMap",s,((BasicExpression) Set.any(arrayIndex)).mapExpression(),cexp));
    result = ca; }
 }

   
  }  else
      if (true) 
  {     if (Controller.inst().getCAssignmentByPK(stat.getstatId()) != null)
    { CAssignment ca = Controller.inst().getCAssignmentByPK(stat.getstatId());
     ca.setleft(this.mapExpression());
    ca.setright(cexp);
    result = ca;
  }
    else
    { CAssignment ca = new CAssignment();
    Controller.inst().addCAssignment(ca);
    ca.setcstatId(stat.getstatId());
    ca.setleft(this.mapExpression());
    ca.setright(cexp);
    result = ca; }

   
  }       return result;
  }


    public CStatement mapAssignment(Statement stat,CExpression cexp)
  {   CStatement result = null;
 
  if (arrayIndex.size() > 0) 
  {   result = this.mapIndexedAssignment(stat,cexp);
 
  }  else
      {   if (( umlKind == attribute || umlKind == role ) && arrayIndex.size() == 0 && objectRef.size() == 0) 
  {     if (Controller.inst().getOpCallStatementByPK(stat.getstatId()) != null)
    { OpCallStatement ca = Controller.inst().getOpCallStatementByPK(stat.getstatId());
       if (Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call") != null)
    { CBasicExpression op = Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call");
     op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    Controller.inst().addparameters(op,cexp);
    ca.setcallExp(op);
    result = ca;
  }
    else
    { CBasicExpression op = new CBasicExpression();
    Controller.inst().addCBasicExpression(op);
    op.setcexpId(stat.getstatId() + "_call");
    op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    Controller.inst().addparameters(op,cexp);
    ca.setcallExp(op);
    result = ca; }

  }
    else
    { OpCallStatement ca = new OpCallStatement();
    Controller.inst().addOpCallStatement(ca);
    ca.setcstatId(stat.getstatId());
      if (Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call") != null)
    { CBasicExpression op = Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call");
     op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    Controller.inst().addparameters(op,cexp);
    ca.setcallExp(op);
    result = ca;
  }
    else
    { CBasicExpression op = new CBasicExpression();
    Controller.inst().addCBasicExpression(op);
    op.setcexpId(stat.getstatId() + "_call");
    op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
      if (Controller.inst().getCBasicExpressionByPK(expId + "_self") != null)
    { CBasicExpression s = Controller.inst().getCBasicExpressionByPK(expId + "_self");
     s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype());
  }
    else
    { CBasicExpression s = new CBasicExpression();
    Controller.inst().addCBasicExpression(s);
    s.setdata("self");
    s.setkind("variable");
    Controller.inst().addparameters(op,s);
    s.setcexpId(expId + "_self");
    s.settype(Controller.inst().getCTypeByPK(((Entity) Set.any(context)).gettypeId()));
    s.setelementType(s.gettype()); }

    Controller.inst().addparameters(op,cexp);
    ca.setcallExp(op);
    result = ca; }
 }

   
  }  else
      {   if (( umlKind == attribute || umlKind == role ) && arrayIndex.size() == 0 && objectRef.size() > 0) 
  {     if (Controller.inst().getOpCallStatementByPK(stat.getstatId()) != null)
    { OpCallStatement ca = Controller.inst().getOpCallStatementByPK(stat.getstatId());
       if (Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call") != null)
    { CBasicExpression op = Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call");
     op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
    op.setparameters((new SystemTypes.Set()).add(((BasicExpression) Set.any(objectRef)).mapExpression()).add(cexp).getElements());
    ca.setcallExp(op);
    result = ca;
  }
    else
    { CBasicExpression op = new CBasicExpression();
    Controller.inst().addCBasicExpression(op);
    op.setcexpId(stat.getstatId() + "_call");
    op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
    op.setparameters((new SystemTypes.Set()).add(((BasicExpression) Set.any(objectRef)).mapExpression()).add(cexp).getElements());
    ca.setcallExp(op);
    result = ca; }

  }
    else
    { OpCallStatement ca = new OpCallStatement();
    Controller.inst().addOpCallStatement(ca);
    ca.setcstatId(stat.getstatId());
      if (Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call") != null)
    { CBasicExpression op = Controller.inst().getCBasicExpressionByPK(stat.getstatId() + "_call");
     op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
    op.setparameters((new SystemTypes.Set()).add(((BasicExpression) Set.any(objectRef)).mapExpression()).add(cexp).getElements());
    ca.setcallExp(op);
    result = ca;
  }
    else
    { CBasicExpression op = new CBasicExpression();
    Controller.inst().addCBasicExpression(op);
    op.setcexpId(stat.getstatId() + "_call");
    op.setdata("set" + ((Entity) Set.any(context)).getname() + "_" + data);
    op.setparameters((new SystemTypes.Set()).add(((BasicExpression) Set.any(objectRef)).mapExpression()).add(cexp).getElements());
    ca.setcallExp(op);
    result = ca; }
 }

   
  }  else
      if (true) 
  {     if (Controller.inst().getCAssignmentByPK(stat.getstatId()) != null)
    { CAssignment ca = Controller.inst().getCAssignmentByPK(stat.getstatId());
     ca.setleft(this.mapExpression());
    ca.setright(cexp);
    result = ca;
  }
    else
    { CAssignment ca = new CAssignment();
    Controller.inst().addCAssignment(ca);
    ca.setcstatId(stat.getstatId());
    ca.setleft(this.mapExpression());
    ca.setright(cexp);
    result = ca; }

   
  }   
   } 
   }     return result;
  }


    public CExpression mapBasicExpression(List ob,List aind,List pars)
  {   CExpression result = null;
 
  if (umlKind == value) 
  {   result = this.mapValueExpression(aind);
 
  }  else
      {   if (umlKind == variable) 
  {   result = this.mapVariableExpression(aind,pars);
 
  }  else
      {   if (umlKind == attribute) 
  {   result = this.mapAttributeExpression(ob,aind,pars);
 
  }  else
      {   if (umlKind == role) 
  {   result = this.mapRoleExpression(ob,aind,pars);
 
  }  else
      {   if (umlKind == operation) 
  {   result = this.mapOperationExpression(ob,aind,pars);
 
  }  else
      {   if (umlKind == classid) 
  {   result = this.mapClassExpression(ob,aind,pars);
 
  }  else
      if (umlKind == function) 
  {   result = this.mapFunctionExpression(ob,aind,pars);
 
  }   
   } 
   } 
   } 
   } 
   }     return result;
  }


    public CExpression mapExpression()
  {   CExpression result = null;
result = this.mapBasicExpression(  Controller.inst().AllBasicExpressionmapExpression(this.getobjectRef()),  Controller.inst().AllBasicExpressionmapExpression(this.getarrayIndex()),  Controller.inst().AllExpressionmapExpression(this.getparameters()));
  return result;

  }


}


class Property
  implements SystemTypes
{
  private String name = ""; // internal
  private int lower = 0; // internal
  private int upper = 0; // internal
  private boolean isOrdered = false; // internal
  private boolean isUnique = false; // internal
  private boolean isDerived = false; // internal
  private boolean isReadOnly = false; // internal
  private boolean isStatic = false; // internal
  private Type type;
  private Expression initialValue;
  private Entity owner;

  public Property(Type type,Expression initialValue,Entity owner)
  {
    this.name = "";
    this.lower = 0;
    this.upper = 0;
    this.isOrdered = false;
    this.isUnique = false;
    this.isDerived = false;
    this.isReadOnly = false;
    this.isStatic = false;
    this.type = type;
    this.initialValue = initialValue;
    this.owner = owner;

  }

  public Property() { }



  public String toString()
  { String _res_ = "(Property) ";
    _res_ = _res_ + name + ",";
    _res_ = _res_ + lower + ",";
    _res_ = _res_ + upper + ",";
    _res_ = _res_ + isOrdered + ",";
    _res_ = _res_ + isUnique + ",";
    _res_ = _res_ + isDerived + ",";
    _res_ = _res_ + isReadOnly + ",";
    _res_ = _res_ + isStatic;
    return _res_;
  }

  public static Property parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Property propertyx = new Property();
    propertyx.name = (String) _line1vals.get(0);
    propertyx.lower = Integer.parseInt((String) _line1vals.get(1));
    propertyx.upper = Integer.parseInt((String) _line1vals.get(2));
    propertyx.isOrdered = Boolean.parseBoolean((String) _line1vals.get(3));
    propertyx.isUnique = Boolean.parseBoolean((String) _line1vals.get(4));
    propertyx.isDerived = Boolean.parseBoolean((String) _line1vals.get(5));
    propertyx.isReadOnly = Boolean.parseBoolean((String) _line1vals.get(6));
    propertyx.isStatic = Boolean.parseBoolean((String) _line1vals.get(7));
    return propertyx;
  }


  public void writeCSV(PrintWriter _out)
  { Property propertyx = this;
    _out.print("" + propertyx.name);
    _out.print(" , ");
    _out.print("" + propertyx.lower);
    _out.print(" , ");
    _out.print("" + propertyx.upper);
    _out.print(" , ");
    _out.print("" + propertyx.isOrdered);
    _out.print(" , ");
    _out.print("" + propertyx.isUnique);
    _out.print(" , ");
    _out.print("" + propertyx.isDerived);
    _out.print(" , ");
    _out.print("" + propertyx.isReadOnly);
    _out.print(" , ");
    _out.print("" + propertyx.isStatic);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List propertys,String val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setname(propertyx,val); } }


  public void setlower(int lower_x) { lower = lower_x;  }


    public static void setAlllower(List propertys,int val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setlower(propertyx,val); } }


  public void setupper(int upper_x) { upper = upper_x;  }


    public static void setAllupper(List propertys,int val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setupper(propertyx,val); } }


  public void setisOrdered(boolean isOrdered_x) { isOrdered = isOrdered_x;  }


    public static void setAllisOrdered(List propertys,boolean val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setisOrdered(propertyx,val); } }


  public void setisUnique(boolean isUnique_x) { isUnique = isUnique_x;  }


    public static void setAllisUnique(List propertys,boolean val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setisUnique(propertyx,val); } }


  public void setisDerived(boolean isDerived_x) { isDerived = isDerived_x;  }


    public static void setAllisDerived(List propertys,boolean val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setisDerived(propertyx,val); } }


  public void setisReadOnly(boolean isReadOnly_x) { isReadOnly = isReadOnly_x;  }


    public static void setAllisReadOnly(List propertys,boolean val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setisReadOnly(propertyx,val); } }


  public void setisStatic(boolean isStatic_x) { isStatic = isStatic_x;  }


    public static void setAllisStatic(List propertys,boolean val)
  { for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      Controller.inst().setisStatic(propertyx,val); } }


  public void settype(Type type_xx) { type = type_xx;
  }

  public static void setAlltype(List propertys, Type _val)
  { for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      Controller.inst().settype(propertyx, _val); } }

  public void setinitialValue(Expression initialValue_xx) { initialValue = initialValue_xx;
  }

  public static void setAllinitialValue(List propertys, Expression _val)
  { for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      Controller.inst().setinitialValue(propertyx, _val); } }

  public void setowner(Entity owner_xx) { owner = owner_xx;
  }

  public static void setAllowner(List propertys, Entity _val)
  { for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      Controller.inst().setowner(propertyx, _val); } }

    public String getname() { return name; }

    public static List getAllname(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(propertyx.getname())) { }
      else { result.add(propertyx.getname()); } }
    return result; }

    public static List getAllOrderedname(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(propertyx.getname()); } 
    return result; }

    public int getlower() { return lower; }

    public static List getAlllower(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(new Integer(propertyx.getlower()))) { }
      else { result.add(new Integer(propertyx.getlower())); } }
    return result; }

    public static List getAllOrderedlower(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(new Integer(propertyx.getlower())); } 
    return result; }

    public int getupper() { return upper; }

    public static List getAllupper(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(new Integer(propertyx.getupper()))) { }
      else { result.add(new Integer(propertyx.getupper())); } }
    return result; }

    public static List getAllOrderedupper(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(new Integer(propertyx.getupper())); } 
    return result; }

    public boolean getisOrdered() { return isOrdered; }

    public static List getAllisOrdered(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(new Boolean(propertyx.getisOrdered()))) { }
      else { result.add(new Boolean(propertyx.getisOrdered())); } }
    return result; }

    public static List getAllOrderedisOrdered(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(new Boolean(propertyx.getisOrdered())); } 
    return result; }

    public boolean getisUnique() { return isUnique; }

    public static List getAllisUnique(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(new Boolean(propertyx.getisUnique()))) { }
      else { result.add(new Boolean(propertyx.getisUnique())); } }
    return result; }

    public static List getAllOrderedisUnique(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(new Boolean(propertyx.getisUnique())); } 
    return result; }

    public boolean getisDerived() { return isDerived; }

    public static List getAllisDerived(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(new Boolean(propertyx.getisDerived()))) { }
      else { result.add(new Boolean(propertyx.getisDerived())); } }
    return result; }

    public static List getAllOrderedisDerived(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(new Boolean(propertyx.getisDerived())); } 
    return result; }

    public boolean getisReadOnly() { return isReadOnly; }

    public static List getAllisReadOnly(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(new Boolean(propertyx.getisReadOnly()))) { }
      else { result.add(new Boolean(propertyx.getisReadOnly())); } }
    return result; }

    public static List getAllOrderedisReadOnly(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(new Boolean(propertyx.getisReadOnly())); } 
    return result; }

    public boolean getisStatic() { return isStatic; }

    public static List getAllisStatic(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      if (result.contains(new Boolean(propertyx.getisStatic()))) { }
      else { result.add(new Boolean(propertyx.getisStatic())); } }
    return result; }

    public static List getAllOrderedisStatic(List propertys)
  { List result = new Vector();
    for (int i = 0; i < propertys.size(); i++)
    { Property propertyx = (Property) propertys.get(i);
      result.add(new Boolean(propertyx.getisStatic())); } 
    return result; }

  public Type gettype() { return type; }

  public static List getAlltype(List propertys)
  { List result = new Vector();
    for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      if (result.contains(propertyx.gettype())) {}
      else { result.add(propertyx.gettype()); }
 }
    return result; }

  public static List getAllOrderedtype(List propertys)
  { List result = new Vector();
    for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      if (result.contains(propertyx.gettype())) {}
      else { result.add(propertyx.gettype()); }
 }
    return result; }

  public Expression getinitialValue() { return initialValue; }

  public static List getAllinitialValue(List propertys)
  { List result = new Vector();
    for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      if (result.contains(propertyx.getinitialValue())) {}
      else { result.add(propertyx.getinitialValue()); }
 }
    return result; }

  public static List getAllOrderedinitialValue(List propertys)
  { List result = new Vector();
    for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      if (result.contains(propertyx.getinitialValue())) {}
      else { result.add(propertyx.getinitialValue()); }
 }
    return result; }

  public Entity getowner() { return owner; }

  public static List getAllowner(List propertys)
  { List result = new Vector();
    for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      if (result.contains(propertyx.getowner())) {}
      else { result.add(propertyx.getowner()); }
 }
    return result; }

  public static List getAllOrderedowner(List propertys)
  { List result = new Vector();
    for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx = (Property) propertys.get(_i);
      if (result.contains(propertyx.getowner())) {}
      else { result.add(propertyx.getowner()); }
 }
    return result; }


}


class Exp2C
  implements SystemTypes
{

  public Exp2C()
  {

  }



  public String toString()
  { String _res_ = "(Exp2C) ";
    return _res_;
  }

  public static Exp2C parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Exp2C exp2cx = new Exp2C();
    return exp2cx;
  }


  public void writeCSV(PrintWriter _out)
  { Exp2C exp2cx = this;
    _out.println();
  }


    public void exp2C()
  { {} /* No update form for: true */
  }


}


class CPrimitiveType
  extends CType
  implements SystemTypes
{
  private String name = ""; // internal

  public CPrimitiveType()
  {
    this.name = "";

  }



  public static CPrimitiveType parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CPrimitiveType cprimitivetypex = new CPrimitiveType();
    cprimitivetypex.name = (String) _line1vals.get(0);
    return cprimitivetypex;
  }


  public void writeCSV(PrintWriter _out)
  { CPrimitiveType cprimitivetypex = this;
    _out.print("" + cprimitivetypex.name);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List cprimitivetypes,String val)
  { for (int i = 0; i < cprimitivetypes.size(); i++)
    { CPrimitiveType cprimitivetypex = (CPrimitiveType) cprimitivetypes.get(i);
      Controller.inst().setname(cprimitivetypex,val); } }


    public String getname() { return name; }

    public static List getAllname(List cprimitivetypes)
  { List result = new Vector();
    for (int i = 0; i < cprimitivetypes.size(); i++)
    { CPrimitiveType cprimitivetypex = (CPrimitiveType) cprimitivetypes.get(i);
      if (result.contains(cprimitivetypex.getname())) { }
      else { result.add(cprimitivetypex.getname()); } }
    return result; }

    public static List getAllOrderedname(List cprimitivetypes)
  { List result = new Vector();
    for (int i = 0; i < cprimitivetypes.size(); i++)
    { CPrimitiveType cprimitivetypex = (CPrimitiveType) cprimitivetypes.get(i);
      result.add(cprimitivetypex.getname()); } 
    return result; }

    public String toString()
  {   String result = "";
 
  result = name;
    return result;
  }


    public static CPrimitiveType newCPrimitiveType(String id,String nme)
  {   CPrimitiveType result = null;
 
    if (Controller.inst().getCPrimitiveTypeByPK(id) != null)
    { CPrimitiveType t = Controller.inst().getCPrimitiveTypeByPK(id);
     t.setname(nme);
    result = t;
  }
    else
    { CPrimitiveType t = new CPrimitiveType();
    Controller.inst().addCPrimitiveType(t);
    t.setname(nme);
    t.setctypeId(id);
    result = t; }

      return result;
  }



}


class CArrayType
  extends CType
  implements SystemTypes
{
  private boolean duplicates = false; // internal
  private CType componentType;

  public CArrayType(CType componentType)
  {
    this.duplicates = false;
    this.componentType = componentType;

  }

  public CArrayType() { }



  public static CArrayType parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CArrayType carraytypex = new CArrayType();
    carraytypex.duplicates = Boolean.parseBoolean((String) _line1vals.get(0));
    return carraytypex;
  }


  public void writeCSV(PrintWriter _out)
  { CArrayType carraytypex = this;
    _out.print("" + carraytypex.duplicates);
    _out.println();
  }


  public void setduplicates(boolean duplicates_x) { duplicates = duplicates_x;  }


    public static void setAllduplicates(List carraytypes,boolean val)
  { for (int i = 0; i < carraytypes.size(); i++)
    { CArrayType carraytypex = (CArrayType) carraytypes.get(i);
      Controller.inst().setduplicates(carraytypex,val); } }


  public void setcomponentType(CType componentType_xx) { componentType = componentType_xx;
  }

  public static void setAllcomponentType(List carraytypes, CType _val)
  { for (int _i = 0; _i < carraytypes.size(); _i++)
    { CArrayType carraytypex = (CArrayType) carraytypes.get(_i);
      Controller.inst().setcomponentType(carraytypex, _val); } }

    public boolean getduplicates() { return duplicates; }

    public static List getAllduplicates(List carraytypes)
  { List result = new Vector();
    for (int i = 0; i < carraytypes.size(); i++)
    { CArrayType carraytypex = (CArrayType) carraytypes.get(i);
      if (result.contains(new Boolean(carraytypex.getduplicates()))) { }
      else { result.add(new Boolean(carraytypex.getduplicates())); } }
    return result; }

    public static List getAllOrderedduplicates(List carraytypes)
  { List result = new Vector();
    for (int i = 0; i < carraytypes.size(); i++)
    { CArrayType carraytypex = (CArrayType) carraytypes.get(i);
      result.add(new Boolean(carraytypex.getduplicates())); } 
    return result; }

  public CType getcomponentType() { return componentType; }

  public static List getAllcomponentType(List carraytypes)
  { List result = new Vector();
    for (int _i = 0; _i < carraytypes.size(); _i++)
    { CArrayType carraytypex = (CArrayType) carraytypes.get(_i);
      if (result.contains(carraytypex.getcomponentType())) {}
      else { result.add(carraytypex.getcomponentType()); }
 }
    return result; }

  public static List getAllOrderedcomponentType(List carraytypes)
  { List result = new Vector();
    for (int _i = 0; _i < carraytypes.size(); _i++)
    { CArrayType carraytypex = (CArrayType) carraytypes.get(_i);
      if (result.contains(carraytypex.getcomponentType())) {}
      else { result.add(carraytypex.getcomponentType()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  result = componentType + "*";
    return result;
  }



}


class CPointerType
  extends CType
  implements SystemTypes
{
  private CType pointsTo;

  public CPointerType(CType pointsTo)
  {
    this.pointsTo = pointsTo;

  }

  public CPointerType() { }



  public static CPointerType parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CPointerType cpointertypex = new CPointerType();
    return cpointertypex;
  }


  public void writeCSV(PrintWriter _out)
  { CPointerType cpointertypex = this;
    _out.println();
  }


  public void setpointsTo(CType pointsTo_xx) { pointsTo = pointsTo_xx;
  }

  public static void setAllpointsTo(List cpointertypes, CType _val)
  { for (int _i = 0; _i < cpointertypes.size(); _i++)
    { CPointerType cpointertypex = (CPointerType) cpointertypes.get(_i);
      Controller.inst().setpointsTo(cpointertypex, _val); } }

  public CType getpointsTo() { return pointsTo; }

  public static List getAllpointsTo(List cpointertypes)
  { List result = new Vector();
    for (int _i = 0; _i < cpointertypes.size(); _i++)
    { CPointerType cpointertypex = (CPointerType) cpointertypes.get(_i);
      if (result.contains(cpointertypex.getpointsTo())) {}
      else { result.add(cpointertypex.getpointsTo()); }
 }
    return result; }

  public static List getAllOrderedpointsTo(List cpointertypes)
  { List result = new Vector();
    for (int _i = 0; _i < cpointertypes.size(); _i++)
    { CPointerType cpointertypex = (CPointerType) cpointertypes.get(_i);
      if (result.contains(cpointertypex.getpointsTo())) {}
      else { result.add(cpointertypex.getpointsTo()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  result = pointsTo + "*";
    return result;
  }



}


class CStruct
  extends CType
  implements SystemTypes
{
  private String name = ""; // internal
  private List members = new Vector(); // of CMember
  private List allMembers = new Vector(); // of CMember

  public CStruct()
  {
    this.name = "";

  }



  public static CStruct parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CStruct cstructx = new CStruct();
    cstructx.name = (String) _line1vals.get(0);
      Controller.inst().cstructnameindex.put(cstructx.getname(), cstructx);
    return cstructx;
  }


  public void writeCSV(PrintWriter _out)
  { CStruct cstructx = this;
    _out.print("" + cstructx.name);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List cstructs,String val)
  { for (int i = 0; i < cstructs.size(); i++)
    { CStruct cstructx = (CStruct) cstructs.get(i);
      Controller.inst().setname(cstructx,val); } }


  public void setmembers(List members_xx) { members = members_xx;
    }
 
  public void setmembers(int ind_x, CMember members_xx) { if (ind_x >= 0 && ind_x < members.size()) { members.set(ind_x, members_xx); } }

 public void addmembers(CMember members_xx) { members.add(members_xx);
    }
 
  public void removemembers(CMember members_xx) { Vector _removedmembersmembers_xx = new Vector();
  _removedmembersmembers_xx.add(members_xx);
  members.removeAll(_removedmembersmembers_xx);
    }

  public static void setAllmembers(List cstructs, List _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().setmembers(cstructx, _val); } }

  public static void setAllmembers(List cstructs, int _ind,CMember _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().setmembers(cstructx,_ind,_val); } }

  public static void addAllmembers(List cstructs, CMember _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().addmembers(cstructx,  _val); } }


  public static void removeAllmembers(List cstructs,CMember _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().removemembers(cstructx, _val); } }


  public static void unionAllmembers(List cstructs, List _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().unionmembers(cstructx, _val); } }


  public static void subtractAllmembers(List cstructs,  List _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().subtractmembers(cstructx,  _val); } }


  public void setallMembers(List allMembers_xx) { allMembers = allMembers_xx;
    }
 
  public void addallMembers(CMember allMembers_xx) { if (allMembers.contains(allMembers_xx)) {} else { allMembers.add(allMembers_xx); }
    }
 
  public void removeallMembers(CMember allMembers_xx) { Vector _removedallMembersallMembers_xx = new Vector();
  _removedallMembersallMembers_xx.add(allMembers_xx);
  allMembers.removeAll(_removedallMembersallMembers_xx);
    }

  public static void setAllallMembers(List cstructs, List _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().setallMembers(cstructx, _val); } }

  public static void addAllallMembers(List cstructs, CMember _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().addallMembers(cstructx,  _val); } }


  public static void removeAllallMembers(List cstructs,CMember _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().removeallMembers(cstructx, _val); } }


  public static void unionAllallMembers(List cstructs, List _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().unionallMembers(cstructx, _val); } }


  public static void subtractAllallMembers(List cstructs,  List _val)
  { for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      Controller.inst().subtractallMembers(cstructx,  _val); } }


    public String getname() { return name; }

    public static List getAllname(List cstructs)
  { List result = new Vector();
    for (int i = 0; i < cstructs.size(); i++)
    { CStruct cstructx = (CStruct) cstructs.get(i);
      if (result.contains(cstructx.getname())) { }
      else { result.add(cstructx.getname()); } }
    return result; }

    public static List getAllOrderedname(List cstructs)
  { List result = new Vector();
    for (int i = 0; i < cstructs.size(); i++)
    { CStruct cstructx = (CStruct) cstructs.get(i);
      result.add(cstructx.getname()); } 
    return result; }

  public List getmembers() { return (Vector) ((Vector) members).clone(); }

  public static List getAllmembers(List cstructs)
  { List result = new Vector();
    for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      result = Set.union(result, cstructx.getmembers()); }
    return result; }

  public static List getAllOrderedmembers(List cstructs)
  { List result = new Vector();
    for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      result.addAll(cstructx.getmembers()); }
    return result; }

  public List getallMembers() { return (Vector) ((Vector) allMembers).clone(); }

  public static List getAllallMembers(List cstructs)
  { List result = new Vector();
    for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      result = Set.union(result, cstructx.getallMembers()); }
    return result; }

  public static List getAllOrderedallMembers(List cstructs)
  { List result = new Vector();
    for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructs.get(_i);
      result = Set.union(result, cstructx.getallMembers()); }
    return result; }

    public String toString()
  {   String result = "";
 
  result = "struct " + name;
    return result;
  }


    public List allCMembers()
  {   List result = new Vector();
 
  final List sups = Set.select_0(members); 
     if (sups.size() == 0) 
  {   result = members;
 
  }  else
      if (sups.size() > 0) 
  {   result = Set.union(( Set.subtract(members,sups) ),((CMember) Set.any(sups)).inheritedCMembers());
 
  }          return result;
  }


    public String createOp(String ent)
  {   String result = "";
 
  final String einst = ent.toLowerCase() + "_instances"; 
     result = "struct " + ent + "* create" + ent + "()\n" + "{ struct " + ent + "* result = (struct " + ent + "*) malloc(sizeof(struct " + ent + "));\n" + Set.sumString(Set.collect_1(members)) + "  " + einst + " = append" + ent + "(" + einst + ", result);\n" + "  " + ent.toLowerCase() + "_size++;\n" + "  return result;\n" + "}\n";
       return result;
  }


    public String createPKOp(String ent,String key)
  {   String result = "";
 
  final String einst = ent.toLowerCase() + "_instances"; 
     result = "struct " + ent + "* create" + ent + "(char* _value)\n" + "{ struct " + ent + "* result = NULL;\n" + "  result = get" + ent + "ByPK(_value);\n" + "  if (result != NULL) { return result; }\n" + "  result = (struct " + ent + "*) malloc(sizeof(struct " + ent + "));\n" + Set.sumString(Set.collect_1(members)) + "  set" + ent + "_" + key + "(result, _value);\n" + "  " + einst + " = append" + ent + "(" + einst + ", result);\n" + "  " + ent.toLowerCase() + "_size++;\n" + "  return result;\n" + "}\n";
       return result;
  }


    public String concatenateOp()
  {   String result = "";
 
  result = "struct " + name + "** concatenate" + name + "(struct " + name + "* _col1[], struct " + name + "* _col2[])\n" + "{ int n = length((void**) _col1);\n" + "  int m = length((void**) _col2);\n" + "  struct " + name + "** result = (struct " + name + "**) calloc(n + m + 1, sizeof(struct " + name + "*));\n" + "  int i = 0;\n" + "  int j = 0;\n" + "  for ( ; i < n; i++)\n" + "  { result[j] = _col1[i];\n" + "    j++;\n" + "  }\n" + "  i = 0;\n" + "  for ( ; i < m; i++)\n" + "  { result[j] = _col2[i];\n" + "    j++;\n" + "  }\n" + "  result[j] = NULL;\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String intersectionOp()
  {   String result = "";
 
  result = "struct " + name + "** intersection" + name + "(struct " + name + "* _col1[], struct " + name + "* _col2[])\n" + "{ int n = length((void**) _col1);\n" + "  int m = length((void**) _col2);\n" + "  struct " + name + "** result = (struct " + name + "**) calloc(n + 1, sizeof(struct " + name + "*));\n" + "  int i = 0;\n" + "  int j = 0;\n" + "  for ( ; i < n; i++)\n" + "  { struct " + name + "* _ex = _col1[i];\n" + "    if (isIn((void*) _ex, (void**) _col2))\n" + "    { result[j] = _ex; j++; }\n" + "  }\n" + "  result[j] = NULL;\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String insertAtOp()
  {   String result = "";
 
  result = "struct " + name + "** insertAt" + name + "(struct " + name + "* col1[], int ind, struct " + name + "* col2[])\n" + "{ if (ind <= 0) { return col1; }\n" + "  int n = length((void**) col1);\n" + "  int m = length((void**) col2);\n" + "  if (m == 0) { return col1; }\n" + "  struct " + name + "** result = (struct " + name + "**) calloc(n + m + 1, sizeof(struct " + name + "*));\n" + "  int i = 0; int j = 0;\n" + "  for ( ; i < ind - 1 && i < n; i++)\n" + "  { result[i] = col1[i]; }\n" + "  if (i == ind - 1)\n" + "  { for ( ; j < m; j++, i++)\n" + "    { result[i] = col2[j]; }\n" + "    for ( ; i < n + m; i++)\n" + "    { result[i] = col1[i - m]; }\n" + "  }\n" + "  else \n" + "  { for ( ; j < m; j++, i++)\n" + "    { result[i] = col2[j]; }\n" + "  }\n" + "  result[n+m] = NULL;\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String exists1Op()
  {   String result = "";
 
  result = "unsigned char exists1" + name + "(struct " + name + "* col[], unsigned char (*test)(struct " + name + "* ex))\n" + "{ int n = length((void**) col);\n" + "  unsigned char result = FALSE; \n" + "  unsigned char found = FALSE;\n" + "  int i = 0;  \n" + "  for ( ; i < n; i++)\n" + "  { struct " + name + "* ex = col[i];\n" + "    if (ex == NULL) { return result; }\n" + "    if ((*test)(ex))\n" + "    { if (found) { return FALSE; }\n" + "      else { found = TRUE; }\n" + "    }\n" + "  }\n" + "  if (found) { return TRUE; }\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String isUniqueOp()
  {   String result = "";
 
  result = "unsigned char isUnique" + name + "(struct " + name + "* col[], void* (*fe)(struct " + name + "* ex))\n" + "{ unsigned char result = TRUE; \n" + "  void** values = collect" + name + "(col, fe);\n" + "  int n = length((void**) values);\n" + "  int i = 0;  \n" + "  for ( ; i < n; i++)\n" + "  { void* ex = values[i];\n" + "    if (i < n - 1 && isIn(ex, values + (i + 1)))\n" + "    { return FALSE; }\n" + "  }\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String frontOp()
  {   String result = "";
 
  result = "struct " + name + "** front" + name + "(struct " + name + "* col[])\n" + "{ int n = length((void**) col);\n" + "  return subrange" + name + "(col, 1, n-1); }\n";
    return result;
  }


    public String tailOp()
  {   String result = "";
 
  result = "struct " + name + "** tail" + name + "(struct " + name + "* col[])\n" + "{ int n = length((void**) col);\n" + "  return subrange" + name + "(col, 2, n); }\n";
    return result;
  }


    public String removeAllOp()
  {   String result = "";
 
  result = "struct " + name + "** removeAll" + name + "(struct " + name + "* col1[], struct " + name + "* col2[])\n" + "{ int n = length((void**) col1);\n" + "  struct " + name + "** result = (struct " + name + "**) calloc(n+1, sizeof(struct " + name + "*));\n" + "  int i = 0; int j = 0;\n" + "  for ( ; i < n; i++)\n" + "  { struct " + name + "* ex = col1[i];\n" + "    if (isIn((void*) ex, (void**) col2)) {}\n" + "    else \n" + "    { result[j] = ex; j++; }\n" + "  }\n" + "  result[j] = NULL;\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String asSetOp()
  {   String result = "";
 
  result = "struct " + name + "** asSet" + name + "(struct " + name + "* col[])\n" + "{ int n = length((void**) col);\n" + "  if (n == 0) { return col; }\n" + "  struct " + name + "** result = (struct " + name + "**) calloc(n + 1, sizeof(struct " + name + "*));\n" + "  int i = 0; int j = 0;\n" + "  result[j] = NULL;\n" + "  for ( ; i < n; i++)\n" + "  { struct " + name + "* ex = col[i];\n" + "    if (isIn((void*) ex, (void**) result)) {}\n" + "    else  \n" + "    { result[j] = col[i]; j++;\n" + "      result[j] = NULL; }\n" + "  }    \n" + "  result[j] = NULL;\n" + "  return result;\n" + "}\n";
    return result;
  }


    public void printcode2()
  { Controller.inst().setallMembers(this,this.allCMembers());
  }

    public void printcode3()
  {   System.out.println("" + ( "struct " + this.getname() + "** " + this.getname().toLowerCase() + "_instances = NULL;" ));

      System.out.println("" + ( "int " + this.getname().toLowerCase() + "_size = 0;\n" ));

  }

    public void printcode4()
  {   System.out.println("" + ( "struct " + this.getname() + "** new" + this.getname() + "List()" ));

      System.out.println("" + ( "{ return (struct " + this.getname() + "**) calloc(ALLOCATIONSIZE, sizeof(struct " + this.getname() + "*)); }\n" ));

  }

    public void printcode5(CMember f)
  {   System.out.println("" + f.getterOp(this.getname()));

  }

    public void printcode5outer()
  {  CStruct cstructx = this;
    List _range40 = new Vector();
  _range40.addAll(cstructx.getmembers());
  for (int _i39 = 0; _i39 < _range40.size(); _i39++)
  { CMember f = (CMember) _range40.get(_i39);
        if (!(f.getname().equals("super")))
    {    this.printcode5(f); }

  }
  }


    public void printcode6(CMember f)
  {   System.out.println("" + f.inheritedGetterOps(this.getname()));

  }

    public void printcode6outer()
  {  CStruct cstructx = this;
    List _range42 = new Vector();
  _range42.addAll(cstructx.getmembers());
  for (int _i41 = 0; _i41 < _range42.size(); _i41++)
  { CMember f = (CMember) _range42.get(_i41);
        if (f.getname().equals("super"))
    {    this.printcode6(f); }

  }
  }


    public void printcode7(CMember f)
  {   System.out.println("" + f.setterOp(this.getname()));

  }

    public void printcode7outer()
  {  CStruct cstructx = this;
    List _range44 = new Vector();
  _range44.addAll(cstructx.getmembers());
  for (int _i43 = 0; _i43 < _range44.size(); _i43++)
  { CMember f = (CMember) _range44.get(_i43);
        if (!(f.getname().equals("super")))
    {    this.printcode7(f); }

  }
  }


    public void printcode8(CMember f)
  {   System.out.println("" + f.inheritedSetterOps(this.getname()));

  }

    public void printcode8outer()
  {  CStruct cstructx = this;
    List _range46 = new Vector();
  _range46.addAll(cstructx.getmembers());
  for (int _i45 = 0; _i45 < _range46.size(); _i45++)
  { CMember f = (CMember) _range46.get(_i45);
        if (f.getname().equals("super"))
    {    this.printcode8(f); }

  }
  }


    public void printcode9(CMember f)
  {   System.out.println("" + f.getAllOp(this.getname()));

  }

    public void printcode9outer()
  {  CStruct cstructx = this;
    List _range48 = new Vector();
  _range48.addAll(cstructx.getallMembers());
  for (int _i47 = 0; _i47 < _range48.size(); _i47++)
  { CMember f = (CMember) _range48.get(_i47);
        if ((f.gettype() instanceof CPrimitiveType))
    {    this.printcode9(f); }

  }
  }


    public void printcode10(CMember f)
  {   System.out.println("" + f.getAllOp1(this.getname()));

  }

    public void printcode10outer()
  {  CStruct cstructx = this;
    List _range50 = new Vector();
  _range50.addAll(cstructx.getallMembers());
  for (int _i49 = 0; _i49 < _range50.size(); _i49++)
  { CMember f = (CMember) _range50.get(_i49);
        if (!(f.getname().equals("super")))
    {     if ((f.gettype() instanceof CPointerType))
    {    this.printcode10(f); }
 }

  }
  }


    public void printcode11(CMember key)
  {   System.out.println("" + key.getPKOp(this.getname()));

      System.out.println("" + key.getPKsOp(this.getname()));

  }

    public void printcode11outer()
  {  CStruct cstructx = this;
      if (Set.exists_2(cstructx.getallMembers()))
    {   CMember key = ((CMember) Set.any(Set.select_3(cstructx.getallMembers())));
     this.printcode11(key);
 }

  }


    public void printcode12()
  {   System.out.println("" + ( "struct " + this.getname() + "** append" + this.getname() + "(struct " + this.getname() + "* col[], struct " + this.getname() + "* ex)" ));

      System.out.println("" + ( "   { struct " + this.getname() + "** result;" ));

      System.out.println("" + "     int len = length((void**) col);");

      System.out.println("" + "     if (len % ALLOCATIONSIZE == 0)");

      System.out.println("" + ( "     { result = (struct " + this.getname() + "**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct " + this.getname() + "*));" ));

      System.out.println("" + "       int i = 0;");

      System.out.println("" + "       for ( ; i < len; i++) { result[i] = col[i]; }");

      System.out.println("" + "     }");

      System.out.println("" + "    else { result = col; }");

      System.out.println("" + "    result[len] = ex;");

      System.out.println("" + "    result[len+1] = NULL;");

      System.out.println("" + "    return result;");

      System.out.println("" + "  }\n");

  }

    public void printcode13(CMember key)
  {   System.out.println("" + this.createPKOp(this.getname(),key.getname()));

  }

    public void printcode13outer()
  {  CStruct cstructx = this;
      if (Set.exists_2(cstructx.getallMembers()))
    {   CMember key = ((CMember) Set.any(Set.select_3(cstructx.getallMembers())));
     this.printcode13(key);
 }

  }


    public void printcode14()
  {   System.out.println("" + this.createOp(this.getname()));

  }

    public void printcode15()
  {   System.out.println("" + ( "struct " + this.getname() + "** insert" + this.getname() + "(struct " + this.getname() + "* col[], struct " + this.getname() + "* self)" ));

      System.out.println("" + "  { if (isIn((void*) self, (void**) col))");

      System.out.println("" + "    { return col; }");

      System.out.println("" + ( "    return append" + this.getname() + "(col,self);" ));

      System.out.println("" + "  }\n");

  }

    public void printcode16()
  {   if (Set.exists_4(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + ( "struct " + this.getname() + "** select" + this.getname() + "(struct " + this.getname() + "* col[], unsigned char (*test)(struct " + this.getname() + "* self))" ));

      System.out.println("" + ( "{ struct " + this.getname() + "** result;" ));

      System.out.println("" + "  int len = length((void**) col);");

      System.out.println("" + ( "  result = (struct " + this.getname() + "**) calloc(len + 1, sizeof(struct " + this.getname() + "*));" ));

      System.out.println("" + "  int j = 0;");

      System.out.println("" + "  int i = 0;");

      System.out.println("" + "  for ( ; i < len; i++)");

      System.out.println("" + ( "  { struct " + this.getname() + "* self = col[i];" ));

      System.out.println("" + "    if (self == NULL)");

      System.out.println("" + "	{ result[j] = NULL;");

      System.out.println("" + "	  return result;");

      System.out.println("" + "	}");

      System.out.println("" + "	if ((*test)(self))");

      System.out.println("" + "    { result[j] = self;");

      System.out.println("" + "	  j++;");

      System.out.println("" + "	}");

      System.out.println("" + "  }");

      System.out.println("" + "  result[j] = NULL;");

      System.out.println("" + "  return result;");

      System.out.println("" + "}\n");
}
  }

    public void printcode17()
  {   if (Set.exists_5(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + ( "struct " + this.getname() + "** reject" + this.getname() + "(struct " + this.getname() + "* col[], unsigned char (*test)(struct " + this.getname() + "* self))" ));

      System.out.println("" + ( "{ struct " + this.getname() + "** result;" ));

      System.out.println("" + "  int len = length((void**) col);");

      System.out.println("" + ( "  result = (struct " + this.getname() + "**) calloc(len + 1, sizeof(struct " + this.getname() + "*));" ));

      System.out.println("" + "  int j = 0;");

      System.out.println("" + "  int i = 0;");

      System.out.println("" + "  for ( ; i < len; i++)");

      System.out.println("" + ( "  { struct " + this.getname() + "* self = col[i];" ));

      System.out.println("" + "    if (self == NULL)");

      System.out.println("" + "	{ result[j] = NULL;");

      System.out.println("" + "	  return result;");

      System.out.println("" + "	}");

      System.out.println("" + "	if ((*test)(self)) {}");

      System.out.println("" + "    else { result[j] = self;");

      System.out.println("" + "	  j++;");

      System.out.println("" + "	}");

      System.out.println("" + "  }");

      System.out.println("" + "  result[j] = NULL;");

      System.out.println("" + "  return result;");

      System.out.println("" + "}\n");
}
  }

    public void printcode18()
  {   if (Set.exists_6(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + ( "   void** collect" + this.getname() + "(struct " + this.getname() + "* col[], void* (*fe)(struct " + this.getname() + "*))" ));

      System.out.println("" + "   { int n = length((void**) col);");

      System.out.println("" + "    void** result = (void**) calloc(n+1, sizeof(void*));");

      System.out.println("" + "    int i = 0;");

      System.out.println("" + "    for ( ; i < n; i++)");

      System.out.println("" + ( "    { struct " + this.getname() + "* self = col[i];" ));

      System.out.println("" + "      result[i] = (*fe)(self);");

      System.out.println("" + "    }");

      System.out.println("" + "    result[n] = NULL;");

      System.out.println("" + "    return result;");

      System.out.println("" + "  }\n");
}
  }

    public void printcode19()
  {   if (Set.exists_7(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + ( " unsigned char exists" + this.getname() + "(struct " + this.getname() + "* col[], unsigned char (*test)(struct " + this.getname() + "* ex))" ));

      System.out.println("" + " { int n = length((void**) col);");

      System.out.println("" + "   unsigned char result = FALSE;");

      System.out.println("" + "   int i = 0;");

      System.out.println("" + "   for ( ; i < n; i++)");

      System.out.println("" + ( "   { struct " + this.getname() + "* ex = col[i];" ));

      System.out.println("" + "     if (ex == NULL) { return result; }");

      System.out.println("" + "     if ((*test)(ex))");

      System.out.println("" + "     { return TRUE; }");

      System.out.println("" + "   }");

      System.out.println("" + "   return result;");

      System.out.println("" + " }\n");
}
  }

    public void printcode20()
  {   if (Set.exists_8(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + ( " unsigned char forAll" + this.getname() + "(struct " + this.getname() + "* col[], unsigned char (*test)(struct " + this.getname() + "* ex))" ));

      System.out.println("" + " { int n = length((void**) col);");

      System.out.println("" + "   unsigned char result = TRUE;");

      System.out.println("" + "   int i = 0;");

      System.out.println("" + "   for ( ; i < n; i++)");

      System.out.println("" + ( "   { struct " + this.getname() + "* ex = col[i];" ));

      System.out.println("" + "     if (ex == NULL) { return result; }");

      System.out.println("" + "     if ((*test)(ex)) {}");

      System.out.println("" + "     else { return FALSE; }");

      System.out.println("" + "   }");

      System.out.println("" + "   return result;");

      System.out.println("" + " }\n");
}
  }

    public void printcode21()
  {   System.out.println("" + ( "  struct " + this.getname() + "** subrange" + this.getname() + "(struct " + this.getname() + "** col, int i, int j)" ));

      System.out.println("" + "  { int len = length((void**) col);");

      System.out.println("" + "    if (i > j || j > len) { return NULL; }");

      System.out.println("" + ( "    struct " + this.getname() + "** result = (struct " + this.getname() + "**) calloc(j - i + 2, sizeof(struct " + this.getname() + "*));" ));

      System.out.println("" + "     int k = i-1;");

      System.out.println("" + "     int l = 0;");

      System.out.println("" + "     for ( ; k < j; k++, l++)");

      System.out.println("" + "     { result[l] = col[k]; }");

      System.out.println("" + "    result[l] = NULL;");

      System.out.println("" + "    return result;");

      System.out.println("" + "  }\n");

  }

    public void printcode22()
  {   System.out.println("" + ( "  struct " + this.getname() + "** reverse" + this.getname() + "(struct " + this.getname() + "** col)" ));

      System.out.println("" + "  { int n = length((void**) col);");

      System.out.println("" + ( "    struct " + this.getname() + "** result = (struct " + this.getname() + "**) calloc(n+1, sizeof(struct " + this.getname() + "*));" ));

      System.out.println("" + "    int i = 0;");

      System.out.println("" + "    int x = n-1;");

      System.out.println("" + "    for ( ; i < n; i++, x--)");

      System.out.println("" + "    { result[i] = col[x]; }");

      System.out.println("" + "    result[n] = NULL;");

      System.out.println("" + "    return result;");

      System.out.println("" + "  }\n");

  }

    public void printcode23()
  {   System.out.println("" + ( "struct " + this.getname() + "** remove" + this.getname() + "(struct " + this.getname() + "* col[], struct " + this.getname() + "* ex)" ));

      System.out.println("" + "{ int len = length((void**) col);");

      System.out.println("" + ( "  struct " + this.getname() + "** result = (struct " + this.getname() + "**) calloc(len+1, sizeof(struct " + this.getname() + "*));" ));

      System.out.println("" + "  int j = 0;");

      System.out.println("" + "  int i = 0;");

      System.out.println("" + "  for ( ; i < len; i++)");

      System.out.println("" + ( "  { struct " + this.getname() + "* eobj = col[i];" ));

      System.out.println("" + "    if (eobj == NULL)");

      System.out.println("" + "    { result[j] = NULL;");

      System.out.println("" + "      return result; ");

      System.out.println("" + "    }");

      System.out.println("" + "    if (eobj == ex) { }");

      System.out.println("" + "    else");

      System.out.println("" + "    { result[j] = eobj; j++; }");

      System.out.println("" + "  }");

      System.out.println("" + "  result[j] = NULL;");

      System.out.println("" + "  return result;");

      System.out.println("" + "}\n");

  }

    public void printcode24()
  {   if (Set.exists_9(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + ( "struct " + this.getname() + "** union" + this.getname() + "(struct " + this.getname() + "* col1[], struct " + this.getname() + "* col2[])" ));

      System.out.println("" + "  { int n = length((void**) col1);");

      System.out.println("" + "    int m = length((void**) col2);");

      System.out.println("" + ( "    struct " + this.getname() + "** result = (struct " + this.getname() + "**) calloc(n + m + 1, sizeof(struct " + this.getname() + "*));" ));

      System.out.println("" + "    int i = 0;");

      System.out.println("" + "    int j = 0;");

      System.out.println("" + "    for ( ; i < n; i++)");

      System.out.println("" + ( "    { struct " + this.getname() + "* ex = col1[i];" ));

      System.out.println("" + "      if (isIn((void*) ex, (void**) result)) { }");

      System.out.println("" + "      else   ");

      System.out.println("" + "      { result[j] = ex; j++; }");

      System.out.println("" + "    }    ");

      System.out.println("" + "    i = 0;");

      System.out.println("" + "    for ( ; i < m; i++)");

      System.out.println("" + ( "    { struct " + this.getname() + "* ex = col2[i];" ));

      System.out.println("" + "      if (isIn((void*) ex, (void**) result)) { }");

      System.out.println("" + "      else   ");

      System.out.println("" + "      { result[j] = ex; j++; }");

      System.out.println("" + "    }");

      System.out.println("" + "    result[j] = NULL;");

      System.out.println("" + "    return result;");

      System.out.println("" + "  }\n");
}
  }

    public void printcode25()
  {   System.out.println("" + this.removeAllOp());

  }

    public void printcode26()
  {   System.out.println("" + this.frontOp());

  }

    public void printcode27()
  {   System.out.println("" + this.tailOp());

  }

    public void printcode28()
  {   if (Set.exists_10(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + this.concatenateOp());
}
  }

    public void printcode29()
  {   if (Set.exists_11(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + this.intersectionOp());
}
  }

    public void printcode30()
  {   if (Set.exists_12(Controller.inst().basicexpressions)) 
  {   System.out.println("" + this.insertAtOp());
}
  }

    public void printcode31()
  {   if (Set.exists_13(Controller.inst().binaryexpressions,this)) 
  {   System.out.println("" + this.exists1Op());
}
  }

    public void printcode32()
  {   if (Set.exists_14(Controller.inst().unaryexpressions,this)) 
  {   System.out.println("" + this.isUniqueOp());
}
  }

    public void printcode33()
  {   if (Set.exists_15(Controller.inst().unaryexpressions,this)) 
  {   System.out.println("" + this.asSetOp());
}
  }


}


class CMember
  implements SystemTypes
{
  private String name = ""; // internal
  private boolean isKey = false; // internal
  private CType type;

  public CMember(CType type)
  {
    this.name = "";
    this.isKey = false;
    this.type = type;

  }

  public CMember() { }



  public String toString()
  { String _res_ = "(CMember) ";
    _res_ = _res_ + name + ",";
    _res_ = _res_ + isKey;
    return _res_;
  }

  public static CMember parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CMember cmemberx = new CMember();
    cmemberx.name = (String) _line1vals.get(0);
    cmemberx.isKey = Boolean.parseBoolean((String) _line1vals.get(1));
    return cmemberx;
  }


  public void writeCSV(PrintWriter _out)
  { CMember cmemberx = this;
    _out.print("" + cmemberx.name);
    _out.print(" , ");
    _out.print("" + cmemberx.isKey);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List cmembers,String val)
  { for (int i = 0; i < cmembers.size(); i++)
    { CMember cmemberx = (CMember) cmembers.get(i);
      Controller.inst().setname(cmemberx,val); } }


  public void setisKey(boolean isKey_x) { isKey = isKey_x;  }


    public static void setAllisKey(List cmembers,boolean val)
  { for (int i = 0; i < cmembers.size(); i++)
    { CMember cmemberx = (CMember) cmembers.get(i);
      Controller.inst().setisKey(cmemberx,val); } }


  public void settype(CType type_xx) { type = type_xx;
  }

  public static void setAlltype(List cmembers, CType _val)
  { for (int _i = 0; _i < cmembers.size(); _i++)
    { CMember cmemberx = (CMember) cmembers.get(_i);
      Controller.inst().settype(cmemberx, _val); } }

    public String getname() { return name; }

    public static List getAllname(List cmembers)
  { List result = new Vector();
    for (int i = 0; i < cmembers.size(); i++)
    { CMember cmemberx = (CMember) cmembers.get(i);
      if (result.contains(cmemberx.getname())) { }
      else { result.add(cmemberx.getname()); } }
    return result; }

    public static List getAllOrderedname(List cmembers)
  { List result = new Vector();
    for (int i = 0; i < cmembers.size(); i++)
    { CMember cmemberx = (CMember) cmembers.get(i);
      result.add(cmemberx.getname()); } 
    return result; }

    public boolean getisKey() { return isKey; }

    public static List getAllisKey(List cmembers)
  { List result = new Vector();
    for (int i = 0; i < cmembers.size(); i++)
    { CMember cmemberx = (CMember) cmembers.get(i);
      if (result.contains(new Boolean(cmemberx.getisKey()))) { }
      else { result.add(new Boolean(cmemberx.getisKey())); } }
    return result; }

    public static List getAllOrderedisKey(List cmembers)
  { List result = new Vector();
    for (int i = 0; i < cmembers.size(); i++)
    { CMember cmemberx = (CMember) cmembers.get(i);
      result.add(new Boolean(cmemberx.getisKey())); } 
    return result; }

  public CType gettype() { return type; }

  public static List getAlltype(List cmembers)
  { List result = new Vector();
    for (int _i = 0; _i < cmembers.size(); _i++)
    { CMember cmemberx = (CMember) cmembers.get(_i);
      if (result.contains(cmemberx.gettype())) {}
      else { result.add(cmemberx.gettype()); }
 }
    return result; }

  public static List getAllOrderedtype(List cmembers)
  { List result = new Vector();
    for (int _i = 0; _i < cmembers.size(); _i++)
    { CMember cmemberx = (CMember) cmembers.get(_i);
      if (result.contains(cmemberx.gettype())) {}
      else { result.add(cmemberx.gettype()); }
 }
    return result; }

    public List inheritedCMembers()
  {   List result = new Vector();
    if (!(type instanceof CPointerType) || !(((CPointerType) type).getpointsTo() instanceof CStruct)) { return result; } 
   
  final CType anc = ((CPointerType) type).getpointsTo(); 
     result = ((CStruct) anc).allCMembers();
       return result;
  }


    public String getterOp(String ent)
  {   String result = "";
 
    if ((type instanceof CFunctionPointerType))
    {   CType td = ((CFunctionPointerType) type).getdomainType();
    CType tr = ((CFunctionPointerType) type).getrangeType();
     result = tr + " (*get" + ent + "_" + name + "(struct " + ent + "* self))(" + td + ")\n" + "{ return self->" + name + "; }\n";

 }
  else
      if (true) 
  {   result = type + " get" + ent + "_" + name + "(struct " + ent + "* self)\n{ return self->" + name + "; }\n";
 
  }       return result;
  }


    public String inheritedGetterOp(String ent,String sup)
  {   String result = "";
 
  if (!(name.equals("super"))) 
  {   result = type + " get" + ent + "_" + name + "(struct " + ent + "* self) { return get" + sup + "_" + name + "(self->super); }\n";
 
  }  else
      if (name.equals("super")) 
  {   result = this.ancestorGetterOps(ent,sup);
 
  }       return result;
  }


    public String ancestorGetterOps(String ent,String sup)
  {   String result = "";
    if (!(type instanceof CPointerType) || !(((CPointerType) type).getpointsTo() instanceof CStruct)) { return result; } 
   
  final CType anc = ((CPointerType) type).getpointsTo(); 
     result = Set.sumString(Set.collect_16(((CStruct) anc).getmembers(),ent,sup));
       return result;
  }


    public String inheritedGetterOps(String ent)
  {   String result = "";
    if (!(type instanceof CPointerType) || !(((CPointerType) type).getpointsTo() instanceof CStruct)) { return result; } 
   
  final CType sup = ((CPointerType) type).getpointsTo(); 
     result = Set.sumString(Set.collect_17(((CStruct) sup).getmembers(),ent,sup));
       return result;
  }


    public String setterOp(String ent)
  {   String result = "";
 
    if ((type instanceof CFunctionPointerType))
    {   CType td = ((CFunctionPointerType) type).getdomainType();
    CType tr = ((CFunctionPointerType) type).getrangeType();
     result = "void set" + ent + "_" + name + "(struct " + ent + "* self, " + tr + " (*_value)(" + td + ")\n{ self->" + name + " = _value; }\n";

 }
  else
      if (true) 
  {   result = "void set" + ent + "_" + name + "(struct " + ent + "* self, " + type + " _value)\n{ self->" + name + " = _value; }\n";
 
  }       return result;
  }


    public String inheritedSetterOp(String ent,String sup)
  {   String result = "";
 
  if (!(name.equals("super"))) 
  {   result = "void set" + ent + "_" + name + "(struct " + ent + "* self, " + type + " _value) { set" + sup + "_" + name + "(self->super, _value); }\n";
 
  }  else
      if (name.equals("super")) 
  {   result = this.ancestorSetterOps(ent,sup);
 
  }       return result;
  }


    public String ancestorSetterOps(String ent,String sup)
  {   String result = "";
    if (!(type instanceof CPointerType) || !(((CPointerType) type).getpointsTo() instanceof CStruct)) { return result; } 
   
  final CType anc = ((CPointerType) type).getpointsTo(); 
     result = Set.sumString(Set.collect_18(((CStruct) anc).getmembers(),ent,sup));
       return result;
  }


    public String inheritedSetterOps(String ent)
  {   String result = "";
    if (!(type instanceof CPointerType) || !(((CPointerType) type).getpointsTo() instanceof CStruct)) { return result; } 
   
  final CType sup = ((CPointerType) type).getpointsTo(); 
     result = Set.sumString(Set.collect_19(((CStruct) sup).getmembers(),ent,sup));
       return result;
  }


    public String getAllOp(String ent)
  {   String result = "";
 
  result = type + "* getAll" + ent + "_" + name + "(struct " + ent + "* _col[])\n" + "{ int n = length((void**) _col);\n" + "  " + type + "* result = (" + type + "*) calloc(n, sizeof(" + type + "));\n" + "  int i = 0;\n" + "  for ( ; i < n; i++)\n" + "  { result[i] = get" + ent + "_" + name + "(_col[i]); }\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String getAllOp1(String ent)
  {   String result = "";
 
  result = type + "* getAll" + ent + "_" + name + "(struct " + ent + "* _col[])\n" + "{ int n = length((void**) _col);\n" + "  " + type + "* result = (" + type + "*) calloc(n+1, sizeof(" + type + "));\n" + "  int i = 0;\n" + "  for ( ; i < n; i++)\n" + "  { result[i] = get" + ent + "_" + name + "(_col[i]); }\n" + "  result[n] = NULL;\n" + "  return result;\n" + "}\n";
    return result;
  }


    public String inheritedAllOp(String ent,String sup)
  {   String result = "";
 
  if (!(name.equals("super")) && (type instanceof CPrimitiveType)) 
  {   result = this.getAllOp(ent);
 
  }  else
      {   if (!(name.equals("super")) && (type instanceof CPointerType)) 
  {   result = this.getAllOp1(ent);
 
  }  else
      if (name.equals("super")) 
  {   result = this.ancestorAllOps(ent,sup);
 
  }   
   }     return result;
  }


    public String ancestorAllOps(String ent,String sup)
  {   String result = "";
    if (!(type instanceof CPointerType)) { return result; } 
   
  final CType anc = ((CPointerType) type).getpointsTo(); 
     result = Set.sumString(Set.collect_20(((CStruct) anc).getmembers(),ent,sup));
       return result;
  }


    public String inheritedAllOps(String ent)
  {   String result = "";
    if (!(type instanceof CPointerType)) { return result; } 
   
  final CType sup = ((CPointerType) type).getpointsTo(); 
     result = Set.sumString(Set.collect_21(((CStruct) sup).getmembers(),ent,sup));
       return result;
  }


    public String getPKOp(String ent)
  {   String result = "";
 
  final String e = ent.toLowerCase(); 
     result = "struct " + ent + "* get" + ent + "ByPK(char* _ex)\n" + "{ int n = length((void**) " + e + "_instances);\n" + "  int i = 0;\n" + "  for ( ; i < n; i++)\n" + "  { char* _v = get" + ent + "_" + name + "(" + e + "_instances[i]);\n" + "    if (_v != NULL && strcmp(_v,_ex) == 0)\n" + "    { return " + e + "_instances[i]; }\n" + "  }\n" + "  return NULL;\n" + "}\n";
       return result;
  }


    public String getPKsOp(String ent)
  {   String result = "";
 
  final String e = ent.toLowerCase(); 
     result = "struct " + ent + "** get" + ent + "ByPKs(char* _col[])\n" + "{ int n = length((void**) _col);\n" + "  struct " + ent + "** result = (struct " + ent + "**) calloc(n+1, sizeof(struct " + ent + "*));\n" + "  int i = 0; int j = 0;\n" + "  for ( ; i < n; i++)\n" + "  { char* _v = _col[i];\n" + "    struct " + ent + "* _ex = get" + ent + "ByPK(_v);\n" + "    if (_ex != NULL)\n" + "    { result[j] = _ex; j++; }\n" + "  }\n" + "  result[j] = NULL;\n" + "  return result; }\n";
       return result;
  }


    public String initialiser()
  {   String result = "";
 
  if (isKey == true) 
  {   result = "";
 
  }  else
      {   if (name.equals("super")) 
  {   result = "  result->super = create" + ((CPointerType) type).getpointsTo().getname() + "();\n";
 
  }  else
      {   if ((type instanceof CPointerType) || (type instanceof CArrayType)) 
  {   result = "  result->" + name + " = NULL;\n";
 
  }  else
      if ((type instanceof CPrimitiveType)) 
  {   result = "  result->" + name + " = 0;\n";
 
  }   
   } 
   }     return result;
  }



}


class CVariable
  implements SystemTypes
{
  private String name = ""; // internal
  private String kind = ""; // internal
  private String initialisation = ""; // internal
  private CType type;

  public CVariable(CType type)
  {
    this.name = "";
    this.kind = "";
    this.initialisation = "";
    this.type = type;

  }

  public CVariable() { }



  public String toString()
  { String _res_ = "(CVariable) ";
    _res_ = _res_ + name + ",";
    _res_ = _res_ + kind + ",";
    _res_ = _res_ + initialisation;
    return _res_;
  }

  public static CVariable parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CVariable cvariablex = new CVariable();
    cvariablex.name = (String) _line1vals.get(0);
    cvariablex.kind = (String) _line1vals.get(1);
    cvariablex.initialisation = (String) _line1vals.get(2);
    return cvariablex;
  }


  public void writeCSV(PrintWriter _out)
  { CVariable cvariablex = this;
    _out.print("" + cvariablex.name);
    _out.print(" , ");
    _out.print("" + cvariablex.kind);
    _out.print(" , ");
    _out.print("" + cvariablex.initialisation);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List cvariables,String val)
  { for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      Controller.inst().setname(cvariablex,val); } }


  public void setkind(String kind_x) { kind = kind_x;  }


    public static void setAllkind(List cvariables,String val)
  { for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      Controller.inst().setkind(cvariablex,val); } }


  public void setinitialisation(String initialisation_x) { initialisation = initialisation_x;  }


    public static void setAllinitialisation(List cvariables,String val)
  { for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      Controller.inst().setinitialisation(cvariablex,val); } }


  public void settype(CType type_xx) { type = type_xx;
  }

  public static void setAlltype(List cvariables, CType _val)
  { for (int _i = 0; _i < cvariables.size(); _i++)
    { CVariable cvariablex = (CVariable) cvariables.get(_i);
      Controller.inst().settype(cvariablex, _val); } }

    public String getname() { return name; }

    public static List getAllname(List cvariables)
  { List result = new Vector();
    for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      if (result.contains(cvariablex.getname())) { }
      else { result.add(cvariablex.getname()); } }
    return result; }

    public static List getAllOrderedname(List cvariables)
  { List result = new Vector();
    for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      result.add(cvariablex.getname()); } 
    return result; }

    public String getkind() { return kind; }

    public static List getAllkind(List cvariables)
  { List result = new Vector();
    for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      if (result.contains(cvariablex.getkind())) { }
      else { result.add(cvariablex.getkind()); } }
    return result; }

    public static List getAllOrderedkind(List cvariables)
  { List result = new Vector();
    for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      result.add(cvariablex.getkind()); } 
    return result; }

    public String getinitialisation() { return initialisation; }

    public static List getAllinitialisation(List cvariables)
  { List result = new Vector();
    for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      if (result.contains(cvariablex.getinitialisation())) { }
      else { result.add(cvariablex.getinitialisation()); } }
    return result; }

    public static List getAllOrderedinitialisation(List cvariables)
  { List result = new Vector();
    for (int i = 0; i < cvariables.size(); i++)
    { CVariable cvariablex = (CVariable) cvariables.get(i);
      result.add(cvariablex.getinitialisation()); } 
    return result; }

  public CType gettype() { return type; }

  public static List getAlltype(List cvariables)
  { List result = new Vector();
    for (int _i = 0; _i < cvariables.size(); _i++)
    { CVariable cvariablex = (CVariable) cvariables.get(_i);
      if (result.contains(cvariablex.gettype())) {}
      else { result.add(cvariablex.gettype()); }
 }
    return result; }

  public static List getAllOrderedtype(List cvariables)
  { List result = new Vector();
    for (int _i = 0; _i < cvariables.size(); _i++)
    { CVariable cvariablex = (CVariable) cvariables.get(_i);
      if (result.contains(cvariablex.gettype())) {}
      else { result.add(cvariablex.gettype()); }
 }
    return result; }

    public String parameterDeclaration()
  {   String result = "";
 
  if ((type instanceof CFunctionPointerType)) 
  {   result = ((CFunctionPointerType) type).getrangeType() + " (*" + name + ")(" + ((CFunctionPointerType) type).getdomainType() + ")";
 
  }  else
      if (!(type instanceof CFunctionPointerType)) 
  {   result = type + " " + name;
 
  }       return result;
  }



}


class CProgram
  implements SystemTypes
{
  private List operations = new Vector(); // of COperation
  private List variables = new Vector(); // of CVariable
  private List structs = new Vector(); // of CStruct

  public CProgram()
  {

  }



  public String toString()
  { String _res_ = "(CProgram) ";
    return _res_;
  }

  public static CProgram parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CProgram cprogramx = new CProgram();
    return cprogramx;
  }


  public void writeCSV(PrintWriter _out)
  { CProgram cprogramx = this;
    _out.println();
  }


  public void setoperations(List operations_xx) { operations = operations_xx;
    }
 
  public void addoperations(COperation operations_xx) { if (operations.contains(operations_xx)) {} else { operations.add(operations_xx); }
    }
 
  public void removeoperations(COperation operations_xx) { Vector _removedoperationsoperations_xx = new Vector();
  _removedoperationsoperations_xx.add(operations_xx);
  operations.removeAll(_removedoperationsoperations_xx);
    }

  public static void setAlloperations(List cprograms, List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().setoperations(cprogramx, _val); } }

  public static void addAlloperations(List cprograms, COperation _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().addoperations(cprogramx,  _val); } }


  public static void removeAlloperations(List cprograms,COperation _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().removeoperations(cprogramx, _val); } }


  public static void unionAlloperations(List cprograms, List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().unionoperations(cprogramx, _val); } }


  public static void subtractAlloperations(List cprograms,  List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().subtractoperations(cprogramx,  _val); } }


  public void setvariables(List variables_xx) { variables = variables_xx;
    }
 
  public void addvariables(CVariable variables_xx) { if (variables.contains(variables_xx)) {} else { variables.add(variables_xx); }
    }
 
  public void removevariables(CVariable variables_xx) { Vector _removedvariablesvariables_xx = new Vector();
  _removedvariablesvariables_xx.add(variables_xx);
  variables.removeAll(_removedvariablesvariables_xx);
    }

  public static void setAllvariables(List cprograms, List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().setvariables(cprogramx, _val); } }

  public static void addAllvariables(List cprograms, CVariable _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().addvariables(cprogramx,  _val); } }


  public static void removeAllvariables(List cprograms,CVariable _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().removevariables(cprogramx, _val); } }


  public static void unionAllvariables(List cprograms, List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().unionvariables(cprogramx, _val); } }


  public static void subtractAllvariables(List cprograms,  List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().subtractvariables(cprogramx,  _val); } }


  public void setstructs(List structs_xx) { structs = structs_xx;
    }
 
  public void addstructs(CStruct structs_xx) { if (structs.contains(structs_xx)) {} else { structs.add(structs_xx); }
    }
 
  public void removestructs(CStruct structs_xx) { Vector _removedstructsstructs_xx = new Vector();
  _removedstructsstructs_xx.add(structs_xx);
  structs.removeAll(_removedstructsstructs_xx);
    }

  public static void setAllstructs(List cprograms, List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().setstructs(cprogramx, _val); } }

  public static void addAllstructs(List cprograms, CStruct _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().addstructs(cprogramx,  _val); } }


  public static void removeAllstructs(List cprograms,CStruct _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().removestructs(cprogramx, _val); } }


  public static void unionAllstructs(List cprograms, List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().unionstructs(cprogramx, _val); } }


  public static void subtractAllstructs(List cprograms,  List _val)
  { for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      Controller.inst().subtractstructs(cprogramx,  _val); } }


  public List getoperations() { return (Vector) ((Vector) operations).clone(); }

  public static List getAlloperations(List cprograms)
  { List result = new Vector();
    for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      result = Set.union(result, cprogramx.getoperations()); }
    return result; }

  public static List getAllOrderedoperations(List cprograms)
  { List result = new Vector();
    for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      result = Set.union(result, cprogramx.getoperations()); }
    return result; }

  public List getvariables() { return (Vector) ((Vector) variables).clone(); }

  public static List getAllvariables(List cprograms)
  { List result = new Vector();
    for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      result = Set.union(result, cprogramx.getvariables()); }
    return result; }

  public static List getAllOrderedvariables(List cprograms)
  { List result = new Vector();
    for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      result = Set.union(result, cprogramx.getvariables()); }
    return result; }

  public List getstructs() { return (Vector) ((Vector) structs).clone(); }

  public static List getAllstructs(List cprograms)
  { List result = new Vector();
    for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      result = Set.union(result, cprogramx.getstructs()); }
    return result; }

  public static List getAllOrderedstructs(List cprograms)
  { List result = new Vector();
    for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx = (CProgram) cprograms.get(_i);
      result = Set.union(result, cprogramx.getstructs()); }
    return result; }

    public COperation defineCOp(CExpression b,String par,CType pt)
  {   COperation result = null;
 
  COperation op = new COperation();
    Controller.inst().addCOperation(op);
    op.setname("op_" + operations.size());
    op.setscope("auxiliary");
    op.setisStatic(false);
    b.setneedsBracket(true);
    op.setreturnType(b.gettype());
    op.setisQuery(true);
      if (Controller.inst().getCReturnStatementByPK("return_" + b.getcexpId()) != null)
    { CReturnStatement rt = Controller.inst().getCReturnStatementByPK("return_" + b.getcexpId());
     Controller.inst().addreturnValue(rt,b);
    op.setcode(rt);
  }
    else
    { CReturnStatement rt = new CReturnStatement();
    Controller.inst().addCReturnStatement(rt);
    rt.setcstatId("return_" + b.getcexpId());
    Controller.inst().addreturnValue(rt,b);
    op.setcode(rt); }

    CVariable v = new CVariable();
    Controller.inst().addCVariable(v);
    v.setname(par);
    v.settype(pt);
    Controller.inst().addparameters(op,v);
    operations.add(op);
    result = op;
      return result;
  }


    public void printOperations()
  {     List _coperation_list51 = new Vector();
    _coperation_list51.addAll(this.getoperations());
    for (int _ind52 = 0; _ind52 < _coperation_list51.size(); _ind52++)
    { COperation op = (COperation) _coperation_list51.get(_ind52);
        System.out.println("" + op);

    }

  }

    public void printProgramHeader()
  {   System.out.println("" + "#include <ctype.h>");

      System.out.println("" + "#include <stdio.h>");

      System.out.println("" + "#include <string.h>");

      System.out.println("" + "#include <stdlib.h>");

      System.out.println("" + "#include <time.h>");

      System.out.println("" + "#include <math.h>");

      System.out.println("" + "#define ALLOCATIONSIZE 10\n");

      System.out.println("" + "#define TRUE 1");

      System.out.println("" + "#define FALSE 0\n");

      System.out.println("" + "#include \"ocl.h\"\n");

      System.out.println("" + "#include \"app.h\"\n");

  }

    public void exp2c6()
  {   System.out.println("" + "int main(int _argc, char* _argv[]) { return 0; }");

  }

    public void printcode1()
  { this.printProgramHeader();
  }


}


class CFunctionPointerType
  extends CType
  implements SystemTypes
{
  private CType domainType;
  private CType rangeType;

  public CFunctionPointerType(CType domainType,CType rangeType)
  {
    this.domainType = domainType;
    this.rangeType = rangeType;

  }

  public CFunctionPointerType() { }



  public static CFunctionPointerType parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CFunctionPointerType cfunctionpointertypex = new CFunctionPointerType();
    return cfunctionpointertypex;
  }


  public void writeCSV(PrintWriter _out)
  { CFunctionPointerType cfunctionpointertypex = this;
    _out.println();
  }


  public void setdomainType(CType domainType_xx) { domainType = domainType_xx;
  }

  public static void setAlldomainType(List cfunctionpointertypes, CType _val)
  { for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypes.get(_i);
      Controller.inst().setdomainType(cfunctionpointertypex, _val); } }

  public void setrangeType(CType rangeType_xx) { rangeType = rangeType_xx;
  }

  public static void setAllrangeType(List cfunctionpointertypes, CType _val)
  { for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypes.get(_i);
      Controller.inst().setrangeType(cfunctionpointertypex, _val); } }

  public CType getdomainType() { return domainType; }

  public static List getAlldomainType(List cfunctionpointertypes)
  { List result = new Vector();
    for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypes.get(_i);
      if (result.contains(cfunctionpointertypex.getdomainType())) {}
      else { result.add(cfunctionpointertypex.getdomainType()); }
 }
    return result; }

  public static List getAllOrdereddomainType(List cfunctionpointertypes)
  { List result = new Vector();
    for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypes.get(_i);
      if (result.contains(cfunctionpointertypex.getdomainType())) {}
      else { result.add(cfunctionpointertypex.getdomainType()); }
 }
    return result; }

  public CType getrangeType() { return rangeType; }

  public static List getAllrangeType(List cfunctionpointertypes)
  { List result = new Vector();
    for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypes.get(_i);
      if (result.contains(cfunctionpointertypex.getrangeType())) {}
      else { result.add(cfunctionpointertypex.getrangeType()); }
 }
    return result; }

  public static List getAllOrderedrangeType(List cfunctionpointertypes)
  { List result = new Vector();
    for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypes.get(_i);
      if (result.contains(cfunctionpointertypex.getrangeType())) {}
      else { result.add(cfunctionpointertypex.getrangeType()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  result = rangeType + " (*)(" + domainType + ")";
    return result;
  }


    public static String declarationString(CType t,String var)
  {   String result = "";
 
  if ((t instanceof CFunctionPointerType)) 
  {   result = ((CFunctionPointerType) t).getrangeType() + " (*" + var + ")(" + ((CFunctionPointerType) t).getdomainType() + ")";
 
  }  else
      if (true) 
  {   result = t + " " + var;
 
  }       return result;
  }



}


class COperation
  implements SystemTypes
{
  private String name = ""; // internal
  private String opId = ""; // internal
  private boolean isStatic = false; // internal
  private String scope = ""; // internal
  private boolean isQuery = false; // internal
  private List parameters = new Vector(); // of CVariable
  private CType returnType;
  private CStatement code;

  public COperation(CType returnType,CStatement code)
  {
    this.name = "";
    this.opId = "";
    this.isStatic = false;
    this.scope = "";
    this.isQuery = false;
    this.returnType = returnType;
    this.code = code;

  }

  public COperation() { }



  public static COperation parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    COperation coperationx = new COperation();
    coperationx.name = (String) _line1vals.get(0);
    coperationx.opId = (String) _line1vals.get(1);
      Controller.inst().coperationopIdindex.put(coperationx.getopId(), coperationx);
    coperationx.isStatic = Boolean.parseBoolean((String) _line1vals.get(2));
    coperationx.scope = (String) _line1vals.get(3);
    coperationx.isQuery = Boolean.parseBoolean((String) _line1vals.get(4));
    return coperationx;
  }


  public void writeCSV(PrintWriter _out)
  { COperation coperationx = this;
    _out.print("" + coperationx.name);
    _out.print(" , ");
    _out.print("" + coperationx.opId);
    _out.print(" , ");
    _out.print("" + coperationx.isStatic);
    _out.print(" , ");
    _out.print("" + coperationx.scope);
    _out.print(" , ");
    _out.print("" + coperationx.isQuery);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List coperations,String val)
  { for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      Controller.inst().setname(coperationx,val); } }


  public void setopId(String opId_x) { opId = opId_x;  }


    public static void setAllopId(List coperations,String val)
  { for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      Controller.inst().setopId(coperationx,val); } }


  public void setisStatic(boolean isStatic_x) { isStatic = isStatic_x;  }


    public static void setAllisStatic(List coperations,boolean val)
  { for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      Controller.inst().setisStatic(coperationx,val); } }


  public void setscope(String scope_x) { scope = scope_x;  }


    public static void setAllscope(List coperations,String val)
  { for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      Controller.inst().setscope(coperationx,val); } }


  public void setisQuery(boolean isQuery_x) { isQuery = isQuery_x;  }


    public static void setAllisQuery(List coperations,boolean val)
  { for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      Controller.inst().setisQuery(coperationx,val); } }


  public void setparameters(List parameters_xx) { parameters = parameters_xx;
    }
 
  public void setparameters(int ind_x, CVariable parameters_xx) { if (ind_x >= 0 && ind_x < parameters.size()) { parameters.set(ind_x, parameters_xx); } }

 public void addparameters(CVariable parameters_xx) { parameters.add(parameters_xx);
    }
 
  public void removeparameters(CVariable parameters_xx) { Vector _removedparametersparameters_xx = new Vector();
  _removedparametersparameters_xx.add(parameters_xx);
  parameters.removeAll(_removedparametersparameters_xx);
    }

  public static void setAllparameters(List coperations, List _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().setparameters(coperationx, _val); } }

  public static void setAllparameters(List coperations, int _ind,CVariable _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().setparameters(coperationx,_ind,_val); } }

  public static void addAllparameters(List coperations, CVariable _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().addparameters(coperationx,  _val); } }


  public static void removeAllparameters(List coperations,CVariable _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().removeparameters(coperationx, _val); } }


  public static void unionAllparameters(List coperations, List _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().unionparameters(coperationx, _val); } }


  public static void subtractAllparameters(List coperations,  List _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().subtractparameters(coperationx,  _val); } }


  public void setreturnType(CType returnType_xx) { returnType = returnType_xx;
  }

  public static void setAllreturnType(List coperations, CType _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().setreturnType(coperationx, _val); } }

  public void setcode(CStatement code_xx) { code = code_xx;
  }

  public static void setAllcode(List coperations, CStatement _val)
  { for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      Controller.inst().setcode(coperationx, _val); } }

    public String getname() { return name; }

    public static List getAllname(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      if (result.contains(coperationx.getname())) { }
      else { result.add(coperationx.getname()); } }
    return result; }

    public static List getAllOrderedname(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      result.add(coperationx.getname()); } 
    return result; }

    public String getopId() { return opId; }

    public static List getAllopId(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      if (result.contains(coperationx.getopId())) { }
      else { result.add(coperationx.getopId()); } }
    return result; }

    public static List getAllOrderedopId(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      result.add(coperationx.getopId()); } 
    return result; }

    public boolean getisStatic() { return isStatic; }

    public static List getAllisStatic(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      if (result.contains(new Boolean(coperationx.getisStatic()))) { }
      else { result.add(new Boolean(coperationx.getisStatic())); } }
    return result; }

    public static List getAllOrderedisStatic(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      result.add(new Boolean(coperationx.getisStatic())); } 
    return result; }

    public String getscope() { return scope; }

    public static List getAllscope(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      if (result.contains(coperationx.getscope())) { }
      else { result.add(coperationx.getscope()); } }
    return result; }

    public static List getAllOrderedscope(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      result.add(coperationx.getscope()); } 
    return result; }

    public boolean getisQuery() { return isQuery; }

    public static List getAllisQuery(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      if (result.contains(new Boolean(coperationx.getisQuery()))) { }
      else { result.add(new Boolean(coperationx.getisQuery())); } }
    return result; }

    public static List getAllOrderedisQuery(List coperations)
  { List result = new Vector();
    for (int i = 0; i < coperations.size(); i++)
    { COperation coperationx = (COperation) coperations.get(i);
      result.add(new Boolean(coperationx.getisQuery())); } 
    return result; }

  public List getparameters() { return (Vector) ((Vector) parameters).clone(); }

  public static List getAllparameters(List coperations)
  { List result = new Vector();
    for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      result = Set.union(result, coperationx.getparameters()); }
    return result; }

  public static List getAllOrderedparameters(List coperations)
  { List result = new Vector();
    for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      result.addAll(coperationx.getparameters()); }
    return result; }

  public CType getreturnType() { return returnType; }

  public static List getAllreturnType(List coperations)
  { List result = new Vector();
    for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      if (result.contains(coperationx.getreturnType())) {}
      else { result.add(coperationx.getreturnType()); }
 }
    return result; }

  public static List getAllOrderedreturnType(List coperations)
  { List result = new Vector();
    for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      if (result.contains(coperationx.getreturnType())) {}
      else { result.add(coperationx.getreturnType()); }
 }
    return result; }

  public CStatement getcode() { return code; }

  public static List getAllcode(List coperations)
  { List result = new Vector();
    for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      if (result.contains(coperationx.getcode())) {}
      else { result.add(coperationx.getcode()); }
 }
    return result; }

  public static List getAllOrderedcode(List coperations)
  { List result = new Vector();
    for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx = (COperation) coperations.get(_i);
      if (result.contains(coperationx.getcode())) {}
      else { result.add(coperationx.getcode()); }
 }
    return result; }

    public static String parameterDeclaration(List s)
  {   String result = "";
 
  if (s.size() == 0) 
  {   result = "void";
 
  }  else
      {     if (s.size() == 1)
    {   CVariable p = ((CVariable) s.get(1 - 1));
     result = p.parameterDeclaration();
 }
  else
        if (s.size() > 1)
    {   CVariable p = ((CVariable) s.get(1 - 1));
     result = p.parameterDeclaration() + ", " + COperation.parameterDeclaration(Set.tail(s));
 }
   
   }     return result;
  }


    public String toString()
  {   String result = "";
 
  result = returnType + " " + name + "(" + COperation.parameterDeclaration(parameters) + ")\n" + "{" + code + "}\n";
    return result;
  }


    public String toUseCaseDefinition()
  {   String result = "";
 
  if (returnType.getname().equals("void")) 
  {   result = returnType + " " + name + "(" + COperation.parameterDeclaration(parameters) + ")\n" + "{" + code + "}\n";
 
  }  else
      if (!(returnType.getname().equals("void"))) 
  {   result = returnType + " " + name + "(" + COperation.parameterDeclaration(parameters) + ")\n" + "{ " + returnType + " result;\n" + code + "  return result;\n}\n";
 
  }       return result;
  }


    public String getDeclaration()
  {   String result = "";
 
  result = returnType + " " + name + "(" + COperation.parameterDeclaration(parameters) + ");\n";
    return result;
  }


    public void exp2c3()
  {   if (this.getscope().equals("auxiliary")) 
  {   System.out.println("" + this);
}
  }

    public void exp2c4()
  {   if (this.getscope().equals("entity")) 
  {   System.out.println("" + this);
}
  }

    public void exp2c5()
  {   if (this.getscope().equals("application")) 
  {   System.out.println("" + this.toUseCaseDefinition());
}
  }


}


abstract class Statement
  implements SystemTypes
{
  protected String statId = ""; // internal

  public Statement()
  {
    this.statId = "";

  }



  public String toString()
  { String _res_ = "(Statement) ";
    _res_ = _res_ + statId;
    return _res_;
  }



  public void setstatId(String statId_x) { statId = statId_x;  }


    public static void setAllstatId(List statements,String val)
  { for (int i = 0; i < statements.size(); i++)
    { Statement statementx = (Statement) statements.get(i);
      Controller.inst().setstatId(statementx,val); } }


    public String getstatId() { return statId; }

    public static List getAllstatId(List statements)
  { List result = new Vector();
    for (int i = 0; i < statements.size(); i++)
    { Statement statementx = (Statement) statements.get(i);
      if (result.contains(statementx.getstatId())) { }
      else { result.add(statementx.getstatId()); } }
    return result; }

    public static List getAllOrderedstatId(List statements)
  { List result = new Vector();
    for (int i = 0; i < statements.size(); i++)
    { Statement statementx = (Statement) statements.get(i);
      result.add(statementx.getstatId()); } 
    return result; }

    public abstract CStatement mapStatement();




}


class ReturnStatement
  extends Statement
  implements SystemTypes
{
  private List returnValue = new Vector(); // of Expression

  public ReturnStatement()
  {

  }



  public String toString()
  { String _res_ = "(ReturnStatement) ";
    return _res_ + super.toString();
  }

  public static ReturnStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    ReturnStatement returnstatementx = new ReturnStatement();
    return returnstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { ReturnStatement returnstatementx = this;
    _out.println();
  }


  public void setreturnValue(List returnValue_xx) { if (returnValue_xx.size() > 1) { return; } 
    returnValue = returnValue_xx;
  }
 
  public void addreturnValue(Expression returnValue_xx) { if (returnValue.size() > 0) { returnValue.clear(); } 
    if (returnValue.contains(returnValue_xx)) {} else { returnValue.add(returnValue_xx); }
    }
 
  public void removereturnValue(Expression returnValue_xx) { Vector _removedreturnValuereturnValue_xx = new Vector();
  _removedreturnValuereturnValue_xx.add(returnValue_xx);
  returnValue.removeAll(_removedreturnValuereturnValue_xx);
    }

  public static void setAllreturnValue(List returnstatements, List _val)
  { for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(_i);
      Controller.inst().setreturnValue(returnstatementx, _val); } }

  public static void addAllreturnValue(List returnstatements, Expression _val)
  { for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(_i);
      Controller.inst().addreturnValue(returnstatementx,  _val); } }


  public static void removeAllreturnValue(List returnstatements,Expression _val)
  { for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(_i);
      Controller.inst().removereturnValue(returnstatementx, _val); } }


  public static void unionAllreturnValue(List returnstatements, List _val)
  { for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(_i);
      Controller.inst().unionreturnValue(returnstatementx, _val); } }


  public static void subtractAllreturnValue(List returnstatements,  List _val)
  { for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(_i);
      Controller.inst().subtractreturnValue(returnstatementx,  _val); } }


  public List getreturnValue() { return (Vector) ((Vector) returnValue).clone(); }

  public static List getAllreturnValue(List returnstatements)
  { List result = new Vector();
    for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(_i);
      result = Set.union(result, returnstatementx.getreturnValue()); }
    return result; }

  public static List getAllOrderedreturnValue(List returnstatements)
  { List result = new Vector();
    for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(_i);
      result = Set.union(result, returnstatementx.getreturnValue()); }
    return result; }

    public CStatement mapStatement()
  {   CStatement result = null;
  if (Controller.inst().getCReturnStatementByPK(this.getstatId()) != null)
    { CReturnStatement r = Controller.inst().getCReturnStatementByPK(this.getstatId());
     Controller.inst().setreturnValue(r,  Controller.inst().AllExpressionmapExpression(this.getreturnValue()));
    result = r;
  }
    else
    { CReturnStatement r = new CReturnStatement();
    Controller.inst().addCReturnStatement(r);
    Controller.inst().setcstatId(r,this.getstatId());
    Controller.inst().setreturnValue(r,  Controller.inst().AllExpressionmapExpression(this.getreturnValue()));
    result = r; }

  return result;

  }


}


abstract class BehaviouralFeature
  implements SystemTypes
{
  protected String name = ""; // internal
  protected boolean isStatic = false; // internal
  protected Statement activity;

  public BehaviouralFeature(Statement activity)
  {
    this.name = "";
    this.isStatic = false;
    this.activity = activity;

  }

  public BehaviouralFeature() { }



  public String toString()
  { String _res_ = "(BehaviouralFeature) ";
    _res_ = _res_ + name + ",";
    _res_ = _res_ + isStatic;
    return _res_;
  }



  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List behaviouralfeatures,String val)
  { for (int i = 0; i < behaviouralfeatures.size(); i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(i);
      Controller.inst().setname(behaviouralfeaturex,val); } }


  public void setisStatic(boolean isStatic_x) { isStatic = isStatic_x;  }


    public static void setAllisStatic(List behaviouralfeatures,boolean val)
  { for (int i = 0; i < behaviouralfeatures.size(); i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(i);
      Controller.inst().setisStatic(behaviouralfeaturex,val); } }


  public void setactivity(Statement activity_xx) { activity = activity_xx;
  }

  public static void setAllactivity(List behaviouralfeatures, Statement _val)
  { for (int _i = 0; _i < behaviouralfeatures.size(); _i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(_i);
      Controller.inst().setactivity(behaviouralfeaturex, _val); } }

    public String getname() { return name; }

    public static List getAllname(List behaviouralfeatures)
  { List result = new Vector();
    for (int i = 0; i < behaviouralfeatures.size(); i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(i);
      if (result.contains(behaviouralfeaturex.getname())) { }
      else { result.add(behaviouralfeaturex.getname()); } }
    return result; }

    public static List getAllOrderedname(List behaviouralfeatures)
  { List result = new Vector();
    for (int i = 0; i < behaviouralfeatures.size(); i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(i);
      result.add(behaviouralfeaturex.getname()); } 
    return result; }

    public boolean getisStatic() { return isStatic; }

    public static List getAllisStatic(List behaviouralfeatures)
  { List result = new Vector();
    for (int i = 0; i < behaviouralfeatures.size(); i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(i);
      if (result.contains(new Boolean(behaviouralfeaturex.getisStatic()))) { }
      else { result.add(new Boolean(behaviouralfeaturex.getisStatic())); } }
    return result; }

    public static List getAllOrderedisStatic(List behaviouralfeatures)
  { List result = new Vector();
    for (int i = 0; i < behaviouralfeatures.size(); i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(i);
      result.add(new Boolean(behaviouralfeaturex.getisStatic())); } 
    return result; }

  public Statement getactivity() { return activity; }

  public static List getAllactivity(List behaviouralfeatures)
  { List result = new Vector();
    for (int _i = 0; _i < behaviouralfeatures.size(); _i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(_i);
      if (result.contains(behaviouralfeaturex.getactivity())) {}
      else { result.add(behaviouralfeaturex.getactivity()); }
 }
    return result; }

  public static List getAllOrderedactivity(List behaviouralfeatures)
  { List result = new Vector();
    for (int _i = 0; _i < behaviouralfeatures.size(); _i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) behaviouralfeatures.get(_i);
      if (result.contains(behaviouralfeaturex.getactivity())) {}
      else { result.add(behaviouralfeaturex.getactivity()); }
 }
    return result; }


}


class Operation
  extends BehaviouralFeature
  implements SystemTypes
{
  private boolean isQuery = false; // internal
  private boolean isCached = false; // internal
  private boolean isStatic = false; // internal
  private Entity owner;

  public Operation(Entity owner)
  {
    this.isQuery = false;
    this.isCached = false;
    this.isStatic = false;
    this.owner = owner;

  }

  public Operation() { }



  public String toString()
  { String _res_ = "(Operation) ";
    _res_ = _res_ + isQuery + ",";
    _res_ = _res_ + isCached + ",";
    _res_ = _res_ + isStatic;
    return _res_ + super.toString();
  }

  public static Operation parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Operation operationx = new Operation();
    operationx.isQuery = Boolean.parseBoolean((String) _line1vals.get(0));
    operationx.isCached = Boolean.parseBoolean((String) _line1vals.get(1));
    operationx.isStatic = Boolean.parseBoolean((String) _line1vals.get(2));
    return operationx;
  }


  public void writeCSV(PrintWriter _out)
  { Operation operationx = this;
    _out.print("" + operationx.isQuery);
    _out.print(" , ");
    _out.print("" + operationx.isCached);
    _out.print(" , ");
    _out.print("" + operationx.isStatic);
    _out.println();
  }


  public void setisQuery(boolean isQuery_x) { isQuery = isQuery_x;  }


    public static void setAllisQuery(List operations,boolean val)
  { for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      Controller.inst().setisQuery(operationx,val); } }


  public void setisCached(boolean isCached_x) { isCached = isCached_x;  }


    public static void setAllisCached(List operations,boolean val)
  { for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      Controller.inst().setisCached(operationx,val); } }


  public void setisStatic(boolean isStatic_x) { isStatic = isStatic_x;  }


    public static void setAllisStatic(List operations,boolean val)
  { for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      Controller.inst().setisStatic(operationx,val); } }


  public void setowner(Entity owner_xx) { owner = owner_xx;
  }

  public static void setAllowner(List operations, Entity _val)
  { for (int _i = 0; _i < operations.size(); _i++)
    { Operation operationx = (Operation) operations.get(_i);
      Controller.inst().setowner(operationx, _val); } }

    public boolean getisQuery() { return isQuery; }

    public static List getAllisQuery(List operations)
  { List result = new Vector();
    for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      if (result.contains(new Boolean(operationx.getisQuery()))) { }
      else { result.add(new Boolean(operationx.getisQuery())); } }
    return result; }

    public static List getAllOrderedisQuery(List operations)
  { List result = new Vector();
    for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      result.add(new Boolean(operationx.getisQuery())); } 
    return result; }

    public boolean getisCached() { return isCached; }

    public static List getAllisCached(List operations)
  { List result = new Vector();
    for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      if (result.contains(new Boolean(operationx.getisCached()))) { }
      else { result.add(new Boolean(operationx.getisCached())); } }
    return result; }

    public static List getAllOrderedisCached(List operations)
  { List result = new Vector();
    for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      result.add(new Boolean(operationx.getisCached())); } 
    return result; }

    public boolean getisStatic() { return isStatic; }

    public static List getAllisStatic(List operations)
  { List result = new Vector();
    for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      if (result.contains(new Boolean(operationx.getisStatic()))) { }
      else { result.add(new Boolean(operationx.getisStatic())); } }
    return result; }

    public static List getAllOrderedisStatic(List operations)
  { List result = new Vector();
    for (int i = 0; i < operations.size(); i++)
    { Operation operationx = (Operation) operations.get(i);
      result.add(new Boolean(operationx.getisStatic())); } 
    return result; }

  public Entity getowner() { return owner; }

  public static List getAllowner(List operations)
  { List result = new Vector();
    for (int _i = 0; _i < operations.size(); _i++)
    { Operation operationx = (Operation) operations.get(_i);
      if (result.contains(operationx.getowner())) {}
      else { result.add(operationx.getowner()); }
 }
    return result; }

  public static List getAllOrderedowner(List operations)
  { List result = new Vector();
    for (int _i = 0; _i < operations.size(); _i++)
    { Operation operationx = (Operation) operations.get(_i);
      if (result.contains(operationx.getowner())) {}
      else { result.add(operationx.getowner()); }
 }
    return result; }

    public void exp2c1()
  {   if (((new SystemTypes.Set()).add(this.getactivity()).getElements()).size() > 0) 
  {   if (Controller.inst().getCOperationByPK(this.getname() + "_" + this.getowner().getname()) != null)
    { COperation c = Controller.inst().getCOperationByPK(this.getname() + "_" + this.getowner().getname());
     Controller.inst().setcode(c,this.getactivity().mapStatement());
  }
    else
    { COperation c = new COperation();
    Controller.inst().addCOperation(c);
    Controller.inst().setopId(c,this.getname() + "_" + this.getowner().getname());
    Controller.inst().setcode(c,this.getactivity().mapStatement()); }
}
  }


}


class UseCase
  implements SystemTypes
{
  private String name = ""; // internal
  private List parameters = new Vector(); // of Property
  private Type resultType;
  private Statement classifierBehaviour;

  public UseCase(Type resultType,Statement classifierBehaviour)
  {
    this.name = "";
    this.resultType = resultType;
    this.classifierBehaviour = classifierBehaviour;

  }

  public UseCase() { }



  public String toString()
  { String _res_ = "(UseCase) ";
    _res_ = _res_ + name;
    return _res_;
  }

  public static UseCase parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    UseCase usecasex = new UseCase();
    usecasex.name = (String) _line1vals.get(0);
    return usecasex;
  }


  public void writeCSV(PrintWriter _out)
  { UseCase usecasex = this;
    _out.print("" + usecasex.name);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List usecases,String val)
  { for (int i = 0; i < usecases.size(); i++)
    { UseCase usecasex = (UseCase) usecases.get(i);
      Controller.inst().setname(usecasex,val); } }


  public void setparameters(List parameters_xx) { parameters = parameters_xx;
    }
 
  public void setparameters(int ind_x, Property parameters_xx) { if (ind_x >= 0 && ind_x < parameters.size()) { parameters.set(ind_x, parameters_xx); } }

 public void addparameters(Property parameters_xx) { parameters.add(parameters_xx);
    }
 
  public void removeparameters(Property parameters_xx) { Vector _removedparametersparameters_xx = new Vector();
  _removedparametersparameters_xx.add(parameters_xx);
  parameters.removeAll(_removedparametersparameters_xx);
    }

  public static void setAllparameters(List usecases, List _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().setparameters(usecasex, _val); } }

  public static void setAllparameters(List usecases, int _ind,Property _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().setparameters(usecasex,_ind,_val); } }

  public static void addAllparameters(List usecases, Property _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().addparameters(usecasex,  _val); } }


  public static void removeAllparameters(List usecases,Property _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().removeparameters(usecasex, _val); } }


  public static void unionAllparameters(List usecases, List _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().unionparameters(usecasex, _val); } }


  public static void subtractAllparameters(List usecases,  List _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().subtractparameters(usecasex,  _val); } }


  public void setresultType(Type resultType_xx) { resultType = resultType_xx;
  }

  public static void setAllresultType(List usecases, Type _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().setresultType(usecasex, _val); } }

  public void setclassifierBehaviour(Statement classifierBehaviour_xx) { classifierBehaviour = classifierBehaviour_xx;
  }

  public static void setAllclassifierBehaviour(List usecases, Statement _val)
  { for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      Controller.inst().setclassifierBehaviour(usecasex, _val); } }

    public String getname() { return name; }

    public static List getAllname(List usecases)
  { List result = new Vector();
    for (int i = 0; i < usecases.size(); i++)
    { UseCase usecasex = (UseCase) usecases.get(i);
      if (result.contains(usecasex.getname())) { }
      else { result.add(usecasex.getname()); } }
    return result; }

    public static List getAllOrderedname(List usecases)
  { List result = new Vector();
    for (int i = 0; i < usecases.size(); i++)
    { UseCase usecasex = (UseCase) usecases.get(i);
      result.add(usecasex.getname()); } 
    return result; }

  public List getparameters() { return (Vector) ((Vector) parameters).clone(); }

  public static List getAllparameters(List usecases)
  { List result = new Vector();
    for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      result = Set.union(result, usecasex.getparameters()); }
    return result; }

  public static List getAllOrderedparameters(List usecases)
  { List result = new Vector();
    for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      result.addAll(usecasex.getparameters()); }
    return result; }

  public Type getresultType() { return resultType; }

  public static List getAllresultType(List usecases)
  { List result = new Vector();
    for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      if (result.contains(usecasex.getresultType())) {}
      else { result.add(usecasex.getresultType()); }
 }
    return result; }

  public static List getAllOrderedresultType(List usecases)
  { List result = new Vector();
    for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      if (result.contains(usecasex.getresultType())) {}
      else { result.add(usecasex.getresultType()); }
 }
    return result; }

  public Statement getclassifierBehaviour() { return classifierBehaviour; }

  public static List getAllclassifierBehaviour(List usecases)
  { List result = new Vector();
    for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      if (result.contains(usecasex.getclassifierBehaviour())) {}
      else { result.add(usecasex.getclassifierBehaviour()); }
 }
    return result; }

  public static List getAllOrderedclassifierBehaviour(List usecases)
  { List result = new Vector();
    for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex = (UseCase) usecases.get(_i);
      if (result.contains(usecasex.getclassifierBehaviour())) {}
      else { result.add(usecasex.getclassifierBehaviour()); }
 }
    return result; }

    public void exp2c2()
  {   if (((new SystemTypes.Set()).add(this.getclassifierBehaviour()).getElements()).size() > 0) 
  { COperation cop = new COperation();
    Controller.inst().addCOperation(cop);
    Controller.inst().setname(cop,this.getname());
    Controller.inst().setscope(cop,"application");
    Controller.inst().setisQuery(cop,false);
    Controller.inst().setisStatic(cop,true);
    Controller.inst().setcode(cop,this.getclassifierBehaviour().mapStatement());
        List _property_list53 = new Vector();
    _property_list53.addAll(this.getparameters());
    for (int _ind54 = 0; _ind54 < _property_list53.size(); _ind54++)
    { Property x = (Property) _property_list53.get(_ind54);
      CVariable y = new CVariable();
    Controller.inst().addCVariable(y);
    Controller.inst().setname(y,x.getname());
    Controller.inst().setkind(y,"parameter");
    Controller.inst().settype(y,Controller.inst().getCTypeByPK(x.gettype().gettypeId()));
    Controller.inst().addparameters(cop,y);
    }

    Controller.inst().setreturnType(cop,Controller.inst().getCTypeByPK(this.getresultType().gettypeId()));}
  }


}


class BreakStatement
  extends Statement
  implements SystemTypes
{

  public BreakStatement()
  {

  }



  public String toString()
  { String _res_ = "(BreakStatement) ";
    return _res_ + super.toString();
  }

  public static BreakStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    BreakStatement breakstatementx = new BreakStatement();
    return breakstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { BreakStatement breakstatementx = this;
    _out.println();
  }


    public CStatement mapStatement()
  {   CStatement result = null;
  if (Controller.inst().getCBreakStatementByPK(this.getstatId()) != null)
    { CBreakStatement r = Controller.inst().getCBreakStatementByPK(this.getstatId());
     result = r;
  }
    else
    { CBreakStatement r = new CBreakStatement();
    Controller.inst().addCBreakStatement(r);
    Controller.inst().setcstatId(r,this.getstatId());
    result = r; }

  return result;

  }


}


class OperationCallStatement
  extends Statement
  implements SystemTypes
{
  private String assignsTo = ""; // internal
  private Expression callExp;

  public OperationCallStatement(Expression callExp)
  {
    this.assignsTo = "";
    this.callExp = callExp;

  }

  public OperationCallStatement() { }



  public String toString()
  { String _res_ = "(OperationCallStatement) ";
    _res_ = _res_ + assignsTo;
    return _res_ + super.toString();
  }

  public static OperationCallStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    OperationCallStatement operationcallstatementx = new OperationCallStatement();
    operationcallstatementx.assignsTo = (String) _line1vals.get(0);
    return operationcallstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { OperationCallStatement operationcallstatementx = this;
    _out.print("" + operationcallstatementx.assignsTo);
    _out.println();
  }


  public void setassignsTo(String assignsTo_x) { assignsTo = assignsTo_x;  }


    public static void setAllassignsTo(List operationcallstatements,String val)
  { for (int i = 0; i < operationcallstatements.size(); i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatements.get(i);
      Controller.inst().setassignsTo(operationcallstatementx,val); } }


  public void setcallExp(Expression callExp_xx) { callExp = callExp_xx;
  }

  public static void setAllcallExp(List operationcallstatements, Expression _val)
  { for (int _i = 0; _i < operationcallstatements.size(); _i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatements.get(_i);
      Controller.inst().setcallExp(operationcallstatementx, _val); } }

    public String getassignsTo() { return assignsTo; }

    public static List getAllassignsTo(List operationcallstatements)
  { List result = new Vector();
    for (int i = 0; i < operationcallstatements.size(); i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatements.get(i);
      if (result.contains(operationcallstatementx.getassignsTo())) { }
      else { result.add(operationcallstatementx.getassignsTo()); } }
    return result; }

    public static List getAllOrderedassignsTo(List operationcallstatements)
  { List result = new Vector();
    for (int i = 0; i < operationcallstatements.size(); i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatements.get(i);
      result.add(operationcallstatementx.getassignsTo()); } 
    return result; }

  public Expression getcallExp() { return callExp; }

  public static List getAllcallExp(List operationcallstatements)
  { List result = new Vector();
    for (int _i = 0; _i < operationcallstatements.size(); _i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatements.get(_i);
      if (result.contains(operationcallstatementx.getcallExp())) {}
      else { result.add(operationcallstatementx.getcallExp()); }
 }
    return result; }

  public static List getAllOrderedcallExp(List operationcallstatements)
  { List result = new Vector();
    for (int _i = 0; _i < operationcallstatements.size(); _i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatements.get(_i);
      if (result.contains(operationcallstatementx.getcallExp())) {}
      else { result.add(operationcallstatementx.getcallExp()); }
 }
    return result; }

    public CStatement mapStatement()
  {   CStatement result = null;
  if (Controller.inst().getOpCallStatementByPK(this.getstatId()) != null)
    { OpCallStatement ca = Controller.inst().getOpCallStatementByPK(this.getstatId());
     Controller.inst().setcallExp(ca,this.getcallExp().mapExpression());
    Controller.inst().setassignsTo(ca,this.getassignsTo());
    result = ca;
  }
    else
    { OpCallStatement ca = new OpCallStatement();
    Controller.inst().addOpCallStatement(ca);
    Controller.inst().setcstatId(ca,this.getstatId());
    Controller.inst().setcallExp(ca,this.getcallExp().mapExpression());
    Controller.inst().setassignsTo(ca,this.getassignsTo());
    result = ca; }

  return result;

  }


}


class ImplicitCallStatement
  extends Statement
  implements SystemTypes
{
  private String assignsTo = ""; // internal
  private Expression callExp;

  public ImplicitCallStatement(Expression callExp)
  {
    this.assignsTo = "";
    this.callExp = callExp;

  }

  public ImplicitCallStatement() { }



  public String toString()
  { String _res_ = "(ImplicitCallStatement) ";
    _res_ = _res_ + assignsTo;
    return _res_ + super.toString();
  }

  public static ImplicitCallStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    ImplicitCallStatement implicitcallstatementx = new ImplicitCallStatement();
    implicitcallstatementx.assignsTo = (String) _line1vals.get(0);
    return implicitcallstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { ImplicitCallStatement implicitcallstatementx = this;
    _out.print("" + implicitcallstatementx.assignsTo);
    _out.println();
  }


  public void setassignsTo(String assignsTo_x) { assignsTo = assignsTo_x;  }


    public static void setAllassignsTo(List implicitcallstatements,String val)
  { for (int i = 0; i < implicitcallstatements.size(); i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatements.get(i);
      Controller.inst().setassignsTo(implicitcallstatementx,val); } }


  public void setcallExp(Expression callExp_xx) { callExp = callExp_xx;
  }

  public static void setAllcallExp(List implicitcallstatements, Expression _val)
  { for (int _i = 0; _i < implicitcallstatements.size(); _i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatements.get(_i);
      Controller.inst().setcallExp(implicitcallstatementx, _val); } }

    public String getassignsTo() { return assignsTo; }

    public static List getAllassignsTo(List implicitcallstatements)
  { List result = new Vector();
    for (int i = 0; i < implicitcallstatements.size(); i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatements.get(i);
      if (result.contains(implicitcallstatementx.getassignsTo())) { }
      else { result.add(implicitcallstatementx.getassignsTo()); } }
    return result; }

    public static List getAllOrderedassignsTo(List implicitcallstatements)
  { List result = new Vector();
    for (int i = 0; i < implicitcallstatements.size(); i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatements.get(i);
      result.add(implicitcallstatementx.getassignsTo()); } 
    return result; }

  public Expression getcallExp() { return callExp; }

  public static List getAllcallExp(List implicitcallstatements)
  { List result = new Vector();
    for (int _i = 0; _i < implicitcallstatements.size(); _i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatements.get(_i);
      if (result.contains(implicitcallstatementx.getcallExp())) {}
      else { result.add(implicitcallstatementx.getcallExp()); }
 }
    return result; }

  public static List getAllOrderedcallExp(List implicitcallstatements)
  { List result = new Vector();
    for (int _i = 0; _i < implicitcallstatements.size(); _i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatements.get(_i);
      if (result.contains(implicitcallstatementx.getcallExp())) {}
      else { result.add(implicitcallstatementx.getcallExp()); }
 }
    return result; }

    public CStatement mapStatement()
  {   CStatement result = null;
  if (Controller.inst().getOpCallStatementByPK(this.getstatId()) != null)
    { OpCallStatement ca = Controller.inst().getOpCallStatementByPK(this.getstatId());
     Controller.inst().setcallExp(ca,this.getcallExp().mapExpression());
    Controller.inst().setassignsTo(ca,this.getassignsTo());
    result = ca;
  }
    else
    { OpCallStatement ca = new OpCallStatement();
    Controller.inst().addOpCallStatement(ca);
    Controller.inst().setcstatId(ca,this.getstatId());
    Controller.inst().setcallExp(ca,this.getcallExp().mapExpression());
    Controller.inst().setassignsTo(ca,this.getassignsTo());
    result = ca; }

  return result;

  }


}


abstract class LoopStatement
  extends Statement
  implements SystemTypes
{
  protected Expression test;
  protected Statement body;

  public LoopStatement(Expression test,Statement body)
  {
    this.test = test;
    this.body = body;

  }

  public LoopStatement() { }



  public String toString()
  { String _res_ = "(LoopStatement) ";
    return _res_ + super.toString();
  }



  public void settest(Expression test_xx) { test = test_xx;
  }

  public static void setAlltest(List loopstatements, Expression _val)
  { for (int _i = 0; _i < loopstatements.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) loopstatements.get(_i);
      Controller.inst().settest(loopstatementx, _val); } }

  public void setbody(Statement body_xx) { body = body_xx;
  }

  public static void setAllbody(List loopstatements, Statement _val)
  { for (int _i = 0; _i < loopstatements.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) loopstatements.get(_i);
      Controller.inst().setbody(loopstatementx, _val); } }

  public Expression gettest() { return test; }

  public static List getAlltest(List loopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < loopstatements.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) loopstatements.get(_i);
      if (result.contains(loopstatementx.gettest())) {}
      else { result.add(loopstatementx.gettest()); }
 }
    return result; }

  public static List getAllOrderedtest(List loopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < loopstatements.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) loopstatements.get(_i);
      if (result.contains(loopstatementx.gettest())) {}
      else { result.add(loopstatementx.gettest()); }
 }
    return result; }

  public Statement getbody() { return body; }

  public static List getAllbody(List loopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < loopstatements.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) loopstatements.get(_i);
      if (result.contains(loopstatementx.getbody())) {}
      else { result.add(loopstatementx.getbody()); }
 }
    return result; }

  public static List getAllOrderedbody(List loopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < loopstatements.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) loopstatements.get(_i);
      if (result.contains(loopstatementx.getbody())) {}
      else { result.add(loopstatementx.getbody()); }
 }
    return result; }


}


class BoundedLoopStatement
  extends LoopStatement
  implements SystemTypes
{
  private Expression loopRange;
  private Expression loopVar;

  public BoundedLoopStatement(Expression loopRange,Expression loopVar)
  {
    this.loopRange = loopRange;
    this.loopVar = loopVar;

  }

  public BoundedLoopStatement() { }



  public String toString()
  { String _res_ = "(BoundedLoopStatement) ";
    return _res_ + super.toString();
  }

  public static BoundedLoopStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    BoundedLoopStatement boundedloopstatementx = new BoundedLoopStatement();
    return boundedloopstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { BoundedLoopStatement boundedloopstatementx = this;
    _out.println();
  }


  public void setloopRange(Expression loopRange_xx) { loopRange = loopRange_xx;
  }

  public static void setAllloopRange(List boundedloopstatements, Expression _val)
  { for (int _i = 0; _i < boundedloopstatements.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatements.get(_i);
      Controller.inst().setloopRange(boundedloopstatementx, _val); } }

  public void setloopVar(Expression loopVar_xx) { loopVar = loopVar_xx;
  }

  public static void setAllloopVar(List boundedloopstatements, Expression _val)
  { for (int _i = 0; _i < boundedloopstatements.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatements.get(_i);
      Controller.inst().setloopVar(boundedloopstatementx, _val); } }

  public Expression getloopRange() { return loopRange; }

  public static List getAllloopRange(List boundedloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < boundedloopstatements.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatements.get(_i);
      if (result.contains(boundedloopstatementx.getloopRange())) {}
      else { result.add(boundedloopstatementx.getloopRange()); }
 }
    return result; }

  public static List getAllOrderedloopRange(List boundedloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < boundedloopstatements.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatements.get(_i);
      if (result.contains(boundedloopstatementx.getloopRange())) {}
      else { result.add(boundedloopstatementx.getloopRange()); }
 }
    return result; }

  public Expression getloopVar() { return loopVar; }

  public static List getAllloopVar(List boundedloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < boundedloopstatements.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatements.get(_i);
      if (result.contains(boundedloopstatementx.getloopVar())) {}
      else { result.add(boundedloopstatementx.getloopVar()); }
 }
    return result; }

  public static List getAllOrderedloopVar(List boundedloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < boundedloopstatements.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatements.get(_i);
      if (result.contains(boundedloopstatementx.getloopVar())) {}
      else { result.add(boundedloopstatementx.getloopVar()); }
 }
    return result; }

    public CStatement mapBoundedLoopStatement(CStatement bdy)
  {   CStatement result = null;
  if (Controller.inst().getForLoopByPK(this.getstatId()) != null)
    { ForLoop lp = Controller.inst().getForLoopByPK(this.getstatId());
     Controller.inst().setbody(lp,bdy);
    Controller.inst().settest(lp,this.gettest().mapExpression());
    Controller.inst().setloopVar(lp,this.getloopVar().mapExpression());
    Controller.inst().setloopRange(lp,this.getloopRange().mapExpression());
    result = lp;
  }
    else
    { ForLoop lp = new ForLoop();
    Controller.inst().addForLoop(lp);
    Controller.inst().setcstatId(lp,this.getstatId());
    Controller.inst().setbody(lp,bdy);
    Controller.inst().settest(lp,this.gettest().mapExpression());
    Controller.inst().setloopVar(lp,this.getloopVar().mapExpression());
    Controller.inst().setloopRange(lp,this.getloopRange().mapExpression());
    result = lp; }

  return result;

  }

    public CStatement mapStatement()
  {   CStatement result = null;
result = this.mapBoundedLoopStatement(this.getbody().mapStatement());
  return result;

  }


}


class UnboundedLoopStatement
  extends LoopStatement
  implements SystemTypes
{

  public UnboundedLoopStatement()
  {

  }



  public String toString()
  { String _res_ = "(UnboundedLoopStatement) ";
    return _res_ + super.toString();
  }

  public static UnboundedLoopStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    UnboundedLoopStatement unboundedloopstatementx = new UnboundedLoopStatement();
    return unboundedloopstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { UnboundedLoopStatement unboundedloopstatementx = this;
    _out.println();
  }


    public CStatement mapUnboundedLoopStatement(CStatement bdy)
  {   CStatement result = null;
  if (Controller.inst().getWhileLoopByPK(this.getstatId()) != null)
    { WhileLoop lp = Controller.inst().getWhileLoopByPK(this.getstatId());
     Controller.inst().setbody(lp,bdy);
    Controller.inst().settest(lp,this.gettest().mapExpression());
    result = lp;
  }
    else
    { WhileLoop lp = new WhileLoop();
    Controller.inst().addWhileLoop(lp);
    Controller.inst().setcstatId(lp,this.getstatId());
    Controller.inst().setbody(lp,bdy);
    Controller.inst().settest(lp,this.gettest().mapExpression());
    result = lp; }

  return result;

  }

    public CStatement mapStatement()
  {   CStatement result = null;
result = this.mapUnboundedLoopStatement(this.getbody().mapStatement());
  return result;

  }


}


class AssignStatement
  extends Statement
  implements SystemTypes
{
  private List type = new Vector(); // of Type
  private Expression left;
  private Expression right;

  public AssignStatement(Expression left,Expression right)
  {
    this.left = left;
    this.right = right;

  }

  public AssignStatement() { }



  public String toString()
  { String _res_ = "(AssignStatement) ";
    return _res_ + super.toString();
  }

  public static AssignStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    AssignStatement assignstatementx = new AssignStatement();
    return assignstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { AssignStatement assignstatementx = this;
    _out.println();
  }


  public void settype(List type_xx) { if (type_xx.size() > 1) { return; } 
    type = type_xx;
  }
 
  public void addtype(Type type_xx) { if (type.size() > 0) { type.clear(); } 
    if (type.contains(type_xx)) {} else { type.add(type_xx); }
    }
 
  public void removetype(Type type_xx) { Vector _removedtypetype_xx = new Vector();
  _removedtypetype_xx.add(type_xx);
  type.removeAll(_removedtypetype_xx);
    }

  public static void setAlltype(List assignstatements, List _val)
  { for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      Controller.inst().settype(assignstatementx, _val); } }

  public static void addAlltype(List assignstatements, Type _val)
  { for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      Controller.inst().addtype(assignstatementx,  _val); } }


  public static void removeAlltype(List assignstatements,Type _val)
  { for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      Controller.inst().removetype(assignstatementx, _val); } }


  public static void unionAlltype(List assignstatements, List _val)
  { for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      Controller.inst().uniontype(assignstatementx, _val); } }


  public static void subtractAlltype(List assignstatements,  List _val)
  { for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      Controller.inst().subtracttype(assignstatementx,  _val); } }


  public void setleft(Expression left_xx) { left = left_xx;
  }

  public static void setAllleft(List assignstatements, Expression _val)
  { for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      Controller.inst().setleft(assignstatementx, _val); } }

  public void setright(Expression right_xx) { right = right_xx;
  }

  public static void setAllright(List assignstatements, Expression _val)
  { for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      Controller.inst().setright(assignstatementx, _val); } }

  public List gettype() { return (Vector) ((Vector) type).clone(); }

  public static List getAlltype(List assignstatements)
  { List result = new Vector();
    for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      result = Set.union(result, assignstatementx.gettype()); }
    return result; }

  public static List getAllOrderedtype(List assignstatements)
  { List result = new Vector();
    for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      result = Set.union(result, assignstatementx.gettype()); }
    return result; }

  public Expression getleft() { return left; }

  public static List getAllleft(List assignstatements)
  { List result = new Vector();
    for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      if (result.contains(assignstatementx.getleft())) {}
      else { result.add(assignstatementx.getleft()); }
 }
    return result; }

  public static List getAllOrderedleft(List assignstatements)
  { List result = new Vector();
    for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      if (result.contains(assignstatementx.getleft())) {}
      else { result.add(assignstatementx.getleft()); }
 }
    return result; }

  public Expression getright() { return right; }

  public static List getAllright(List assignstatements)
  { List result = new Vector();
    for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      if (result.contains(assignstatementx.getright())) {}
      else { result.add(assignstatementx.getright()); }
 }
    return result; }

  public static List getAllOrderedright(List assignstatements)
  { List result = new Vector();
    for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(_i);
      if (result.contains(assignstatementx.getright())) {}
      else { result.add(assignstatementx.getright()); }
 }
    return result; }

    public CStatement mapStatement()
  {   CStatement result = null;
  if (this.gettype().size() == 0) 
  { result = this.getleft().mapAssignment(this,this.getright().mapExpression());}
      if (this.gettype().size() > 0) 
  {   if (Controller.inst().getCAssignmentByPK(this.getstatId()) != null)
    { CAssignment ca = Controller.inst().getCAssignmentByPK(this.getstatId());
     Controller.inst().setleft(ca,this.getleft().mapExpression());
    Controller.inst().setright(ca,this.getright().mapExpression());
    Controller.inst().settype(ca,Controller.inst().getCTypeByPK(Type.getAlltypeId(this.gettype())));
    result = ca;
  }
    else
    { CAssignment ca = new CAssignment();
    Controller.inst().addCAssignment(ca);
    Controller.inst().setcstatId(ca,this.getstatId());
    Controller.inst().setleft(ca,this.getleft().mapExpression());
    Controller.inst().setright(ca,this.getright().mapExpression());
    Controller.inst().settype(ca,Controller.inst().getCTypeByPK(Type.getAlltypeId(this.gettype())));
    result = ca; }
}
  return result;

  }


}


class SequenceStatement
  extends Statement
  implements SystemTypes
{
  private int kind = 0; // internal
  private List statements = new Vector(); // of Statement

  public SequenceStatement()
  {
    this.kind = 0;

  }



  public String toString()
  { String _res_ = "(SequenceStatement) ";
    _res_ = _res_ + kind;
    return _res_ + super.toString();
  }

  public static SequenceStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    SequenceStatement sequencestatementx = new SequenceStatement();
    sequencestatementx.kind = Integer.parseInt((String) _line1vals.get(0));
    return sequencestatementx;
  }


  public void writeCSV(PrintWriter _out)
  { SequenceStatement sequencestatementx = this;
    _out.print("" + sequencestatementx.kind);
    _out.println();
  }


  public void setkind(int kind_x) { kind = kind_x;  }


    public static void setAllkind(List sequencestatements,int val)
  { for (int i = 0; i < sequencestatements.size(); i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(i);
      Controller.inst().setkind(sequencestatementx,val); } }


  public void setstatements(List statements_xx) { statements = statements_xx;
    }
 
  public void setstatements(int ind_x, Statement statements_xx) { if (ind_x >= 0 && ind_x < statements.size()) { statements.set(ind_x, statements_xx); } }

 public void addstatements(Statement statements_xx) { statements.add(statements_xx);
    }
 
  public void removestatements(Statement statements_xx) { Vector _removedstatementsstatements_xx = new Vector();
  _removedstatementsstatements_xx.add(statements_xx);
  statements.removeAll(_removedstatementsstatements_xx);
    }

  public static void setAllstatements(List sequencestatements, List _val)
  { for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      Controller.inst().setstatements(sequencestatementx, _val); } }

  public static void setAllstatements(List sequencestatements, int _ind,Statement _val)
  { for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      Controller.inst().setstatements(sequencestatementx,_ind,_val); } }

  public static void addAllstatements(List sequencestatements, Statement _val)
  { for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      Controller.inst().addstatements(sequencestatementx,  _val); } }


  public static void removeAllstatements(List sequencestatements,Statement _val)
  { for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      Controller.inst().removestatements(sequencestatementx, _val); } }


  public static void unionAllstatements(List sequencestatements, List _val)
  { for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      Controller.inst().unionstatements(sequencestatementx, _val); } }


  public static void subtractAllstatements(List sequencestatements,  List _val)
  { for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      Controller.inst().subtractstatements(sequencestatementx,  _val); } }


    public int getkind() { return kind; }

    public static List getAllkind(List sequencestatements)
  { List result = new Vector();
    for (int i = 0; i < sequencestatements.size(); i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(i);
      if (result.contains(new Integer(sequencestatementx.getkind()))) { }
      else { result.add(new Integer(sequencestatementx.getkind())); } }
    return result; }

    public static List getAllOrderedkind(List sequencestatements)
  { List result = new Vector();
    for (int i = 0; i < sequencestatements.size(); i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(i);
      result.add(new Integer(sequencestatementx.getkind())); } 
    return result; }

  public List getstatements() { return (Vector) ((Vector) statements).clone(); }

  public static List getAllstatements(List sequencestatements)
  { List result = new Vector();
    for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      result = Set.union(result, sequencestatementx.getstatements()); }
    return result; }

  public static List getAllOrderedstatements(List sequencestatements)
  { List result = new Vector();
    for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(_i);
      result.addAll(sequencestatementx.getstatements()); }
    return result; }

    public CStatement mapSequenceStatement(List css)
  {   CStatement result = null;
  if (Controller.inst().getCSequenceStatementByPK(this.getstatId()) != null)
    { CSequenceStatement cs = Controller.inst().getCSequenceStatementByPK(this.getstatId());
     Controller.inst().setkind(cs,this.getkind());
    Controller.inst().setstatements(cs,css);
    result = cs;
  }
    else
    { CSequenceStatement cs = new CSequenceStatement();
    Controller.inst().addCSequenceStatement(cs);
    Controller.inst().setcstatId(cs,this.getstatId());
    Controller.inst().setkind(cs,this.getkind());
    Controller.inst().setstatements(cs,css);
    result = cs; }

  return result;

  }

    public CStatement mapStatement()
  {   CStatement result = null;
result = this.mapSequenceStatement(  Controller.inst().AllStatementmapStatement(this.getstatements()));
  return result;

  }


}


class ConditionalStatement
  extends Statement
  implements SystemTypes
{
  private Expression test;
  private Statement ifPart;
  private List elsePart = new Vector(); // of Statement

  public ConditionalStatement(Expression test,Statement ifPart)
  {
    this.test = test;
    this.ifPart = ifPart;

  }

  public ConditionalStatement() { }



  public String toString()
  { String _res_ = "(ConditionalStatement) ";
    return _res_ + super.toString();
  }

  public static ConditionalStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    ConditionalStatement conditionalstatementx = new ConditionalStatement();
    return conditionalstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { ConditionalStatement conditionalstatementx = this;
    _out.println();
  }


  public void settest(Expression test_xx) { test = test_xx;
  }

  public static void setAlltest(List conditionalstatements, Expression _val)
  { for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      Controller.inst().settest(conditionalstatementx, _val); } }

  public void setifPart(Statement ifPart_xx) { ifPart = ifPart_xx;
  }

  public static void setAllifPart(List conditionalstatements, Statement _val)
  { for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      Controller.inst().setifPart(conditionalstatementx, _val); } }

  public void setelsePart(List elsePart_xx) { if (elsePart_xx.size() > 1) { return; } 
    elsePart = elsePart_xx;
  }
 
  public void addelsePart(Statement elsePart_xx) { if (elsePart.size() > 0) { elsePart.clear(); } 
    if (elsePart.contains(elsePart_xx)) {} else { elsePart.add(elsePart_xx); }
    }
 
  public void removeelsePart(Statement elsePart_xx) { Vector _removedelsePartelsePart_xx = new Vector();
  _removedelsePartelsePart_xx.add(elsePart_xx);
  elsePart.removeAll(_removedelsePartelsePart_xx);
    }

  public static void setAllelsePart(List conditionalstatements, List _val)
  { for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      Controller.inst().setelsePart(conditionalstatementx, _val); } }

  public static void addAllelsePart(List conditionalstatements, Statement _val)
  { for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      Controller.inst().addelsePart(conditionalstatementx,  _val); } }


  public static void removeAllelsePart(List conditionalstatements,Statement _val)
  { for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      Controller.inst().removeelsePart(conditionalstatementx, _val); } }


  public static void unionAllelsePart(List conditionalstatements, List _val)
  { for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      Controller.inst().unionelsePart(conditionalstatementx, _val); } }


  public static void subtractAllelsePart(List conditionalstatements,  List _val)
  { for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      Controller.inst().subtractelsePart(conditionalstatementx,  _val); } }


  public Expression gettest() { return test; }

  public static List getAlltest(List conditionalstatements)
  { List result = new Vector();
    for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      if (result.contains(conditionalstatementx.gettest())) {}
      else { result.add(conditionalstatementx.gettest()); }
 }
    return result; }

  public static List getAllOrderedtest(List conditionalstatements)
  { List result = new Vector();
    for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      if (result.contains(conditionalstatementx.gettest())) {}
      else { result.add(conditionalstatementx.gettest()); }
 }
    return result; }

  public Statement getifPart() { return ifPart; }

  public static List getAllifPart(List conditionalstatements)
  { List result = new Vector();
    for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      if (result.contains(conditionalstatementx.getifPart())) {}
      else { result.add(conditionalstatementx.getifPart()); }
 }
    return result; }

  public static List getAllOrderedifPart(List conditionalstatements)
  { List result = new Vector();
    for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      if (result.contains(conditionalstatementx.getifPart())) {}
      else { result.add(conditionalstatementx.getifPart()); }
 }
    return result; }

  public List getelsePart() { return (Vector) ((Vector) elsePart).clone(); }

  public static List getAllelsePart(List conditionalstatements)
  { List result = new Vector();
    for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      result = Set.union(result, conditionalstatementx.getelsePart()); }
    return result; }

  public static List getAllOrderedelsePart(List conditionalstatements)
  { List result = new Vector();
    for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(_i);
      result = Set.union(result, conditionalstatementx.getelsePart()); }
    return result; }

    public CStatement mapConditionalStatement(CStatement ifP,List elseP)
  {   CStatement result = null;
  if (Controller.inst().getIfStatementByPK(this.getstatId()) != null)
    { IfStatement istat = Controller.inst().getIfStatementByPK(this.getstatId());
     Controller.inst().setifPart(istat,ifP);
    Controller.inst().setelsePart(istat,elseP);
    Controller.inst().settest(istat,this.gettest().mapExpression());
    result = istat;
  }
    else
    { IfStatement istat = new IfStatement();
    Controller.inst().addIfStatement(istat);
    Controller.inst().setcstatId(istat,this.getstatId());
    Controller.inst().setifPart(istat,ifP);
    Controller.inst().setelsePart(istat,elseP);
    Controller.inst().settest(istat,this.gettest().mapExpression());
    result = istat; }

  return result;

  }

    public CStatement mapStatement()
  {   CStatement result = null;
result = this.mapConditionalStatement(this.getifPart().mapStatement(),  Controller.inst().AllStatementmapStatement(this.getelsePart()));
  return result;

  }


}


class CreationStatement
  extends Statement
  implements SystemTypes
{
  private String createsInstanceOf = ""; // internal
  private String assignsTo = ""; // internal
  private Type type;
  private Type elementType;

  public CreationStatement(Type type,Type elementType)
  {
    this.createsInstanceOf = "";
    this.assignsTo = "";
    this.type = type;
    this.elementType = elementType;

  }

  public CreationStatement() { }



  public String toString()
  { String _res_ = "(CreationStatement) ";
    _res_ = _res_ + createsInstanceOf + ",";
    _res_ = _res_ + assignsTo;
    return _res_ + super.toString();
  }

  public static CreationStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CreationStatement creationstatementx = new CreationStatement();
    creationstatementx.createsInstanceOf = (String) _line1vals.get(0);
    creationstatementx.assignsTo = (String) _line1vals.get(1);
    return creationstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { CreationStatement creationstatementx = this;
    _out.print("" + creationstatementx.createsInstanceOf);
    _out.print(" , ");
    _out.print("" + creationstatementx.assignsTo);
    _out.println();
  }


  public void setcreatesInstanceOf(String createsInstanceOf_x) { createsInstanceOf = createsInstanceOf_x;  }


    public static void setAllcreatesInstanceOf(List creationstatements,String val)
  { for (int i = 0; i < creationstatements.size(); i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(i);
      Controller.inst().setcreatesInstanceOf(creationstatementx,val); } }


  public void setassignsTo(String assignsTo_x) { assignsTo = assignsTo_x;  }


    public static void setAllassignsTo(List creationstatements,String val)
  { for (int i = 0; i < creationstatements.size(); i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(i);
      Controller.inst().setassignsTo(creationstatementx,val); } }


  public void settype(Type type_xx) { type = type_xx;
  }

  public static void setAlltype(List creationstatements, Type _val)
  { for (int _i = 0; _i < creationstatements.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(_i);
      Controller.inst().settype(creationstatementx, _val); } }

  public void setelementType(Type elementType_xx) { elementType = elementType_xx;
  }

  public static void setAllelementType(List creationstatements, Type _val)
  { for (int _i = 0; _i < creationstatements.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(_i);
      Controller.inst().setelementType(creationstatementx, _val); } }

    public String getcreatesInstanceOf() { return createsInstanceOf; }

    public static List getAllcreatesInstanceOf(List creationstatements)
  { List result = new Vector();
    for (int i = 0; i < creationstatements.size(); i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(i);
      if (result.contains(creationstatementx.getcreatesInstanceOf())) { }
      else { result.add(creationstatementx.getcreatesInstanceOf()); } }
    return result; }

    public static List getAllOrderedcreatesInstanceOf(List creationstatements)
  { List result = new Vector();
    for (int i = 0; i < creationstatements.size(); i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(i);
      result.add(creationstatementx.getcreatesInstanceOf()); } 
    return result; }

    public String getassignsTo() { return assignsTo; }

    public static List getAllassignsTo(List creationstatements)
  { List result = new Vector();
    for (int i = 0; i < creationstatements.size(); i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(i);
      if (result.contains(creationstatementx.getassignsTo())) { }
      else { result.add(creationstatementx.getassignsTo()); } }
    return result; }

    public static List getAllOrderedassignsTo(List creationstatements)
  { List result = new Vector();
    for (int i = 0; i < creationstatements.size(); i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(i);
      result.add(creationstatementx.getassignsTo()); } 
    return result; }

  public Type gettype() { return type; }

  public static List getAlltype(List creationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < creationstatements.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(_i);
      if (result.contains(creationstatementx.gettype())) {}
      else { result.add(creationstatementx.gettype()); }
 }
    return result; }

  public static List getAllOrderedtype(List creationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < creationstatements.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(_i);
      if (result.contains(creationstatementx.gettype())) {}
      else { result.add(creationstatementx.gettype()); }
 }
    return result; }

  public Type getelementType() { return elementType; }

  public static List getAllelementType(List creationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < creationstatements.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(_i);
      if (result.contains(creationstatementx.getelementType())) {}
      else { result.add(creationstatementx.getelementType()); }
 }
    return result; }

  public static List getAllOrderedelementType(List creationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < creationstatements.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(_i);
      if (result.contains(creationstatementx.getelementType())) {}
      else { result.add(creationstatementx.getelementType()); }
 }
    return result; }

    public CStatement mapStatement()
  {   CStatement result = null;
  if (Controller.inst().getDeclarationStatementByPK(this.getstatId()) != null)
    { DeclarationStatement ds = Controller.inst().getDeclarationStatementByPK(this.getstatId());
     Controller.inst().setcreatesInstanceOf(ds,this.getcreatesInstanceOf());
    Controller.inst().setassignsTo(ds,this.getassignsTo());
    Controller.inst().settype(ds,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(ds,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = ds;
  }
    else
    { DeclarationStatement ds = new DeclarationStatement();
    Controller.inst().addDeclarationStatement(ds);
    Controller.inst().setcstatId(ds,this.getstatId());
    Controller.inst().setcreatesInstanceOf(ds,this.getcreatesInstanceOf());
    Controller.inst().setassignsTo(ds,this.getassignsTo());
    Controller.inst().settype(ds,Controller.inst().getCTypeByPK(this.gettype().gettypeId()));
    Controller.inst().setelementType(ds,Controller.inst().getCTypeByPK(this.getelementType().gettypeId()));
    result = ds; }

  return result;

  }


}


abstract class CStatement
  implements SystemTypes
{
  protected String cstatId = ""; // internal

  public CStatement()
  {
    this.cstatId = "";

  }





  public void setcstatId(String cstatId_x) { cstatId = cstatId_x;  }


    public static void setAllcstatId(List cstatements,String val)
  { for (int i = 0; i < cstatements.size(); i++)
    { CStatement cstatementx = (CStatement) cstatements.get(i);
      Controller.inst().setcstatId(cstatementx,val); } }


    public String getcstatId() { return cstatId; }

    public static List getAllcstatId(List cstatements)
  { List result = new Vector();
    for (int i = 0; i < cstatements.size(); i++)
    { CStatement cstatementx = (CStatement) cstatements.get(i);
      if (result.contains(cstatementx.getcstatId())) { }
      else { result.add(cstatementx.getcstatId()); } }
    return result; }

    public static List getAllOrderedcstatId(List cstatements)
  { List result = new Vector();
    for (int i = 0; i < cstatements.size(); i++)
    { CStatement cstatementx = (CStatement) cstatements.get(i);
      result.add(cstatementx.getcstatId()); } 
    return result; }

    public String toString()
  {   String result = "";
 
  result = "";
    return result;
  }



}


class CReturnStatement
  extends CStatement
  implements SystemTypes
{
  private List returnValue = new Vector(); // of CExpression

  public CReturnStatement()
  {

  }



  public static CReturnStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CReturnStatement creturnstatementx = new CReturnStatement();
    return creturnstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { CReturnStatement creturnstatementx = this;
    _out.println();
  }


  public void setreturnValue(List returnValue_xx) { if (returnValue_xx.size() > 1) { return; } 
    returnValue = returnValue_xx;
  }
 
  public void addreturnValue(CExpression returnValue_xx) { if (returnValue.size() > 0) { returnValue.clear(); } 
    if (returnValue.contains(returnValue_xx)) {} else { returnValue.add(returnValue_xx); }
    }
 
  public void removereturnValue(CExpression returnValue_xx) { Vector _removedreturnValuereturnValue_xx = new Vector();
  _removedreturnValuereturnValue_xx.add(returnValue_xx);
  returnValue.removeAll(_removedreturnValuereturnValue_xx);
    }

  public static void setAllreturnValue(List creturnstatements, List _val)
  { for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(_i);
      Controller.inst().setreturnValue(creturnstatementx, _val); } }

  public static void addAllreturnValue(List creturnstatements, CExpression _val)
  { for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(_i);
      Controller.inst().addreturnValue(creturnstatementx,  _val); } }


  public static void removeAllreturnValue(List creturnstatements,CExpression _val)
  { for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(_i);
      Controller.inst().removereturnValue(creturnstatementx, _val); } }


  public static void unionAllreturnValue(List creturnstatements, List _val)
  { for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(_i);
      Controller.inst().unionreturnValue(creturnstatementx, _val); } }


  public static void subtractAllreturnValue(List creturnstatements,  List _val)
  { for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(_i);
      Controller.inst().subtractreturnValue(creturnstatementx,  _val); } }


  public List getreturnValue() { return (Vector) ((Vector) returnValue).clone(); }

  public static List getAllreturnValue(List creturnstatements)
  { List result = new Vector();
    for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(_i);
      result = Set.union(result, creturnstatementx.getreturnValue()); }
    return result; }

  public static List getAllOrderedreturnValue(List creturnstatements)
  { List result = new Vector();
    for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(_i);
      result = Set.union(result, creturnstatementx.getreturnValue()); }
    return result; }

    public String toString()
  {   String result = "";
 
  if (returnValue.size() == 1) 
  {   result = "  return " + ((CExpression) Set.any(returnValue)) + ";\n";
 
  }  else
      if (returnValue.size() == 0) 
  {   result = "  return;\n";
 
  }       return result;
  }



}


class CBreakStatement
  extends CStatement
  implements SystemTypes
{

  public CBreakStatement()
  {

  }



  public static CBreakStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CBreakStatement cbreakstatementx = new CBreakStatement();
    return cbreakstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { CBreakStatement cbreakstatementx = this;
    _out.println();
  }


    public String toString()
  {   String result = "";
 
  result = "  break;\n";
    return result;
  }



}


class OpCallStatement
  extends CStatement
  implements SystemTypes
{
  private String assignsTo = ""; // internal
  private CExpression callExp;

  public OpCallStatement(CExpression callExp)
  {
    this.assignsTo = "";
    this.callExp = callExp;

  }

  public OpCallStatement() { }



  public static OpCallStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    OpCallStatement opcallstatementx = new OpCallStatement();
    opcallstatementx.assignsTo = (String) _line1vals.get(0);
    return opcallstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { OpCallStatement opcallstatementx = this;
    _out.print("" + opcallstatementx.assignsTo);
    _out.println();
  }


  public void setassignsTo(String assignsTo_x) { assignsTo = assignsTo_x;  }


    public static void setAllassignsTo(List opcallstatements,String val)
  { for (int i = 0; i < opcallstatements.size(); i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatements.get(i);
      Controller.inst().setassignsTo(opcallstatementx,val); } }


  public void setcallExp(CExpression callExp_xx) { callExp = callExp_xx;
  }

  public static void setAllcallExp(List opcallstatements, CExpression _val)
  { for (int _i = 0; _i < opcallstatements.size(); _i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatements.get(_i);
      Controller.inst().setcallExp(opcallstatementx, _val); } }

    public String getassignsTo() { return assignsTo; }

    public static List getAllassignsTo(List opcallstatements)
  { List result = new Vector();
    for (int i = 0; i < opcallstatements.size(); i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatements.get(i);
      if (result.contains(opcallstatementx.getassignsTo())) { }
      else { result.add(opcallstatementx.getassignsTo()); } }
    return result; }

    public static List getAllOrderedassignsTo(List opcallstatements)
  { List result = new Vector();
    for (int i = 0; i < opcallstatements.size(); i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatements.get(i);
      result.add(opcallstatementx.getassignsTo()); } 
    return result; }

  public CExpression getcallExp() { return callExp; }

  public static List getAllcallExp(List opcallstatements)
  { List result = new Vector();
    for (int _i = 0; _i < opcallstatements.size(); _i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatements.get(_i);
      if (result.contains(opcallstatementx.getcallExp())) {}
      else { result.add(opcallstatementx.getcallExp()); }
 }
    return result; }

  public static List getAllOrderedcallExp(List opcallstatements)
  { List result = new Vector();
    for (int _i = 0; _i < opcallstatements.size(); _i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatements.get(_i);
      if (result.contains(opcallstatementx.getcallExp())) {}
      else { result.add(opcallstatementx.getcallExp()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  result = "  " + callExp + ";\n";
    return result;
  }



}


abstract class CLoopStatement
  extends CStatement
  implements SystemTypes
{
  protected CExpression test;
  protected CStatement body;

  public CLoopStatement(CExpression test,CStatement body)
  {
    this.test = test;
    this.body = body;

  }

  public CLoopStatement() { }



  public String toString()
  { String _res_ = "(CLoopStatement) ";
    return _res_ + super.toString();
  }



  public void settest(CExpression test_xx) { test = test_xx;
  }

  public static void setAlltest(List cloopstatements, CExpression _val)
  { for (int _i = 0; _i < cloopstatements.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) cloopstatements.get(_i);
      Controller.inst().settest(cloopstatementx, _val); } }

  public void setbody(CStatement body_xx) { body = body_xx;
  }

  public static void setAllbody(List cloopstatements, CStatement _val)
  { for (int _i = 0; _i < cloopstatements.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) cloopstatements.get(_i);
      Controller.inst().setbody(cloopstatementx, _val); } }

  public CExpression gettest() { return test; }

  public static List getAlltest(List cloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < cloopstatements.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) cloopstatements.get(_i);
      if (result.contains(cloopstatementx.gettest())) {}
      else { result.add(cloopstatementx.gettest()); }
 }
    return result; }

  public static List getAllOrderedtest(List cloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < cloopstatements.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) cloopstatements.get(_i);
      if (result.contains(cloopstatementx.gettest())) {}
      else { result.add(cloopstatementx.gettest()); }
 }
    return result; }

  public CStatement getbody() { return body; }

  public static List getAllbody(List cloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < cloopstatements.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) cloopstatements.get(_i);
      if (result.contains(cloopstatementx.getbody())) {}
      else { result.add(cloopstatementx.getbody()); }
 }
    return result; }

  public static List getAllOrderedbody(List cloopstatements)
  { List result = new Vector();
    for (int _i = 0; _i < cloopstatements.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) cloopstatements.get(_i);
      if (result.contains(cloopstatementx.getbody())) {}
      else { result.add(cloopstatementx.getbody()); }
 }
    return result; }


}


class ForLoop
  extends CLoopStatement
  implements SystemTypes
{
  private CSequenceStatement increment;
  private CExpression loopVar;
  private CExpression loopRange;

  public ForLoop(CSequenceStatement increment,CExpression loopVar,CExpression loopRange)
  {
    this.increment = increment;
    this.loopVar = loopVar;
    this.loopRange = loopRange;

  }

  public ForLoop() { }



  public static ForLoop parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    ForLoop forloopx = new ForLoop();
    return forloopx;
  }


  public void writeCSV(PrintWriter _out)
  { ForLoop forloopx = this;
    _out.println();
  }


  public void setincrement(CSequenceStatement increment_xx) { increment = increment_xx;
  }

  public static void setAllincrement(List forloops, CSequenceStatement _val)
  { for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      Controller.inst().setincrement(forloopx, _val); } }

  public void setloopVar(CExpression loopVar_xx) { loopVar = loopVar_xx;
  }

  public static void setAllloopVar(List forloops, CExpression _val)
  { for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      Controller.inst().setloopVar(forloopx, _val); } }

  public void setloopRange(CExpression loopRange_xx) { loopRange = loopRange_xx;
  }

  public static void setAllloopRange(List forloops, CExpression _val)
  { for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      Controller.inst().setloopRange(forloopx, _val); } }

  public CSequenceStatement getincrement() { return increment; }

  public static List getAllincrement(List forloops)
  { List result = new Vector();
    for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      if (result.contains(forloopx.getincrement())) {}
      else { result.add(forloopx.getincrement()); }
 }
    return result; }

  public static List getAllOrderedincrement(List forloops)
  { List result = new Vector();
    for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      if (result.contains(forloopx.getincrement())) {}
      else { result.add(forloopx.getincrement()); }
 }
    return result; }

  public CExpression getloopVar() { return loopVar; }

  public static List getAllloopVar(List forloops)
  { List result = new Vector();
    for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      if (result.contains(forloopx.getloopVar())) {}
      else { result.add(forloopx.getloopVar()); }
 }
    return result; }

  public static List getAllOrderedloopVar(List forloops)
  { List result = new Vector();
    for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      if (result.contains(forloopx.getloopVar())) {}
      else { result.add(forloopx.getloopVar()); }
 }
    return result; }

  public CExpression getloopRange() { return loopRange; }

  public static List getAllloopRange(List forloops)
  { List result = new Vector();
    for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      if (result.contains(forloopx.getloopRange())) {}
      else { result.add(forloopx.getloopRange()); }
 }
    return result; }

  public static List getAllOrderedloopRange(List forloops)
  { List result = new Vector();
    for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloops.get(_i);
      if (result.contains(forloopx.getloopRange())) {}
      else { result.add(forloopx.getloopRange()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  final String ind = "ind_" + cstatId; 
     result = "  int " + ind + " = 0;\n" + "  for ( ; " + ind + " < length((void**) " + loopRange + "); " + ind + "++)\n" + "  { " + loopRange.getelementType() + " " + loopVar + " = (" + loopRange + ")[" + ind + "];\n" + "    " + body + "\n" + "  }\n";
       return result;
  }



}


class WhileLoop
  extends CLoopStatement
  implements SystemTypes
{

  public WhileLoop()
  {

  }



  public static WhileLoop parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    WhileLoop whileloopx = new WhileLoop();
    return whileloopx;
  }


  public void writeCSV(PrintWriter _out)
  { WhileLoop whileloopx = this;
    _out.println();
  }


    public String toString()
  {   String result = "";
 
  result = "  while (" + test + ")\n" + "  { " + body + "  }\n";
    return result;
  }



}


class CAssignment
  extends CStatement
  implements SystemTypes
{
  private List type = new Vector(); // of CType
  private CExpression left;
  private CExpression right;

  public CAssignment(CExpression left,CExpression right)
  {
    this.left = left;
    this.right = right;

  }

  public CAssignment() { }



  public static CAssignment parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CAssignment cassignmentx = new CAssignment();
    return cassignmentx;
  }


  public void writeCSV(PrintWriter _out)
  { CAssignment cassignmentx = this;
    _out.println();
  }


  public void settype(List type_xx) { if (type_xx.size() > 1) { return; } 
    type = type_xx;
  }
 
  public void addtype(CType type_xx) { if (type.size() > 0) { type.clear(); } 
    if (type.contains(type_xx)) {} else { type.add(type_xx); }
    }
 
  public void removetype(CType type_xx) { Vector _removedtypetype_xx = new Vector();
  _removedtypetype_xx.add(type_xx);
  type.removeAll(_removedtypetype_xx);
    }

  public static void setAlltype(List cassignments, List _val)
  { for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      Controller.inst().settype(cassignmentx, _val); } }

  public static void addAlltype(List cassignments, CType _val)
  { for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      Controller.inst().addtype(cassignmentx,  _val); } }


  public static void removeAlltype(List cassignments,CType _val)
  { for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      Controller.inst().removetype(cassignmentx, _val); } }


  public static void unionAlltype(List cassignments, List _val)
  { for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      Controller.inst().uniontype(cassignmentx, _val); } }


  public static void subtractAlltype(List cassignments,  List _val)
  { for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      Controller.inst().subtracttype(cassignmentx,  _val); } }


  public void setleft(CExpression left_xx) { left = left_xx;
  }

  public static void setAllleft(List cassignments, CExpression _val)
  { for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      Controller.inst().setleft(cassignmentx, _val); } }

  public void setright(CExpression right_xx) { right = right_xx;
  }

  public static void setAllright(List cassignments, CExpression _val)
  { for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      Controller.inst().setright(cassignmentx, _val); } }

  public List gettype() { return (Vector) ((Vector) type).clone(); }

  public static List getAlltype(List cassignments)
  { List result = new Vector();
    for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      result = Set.union(result, cassignmentx.gettype()); }
    return result; }

  public static List getAllOrderedtype(List cassignments)
  { List result = new Vector();
    for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      result = Set.union(result, cassignmentx.gettype()); }
    return result; }

  public CExpression getleft() { return left; }

  public static List getAllleft(List cassignments)
  { List result = new Vector();
    for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      if (result.contains(cassignmentx.getleft())) {}
      else { result.add(cassignmentx.getleft()); }
 }
    return result; }

  public static List getAllOrderedleft(List cassignments)
  { List result = new Vector();
    for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      if (result.contains(cassignmentx.getleft())) {}
      else { result.add(cassignmentx.getleft()); }
 }
    return result; }

  public CExpression getright() { return right; }

  public static List getAllright(List cassignments)
  { List result = new Vector();
    for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      if (result.contains(cassignmentx.getright())) {}
      else { result.add(cassignmentx.getright()); }
 }
    return result; }

  public static List getAllOrderedright(List cassignments)
  { List result = new Vector();
    for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignments.get(_i);
      if (result.contains(cassignmentx.getright())) {}
      else { result.add(cassignmentx.getright()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  if (type.size() == 0) 
  {   result = "  " + left + " = " + right + ";\n";
 
  }  else
      if (type.size() > 0) 
  {   result = "  " + ((CType) Set.any(type)) + " " + left + " = " + right + ";\n";
 
  }       return result;
  }



}


class CSequenceStatement
  extends CStatement
  implements SystemTypes
{
  private int kind = 0; // internal
  private List statements = new Vector(); // of CStatement

  public CSequenceStatement()
  {
    this.kind = 0;

  }



  public static CSequenceStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CSequenceStatement csequencestatementx = new CSequenceStatement();
    csequencestatementx.kind = Integer.parseInt((String) _line1vals.get(0));
    return csequencestatementx;
  }


  public void writeCSV(PrintWriter _out)
  { CSequenceStatement csequencestatementx = this;
    _out.print("" + csequencestatementx.kind);
    _out.println();
  }


  public void setkind(int kind_x) { kind = kind_x;  }


    public static void setAllkind(List csequencestatements,int val)
  { for (int i = 0; i < csequencestatements.size(); i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(i);
      Controller.inst().setkind(csequencestatementx,val); } }


  public void setstatements(List statements_xx) { statements = statements_xx;
    }
 
  public void setstatements(int ind_x, CStatement statements_xx) { if (ind_x >= 0 && ind_x < statements.size()) { statements.set(ind_x, statements_xx); } }

 public void addstatements(CStatement statements_xx) { statements.add(statements_xx);
    }
 
  public void removestatements(CStatement statements_xx) { Vector _removedstatementsstatements_xx = new Vector();
  _removedstatementsstatements_xx.add(statements_xx);
  statements.removeAll(_removedstatementsstatements_xx);
    }

  public static void setAllstatements(List csequencestatements, List _val)
  { for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      Controller.inst().setstatements(csequencestatementx, _val); } }

  public static void setAllstatements(List csequencestatements, int _ind,CStatement _val)
  { for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      Controller.inst().setstatements(csequencestatementx,_ind,_val); } }

  public static void addAllstatements(List csequencestatements, CStatement _val)
  { for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      Controller.inst().addstatements(csequencestatementx,  _val); } }


  public static void removeAllstatements(List csequencestatements,CStatement _val)
  { for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      Controller.inst().removestatements(csequencestatementx, _val); } }


  public static void unionAllstatements(List csequencestatements, List _val)
  { for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      Controller.inst().unionstatements(csequencestatementx, _val); } }


  public static void subtractAllstatements(List csequencestatements,  List _val)
  { for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      Controller.inst().subtractstatements(csequencestatementx,  _val); } }


    public int getkind() { return kind; }

    public static List getAllkind(List csequencestatements)
  { List result = new Vector();
    for (int i = 0; i < csequencestatements.size(); i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(i);
      if (result.contains(new Integer(csequencestatementx.getkind()))) { }
      else { result.add(new Integer(csequencestatementx.getkind())); } }
    return result; }

    public static List getAllOrderedkind(List csequencestatements)
  { List result = new Vector();
    for (int i = 0; i < csequencestatements.size(); i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(i);
      result.add(new Integer(csequencestatementx.getkind())); } 
    return result; }

  public List getstatements() { return (Vector) ((Vector) statements).clone(); }

  public static List getAllstatements(List csequencestatements)
  { List result = new Vector();
    for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      result = Set.union(result, csequencestatementx.getstatements()); }
    return result; }

  public static List getAllOrderedstatements(List csequencestatements)
  { List result = new Vector();
    for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(_i);
      result.addAll(csequencestatementx.getstatements()); }
    return result; }

    public String toString()
  {   String result = "";
 
  result = Set.sumString(Set.collect_22(statements));
    return result;
  }



}


class IfStatement
  extends CStatement
  implements SystemTypes
{
  private CExpression test;
  private CStatement ifPart;
  private List elsePart = new Vector(); // of CStatement

  public IfStatement(CExpression test,CStatement ifPart)
  {
    this.test = test;
    this.ifPart = ifPart;

  }

  public IfStatement() { }



  public static IfStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    IfStatement ifstatementx = new IfStatement();
    return ifstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { IfStatement ifstatementx = this;
    _out.println();
  }


  public void settest(CExpression test_xx) { test = test_xx;
  }

  public static void setAlltest(List ifstatements, CExpression _val)
  { for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      Controller.inst().settest(ifstatementx, _val); } }

  public void setifPart(CStatement ifPart_xx) { ifPart = ifPart_xx;
  }

  public static void setAllifPart(List ifstatements, CStatement _val)
  { for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      Controller.inst().setifPart(ifstatementx, _val); } }

  public void setelsePart(List elsePart_xx) { if (elsePart_xx.size() > 1) { return; } 
    elsePart = elsePart_xx;
  }
 
  public void addelsePart(CStatement elsePart_xx) { if (elsePart.size() > 0) { elsePart.clear(); } 
    if (elsePart.contains(elsePart_xx)) {} else { elsePart.add(elsePart_xx); }
    }
 
  public void removeelsePart(CStatement elsePart_xx) { Vector _removedelsePartelsePart_xx = new Vector();
  _removedelsePartelsePart_xx.add(elsePart_xx);
  elsePart.removeAll(_removedelsePartelsePart_xx);
    }

  public static void setAllelsePart(List ifstatements, List _val)
  { for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      Controller.inst().setelsePart(ifstatementx, _val); } }

  public static void addAllelsePart(List ifstatements, CStatement _val)
  { for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      Controller.inst().addelsePart(ifstatementx,  _val); } }


  public static void removeAllelsePart(List ifstatements,CStatement _val)
  { for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      Controller.inst().removeelsePart(ifstatementx, _val); } }


  public static void unionAllelsePart(List ifstatements, List _val)
  { for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      Controller.inst().unionelsePart(ifstatementx, _val); } }


  public static void subtractAllelsePart(List ifstatements,  List _val)
  { for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      Controller.inst().subtractelsePart(ifstatementx,  _val); } }


  public CExpression gettest() { return test; }

  public static List getAlltest(List ifstatements)
  { List result = new Vector();
    for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      if (result.contains(ifstatementx.gettest())) {}
      else { result.add(ifstatementx.gettest()); }
 }
    return result; }

  public static List getAllOrderedtest(List ifstatements)
  { List result = new Vector();
    for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      if (result.contains(ifstatementx.gettest())) {}
      else { result.add(ifstatementx.gettest()); }
 }
    return result; }

  public CStatement getifPart() { return ifPart; }

  public static List getAllifPart(List ifstatements)
  { List result = new Vector();
    for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      if (result.contains(ifstatementx.getifPart())) {}
      else { result.add(ifstatementx.getifPart()); }
 }
    return result; }

  public static List getAllOrderedifPart(List ifstatements)
  { List result = new Vector();
    for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      if (result.contains(ifstatementx.getifPart())) {}
      else { result.add(ifstatementx.getifPart()); }
 }
    return result; }

  public List getelsePart() { return (Vector) ((Vector) elsePart).clone(); }

  public static List getAllelsePart(List ifstatements)
  { List result = new Vector();
    for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      result = Set.union(result, ifstatementx.getelsePart()); }
    return result; }

  public static List getAllOrderedelsePart(List ifstatements)
  { List result = new Vector();
    for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatements.get(_i);
      result = Set.union(result, ifstatementx.getelsePart()); }
    return result; }

    public String toString()
  {   String result = "";
 
  if (elsePart.size() == 0) 
  {   result = "  if (" + test + ")\n" + "  {" + ifPart + "  }\n";
 
  }  else
      if (elsePart.size() > 0) 
  {   result = "  if (" + test + ")\n" + "  {" + ifPart + "  }\n" + "  else \n" + "  {" + ((CStatement) Set.any(elsePart)) + "  }\n";
 
  }       return result;
  }



}


class DeclarationStatement
  extends CStatement
  implements SystemTypes
{
  private String createsInstanceOf = ""; // internal
  private String assignsTo = ""; // internal
  private CType type;
  private CType elementType;

  public DeclarationStatement(CType type,CType elementType)
  {
    this.createsInstanceOf = "";
    this.assignsTo = "";
    this.type = type;
    this.elementType = elementType;

  }

  public DeclarationStatement() { }



  public static DeclarationStatement parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    DeclarationStatement declarationstatementx = new DeclarationStatement();
    declarationstatementx.createsInstanceOf = (String) _line1vals.get(0);
    declarationstatementx.assignsTo = (String) _line1vals.get(1);
    return declarationstatementx;
  }


  public void writeCSV(PrintWriter _out)
  { DeclarationStatement declarationstatementx = this;
    _out.print("" + declarationstatementx.createsInstanceOf);
    _out.print(" , ");
    _out.print("" + declarationstatementx.assignsTo);
    _out.println();
  }


  public void setcreatesInstanceOf(String createsInstanceOf_x) { createsInstanceOf = createsInstanceOf_x;  }


    public static void setAllcreatesInstanceOf(List declarationstatements,String val)
  { for (int i = 0; i < declarationstatements.size(); i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(i);
      Controller.inst().setcreatesInstanceOf(declarationstatementx,val); } }


  public void setassignsTo(String assignsTo_x) { assignsTo = assignsTo_x;  }


    public static void setAllassignsTo(List declarationstatements,String val)
  { for (int i = 0; i < declarationstatements.size(); i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(i);
      Controller.inst().setassignsTo(declarationstatementx,val); } }


  public void settype(CType type_xx) { type = type_xx;
  }

  public static void setAlltype(List declarationstatements, CType _val)
  { for (int _i = 0; _i < declarationstatements.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(_i);
      Controller.inst().settype(declarationstatementx, _val); } }

  public void setelementType(CType elementType_xx) { elementType = elementType_xx;
  }

  public static void setAllelementType(List declarationstatements, CType _val)
  { for (int _i = 0; _i < declarationstatements.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(_i);
      Controller.inst().setelementType(declarationstatementx, _val); } }

    public String getcreatesInstanceOf() { return createsInstanceOf; }

    public static List getAllcreatesInstanceOf(List declarationstatements)
  { List result = new Vector();
    for (int i = 0; i < declarationstatements.size(); i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(i);
      if (result.contains(declarationstatementx.getcreatesInstanceOf())) { }
      else { result.add(declarationstatementx.getcreatesInstanceOf()); } }
    return result; }

    public static List getAllOrderedcreatesInstanceOf(List declarationstatements)
  { List result = new Vector();
    for (int i = 0; i < declarationstatements.size(); i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(i);
      result.add(declarationstatementx.getcreatesInstanceOf()); } 
    return result; }

    public String getassignsTo() { return assignsTo; }

    public static List getAllassignsTo(List declarationstatements)
  { List result = new Vector();
    for (int i = 0; i < declarationstatements.size(); i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(i);
      if (result.contains(declarationstatementx.getassignsTo())) { }
      else { result.add(declarationstatementx.getassignsTo()); } }
    return result; }

    public static List getAllOrderedassignsTo(List declarationstatements)
  { List result = new Vector();
    for (int i = 0; i < declarationstatements.size(); i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(i);
      result.add(declarationstatementx.getassignsTo()); } 
    return result; }

  public CType gettype() { return type; }

  public static List getAlltype(List declarationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < declarationstatements.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(_i);
      if (result.contains(declarationstatementx.gettype())) {}
      else { result.add(declarationstatementx.gettype()); }
 }
    return result; }

  public static List getAllOrderedtype(List declarationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < declarationstatements.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(_i);
      if (result.contains(declarationstatementx.gettype())) {}
      else { result.add(declarationstatementx.gettype()); }
 }
    return result; }

  public CType getelementType() { return elementType; }

  public static List getAllelementType(List declarationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < declarationstatements.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(_i);
      if (result.contains(declarationstatementx.getelementType())) {}
      else { result.add(declarationstatementx.getelementType()); }
 }
    return result; }

  public static List getAllOrderedelementType(List declarationstatements)
  { List result = new Vector();
    for (int _i = 0; _i < declarationstatements.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(_i);
      if (result.contains(declarationstatementx.getelementType())) {}
      else { result.add(declarationstatementx.getelementType()); }
 }
    return result; }

    public String toString()
  {   String result = "";
 
  if (createsInstanceOf.equals("String")) 
  {   result = " " + type + " " + assignsTo + " = \"\";\n";
 
  }  else
      {   if ((type instanceof CPrimitiveType)) 
  {   result = " " + type + " " + assignsTo + " = 0;\n";
 
  }  else
      if (true) 
  {   result = " " + type + " " + assignsTo + " = NULL;\n";
 
  }   
   }     return result;
  }



}


class Printcode
  implements SystemTypes
{

  public Printcode()
  {

  }



  public String toString()
  { String _res_ = "(Printcode) ";
    return _res_;
  }

  public static Printcode parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Printcode printcodex = new Printcode();
    return printcodex;
  }


  public void writeCSV(PrintWriter _out)
  { Printcode printcodex = this;
    _out.println();
  }


    public void printcode()
  { {} /* No update form for: true */
  }


}



public class Controller implements SystemTypes, ControllerInterface
{
  Vector cexpressions = new Vector();
  Map cexpressioncexpIdindex = new HashMap(); // String --> CExpression

  Vector cbinaryexpressions = new Vector();
  Vector cunaryexpressions = new Vector();
  Vector ctypes = new Vector();
  Map ctypectypeIdindex = new HashMap(); // String --> CType

  Vector cbasicexpressions = new Vector();
  Vector types = new Vector();
  Map typetypeIdindex = new HashMap(); // String --> Type

  Vector classifiers = new Vector();
  Vector datatypes = new Vector();
  Vector primitivetypes = new Vector();
  Vector entitys = new Vector();
  Vector collectiontypes = new Vector();
  Vector expressions = new Vector();
  Map expressionexpIdindex = new HashMap(); // String --> Expression

  Vector binaryexpressions = new Vector();
  Vector unaryexpressions = new Vector();
  Vector collectionexpressions = new Vector();
  Vector basicexpressions = new Vector();
  Vector propertys = new Vector();
  Vector exp2cs = new Vector();
  Vector cprimitivetypes = new Vector();
  Vector carraytypes = new Vector();
  Vector cpointertypes = new Vector();
  Vector cstructs = new Vector();
  Map cstructnameindex = new HashMap(); // String --> CStruct

  Vector cmembers = new Vector();
  Vector cvariables = new Vector();
  Vector cprograms = new Vector();
  Vector cfunctionpointertypes = new Vector();
  Vector coperations = new Vector();
  Map coperationopIdindex = new HashMap(); // String --> COperation

  Vector statements = new Vector();
  Map statementstatIdindex = new HashMap(); // String --> Statement

  Vector returnstatements = new Vector();
  Vector behaviouralfeatures = new Vector();
  Vector operations = new Vector();
  Vector usecases = new Vector();
  Vector breakstatements = new Vector();
  Vector operationcallstatements = new Vector();
  Vector implicitcallstatements = new Vector();
  Vector loopstatements = new Vector();
  Vector boundedloopstatements = new Vector();
  Vector unboundedloopstatements = new Vector();
  Vector assignstatements = new Vector();
  Vector sequencestatements = new Vector();
  Vector conditionalstatements = new Vector();
  Vector creationstatements = new Vector();
  Vector cstatements = new Vector();
  Map cstatementcstatIdindex = new HashMap(); // String --> CStatement

  Vector creturnstatements = new Vector();
  Vector cbreakstatements = new Vector();
  Vector opcallstatements = new Vector();
  Vector cloopstatements = new Vector();
  Vector forloops = new Vector();
  Vector whileloops = new Vector();
  Vector cassignments = new Vector();
  Vector csequencestatements = new Vector();
  Vector ifstatements = new Vector();
  Vector declarationstatements = new Vector();
  Vector printcodes = new Vector();
  private static Controller uniqueInstance; 


  private Controller() { } 


  public static Controller inst() 
    { if (uniqueInstance == null) 
    { uniqueInstance = new Controller(); }
    return uniqueInstance; } 


  public static void loadModel(String file)
  {
    try
    { BufferedReader br = null;
      File f = new File(file);
      try 
      { br = new BufferedReader(new FileReader(f)); }
      catch (Exception ex) 
      { System.err.println("No file: " + file); return; }
      Class cont = Class.forName("uml2Cb.Controller");
      java.util.Map objectmap = new java.util.HashMap();
      while (true)
      { String line1;
        try { line1 = br.readLine(); }
        catch (Exception e)
        { return; }
        if (line1 == null)
        { return; }
        line1 = line1.trim();

        if (line1.length() == 0) { continue; }
        if (line1.startsWith("//")) { continue; }
        String left;
        String op;
        String right;
        if (line1.charAt(line1.length() - 1) == '"')
        { int eqind = line1.indexOf("="); 
          if (eqind == -1) { continue; }
          else 
          { left = line1.substring(0,eqind-1).trim();
            op = "="; 
            right = line1.substring(eqind+1,line1.length()).trim();
          }
        }
        else
        { StringTokenizer st1 = new StringTokenizer(line1);
          Vector vals1 = new Vector();
          while (st1.hasMoreTokens())
          { String val1 = st1.nextToken();
            vals1.add(val1);
          }
          if (vals1.size() < 3)
          { continue; }
          left = (String) vals1.get(0);
          op = (String) vals1.get(1);
          right = (String) vals1.get(2);
        }
        if (":".equals(op))
        { int i2 = right.indexOf(".");
          if (i2 == -1)
          { Class cl;
            try { cl = Class.forName("uml2Cb." + right); }
            catch (Exception _x) { System.err.println("No entity: " + right); continue; }
            Object xinst = cl.newInstance();
            objectmap.put(left,xinst);
            Class[] cargs = new Class[] { cl };
            Method addC = null;
            try { addC = cont.getMethod("add" + right,cargs); }
            catch (Exception _xx) { System.err.println("No entity: " + right); continue; }
            if (addC == null) { continue; }
            Object[] args = new Object[] { xinst };
            addC.invoke(Controller.inst(),args);
          }
          else
          { String obj = right.substring(0,i2);
            String role = right.substring(i2+1,right.length());
            Object objinst = objectmap.get(obj); 
            if (objinst == null) 
            { continue; }
            Object val = objectmap.get(left);
            if (val == null) 
            { continue; }
            Class objC = objinst.getClass();
            Class typeclass = val.getClass(); 
            Object[] args = new Object[] { val }; 
            Class[] settypes = new Class[] { typeclass };
            Method addrole = Controller.findMethod(objC,"add" + role);
            if (addrole != null) 
            { addrole.invoke(objinst, args); }
            else { System.err.println("Error: cannot add to " + role); }
          }
        }
        else if ("=".equals(op))
        { int i1 = left.indexOf(".");
          if (i1 == -1) 
          { continue; }
          String obj = left.substring(0,i1);
          String att = left.substring(i1+1,left.length());
          Object objinst = objectmap.get(obj); 
          if (objinst == null) 
          { System.err.println("No object: " + obj); continue; }
          Class objC = objinst.getClass();
          Class typeclass; 
          Object val; 
          if (right.charAt(0) == '"' &&
              right.charAt(right.length() - 1) == '"')
          { typeclass = String.class;
            val = right.substring(1,right.length() - 1);
          } 
          else if ("true".equals(right) || "false".equals(right))
          { typeclass = boolean.class;
            if ("true".equals(right))
            { val = new Boolean(true); }
            else
            { val = new Boolean(false); }
          }
          else 
          { val = objectmap.get(right);
            if (val != null)
            { typeclass = val.getClass(); }
            else 
            { int i;
              long l; 
              double d;
              try 
              { i = Integer.parseInt(right);
                typeclass = int.class;
                val = new Integer(i); 
              }
              catch (Exception ee)
              { try 
                { l = Long.parseLong(right);
                  typeclass = long.class;
                  val = new Long(l); 
                }
                catch (Exception eee)
                { try
                  { d = Double.parseDouble(right);
                    typeclass = double.class;
                    val = new Double(d);
                  }
                  catch (Exception ff)
                  { continue; }
                }
              }
            }
          }
          Object[] args = new Object[] { val }; 
          Class[] settypes = new Class[] { typeclass };
          Method setatt = Controller.findMethod(objC,"set" + att);
          if (setatt != null) 
          { setatt.invoke(objinst, args); }
          else { System.err.println("No attribute: " + objC.getName() + "::" + att); }
        }
      }
    } catch (Exception e) { }
  }

  public static Method findMethod(Class c, String name)
  { Method[] mets = c.getMethods(); 
    for (int i = 0; i < mets.length; i++)
    { Method m = mets[i];
      if (m.getName().equals(name))
      { return m; }
    } 
    return null;
  }


  public static void loadCSVModel()
  { boolean __eof = false;
    String __s = "";
    Controller __cont = Controller.inst();
    BufferedReader __br = null;
    try
    { File _cbinaryexpression = new File("CBinaryExpression.csv");
      __br = new BufferedReader(new FileReader(_cbinaryexpression));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CBinaryExpression cbinaryexpressionx = CBinaryExpression.parseCSV(__s.trim());
          if (cbinaryexpressionx != null)
          { __cont.addCBinaryExpression(cbinaryexpressionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cunaryexpression = new File("CUnaryExpression.csv");
      __br = new BufferedReader(new FileReader(_cunaryexpression));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CUnaryExpression cunaryexpressionx = CUnaryExpression.parseCSV(__s.trim());
          if (cunaryexpressionx != null)
          { __cont.addCUnaryExpression(cunaryexpressionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cbasicexpression = new File("CBasicExpression.csv");
      __br = new BufferedReader(new FileReader(_cbasicexpression));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CBasicExpression cbasicexpressionx = CBasicExpression.parseCSV(__s.trim());
          if (cbasicexpressionx != null)
          { __cont.addCBasicExpression(cbasicexpressionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _primitivetype = new File("PrimitiveType.csv");
      __br = new BufferedReader(new FileReader(_primitivetype));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { PrimitiveType primitivetypex = PrimitiveType.parseCSV(__s.trim());
          if (primitivetypex != null)
          { __cont.addPrimitiveType(primitivetypex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _entity = new File("Entity.csv");
      __br = new BufferedReader(new FileReader(_entity));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Entity entityx = Entity.parseCSV(__s.trim());
          if (entityx != null)
          { __cont.addEntity(entityx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _collectiontype = new File("CollectionType.csv");
      __br = new BufferedReader(new FileReader(_collectiontype));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CollectionType collectiontypex = CollectionType.parseCSV(__s.trim());
          if (collectiontypex != null)
          { __cont.addCollectionType(collectiontypex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _binaryexpression = new File("BinaryExpression.csv");
      __br = new BufferedReader(new FileReader(_binaryexpression));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { BinaryExpression binaryexpressionx = BinaryExpression.parseCSV(__s.trim());
          if (binaryexpressionx != null)
          { __cont.addBinaryExpression(binaryexpressionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _unaryexpression = new File("UnaryExpression.csv");
      __br = new BufferedReader(new FileReader(_unaryexpression));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { UnaryExpression unaryexpressionx = UnaryExpression.parseCSV(__s.trim());
          if (unaryexpressionx != null)
          { __cont.addUnaryExpression(unaryexpressionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _collectionexpression = new File("CollectionExpression.csv");
      __br = new BufferedReader(new FileReader(_collectionexpression));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CollectionExpression collectionexpressionx = CollectionExpression.parseCSV(__s.trim());
          if (collectionexpressionx != null)
          { __cont.addCollectionExpression(collectionexpressionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _basicexpression = new File("BasicExpression.csv");
      __br = new BufferedReader(new FileReader(_basicexpression));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { BasicExpression basicexpressionx = BasicExpression.parseCSV(__s.trim());
          if (basicexpressionx != null)
          { __cont.addBasicExpression(basicexpressionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _property = new File("Property.csv");
      __br = new BufferedReader(new FileReader(_property));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Property propertyx = Property.parseCSV(__s.trim());
          if (propertyx != null)
          { __cont.addProperty(propertyx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _exp2c = new File("Exp2C.csv");
      __br = new BufferedReader(new FileReader(_exp2c));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Exp2C exp2cx = Exp2C.parseCSV(__s.trim());
          if (exp2cx != null)
          { __cont.addExp2C(exp2cx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cprimitivetype = new File("CPrimitiveType.csv");
      __br = new BufferedReader(new FileReader(_cprimitivetype));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CPrimitiveType cprimitivetypex = CPrimitiveType.parseCSV(__s.trim());
          if (cprimitivetypex != null)
          { __cont.addCPrimitiveType(cprimitivetypex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _carraytype = new File("CArrayType.csv");
      __br = new BufferedReader(new FileReader(_carraytype));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CArrayType carraytypex = CArrayType.parseCSV(__s.trim());
          if (carraytypex != null)
          { __cont.addCArrayType(carraytypex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cpointertype = new File("CPointerType.csv");
      __br = new BufferedReader(new FileReader(_cpointertype));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CPointerType cpointertypex = CPointerType.parseCSV(__s.trim());
          if (cpointertypex != null)
          { __cont.addCPointerType(cpointertypex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cstruct = new File("CStruct.csv");
      __br = new BufferedReader(new FileReader(_cstruct));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CStruct cstructx = CStruct.parseCSV(__s.trim());
          if (cstructx != null)
          { __cont.addCStruct(cstructx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cmember = new File("CMember.csv");
      __br = new BufferedReader(new FileReader(_cmember));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CMember cmemberx = CMember.parseCSV(__s.trim());
          if (cmemberx != null)
          { __cont.addCMember(cmemberx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cvariable = new File("CVariable.csv");
      __br = new BufferedReader(new FileReader(_cvariable));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CVariable cvariablex = CVariable.parseCSV(__s.trim());
          if (cvariablex != null)
          { __cont.addCVariable(cvariablex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cprogram = new File("CProgram.csv");
      __br = new BufferedReader(new FileReader(_cprogram));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CProgram cprogramx = CProgram.parseCSV(__s.trim());
          if (cprogramx != null)
          { __cont.addCProgram(cprogramx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cfunctionpointertype = new File("CFunctionPointerType.csv");
      __br = new BufferedReader(new FileReader(_cfunctionpointertype));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CFunctionPointerType cfunctionpointertypex = CFunctionPointerType.parseCSV(__s.trim());
          if (cfunctionpointertypex != null)
          { __cont.addCFunctionPointerType(cfunctionpointertypex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _coperation = new File("COperation.csv");
      __br = new BufferedReader(new FileReader(_coperation));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { COperation coperationx = COperation.parseCSV(__s.trim());
          if (coperationx != null)
          { __cont.addCOperation(coperationx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _returnstatement = new File("ReturnStatement.csv");
      __br = new BufferedReader(new FileReader(_returnstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { ReturnStatement returnstatementx = ReturnStatement.parseCSV(__s.trim());
          if (returnstatementx != null)
          { __cont.addReturnStatement(returnstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _operation = new File("Operation.csv");
      __br = new BufferedReader(new FileReader(_operation));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Operation operationx = Operation.parseCSV(__s.trim());
          if (operationx != null)
          { __cont.addOperation(operationx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _usecase = new File("UseCase.csv");
      __br = new BufferedReader(new FileReader(_usecase));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { UseCase usecasex = UseCase.parseCSV(__s.trim());
          if (usecasex != null)
          { __cont.addUseCase(usecasex); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _breakstatement = new File("BreakStatement.csv");
      __br = new BufferedReader(new FileReader(_breakstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { BreakStatement breakstatementx = BreakStatement.parseCSV(__s.trim());
          if (breakstatementx != null)
          { __cont.addBreakStatement(breakstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _operationcallstatement = new File("OperationCallStatement.csv");
      __br = new BufferedReader(new FileReader(_operationcallstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { OperationCallStatement operationcallstatementx = OperationCallStatement.parseCSV(__s.trim());
          if (operationcallstatementx != null)
          { __cont.addOperationCallStatement(operationcallstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _implicitcallstatement = new File("ImplicitCallStatement.csv");
      __br = new BufferedReader(new FileReader(_implicitcallstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { ImplicitCallStatement implicitcallstatementx = ImplicitCallStatement.parseCSV(__s.trim());
          if (implicitcallstatementx != null)
          { __cont.addImplicitCallStatement(implicitcallstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _boundedloopstatement = new File("BoundedLoopStatement.csv");
      __br = new BufferedReader(new FileReader(_boundedloopstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { BoundedLoopStatement boundedloopstatementx = BoundedLoopStatement.parseCSV(__s.trim());
          if (boundedloopstatementx != null)
          { __cont.addBoundedLoopStatement(boundedloopstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _unboundedloopstatement = new File("UnboundedLoopStatement.csv");
      __br = new BufferedReader(new FileReader(_unboundedloopstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { UnboundedLoopStatement unboundedloopstatementx = UnboundedLoopStatement.parseCSV(__s.trim());
          if (unboundedloopstatementx != null)
          { __cont.addUnboundedLoopStatement(unboundedloopstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _assignstatement = new File("AssignStatement.csv");
      __br = new BufferedReader(new FileReader(_assignstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { AssignStatement assignstatementx = AssignStatement.parseCSV(__s.trim());
          if (assignstatementx != null)
          { __cont.addAssignStatement(assignstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _sequencestatement = new File("SequenceStatement.csv");
      __br = new BufferedReader(new FileReader(_sequencestatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { SequenceStatement sequencestatementx = SequenceStatement.parseCSV(__s.trim());
          if (sequencestatementx != null)
          { __cont.addSequenceStatement(sequencestatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _conditionalstatement = new File("ConditionalStatement.csv");
      __br = new BufferedReader(new FileReader(_conditionalstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { ConditionalStatement conditionalstatementx = ConditionalStatement.parseCSV(__s.trim());
          if (conditionalstatementx != null)
          { __cont.addConditionalStatement(conditionalstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _creationstatement = new File("CreationStatement.csv");
      __br = new BufferedReader(new FileReader(_creationstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CreationStatement creationstatementx = CreationStatement.parseCSV(__s.trim());
          if (creationstatementx != null)
          { __cont.addCreationStatement(creationstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _creturnstatement = new File("CReturnStatement.csv");
      __br = new BufferedReader(new FileReader(_creturnstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CReturnStatement creturnstatementx = CReturnStatement.parseCSV(__s.trim());
          if (creturnstatementx != null)
          { __cont.addCReturnStatement(creturnstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cbreakstatement = new File("CBreakStatement.csv");
      __br = new BufferedReader(new FileReader(_cbreakstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CBreakStatement cbreakstatementx = CBreakStatement.parseCSV(__s.trim());
          if (cbreakstatementx != null)
          { __cont.addCBreakStatement(cbreakstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _opcallstatement = new File("OpCallStatement.csv");
      __br = new BufferedReader(new FileReader(_opcallstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { OpCallStatement opcallstatementx = OpCallStatement.parseCSV(__s.trim());
          if (opcallstatementx != null)
          { __cont.addOpCallStatement(opcallstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _forloop = new File("ForLoop.csv");
      __br = new BufferedReader(new FileReader(_forloop));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { ForLoop forloopx = ForLoop.parseCSV(__s.trim());
          if (forloopx != null)
          { __cont.addForLoop(forloopx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _whileloop = new File("WhileLoop.csv");
      __br = new BufferedReader(new FileReader(_whileloop));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { WhileLoop whileloopx = WhileLoop.parseCSV(__s.trim());
          if (whileloopx != null)
          { __cont.addWhileLoop(whileloopx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cassignment = new File("CAssignment.csv");
      __br = new BufferedReader(new FileReader(_cassignment));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CAssignment cassignmentx = CAssignment.parseCSV(__s.trim());
          if (cassignmentx != null)
          { __cont.addCAssignment(cassignmentx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _csequencestatement = new File("CSequenceStatement.csv");
      __br = new BufferedReader(new FileReader(_csequencestatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CSequenceStatement csequencestatementx = CSequenceStatement.parseCSV(__s.trim());
          if (csequencestatementx != null)
          { __cont.addCSequenceStatement(csequencestatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _ifstatement = new File("IfStatement.csv");
      __br = new BufferedReader(new FileReader(_ifstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { IfStatement ifstatementx = IfStatement.parseCSV(__s.trim());
          if (ifstatementx != null)
          { __cont.addIfStatement(ifstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _declarationstatement = new File("DeclarationStatement.csv");
      __br = new BufferedReader(new FileReader(_declarationstatement));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { DeclarationStatement declarationstatementx = DeclarationStatement.parseCSV(__s.trim());
          if (declarationstatementx != null)
          { __cont.addDeclarationStatement(declarationstatementx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _printcode = new File("Printcode.csv");
      __br = new BufferedReader(new FileReader(_printcode));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Printcode printcodex = Printcode.parseCSV(__s.trim());
          if (printcodex != null)
          { __cont.addPrintcode(printcodex); }
        }
      }
    }
    catch(Exception __e) { }
  }


  public void checkCompleteness()
  {   for (int _i = 0; _i < cexpressions.size(); _i++)
  { CExpression cexpression_x = (CExpression) cexpressions.get(_i);
    CExpression cexpression_obj = (CExpression) cexpressioncexpIdindex.get(cexpression_x.getcexpId());
    if (cexpression_obj == cexpression_x) { }
    else if (cexpression_obj == null)
    { cexpressioncexpIdindex.put(cexpression_x.getcexpId(),cexpression_x); }
    else
    { System.out.println("Error: multiple objects with cexpId = " + cexpression_x.getcexpId()); }
  }
  for (int _i = 0; _i < ctypes.size(); _i++)
  { CType ctype_x = (CType) ctypes.get(_i);
    CType ctype_obj = (CType) ctypectypeIdindex.get(ctype_x.getctypeId());
    if (ctype_obj == ctype_x) { }
    else if (ctype_obj == null)
    { ctypectypeIdindex.put(ctype_x.getctypeId(),ctype_x); }
    else
    { System.out.println("Error: multiple objects with ctypeId = " + ctype_x.getctypeId()); }
  }
  for (int _i = 0; _i < types.size(); _i++)
  { Type type_x = (Type) types.get(_i);
    Type type_obj = (Type) typetypeIdindex.get(type_x.gettypeId());
    if (type_obj == type_x) { }
    else if (type_obj == null)
    { typetypeIdindex.put(type_x.gettypeId(),type_x); }
    else
    { System.out.println("Error: multiple objects with typeId = " + type_x.gettypeId()); }
  }
  for (int _i = 0; _i < expressions.size(); _i++)
  { Expression expression_x = (Expression) expressions.get(_i);
    Expression expression_obj = (Expression) expressionexpIdindex.get(expression_x.getexpId());
    if (expression_obj == expression_x) { }
    else if (expression_obj == null)
    { expressionexpIdindex.put(expression_x.getexpId(),expression_x); }
    else
    { System.out.println("Error: multiple objects with expId = " + expression_x.getexpId()); }
  }
  for (int _i = 0; _i < cstructs.size(); _i++)
  { CStruct cstruct_x = (CStruct) cstructs.get(_i);
    CStruct cstruct_obj = (CStruct) cstructnameindex.get(cstruct_x.getname());
    if (cstruct_obj == cstruct_x) { }
    else if (cstruct_obj == null)
    { cstructnameindex.put(cstruct_x.getname(),cstruct_x); }
    else
    { System.out.println("Error: multiple objects with name = " + cstruct_x.getname()); }
  }
  for (int _i = 0; _i < coperations.size(); _i++)
  { COperation coperation_x = (COperation) coperations.get(_i);
    COperation coperation_obj = (COperation) coperationopIdindex.get(coperation_x.getopId());
    if (coperation_obj == coperation_x) { }
    else if (coperation_obj == null)
    { coperationopIdindex.put(coperation_x.getopId(),coperation_x); }
    else
    { System.out.println("Error: multiple objects with opId = " + coperation_x.getopId()); }
  }
  for (int _i = 0; _i < statements.size(); _i++)
  { Statement statement_x = (Statement) statements.get(_i);
    Statement statement_obj = (Statement) statementstatIdindex.get(statement_x.getstatId());
    if (statement_obj == statement_x) { }
    else if (statement_obj == null)
    { statementstatIdindex.put(statement_x.getstatId(),statement_x); }
    else
    { System.out.println("Error: multiple objects with statId = " + statement_x.getstatId()); }
  }
  for (int _i = 0; _i < cstatements.size(); _i++)
  { CStatement cstatement_x = (CStatement) cstatements.get(_i);
    CStatement cstatement_obj = (CStatement) cstatementcstatIdindex.get(cstatement_x.getcstatId());
    if (cstatement_obj == cstatement_x) { }
    else if (cstatement_obj == null)
    { cstatementcstatIdindex.put(cstatement_x.getcstatId(),cstatement_x); }
    else
    { System.out.println("Error: multiple objects with cstatId = " + cstatement_x.getcstatId()); }
  }
  for (int _i = 0; _i < entitys.size(); _i++)
  { Entity owner_entityx1 = (Entity) entitys.get(_i);
    for (int _j = 0; _j < operations.size(); _j++)
    { Operation ownedOperation_operationx2 = (Operation) operations.get(_j);
      if (owner_entityx1.getownedOperation().contains(ownedOperation_operationx2))
      { if (ownedOperation_operationx2.getowner() == owner_entityx1) { }
        else { ownedOperation_operationx2.setowner(owner_entityx1); }
      }
      else if (ownedOperation_operationx2.getowner() == owner_entityx1)
      { owner_entityx1.addownedOperation(ownedOperation_operationx2); } 
    }
  }
  for (int _i = 0; _i < propertys.size(); _i++)
  { Property ownedAttribute_propertyx1 = (Property) propertys.get(_i);
    for (int _j = 0; _j < entitys.size(); _j++)
    { Entity owner_entityx2 = (Entity) entitys.get(_j);
      if (ownedAttribute_propertyx1.getowner() == owner_entityx2)
      { if (owner_entityx2.getownedAttribute().contains(ownedAttribute_propertyx1)) { }
        else { owner_entityx2.addownedAttribute(ownedAttribute_propertyx1); }
      }
      else if (owner_entityx2.getownedAttribute().contains(ownedAttribute_propertyx1))
      { ownedAttribute_propertyx1.setowner(owner_entityx2); } 
    }
  }
  }


  public void saveModel(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
  for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
  { CBinaryExpression cbinaryexpressionx_ = (CBinaryExpression) cbinaryexpressions.get(_i);
    out.println("cbinaryexpressionx_" + _i + " : CBinaryExpression");
    out.println("cbinaryexpressionx_" + _i + ".operator = \"" + cbinaryexpressionx_.getoperator() + "\"");
    out.println("cbinaryexpressionx_" + _i + ".needsBracket = " + cbinaryexpressionx_.getneedsBracket());
    out.println("cbinaryexpressionx_" + _i + ".kind = \"" + cbinaryexpressionx_.getkind() + "\"");
    out.println("cbinaryexpressionx_" + _i + ".cexpId = \"" + cbinaryexpressionx_.getcexpId() + "\"");
    out.println("cbinaryexpressionx_" + _i + ".isStatic = " + cbinaryexpressionx_.getisStatic());
  }

  for (int _i = 0; _i < cunaryexpressions.size(); _i++)
  { CUnaryExpression cunaryexpressionx_ = (CUnaryExpression) cunaryexpressions.get(_i);
    out.println("cunaryexpressionx_" + _i + " : CUnaryExpression");
    out.println("cunaryexpressionx_" + _i + ".operator = \"" + cunaryexpressionx_.getoperator() + "\"");
    out.println("cunaryexpressionx_" + _i + ".needsBracket = " + cunaryexpressionx_.getneedsBracket());
    out.println("cunaryexpressionx_" + _i + ".kind = \"" + cunaryexpressionx_.getkind() + "\"");
    out.println("cunaryexpressionx_" + _i + ".cexpId = \"" + cunaryexpressionx_.getcexpId() + "\"");
    out.println("cunaryexpressionx_" + _i + ".isStatic = " + cunaryexpressionx_.getisStatic());
  }

  for (int _i = 0; _i < cbasicexpressions.size(); _i++)
  { CBasicExpression cbasicexpressionx_ = (CBasicExpression) cbasicexpressions.get(_i);
    out.println("cbasicexpressionx_" + _i + " : CBasicExpression");
    out.println("cbasicexpressionx_" + _i + ".data = \"" + cbasicexpressionx_.getdata() + "\"");
    out.println("cbasicexpressionx_" + _i + ".needsBracket = " + cbasicexpressionx_.getneedsBracket());
    out.println("cbasicexpressionx_" + _i + ".kind = \"" + cbasicexpressionx_.getkind() + "\"");
    out.println("cbasicexpressionx_" + _i + ".cexpId = \"" + cbasicexpressionx_.getcexpId() + "\"");
    out.println("cbasicexpressionx_" + _i + ".isStatic = " + cbasicexpressionx_.getisStatic());
  }

  for (int _i = 0; _i < primitivetypes.size(); _i++)
  { PrimitiveType primitivetypex_ = (PrimitiveType) primitivetypes.get(_i);
    out.println("primitivetypex_" + _i + " : PrimitiveType");
    out.println("primitivetypex_" + _i + ".typeId = \"" + primitivetypex_.gettypeId() + "\"");
    out.println("primitivetypex_" + _i + ".name = \"" + primitivetypex_.getname() + "\"");
  }

  for (int _i = 0; _i < entitys.size(); _i++)
  { Entity entityx_ = (Entity) entitys.get(_i);
    out.println("entityx_" + _i + " : Entity");
    out.println("entityx_" + _i + ".isAbstract = " + entityx_.getisAbstract());
    out.println("entityx_" + _i + ".isInterface = " + entityx_.getisInterface());
    out.println("entityx_" + _i + ".typeId = \"" + entityx_.gettypeId() + "\"");
    out.println("entityx_" + _i + ".name = \"" + entityx_.getname() + "\"");
  }

  for (int _i = 0; _i < collectiontypes.size(); _i++)
  { CollectionType collectiontypex_ = (CollectionType) collectiontypes.get(_i);
    out.println("collectiontypex_" + _i + " : CollectionType");
    out.println("collectiontypex_" + _i + ".typeId = \"" + collectiontypex_.gettypeId() + "\"");
    out.println("collectiontypex_" + _i + ".name = \"" + collectiontypex_.getname() + "\"");
  }

  for (int _i = 0; _i < binaryexpressions.size(); _i++)
  { BinaryExpression binaryexpressionx_ = (BinaryExpression) binaryexpressions.get(_i);
    out.println("binaryexpressionx_" + _i + " : BinaryExpression");
    out.println("binaryexpressionx_" + _i + ".operator = \"" + binaryexpressionx_.getoperator() + "\"");
    out.println("binaryexpressionx_" + _i + ".variable = \"" + binaryexpressionx_.getvariable() + "\"");
    out.println("binaryexpressionx_" + _i + ".needsBracket = " + binaryexpressionx_.getneedsBracket());
    out.println("binaryexpressionx_" + _i + ".umlKind = " + binaryexpressionx_.getumlKind());
    out.println("binaryexpressionx_" + _i + ".expId = \"" + binaryexpressionx_.getexpId() + "\"");
    out.println("binaryexpressionx_" + _i + ".isStatic = " + binaryexpressionx_.getisStatic());
  }

  for (int _i = 0; _i < unaryexpressions.size(); _i++)
  { UnaryExpression unaryexpressionx_ = (UnaryExpression) unaryexpressions.get(_i);
    out.println("unaryexpressionx_" + _i + " : UnaryExpression");
    out.println("unaryexpressionx_" + _i + ".operator = \"" + unaryexpressionx_.getoperator() + "\"");
    out.println("unaryexpressionx_" + _i + ".variable = \"" + unaryexpressionx_.getvariable() + "\"");
    out.println("unaryexpressionx_" + _i + ".needsBracket = " + unaryexpressionx_.getneedsBracket());
    out.println("unaryexpressionx_" + _i + ".umlKind = " + unaryexpressionx_.getumlKind());
    out.println("unaryexpressionx_" + _i + ".expId = \"" + unaryexpressionx_.getexpId() + "\"");
    out.println("unaryexpressionx_" + _i + ".isStatic = " + unaryexpressionx_.getisStatic());
  }

  for (int _i = 0; _i < collectionexpressions.size(); _i++)
  { CollectionExpression collectionexpressionx_ = (CollectionExpression) collectionexpressions.get(_i);
    out.println("collectionexpressionx_" + _i + " : CollectionExpression");
    out.println("collectionexpressionx_" + _i + ".isOrdered = " + collectionexpressionx_.getisOrdered());
    out.println("collectionexpressionx_" + _i + ".needsBracket = " + collectionexpressionx_.getneedsBracket());
    out.println("collectionexpressionx_" + _i + ".umlKind = " + collectionexpressionx_.getumlKind());
    out.println("collectionexpressionx_" + _i + ".expId = \"" + collectionexpressionx_.getexpId() + "\"");
    out.println("collectionexpressionx_" + _i + ".isStatic = " + collectionexpressionx_.getisStatic());
  }

  for (int _i = 0; _i < basicexpressions.size(); _i++)
  { BasicExpression basicexpressionx_ = (BasicExpression) basicexpressions.get(_i);
    out.println("basicexpressionx_" + _i + " : BasicExpression");
    out.println("basicexpressionx_" + _i + ".data = \"" + basicexpressionx_.getdata() + "\"");
    out.println("basicexpressionx_" + _i + ".prestate = " + basicexpressionx_.getprestate());
    out.println("basicexpressionx_" + _i + ".needsBracket = " + basicexpressionx_.getneedsBracket());
    out.println("basicexpressionx_" + _i + ".umlKind = " + basicexpressionx_.getumlKind());
    out.println("basicexpressionx_" + _i + ".expId = \"" + basicexpressionx_.getexpId() + "\"");
    out.println("basicexpressionx_" + _i + ".isStatic = " + basicexpressionx_.getisStatic());
  }

  for (int _i = 0; _i < propertys.size(); _i++)
  { Property propertyx_ = (Property) propertys.get(_i);
    out.println("propertyx_" + _i + " : Property");
    out.println("propertyx_" + _i + ".name = \"" + propertyx_.getname() + "\"");
    out.println("propertyx_" + _i + ".lower = " + propertyx_.getlower());
    out.println("propertyx_" + _i + ".upper = " + propertyx_.getupper());
    out.println("propertyx_" + _i + ".isOrdered = " + propertyx_.getisOrdered());
    out.println("propertyx_" + _i + ".isUnique = " + propertyx_.getisUnique());
    out.println("propertyx_" + _i + ".isDerived = " + propertyx_.getisDerived());
    out.println("propertyx_" + _i + ".isReadOnly = " + propertyx_.getisReadOnly());
    out.println("propertyx_" + _i + ".isStatic = " + propertyx_.getisStatic());
  }

  for (int _i = 0; _i < exp2cs.size(); _i++)
  { Exp2C exp2cx_ = (Exp2C) exp2cs.get(_i);
    out.println("exp2cx_" + _i + " : Exp2C");
  }

  for (int _i = 0; _i < cprimitivetypes.size(); _i++)
  { CPrimitiveType cprimitivetypex_ = (CPrimitiveType) cprimitivetypes.get(_i);
    out.println("cprimitivetypex_" + _i + " : CPrimitiveType");
    out.println("cprimitivetypex_" + _i + ".name = \"" + cprimitivetypex_.getname() + "\"");
    out.println("cprimitivetypex_" + _i + ".ctypeId = \"" + cprimitivetypex_.getctypeId() + "\"");
    out.println("cprimitivetypex_" + _i + ".name = \"" + cprimitivetypex_.getname() + "\"");
  }

  for (int _i = 0; _i < carraytypes.size(); _i++)
  { CArrayType carraytypex_ = (CArrayType) carraytypes.get(_i);
    out.println("carraytypex_" + _i + " : CArrayType");
    out.println("carraytypex_" + _i + ".duplicates = " + carraytypex_.getduplicates());
    out.println("carraytypex_" + _i + ".ctypeId = \"" + carraytypex_.getctypeId() + "\"");
    out.println("carraytypex_" + _i + ".name = \"" + carraytypex_.getname() + "\"");
  }

  for (int _i = 0; _i < cpointertypes.size(); _i++)
  { CPointerType cpointertypex_ = (CPointerType) cpointertypes.get(_i);
    out.println("cpointertypex_" + _i + " : CPointerType");
    out.println("cpointertypex_" + _i + ".ctypeId = \"" + cpointertypex_.getctypeId() + "\"");
    out.println("cpointertypex_" + _i + ".name = \"" + cpointertypex_.getname() + "\"");
  }

  for (int _i = 0; _i < cstructs.size(); _i++)
  { CStruct cstructx_ = (CStruct) cstructs.get(_i);
    out.println("cstructx_" + _i + " : CStruct");
    out.println("cstructx_" + _i + ".name = \"" + cstructx_.getname() + "\"");
    out.println("cstructx_" + _i + ".ctypeId = \"" + cstructx_.getctypeId() + "\"");
    out.println("cstructx_" + _i + ".name = \"" + cstructx_.getname() + "\"");
  }

  for (int _i = 0; _i < cmembers.size(); _i++)
  { CMember cmemberx_ = (CMember) cmembers.get(_i);
    out.println("cmemberx_" + _i + " : CMember");
    out.println("cmemberx_" + _i + ".name = \"" + cmemberx_.getname() + "\"");
    out.println("cmemberx_" + _i + ".isKey = " + cmemberx_.getisKey());
  }

  for (int _i = 0; _i < cvariables.size(); _i++)
  { CVariable cvariablex_ = (CVariable) cvariables.get(_i);
    out.println("cvariablex_" + _i + " : CVariable");
    out.println("cvariablex_" + _i + ".name = \"" + cvariablex_.getname() + "\"");
    out.println("cvariablex_" + _i + ".kind = \"" + cvariablex_.getkind() + "\"");
    out.println("cvariablex_" + _i + ".initialisation = \"" + cvariablex_.getinitialisation() + "\"");
  }

  for (int _i = 0; _i < cprograms.size(); _i++)
  { CProgram cprogramx_ = (CProgram) cprograms.get(_i);
    out.println("cprogramx_" + _i + " : CProgram");
  }

  for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
  { CFunctionPointerType cfunctionpointertypex_ = (CFunctionPointerType) cfunctionpointertypes.get(_i);
    out.println("cfunctionpointertypex_" + _i + " : CFunctionPointerType");
    out.println("cfunctionpointertypex_" + _i + ".ctypeId = \"" + cfunctionpointertypex_.getctypeId() + "\"");
    out.println("cfunctionpointertypex_" + _i + ".name = \"" + cfunctionpointertypex_.getname() + "\"");
  }

  for (int _i = 0; _i < coperations.size(); _i++)
  { COperation coperationx_ = (COperation) coperations.get(_i);
    out.println("coperationx_" + _i + " : COperation");
    out.println("coperationx_" + _i + ".name = \"" + coperationx_.getname() + "\"");
    out.println("coperationx_" + _i + ".opId = \"" + coperationx_.getopId() + "\"");
    out.println("coperationx_" + _i + ".isStatic = " + coperationx_.getisStatic());
    out.println("coperationx_" + _i + ".scope = \"" + coperationx_.getscope() + "\"");
    out.println("coperationx_" + _i + ".isQuery = " + coperationx_.getisQuery());
  }

  for (int _i = 0; _i < returnstatements.size(); _i++)
  { ReturnStatement returnstatementx_ = (ReturnStatement) returnstatements.get(_i);
    out.println("returnstatementx_" + _i + " : ReturnStatement");
    out.println("returnstatementx_" + _i + ".statId = \"" + returnstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < operations.size(); _i++)
  { Operation operationx_ = (Operation) operations.get(_i);
    out.println("operationx_" + _i + " : Operation");
    out.println("operationx_" + _i + ".isQuery = " + operationx_.getisQuery());
    out.println("operationx_" + _i + ".isCached = " + operationx_.getisCached());
    out.println("operationx_" + _i + ".isStatic = " + operationx_.getisStatic());
    out.println("operationx_" + _i + ".name = \"" + operationx_.getname() + "\"");
    out.println("operationx_" + _i + ".isStatic = " + operationx_.getisStatic());
  }

  for (int _i = 0; _i < usecases.size(); _i++)
  { UseCase usecasex_ = (UseCase) usecases.get(_i);
    out.println("usecasex_" + _i + " : UseCase");
    out.println("usecasex_" + _i + ".name = \"" + usecasex_.getname() + "\"");
  }

  for (int _i = 0; _i < breakstatements.size(); _i++)
  { BreakStatement breakstatementx_ = (BreakStatement) breakstatements.get(_i);
    out.println("breakstatementx_" + _i + " : BreakStatement");
    out.println("breakstatementx_" + _i + ".statId = \"" + breakstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < operationcallstatements.size(); _i++)
  { OperationCallStatement operationcallstatementx_ = (OperationCallStatement) operationcallstatements.get(_i);
    out.println("operationcallstatementx_" + _i + " : OperationCallStatement");
    out.println("operationcallstatementx_" + _i + ".assignsTo = \"" + operationcallstatementx_.getassignsTo() + "\"");
    out.println("operationcallstatementx_" + _i + ".statId = \"" + operationcallstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < implicitcallstatements.size(); _i++)
  { ImplicitCallStatement implicitcallstatementx_ = (ImplicitCallStatement) implicitcallstatements.get(_i);
    out.println("implicitcallstatementx_" + _i + " : ImplicitCallStatement");
    out.println("implicitcallstatementx_" + _i + ".assignsTo = \"" + implicitcallstatementx_.getassignsTo() + "\"");
    out.println("implicitcallstatementx_" + _i + ".statId = \"" + implicitcallstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < boundedloopstatements.size(); _i++)
  { BoundedLoopStatement boundedloopstatementx_ = (BoundedLoopStatement) boundedloopstatements.get(_i);
    out.println("boundedloopstatementx_" + _i + " : BoundedLoopStatement");
    out.println("boundedloopstatementx_" + _i + ".statId = \"" + boundedloopstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < unboundedloopstatements.size(); _i++)
  { UnboundedLoopStatement unboundedloopstatementx_ = (UnboundedLoopStatement) unboundedloopstatements.get(_i);
    out.println("unboundedloopstatementx_" + _i + " : UnboundedLoopStatement");
    out.println("unboundedloopstatementx_" + _i + ".statId = \"" + unboundedloopstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < assignstatements.size(); _i++)
  { AssignStatement assignstatementx_ = (AssignStatement) assignstatements.get(_i);
    out.println("assignstatementx_" + _i + " : AssignStatement");
    out.println("assignstatementx_" + _i + ".statId = \"" + assignstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < sequencestatements.size(); _i++)
  { SequenceStatement sequencestatementx_ = (SequenceStatement) sequencestatements.get(_i);
    out.println("sequencestatementx_" + _i + " : SequenceStatement");
    out.println("sequencestatementx_" + _i + ".kind = " + sequencestatementx_.getkind());
    out.println("sequencestatementx_" + _i + ".statId = \"" + sequencestatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < conditionalstatements.size(); _i++)
  { ConditionalStatement conditionalstatementx_ = (ConditionalStatement) conditionalstatements.get(_i);
    out.println("conditionalstatementx_" + _i + " : ConditionalStatement");
    out.println("conditionalstatementx_" + _i + ".statId = \"" + conditionalstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < creationstatements.size(); _i++)
  { CreationStatement creationstatementx_ = (CreationStatement) creationstatements.get(_i);
    out.println("creationstatementx_" + _i + " : CreationStatement");
    out.println("creationstatementx_" + _i + ".createsInstanceOf = \"" + creationstatementx_.getcreatesInstanceOf() + "\"");
    out.println("creationstatementx_" + _i + ".assignsTo = \"" + creationstatementx_.getassignsTo() + "\"");
    out.println("creationstatementx_" + _i + ".statId = \"" + creationstatementx_.getstatId() + "\"");
  }

  for (int _i = 0; _i < creturnstatements.size(); _i++)
  { CReturnStatement creturnstatementx_ = (CReturnStatement) creturnstatements.get(_i);
    out.println("creturnstatementx_" + _i + " : CReturnStatement");
    out.println("creturnstatementx_" + _i + ".cstatId = \"" + creturnstatementx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < cbreakstatements.size(); _i++)
  { CBreakStatement cbreakstatementx_ = (CBreakStatement) cbreakstatements.get(_i);
    out.println("cbreakstatementx_" + _i + " : CBreakStatement");
    out.println("cbreakstatementx_" + _i + ".cstatId = \"" + cbreakstatementx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < opcallstatements.size(); _i++)
  { OpCallStatement opcallstatementx_ = (OpCallStatement) opcallstatements.get(_i);
    out.println("opcallstatementx_" + _i + " : OpCallStatement");
    out.println("opcallstatementx_" + _i + ".assignsTo = \"" + opcallstatementx_.getassignsTo() + "\"");
    out.println("opcallstatementx_" + _i + ".cstatId = \"" + opcallstatementx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < forloops.size(); _i++)
  { ForLoop forloopx_ = (ForLoop) forloops.get(_i);
    out.println("forloopx_" + _i + " : ForLoop");
    out.println("forloopx_" + _i + ".cstatId = \"" + forloopx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < whileloops.size(); _i++)
  { WhileLoop whileloopx_ = (WhileLoop) whileloops.get(_i);
    out.println("whileloopx_" + _i + " : WhileLoop");
    out.println("whileloopx_" + _i + ".cstatId = \"" + whileloopx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < cassignments.size(); _i++)
  { CAssignment cassignmentx_ = (CAssignment) cassignments.get(_i);
    out.println("cassignmentx_" + _i + " : CAssignment");
    out.println("cassignmentx_" + _i + ".cstatId = \"" + cassignmentx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < csequencestatements.size(); _i++)
  { CSequenceStatement csequencestatementx_ = (CSequenceStatement) csequencestatements.get(_i);
    out.println("csequencestatementx_" + _i + " : CSequenceStatement");
    out.println("csequencestatementx_" + _i + ".kind = " + csequencestatementx_.getkind());
    out.println("csequencestatementx_" + _i + ".cstatId = \"" + csequencestatementx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < ifstatements.size(); _i++)
  { IfStatement ifstatementx_ = (IfStatement) ifstatements.get(_i);
    out.println("ifstatementx_" + _i + " : IfStatement");
    out.println("ifstatementx_" + _i + ".cstatId = \"" + ifstatementx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < declarationstatements.size(); _i++)
  { DeclarationStatement declarationstatementx_ = (DeclarationStatement) declarationstatements.get(_i);
    out.println("declarationstatementx_" + _i + " : DeclarationStatement");
    out.println("declarationstatementx_" + _i + ".createsInstanceOf = \"" + declarationstatementx_.getcreatesInstanceOf() + "\"");
    out.println("declarationstatementx_" + _i + ".assignsTo = \"" + declarationstatementx_.getassignsTo() + "\"");
    out.println("declarationstatementx_" + _i + ".cstatId = \"" + declarationstatementx_.getcstatId() + "\"");
  }

  for (int _i = 0; _i < printcodes.size(); _i++)
  { Printcode printcodex_ = (Printcode) printcodes.get(_i);
    out.println("printcodex_" + _i + " : Printcode");
  }

  for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
  { CBinaryExpression cbinaryexpressionx_ = (CBinaryExpression) cbinaryexpressions.get(_i);
    if (cbinaryexpressionx_.getleft() instanceof CUnaryExpression)
    { out.println("cbinaryexpressionx_" + _i + ".left = cunaryexpressionx_" + cunaryexpressions.indexOf(cbinaryexpressionx_.getleft())); } 
    if (cbinaryexpressionx_.getleft() instanceof CBasicExpression)
    { out.println("cbinaryexpressionx_" + _i + ".left = cbasicexpressionx_" + cbasicexpressions.indexOf(cbinaryexpressionx_.getleft())); } 
    if (cbinaryexpressionx_.getleft() instanceof CBinaryExpression)
    { out.println("cbinaryexpressionx_" + _i + ".left = cbinaryexpressionx_" + cbinaryexpressions.indexOf(cbinaryexpressionx_.getleft())); } 
    if (cbinaryexpressionx_.getright() instanceof CUnaryExpression)
    { out.println("cbinaryexpressionx_" + _i + ".right = cunaryexpressionx_" + cunaryexpressions.indexOf(cbinaryexpressionx_.getright())); } 
    if (cbinaryexpressionx_.getright() instanceof CBasicExpression)
    { out.println("cbinaryexpressionx_" + _i + ".right = cbasicexpressionx_" + cbasicexpressions.indexOf(cbinaryexpressionx_.getright())); } 
    if (cbinaryexpressionx_.getright() instanceof CBinaryExpression)
    { out.println("cbinaryexpressionx_" + _i + ".right = cbinaryexpressionx_" + cbinaryexpressions.indexOf(cbinaryexpressionx_.getright())); } 
    if (cbinaryexpressionx_.gettype() instanceof CFunctionPointerType)
    { out.println("cbinaryexpressionx_" + _i + ".type = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cbinaryexpressionx_.gettype())); } 
    if (cbinaryexpressionx_.gettype() instanceof CStruct)
    { out.println("cbinaryexpressionx_" + _i + ".type = cstructx_" + cstructs.indexOf(cbinaryexpressionx_.gettype())); } 
    if (cbinaryexpressionx_.gettype() instanceof CPrimitiveType)
    { out.println("cbinaryexpressionx_" + _i + ".type = cprimitivetypex_" + cprimitivetypes.indexOf(cbinaryexpressionx_.gettype())); } 
    if (cbinaryexpressionx_.gettype() instanceof CPointerType)
    { out.println("cbinaryexpressionx_" + _i + ".type = cpointertypex_" + cpointertypes.indexOf(cbinaryexpressionx_.gettype())); } 
    if (cbinaryexpressionx_.gettype() instanceof CArrayType)
    { out.println("cbinaryexpressionx_" + _i + ".type = carraytypex_" + carraytypes.indexOf(cbinaryexpressionx_.gettype())); } 
    if (cbinaryexpressionx_.getelementType() instanceof CFunctionPointerType)
    { out.println("cbinaryexpressionx_" + _i + ".elementType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cbinaryexpressionx_.getelementType())); } 
    if (cbinaryexpressionx_.getelementType() instanceof CStruct)
    { out.println("cbinaryexpressionx_" + _i + ".elementType = cstructx_" + cstructs.indexOf(cbinaryexpressionx_.getelementType())); } 
    if (cbinaryexpressionx_.getelementType() instanceof CPrimitiveType)
    { out.println("cbinaryexpressionx_" + _i + ".elementType = cprimitivetypex_" + cprimitivetypes.indexOf(cbinaryexpressionx_.getelementType())); } 
    if (cbinaryexpressionx_.getelementType() instanceof CPointerType)
    { out.println("cbinaryexpressionx_" + _i + ".elementType = cpointertypex_" + cpointertypes.indexOf(cbinaryexpressionx_.getelementType())); } 
    if (cbinaryexpressionx_.getelementType() instanceof CArrayType)
    { out.println("cbinaryexpressionx_" + _i + ".elementType = carraytypex_" + carraytypes.indexOf(cbinaryexpressionx_.getelementType())); } 
  }
  for (int _i = 0; _i < cunaryexpressions.size(); _i++)
  { CUnaryExpression cunaryexpressionx_ = (CUnaryExpression) cunaryexpressions.get(_i);
    if (cunaryexpressionx_.getargument() instanceof CUnaryExpression)
    { out.println("cunaryexpressionx_" + _i + ".argument = cunaryexpressionx_" + cunaryexpressions.indexOf(cunaryexpressionx_.getargument())); } 
    if (cunaryexpressionx_.getargument() instanceof CBasicExpression)
    { out.println("cunaryexpressionx_" + _i + ".argument = cbasicexpressionx_" + cbasicexpressions.indexOf(cunaryexpressionx_.getargument())); } 
    if (cunaryexpressionx_.getargument() instanceof CBinaryExpression)
    { out.println("cunaryexpressionx_" + _i + ".argument = cbinaryexpressionx_" + cbinaryexpressions.indexOf(cunaryexpressionx_.getargument())); } 
    if (cunaryexpressionx_.gettype() instanceof CFunctionPointerType)
    { out.println("cunaryexpressionx_" + _i + ".type = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cunaryexpressionx_.gettype())); } 
    if (cunaryexpressionx_.gettype() instanceof CStruct)
    { out.println("cunaryexpressionx_" + _i + ".type = cstructx_" + cstructs.indexOf(cunaryexpressionx_.gettype())); } 
    if (cunaryexpressionx_.gettype() instanceof CPrimitiveType)
    { out.println("cunaryexpressionx_" + _i + ".type = cprimitivetypex_" + cprimitivetypes.indexOf(cunaryexpressionx_.gettype())); } 
    if (cunaryexpressionx_.gettype() instanceof CPointerType)
    { out.println("cunaryexpressionx_" + _i + ".type = cpointertypex_" + cpointertypes.indexOf(cunaryexpressionx_.gettype())); } 
    if (cunaryexpressionx_.gettype() instanceof CArrayType)
    { out.println("cunaryexpressionx_" + _i + ".type = carraytypex_" + carraytypes.indexOf(cunaryexpressionx_.gettype())); } 
    if (cunaryexpressionx_.getelementType() instanceof CFunctionPointerType)
    { out.println("cunaryexpressionx_" + _i + ".elementType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cunaryexpressionx_.getelementType())); } 
    if (cunaryexpressionx_.getelementType() instanceof CStruct)
    { out.println("cunaryexpressionx_" + _i + ".elementType = cstructx_" + cstructs.indexOf(cunaryexpressionx_.getelementType())); } 
    if (cunaryexpressionx_.getelementType() instanceof CPrimitiveType)
    { out.println("cunaryexpressionx_" + _i + ".elementType = cprimitivetypex_" + cprimitivetypes.indexOf(cunaryexpressionx_.getelementType())); } 
    if (cunaryexpressionx_.getelementType() instanceof CPointerType)
    { out.println("cunaryexpressionx_" + _i + ".elementType = cpointertypex_" + cpointertypes.indexOf(cunaryexpressionx_.getelementType())); } 
    if (cunaryexpressionx_.getelementType() instanceof CArrayType)
    { out.println("cunaryexpressionx_" + _i + ".elementType = carraytypex_" + carraytypes.indexOf(cunaryexpressionx_.getelementType())); } 
  }
  for (int _i = 0; _i < cbasicexpressions.size(); _i++)
  { CBasicExpression cbasicexpressionx_ = (CBasicExpression) cbasicexpressions.get(_i);
    List cbasicexpression_parameters_CExpression = cbasicexpressionx_.getparameters();
    for (int _k = 0; _k < cbasicexpression_parameters_CExpression.size(); _k++)
    { if (cbasicexpression_parameters_CExpression.get(_k) instanceof CUnaryExpression)
      { out.println("cunaryexpressionx_" + cunaryexpressions.indexOf(cbasicexpression_parameters_CExpression.get(_k)) + " : cbasicexpressionx_" + _i + ".parameters"); }
 if (cbasicexpression_parameters_CExpression.get(_k) instanceof CBasicExpression)
      { out.println("cbasicexpressionx_" + cbasicexpressions.indexOf(cbasicexpression_parameters_CExpression.get(_k)) + " : cbasicexpressionx_" + _i + ".parameters"); }
 if (cbasicexpression_parameters_CExpression.get(_k) instanceof CBinaryExpression)
      { out.println("cbinaryexpressionx_" + cbinaryexpressions.indexOf(cbasicexpression_parameters_CExpression.get(_k)) + " : cbasicexpressionx_" + _i + ".parameters"); }
  }
    List cbasicexpression_arrayIndex_CBasicExpression = cbasicexpressionx_.getarrayIndex();
    for (int _j = 0; _j < cbasicexpression_arrayIndex_CBasicExpression.size(); _j++)
    { out.println("cbasicexpressionx_" + cbasicexpressions.indexOf(cbasicexpression_arrayIndex_CBasicExpression.get(_j)) + " : cbasicexpressionx_" + _i + ".arrayIndex");
    }
    List cbasicexpression_reference_CBasicExpression = cbasicexpressionx_.getreference();
    for (int _j = 0; _j < cbasicexpression_reference_CBasicExpression.size(); _j++)
    { out.println("cbasicexpressionx_" + cbasicexpressions.indexOf(cbasicexpression_reference_CBasicExpression.get(_j)) + " : cbasicexpressionx_" + _i + ".reference");
    }
    if (cbasicexpressionx_.gettype() instanceof CFunctionPointerType)
    { out.println("cbasicexpressionx_" + _i + ".type = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cbasicexpressionx_.gettype())); } 
    if (cbasicexpressionx_.gettype() instanceof CStruct)
    { out.println("cbasicexpressionx_" + _i + ".type = cstructx_" + cstructs.indexOf(cbasicexpressionx_.gettype())); } 
    if (cbasicexpressionx_.gettype() instanceof CPrimitiveType)
    { out.println("cbasicexpressionx_" + _i + ".type = cprimitivetypex_" + cprimitivetypes.indexOf(cbasicexpressionx_.gettype())); } 
    if (cbasicexpressionx_.gettype() instanceof CPointerType)
    { out.println("cbasicexpressionx_" + _i + ".type = cpointertypex_" + cpointertypes.indexOf(cbasicexpressionx_.gettype())); } 
    if (cbasicexpressionx_.gettype() instanceof CArrayType)
    { out.println("cbasicexpressionx_" + _i + ".type = carraytypex_" + carraytypes.indexOf(cbasicexpressionx_.gettype())); } 
    if (cbasicexpressionx_.getelementType() instanceof CFunctionPointerType)
    { out.println("cbasicexpressionx_" + _i + ".elementType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cbasicexpressionx_.getelementType())); } 
    if (cbasicexpressionx_.getelementType() instanceof CStruct)
    { out.println("cbasicexpressionx_" + _i + ".elementType = cstructx_" + cstructs.indexOf(cbasicexpressionx_.getelementType())); } 
    if (cbasicexpressionx_.getelementType() instanceof CPrimitiveType)
    { out.println("cbasicexpressionx_" + _i + ".elementType = cprimitivetypex_" + cprimitivetypes.indexOf(cbasicexpressionx_.getelementType())); } 
    if (cbasicexpressionx_.getelementType() instanceof CPointerType)
    { out.println("cbasicexpressionx_" + _i + ".elementType = cpointertypex_" + cpointertypes.indexOf(cbasicexpressionx_.getelementType())); } 
    if (cbasicexpressionx_.getelementType() instanceof CArrayType)
    { out.println("cbasicexpressionx_" + _i + ".elementType = carraytypex_" + carraytypes.indexOf(cbasicexpressionx_.getelementType())); } 
  }
  for (int _i = 0; _i < entitys.size(); _i++)
  { Entity entityx_ = (Entity) entitys.get(_i);
    List entity_ownedOperation_Operation = entityx_.getownedOperation();
    for (int _j = 0; _j < entity_ownedOperation_Operation.size(); _j++)
    { out.println("operationx_" + operations.indexOf(entity_ownedOperation_Operation.get(_j)) + " : entityx_" + _i + ".ownedOperation");
    }
    List entity_ownedAttribute_Property = entityx_.getownedAttribute();
    for (int _j = 0; _j < entity_ownedAttribute_Property.size(); _j++)
    { out.println("propertyx_" + propertys.indexOf(entity_ownedAttribute_Property.get(_j)) + " : entityx_" + _i + ".ownedAttribute");
    }
  }
  for (int _i = 0; _i < collectiontypes.size(); _i++)
  { CollectionType collectiontypex_ = (CollectionType) collectiontypes.get(_i);
    if (collectiontypex_.getelementType() instanceof Entity)
    { out.println("collectiontypex_" + _i + ".elementType = entityx_" + entitys.indexOf(collectiontypex_.getelementType())); } 
    if (collectiontypex_.getelementType() instanceof PrimitiveType)
    { out.println("collectiontypex_" + _i + ".elementType = primitivetypex_" + primitivetypes.indexOf(collectiontypex_.getelementType())); } 
    if (collectiontypex_.getelementType() instanceof CollectionType)
    { out.println("collectiontypex_" + _i + ".elementType = collectiontypex_" + collectiontypes.indexOf(collectiontypex_.getelementType())); } 
    if (collectiontypex_.getkeyType() instanceof Entity)
    { out.println("collectiontypex_" + _i + ".keyType = entityx_" + entitys.indexOf(collectiontypex_.getkeyType())); } 
    if (collectiontypex_.getkeyType() instanceof PrimitiveType)
    { out.println("collectiontypex_" + _i + ".keyType = primitivetypex_" + primitivetypes.indexOf(collectiontypex_.getkeyType())); } 
    if (collectiontypex_.getkeyType() instanceof CollectionType)
    { out.println("collectiontypex_" + _i + ".keyType = collectiontypex_" + collectiontypes.indexOf(collectiontypex_.getkeyType())); } 
  }
  for (int _i = 0; _i < binaryexpressions.size(); _i++)
  { BinaryExpression binaryexpressionx_ = (BinaryExpression) binaryexpressions.get(_i);
    if (binaryexpressionx_.getleft() instanceof UnaryExpression)
    { out.println("binaryexpressionx_" + _i + ".left = unaryexpressionx_" + unaryexpressions.indexOf(binaryexpressionx_.getleft())); } 
    if (binaryexpressionx_.getleft() instanceof BasicExpression)
    { out.println("binaryexpressionx_" + _i + ".left = basicexpressionx_" + basicexpressions.indexOf(binaryexpressionx_.getleft())); } 
    if (binaryexpressionx_.getleft() instanceof BinaryExpression)
    { out.println("binaryexpressionx_" + _i + ".left = binaryexpressionx_" + binaryexpressions.indexOf(binaryexpressionx_.getleft())); } 
    if (binaryexpressionx_.getleft() instanceof CollectionExpression)
    { out.println("binaryexpressionx_" + _i + ".left = collectionexpressionx_" + collectionexpressions.indexOf(binaryexpressionx_.getleft())); } 
    if (binaryexpressionx_.getright() instanceof UnaryExpression)
    { out.println("binaryexpressionx_" + _i + ".right = unaryexpressionx_" + unaryexpressions.indexOf(binaryexpressionx_.getright())); } 
    if (binaryexpressionx_.getright() instanceof BasicExpression)
    { out.println("binaryexpressionx_" + _i + ".right = basicexpressionx_" + basicexpressions.indexOf(binaryexpressionx_.getright())); } 
    if (binaryexpressionx_.getright() instanceof BinaryExpression)
    { out.println("binaryexpressionx_" + _i + ".right = binaryexpressionx_" + binaryexpressions.indexOf(binaryexpressionx_.getright())); } 
    if (binaryexpressionx_.getright() instanceof CollectionExpression)
    { out.println("binaryexpressionx_" + _i + ".right = collectionexpressionx_" + collectionexpressions.indexOf(binaryexpressionx_.getright())); } 
    if (binaryexpressionx_.gettype() instanceof Entity)
    { out.println("binaryexpressionx_" + _i + ".type = entityx_" + entitys.indexOf(binaryexpressionx_.gettype())); } 
    if (binaryexpressionx_.gettype() instanceof PrimitiveType)
    { out.println("binaryexpressionx_" + _i + ".type = primitivetypex_" + primitivetypes.indexOf(binaryexpressionx_.gettype())); } 
    if (binaryexpressionx_.gettype() instanceof CollectionType)
    { out.println("binaryexpressionx_" + _i + ".type = collectiontypex_" + collectiontypes.indexOf(binaryexpressionx_.gettype())); } 
    if (binaryexpressionx_.getelementType() instanceof Entity)
    { out.println("binaryexpressionx_" + _i + ".elementType = entityx_" + entitys.indexOf(binaryexpressionx_.getelementType())); } 
    if (binaryexpressionx_.getelementType() instanceof PrimitiveType)
    { out.println("binaryexpressionx_" + _i + ".elementType = primitivetypex_" + primitivetypes.indexOf(binaryexpressionx_.getelementType())); } 
    if (binaryexpressionx_.getelementType() instanceof CollectionType)
    { out.println("binaryexpressionx_" + _i + ".elementType = collectiontypex_" + collectiontypes.indexOf(binaryexpressionx_.getelementType())); } 
  }
  for (int _i = 0; _i < unaryexpressions.size(); _i++)
  { UnaryExpression unaryexpressionx_ = (UnaryExpression) unaryexpressions.get(_i);
    if (unaryexpressionx_.getargument() instanceof UnaryExpression)
    { out.println("unaryexpressionx_" + _i + ".argument = unaryexpressionx_" + unaryexpressions.indexOf(unaryexpressionx_.getargument())); } 
    if (unaryexpressionx_.getargument() instanceof BasicExpression)
    { out.println("unaryexpressionx_" + _i + ".argument = basicexpressionx_" + basicexpressions.indexOf(unaryexpressionx_.getargument())); } 
    if (unaryexpressionx_.getargument() instanceof BinaryExpression)
    { out.println("unaryexpressionx_" + _i + ".argument = binaryexpressionx_" + binaryexpressions.indexOf(unaryexpressionx_.getargument())); } 
    if (unaryexpressionx_.getargument() instanceof CollectionExpression)
    { out.println("unaryexpressionx_" + _i + ".argument = collectionexpressionx_" + collectionexpressions.indexOf(unaryexpressionx_.getargument())); } 
    if (unaryexpressionx_.gettype() instanceof Entity)
    { out.println("unaryexpressionx_" + _i + ".type = entityx_" + entitys.indexOf(unaryexpressionx_.gettype())); } 
    if (unaryexpressionx_.gettype() instanceof PrimitiveType)
    { out.println("unaryexpressionx_" + _i + ".type = primitivetypex_" + primitivetypes.indexOf(unaryexpressionx_.gettype())); } 
    if (unaryexpressionx_.gettype() instanceof CollectionType)
    { out.println("unaryexpressionx_" + _i + ".type = collectiontypex_" + collectiontypes.indexOf(unaryexpressionx_.gettype())); } 
    if (unaryexpressionx_.getelementType() instanceof Entity)
    { out.println("unaryexpressionx_" + _i + ".elementType = entityx_" + entitys.indexOf(unaryexpressionx_.getelementType())); } 
    if (unaryexpressionx_.getelementType() instanceof PrimitiveType)
    { out.println("unaryexpressionx_" + _i + ".elementType = primitivetypex_" + primitivetypes.indexOf(unaryexpressionx_.getelementType())); } 
    if (unaryexpressionx_.getelementType() instanceof CollectionType)
    { out.println("unaryexpressionx_" + _i + ".elementType = collectiontypex_" + collectiontypes.indexOf(unaryexpressionx_.getelementType())); } 
  }
  for (int _i = 0; _i < collectionexpressions.size(); _i++)
  { CollectionExpression collectionexpressionx_ = (CollectionExpression) collectionexpressions.get(_i);
    List collectionexpression_elements_Expression = collectionexpressionx_.getelements();
    for (int _k = 0; _k < collectionexpression_elements_Expression.size(); _k++)
    { if (collectionexpression_elements_Expression.get(_k) instanceof UnaryExpression)
      { out.println("unaryexpressionx_" + unaryexpressions.indexOf(collectionexpression_elements_Expression.get(_k)) + " : collectionexpressionx_" + _i + ".elements"); }
 if (collectionexpression_elements_Expression.get(_k) instanceof BasicExpression)
      { out.println("basicexpressionx_" + basicexpressions.indexOf(collectionexpression_elements_Expression.get(_k)) + " : collectionexpressionx_" + _i + ".elements"); }
 if (collectionexpression_elements_Expression.get(_k) instanceof BinaryExpression)
      { out.println("binaryexpressionx_" + binaryexpressions.indexOf(collectionexpression_elements_Expression.get(_k)) + " : collectionexpressionx_" + _i + ".elements"); }
 if (collectionexpression_elements_Expression.get(_k) instanceof CollectionExpression)
      { out.println("collectionexpressionx_" + collectionexpressions.indexOf(collectionexpression_elements_Expression.get(_k)) + " : collectionexpressionx_" + _i + ".elements"); }
  }
    if (collectionexpressionx_.gettype() instanceof Entity)
    { out.println("collectionexpressionx_" + _i + ".type = entityx_" + entitys.indexOf(collectionexpressionx_.gettype())); } 
    if (collectionexpressionx_.gettype() instanceof PrimitiveType)
    { out.println("collectionexpressionx_" + _i + ".type = primitivetypex_" + primitivetypes.indexOf(collectionexpressionx_.gettype())); } 
    if (collectionexpressionx_.gettype() instanceof CollectionType)
    { out.println("collectionexpressionx_" + _i + ".type = collectiontypex_" + collectiontypes.indexOf(collectionexpressionx_.gettype())); } 
    if (collectionexpressionx_.getelementType() instanceof Entity)
    { out.println("collectionexpressionx_" + _i + ".elementType = entityx_" + entitys.indexOf(collectionexpressionx_.getelementType())); } 
    if (collectionexpressionx_.getelementType() instanceof PrimitiveType)
    { out.println("collectionexpressionx_" + _i + ".elementType = primitivetypex_" + primitivetypes.indexOf(collectionexpressionx_.getelementType())); } 
    if (collectionexpressionx_.getelementType() instanceof CollectionType)
    { out.println("collectionexpressionx_" + _i + ".elementType = collectiontypex_" + collectiontypes.indexOf(collectionexpressionx_.getelementType())); } 
  }
  for (int _i = 0; _i < basicexpressions.size(); _i++)
  { BasicExpression basicexpressionx_ = (BasicExpression) basicexpressions.get(_i);
    List basicexpression_parameters_Expression = basicexpressionx_.getparameters();
    for (int _k = 0; _k < basicexpression_parameters_Expression.size(); _k++)
    { if (basicexpression_parameters_Expression.get(_k) instanceof UnaryExpression)
      { out.println("unaryexpressionx_" + unaryexpressions.indexOf(basicexpression_parameters_Expression.get(_k)) + " : basicexpressionx_" + _i + ".parameters"); }
 if (basicexpression_parameters_Expression.get(_k) instanceof BasicExpression)
      { out.println("basicexpressionx_" + basicexpressions.indexOf(basicexpression_parameters_Expression.get(_k)) + " : basicexpressionx_" + _i + ".parameters"); }
 if (basicexpression_parameters_Expression.get(_k) instanceof BinaryExpression)
      { out.println("binaryexpressionx_" + binaryexpressions.indexOf(basicexpression_parameters_Expression.get(_k)) + " : basicexpressionx_" + _i + ".parameters"); }
 if (basicexpression_parameters_Expression.get(_k) instanceof CollectionExpression)
      { out.println("collectionexpressionx_" + collectionexpressions.indexOf(basicexpression_parameters_Expression.get(_k)) + " : basicexpressionx_" + _i + ".parameters"); }
  }
    List basicexpression_referredProperty_Property = basicexpressionx_.getreferredProperty();
    for (int _j = 0; _j < basicexpression_referredProperty_Property.size(); _j++)
    { out.println("propertyx_" + propertys.indexOf(basicexpression_referredProperty_Property.get(_j)) + " : basicexpressionx_" + _i + ".referredProperty");
    }
    List basicexpression_context_Entity = basicexpressionx_.getcontext();
    for (int _j = 0; _j < basicexpression_context_Entity.size(); _j++)
    { out.println("entityx_" + entitys.indexOf(basicexpression_context_Entity.get(_j)) + " : basicexpressionx_" + _i + ".context");
    }
    List basicexpression_arrayIndex_BasicExpression = basicexpressionx_.getarrayIndex();
    for (int _j = 0; _j < basicexpression_arrayIndex_BasicExpression.size(); _j++)
    { out.println("basicexpressionx_" + basicexpressions.indexOf(basicexpression_arrayIndex_BasicExpression.get(_j)) + " : basicexpressionx_" + _i + ".arrayIndex");
    }
    List basicexpression_objectRef_BasicExpression = basicexpressionx_.getobjectRef();
    for (int _j = 0; _j < basicexpression_objectRef_BasicExpression.size(); _j++)
    { out.println("basicexpressionx_" + basicexpressions.indexOf(basicexpression_objectRef_BasicExpression.get(_j)) + " : basicexpressionx_" + _i + ".objectRef");
    }
    if (basicexpressionx_.gettype() instanceof Entity)
    { out.println("basicexpressionx_" + _i + ".type = entityx_" + entitys.indexOf(basicexpressionx_.gettype())); } 
    if (basicexpressionx_.gettype() instanceof PrimitiveType)
    { out.println("basicexpressionx_" + _i + ".type = primitivetypex_" + primitivetypes.indexOf(basicexpressionx_.gettype())); } 
    if (basicexpressionx_.gettype() instanceof CollectionType)
    { out.println("basicexpressionx_" + _i + ".type = collectiontypex_" + collectiontypes.indexOf(basicexpressionx_.gettype())); } 
    if (basicexpressionx_.getelementType() instanceof Entity)
    { out.println("basicexpressionx_" + _i + ".elementType = entityx_" + entitys.indexOf(basicexpressionx_.getelementType())); } 
    if (basicexpressionx_.getelementType() instanceof PrimitiveType)
    { out.println("basicexpressionx_" + _i + ".elementType = primitivetypex_" + primitivetypes.indexOf(basicexpressionx_.getelementType())); } 
    if (basicexpressionx_.getelementType() instanceof CollectionType)
    { out.println("basicexpressionx_" + _i + ".elementType = collectiontypex_" + collectiontypes.indexOf(basicexpressionx_.getelementType())); } 
  }
  for (int _i = 0; _i < propertys.size(); _i++)
  { Property propertyx_ = (Property) propertys.get(_i);
    if (propertyx_.gettype() instanceof Entity)
    { out.println("propertyx_" + _i + ".type = entityx_" + entitys.indexOf(propertyx_.gettype())); } 
    if (propertyx_.gettype() instanceof PrimitiveType)
    { out.println("propertyx_" + _i + ".type = primitivetypex_" + primitivetypes.indexOf(propertyx_.gettype())); } 
    if (propertyx_.gettype() instanceof CollectionType)
    { out.println("propertyx_" + _i + ".type = collectiontypex_" + collectiontypes.indexOf(propertyx_.gettype())); } 
    if (propertyx_.getinitialValue() instanceof UnaryExpression)
    { out.println("propertyx_" + _i + ".initialValue = unaryexpressionx_" + unaryexpressions.indexOf(propertyx_.getinitialValue())); } 
    if (propertyx_.getinitialValue() instanceof BasicExpression)
    { out.println("propertyx_" + _i + ".initialValue = basicexpressionx_" + basicexpressions.indexOf(propertyx_.getinitialValue())); } 
    if (propertyx_.getinitialValue() instanceof BinaryExpression)
    { out.println("propertyx_" + _i + ".initialValue = binaryexpressionx_" + binaryexpressions.indexOf(propertyx_.getinitialValue())); } 
    if (propertyx_.getinitialValue() instanceof CollectionExpression)
    { out.println("propertyx_" + _i + ".initialValue = collectionexpressionx_" + collectionexpressions.indexOf(propertyx_.getinitialValue())); } 
    out.println("propertyx_" + _i + ".owner = entityx_" + entitys.indexOf(((Property) propertys.get(_i)).getowner()));
  }
  for (int _i = 0; _i < carraytypes.size(); _i++)
  { CArrayType carraytypex_ = (CArrayType) carraytypes.get(_i);
    if (carraytypex_.getcomponentType() instanceof CFunctionPointerType)
    { out.println("carraytypex_" + _i + ".componentType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(carraytypex_.getcomponentType())); } 
    if (carraytypex_.getcomponentType() instanceof CStruct)
    { out.println("carraytypex_" + _i + ".componentType = cstructx_" + cstructs.indexOf(carraytypex_.getcomponentType())); } 
    if (carraytypex_.getcomponentType() instanceof CPrimitiveType)
    { out.println("carraytypex_" + _i + ".componentType = cprimitivetypex_" + cprimitivetypes.indexOf(carraytypex_.getcomponentType())); } 
    if (carraytypex_.getcomponentType() instanceof CPointerType)
    { out.println("carraytypex_" + _i + ".componentType = cpointertypex_" + cpointertypes.indexOf(carraytypex_.getcomponentType())); } 
    if (carraytypex_.getcomponentType() instanceof CArrayType)
    { out.println("carraytypex_" + _i + ".componentType = carraytypex_" + carraytypes.indexOf(carraytypex_.getcomponentType())); } 
  }
  for (int _i = 0; _i < cpointertypes.size(); _i++)
  { CPointerType cpointertypex_ = (CPointerType) cpointertypes.get(_i);
    if (cpointertypex_.getpointsTo() instanceof CFunctionPointerType)
    { out.println("cpointertypex_" + _i + ".pointsTo = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cpointertypex_.getpointsTo())); } 
    if (cpointertypex_.getpointsTo() instanceof CStruct)
    { out.println("cpointertypex_" + _i + ".pointsTo = cstructx_" + cstructs.indexOf(cpointertypex_.getpointsTo())); } 
    if (cpointertypex_.getpointsTo() instanceof CPrimitiveType)
    { out.println("cpointertypex_" + _i + ".pointsTo = cprimitivetypex_" + cprimitivetypes.indexOf(cpointertypex_.getpointsTo())); } 
    if (cpointertypex_.getpointsTo() instanceof CPointerType)
    { out.println("cpointertypex_" + _i + ".pointsTo = cpointertypex_" + cpointertypes.indexOf(cpointertypex_.getpointsTo())); } 
    if (cpointertypex_.getpointsTo() instanceof CArrayType)
    { out.println("cpointertypex_" + _i + ".pointsTo = carraytypex_" + carraytypes.indexOf(cpointertypex_.getpointsTo())); } 
  }
  for (int _i = 0; _i < cstructs.size(); _i++)
  { CStruct cstructx_ = (CStruct) cstructs.get(_i);
    List cstruct_members_CMember = cstructx_.getmembers();
    for (int _j = 0; _j < cstruct_members_CMember.size(); _j++)
    { out.println("cmemberx_" + cmembers.indexOf(cstruct_members_CMember.get(_j)) + " : cstructx_" + _i + ".members");
    }
    List cstruct_allMembers_CMember = cstructx_.getallMembers();
    for (int _j = 0; _j < cstruct_allMembers_CMember.size(); _j++)
    { out.println("cmemberx_" + cmembers.indexOf(cstruct_allMembers_CMember.get(_j)) + " : cstructx_" + _i + ".allMembers");
    }
  }
  for (int _i = 0; _i < cmembers.size(); _i++)
  { CMember cmemberx_ = (CMember) cmembers.get(_i);
    if (cmemberx_.gettype() instanceof CFunctionPointerType)
    { out.println("cmemberx_" + _i + ".type = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cmemberx_.gettype())); } 
    if (cmemberx_.gettype() instanceof CStruct)
    { out.println("cmemberx_" + _i + ".type = cstructx_" + cstructs.indexOf(cmemberx_.gettype())); } 
    if (cmemberx_.gettype() instanceof CPrimitiveType)
    { out.println("cmemberx_" + _i + ".type = cprimitivetypex_" + cprimitivetypes.indexOf(cmemberx_.gettype())); } 
    if (cmemberx_.gettype() instanceof CPointerType)
    { out.println("cmemberx_" + _i + ".type = cpointertypex_" + cpointertypes.indexOf(cmemberx_.gettype())); } 
    if (cmemberx_.gettype() instanceof CArrayType)
    { out.println("cmemberx_" + _i + ".type = carraytypex_" + carraytypes.indexOf(cmemberx_.gettype())); } 
  }
  for (int _i = 0; _i < cvariables.size(); _i++)
  { CVariable cvariablex_ = (CVariable) cvariables.get(_i);
    if (cvariablex_.gettype() instanceof CFunctionPointerType)
    { out.println("cvariablex_" + _i + ".type = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cvariablex_.gettype())); } 
    if (cvariablex_.gettype() instanceof CStruct)
    { out.println("cvariablex_" + _i + ".type = cstructx_" + cstructs.indexOf(cvariablex_.gettype())); } 
    if (cvariablex_.gettype() instanceof CPrimitiveType)
    { out.println("cvariablex_" + _i + ".type = cprimitivetypex_" + cprimitivetypes.indexOf(cvariablex_.gettype())); } 
    if (cvariablex_.gettype() instanceof CPointerType)
    { out.println("cvariablex_" + _i + ".type = cpointertypex_" + cpointertypes.indexOf(cvariablex_.gettype())); } 
    if (cvariablex_.gettype() instanceof CArrayType)
    { out.println("cvariablex_" + _i + ".type = carraytypex_" + carraytypes.indexOf(cvariablex_.gettype())); } 
  }
  for (int _i = 0; _i < cprograms.size(); _i++)
  { CProgram cprogramx_ = (CProgram) cprograms.get(_i);
    List cprogram_operations_COperation = cprogramx_.getoperations();
    for (int _j = 0; _j < cprogram_operations_COperation.size(); _j++)
    { out.println("coperationx_" + coperations.indexOf(cprogram_operations_COperation.get(_j)) + " : cprogramx_" + _i + ".operations");
    }
    List cprogram_variables_CVariable = cprogramx_.getvariables();
    for (int _j = 0; _j < cprogram_variables_CVariable.size(); _j++)
    { out.println("cvariablex_" + cvariables.indexOf(cprogram_variables_CVariable.get(_j)) + " : cprogramx_" + _i + ".variables");
    }
    List cprogram_structs_CStruct = cprogramx_.getstructs();
    for (int _j = 0; _j < cprogram_structs_CStruct.size(); _j++)
    { out.println("cstructx_" + cstructs.indexOf(cprogram_structs_CStruct.get(_j)) + " : cprogramx_" + _i + ".structs");
    }
  }
  for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
  { CFunctionPointerType cfunctionpointertypex_ = (CFunctionPointerType) cfunctionpointertypes.get(_i);
    if (cfunctionpointertypex_.getdomainType() instanceof CFunctionPointerType)
    { out.println("cfunctionpointertypex_" + _i + ".domainType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cfunctionpointertypex_.getdomainType())); } 
    if (cfunctionpointertypex_.getdomainType() instanceof CStruct)
    { out.println("cfunctionpointertypex_" + _i + ".domainType = cstructx_" + cstructs.indexOf(cfunctionpointertypex_.getdomainType())); } 
    if (cfunctionpointertypex_.getdomainType() instanceof CPrimitiveType)
    { out.println("cfunctionpointertypex_" + _i + ".domainType = cprimitivetypex_" + cprimitivetypes.indexOf(cfunctionpointertypex_.getdomainType())); } 
    if (cfunctionpointertypex_.getdomainType() instanceof CPointerType)
    { out.println("cfunctionpointertypex_" + _i + ".domainType = cpointertypex_" + cpointertypes.indexOf(cfunctionpointertypex_.getdomainType())); } 
    if (cfunctionpointertypex_.getdomainType() instanceof CArrayType)
    { out.println("cfunctionpointertypex_" + _i + ".domainType = carraytypex_" + carraytypes.indexOf(cfunctionpointertypex_.getdomainType())); } 
    if (cfunctionpointertypex_.getrangeType() instanceof CFunctionPointerType)
    { out.println("cfunctionpointertypex_" + _i + ".rangeType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cfunctionpointertypex_.getrangeType())); } 
    if (cfunctionpointertypex_.getrangeType() instanceof CStruct)
    { out.println("cfunctionpointertypex_" + _i + ".rangeType = cstructx_" + cstructs.indexOf(cfunctionpointertypex_.getrangeType())); } 
    if (cfunctionpointertypex_.getrangeType() instanceof CPrimitiveType)
    { out.println("cfunctionpointertypex_" + _i + ".rangeType = cprimitivetypex_" + cprimitivetypes.indexOf(cfunctionpointertypex_.getrangeType())); } 
    if (cfunctionpointertypex_.getrangeType() instanceof CPointerType)
    { out.println("cfunctionpointertypex_" + _i + ".rangeType = cpointertypex_" + cpointertypes.indexOf(cfunctionpointertypex_.getrangeType())); } 
    if (cfunctionpointertypex_.getrangeType() instanceof CArrayType)
    { out.println("cfunctionpointertypex_" + _i + ".rangeType = carraytypex_" + carraytypes.indexOf(cfunctionpointertypex_.getrangeType())); } 
  }
  for (int _i = 0; _i < coperations.size(); _i++)
  { COperation coperationx_ = (COperation) coperations.get(_i);
    List coperation_parameters_CVariable = coperationx_.getparameters();
    for (int _j = 0; _j < coperation_parameters_CVariable.size(); _j++)
    { out.println("cvariablex_" + cvariables.indexOf(coperation_parameters_CVariable.get(_j)) + " : coperationx_" + _i + ".parameters");
    }
    if (coperationx_.getreturnType() instanceof CFunctionPointerType)
    { out.println("coperationx_" + _i + ".returnType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(coperationx_.getreturnType())); } 
    if (coperationx_.getreturnType() instanceof CStruct)
    { out.println("coperationx_" + _i + ".returnType = cstructx_" + cstructs.indexOf(coperationx_.getreturnType())); } 
    if (coperationx_.getreturnType() instanceof CPrimitiveType)
    { out.println("coperationx_" + _i + ".returnType = cprimitivetypex_" + cprimitivetypes.indexOf(coperationx_.getreturnType())); } 
    if (coperationx_.getreturnType() instanceof CPointerType)
    { out.println("coperationx_" + _i + ".returnType = cpointertypex_" + cpointertypes.indexOf(coperationx_.getreturnType())); } 
    if (coperationx_.getreturnType() instanceof CArrayType)
    { out.println("coperationx_" + _i + ".returnType = carraytypex_" + carraytypes.indexOf(coperationx_.getreturnType())); } 
    if (coperationx_.getcode() instanceof CReturnStatement)
    { out.println("coperationx_" + _i + ".code = creturnstatementx_" + creturnstatements.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof CBreakStatement)
    { out.println("coperationx_" + _i + ".code = cbreakstatementx_" + cbreakstatements.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof OpCallStatement)
    { out.println("coperationx_" + _i + ".code = opcallstatementx_" + opcallstatements.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof CSequenceStatement)
    { out.println("coperationx_" + _i + ".code = csequencestatementx_" + csequencestatements.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof IfStatement)
    { out.println("coperationx_" + _i + ".code = ifstatementx_" + ifstatements.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof CAssignment)
    { out.println("coperationx_" + _i + ".code = cassignmentx_" + cassignments.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof DeclarationStatement)
    { out.println("coperationx_" + _i + ".code = declarationstatementx_" + declarationstatements.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof ForLoop)
    { out.println("coperationx_" + _i + ".code = forloopx_" + forloops.indexOf(coperationx_.getcode())); } 
    if (coperationx_.getcode() instanceof WhileLoop)
    { out.println("coperationx_" + _i + ".code = whileloopx_" + whileloops.indexOf(coperationx_.getcode())); } 
  }
  for (int _i = 0; _i < returnstatements.size(); _i++)
  { ReturnStatement returnstatementx_ = (ReturnStatement) returnstatements.get(_i);
    List returnstatement_returnValue_Expression = returnstatementx_.getreturnValue();
    for (int _k = 0; _k < returnstatement_returnValue_Expression.size(); _k++)
    { if (returnstatement_returnValue_Expression.get(_k) instanceof UnaryExpression)
      { out.println("unaryexpressionx_" + unaryexpressions.indexOf(returnstatement_returnValue_Expression.get(_k)) + " : returnstatementx_" + _i + ".returnValue"); }
 if (returnstatement_returnValue_Expression.get(_k) instanceof BasicExpression)
      { out.println("basicexpressionx_" + basicexpressions.indexOf(returnstatement_returnValue_Expression.get(_k)) + " : returnstatementx_" + _i + ".returnValue"); }
 if (returnstatement_returnValue_Expression.get(_k) instanceof BinaryExpression)
      { out.println("binaryexpressionx_" + binaryexpressions.indexOf(returnstatement_returnValue_Expression.get(_k)) + " : returnstatementx_" + _i + ".returnValue"); }
 if (returnstatement_returnValue_Expression.get(_k) instanceof CollectionExpression)
      { out.println("collectionexpressionx_" + collectionexpressions.indexOf(returnstatement_returnValue_Expression.get(_k)) + " : returnstatementx_" + _i + ".returnValue"); }
  }
  }
  for (int _i = 0; _i < operations.size(); _i++)
  { Operation operationx_ = (Operation) operations.get(_i);
    out.println("operationx_" + _i + ".owner = entityx_" + entitys.indexOf(((Operation) operations.get(_i)).getowner()));
    if (operationx_.getactivity() instanceof ReturnStatement)
    { out.println("operationx_" + _i + ".activity = returnstatementx_" + returnstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof BreakStatement)
    { out.println("operationx_" + _i + ".activity = breakstatementx_" + breakstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof OperationCallStatement)
    { out.println("operationx_" + _i + ".activity = operationcallstatementx_" + operationcallstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof ImplicitCallStatement)
    { out.println("operationx_" + _i + ".activity = implicitcallstatementx_" + implicitcallstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof SequenceStatement)
    { out.println("operationx_" + _i + ".activity = sequencestatementx_" + sequencestatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof ConditionalStatement)
    { out.println("operationx_" + _i + ".activity = conditionalstatementx_" + conditionalstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof AssignStatement)
    { out.println("operationx_" + _i + ".activity = assignstatementx_" + assignstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof CreationStatement)
    { out.println("operationx_" + _i + ".activity = creationstatementx_" + creationstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof BoundedLoopStatement)
    { out.println("operationx_" + _i + ".activity = boundedloopstatementx_" + boundedloopstatements.indexOf(operationx_.getactivity())); } 
    if (operationx_.getactivity() instanceof UnboundedLoopStatement)
    { out.println("operationx_" + _i + ".activity = unboundedloopstatementx_" + unboundedloopstatements.indexOf(operationx_.getactivity())); } 
  }
  for (int _i = 0; _i < usecases.size(); _i++)
  { UseCase usecasex_ = (UseCase) usecases.get(_i);
    List usecase_parameters_Property = usecasex_.getparameters();
    for (int _j = 0; _j < usecase_parameters_Property.size(); _j++)
    { out.println("propertyx_" + propertys.indexOf(usecase_parameters_Property.get(_j)) + " : usecasex_" + _i + ".parameters");
    }
    if (usecasex_.getresultType() instanceof Entity)
    { out.println("usecasex_" + _i + ".resultType = entityx_" + entitys.indexOf(usecasex_.getresultType())); } 
    if (usecasex_.getresultType() instanceof PrimitiveType)
    { out.println("usecasex_" + _i + ".resultType = primitivetypex_" + primitivetypes.indexOf(usecasex_.getresultType())); } 
    if (usecasex_.getresultType() instanceof CollectionType)
    { out.println("usecasex_" + _i + ".resultType = collectiontypex_" + collectiontypes.indexOf(usecasex_.getresultType())); } 
    if (usecasex_.getclassifierBehaviour() instanceof ReturnStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = returnstatementx_" + returnstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof BreakStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = breakstatementx_" + breakstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof OperationCallStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = operationcallstatementx_" + operationcallstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof ImplicitCallStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = implicitcallstatementx_" + implicitcallstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof SequenceStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = sequencestatementx_" + sequencestatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof ConditionalStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = conditionalstatementx_" + conditionalstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof AssignStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = assignstatementx_" + assignstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof CreationStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = creationstatementx_" + creationstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof BoundedLoopStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = boundedloopstatementx_" + boundedloopstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
    if (usecasex_.getclassifierBehaviour() instanceof UnboundedLoopStatement)
    { out.println("usecasex_" + _i + ".classifierBehaviour = unboundedloopstatementx_" + unboundedloopstatements.indexOf(usecasex_.getclassifierBehaviour())); } 
  }
  for (int _i = 0; _i < operationcallstatements.size(); _i++)
  { OperationCallStatement operationcallstatementx_ = (OperationCallStatement) operationcallstatements.get(_i);
    if (operationcallstatementx_.getcallExp() instanceof UnaryExpression)
    { out.println("operationcallstatementx_" + _i + ".callExp = unaryexpressionx_" + unaryexpressions.indexOf(operationcallstatementx_.getcallExp())); } 
    if (operationcallstatementx_.getcallExp() instanceof BasicExpression)
    { out.println("operationcallstatementx_" + _i + ".callExp = basicexpressionx_" + basicexpressions.indexOf(operationcallstatementx_.getcallExp())); } 
    if (operationcallstatementx_.getcallExp() instanceof BinaryExpression)
    { out.println("operationcallstatementx_" + _i + ".callExp = binaryexpressionx_" + binaryexpressions.indexOf(operationcallstatementx_.getcallExp())); } 
    if (operationcallstatementx_.getcallExp() instanceof CollectionExpression)
    { out.println("operationcallstatementx_" + _i + ".callExp = collectionexpressionx_" + collectionexpressions.indexOf(operationcallstatementx_.getcallExp())); } 
  }
  for (int _i = 0; _i < implicitcallstatements.size(); _i++)
  { ImplicitCallStatement implicitcallstatementx_ = (ImplicitCallStatement) implicitcallstatements.get(_i);
    if (implicitcallstatementx_.getcallExp() instanceof UnaryExpression)
    { out.println("implicitcallstatementx_" + _i + ".callExp = unaryexpressionx_" + unaryexpressions.indexOf(implicitcallstatementx_.getcallExp())); } 
    if (implicitcallstatementx_.getcallExp() instanceof BasicExpression)
    { out.println("implicitcallstatementx_" + _i + ".callExp = basicexpressionx_" + basicexpressions.indexOf(implicitcallstatementx_.getcallExp())); } 
    if (implicitcallstatementx_.getcallExp() instanceof BinaryExpression)
    { out.println("implicitcallstatementx_" + _i + ".callExp = binaryexpressionx_" + binaryexpressions.indexOf(implicitcallstatementx_.getcallExp())); } 
    if (implicitcallstatementx_.getcallExp() instanceof CollectionExpression)
    { out.println("implicitcallstatementx_" + _i + ".callExp = collectionexpressionx_" + collectionexpressions.indexOf(implicitcallstatementx_.getcallExp())); } 
  }
  for (int _i = 0; _i < boundedloopstatements.size(); _i++)
  { BoundedLoopStatement boundedloopstatementx_ = (BoundedLoopStatement) boundedloopstatements.get(_i);
    if (boundedloopstatementx_.getloopRange() instanceof UnaryExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopRange = unaryexpressionx_" + unaryexpressions.indexOf(boundedloopstatementx_.getloopRange())); } 
    if (boundedloopstatementx_.getloopRange() instanceof BasicExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopRange = basicexpressionx_" + basicexpressions.indexOf(boundedloopstatementx_.getloopRange())); } 
    if (boundedloopstatementx_.getloopRange() instanceof BinaryExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopRange = binaryexpressionx_" + binaryexpressions.indexOf(boundedloopstatementx_.getloopRange())); } 
    if (boundedloopstatementx_.getloopRange() instanceof CollectionExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopRange = collectionexpressionx_" + collectionexpressions.indexOf(boundedloopstatementx_.getloopRange())); } 
    if (boundedloopstatementx_.getloopVar() instanceof UnaryExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopVar = unaryexpressionx_" + unaryexpressions.indexOf(boundedloopstatementx_.getloopVar())); } 
    if (boundedloopstatementx_.getloopVar() instanceof BasicExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopVar = basicexpressionx_" + basicexpressions.indexOf(boundedloopstatementx_.getloopVar())); } 
    if (boundedloopstatementx_.getloopVar() instanceof BinaryExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopVar = binaryexpressionx_" + binaryexpressions.indexOf(boundedloopstatementx_.getloopVar())); } 
    if (boundedloopstatementx_.getloopVar() instanceof CollectionExpression)
    { out.println("boundedloopstatementx_" + _i + ".loopVar = collectionexpressionx_" + collectionexpressions.indexOf(boundedloopstatementx_.getloopVar())); } 
    if (boundedloopstatementx_.gettest() instanceof UnaryExpression)
    { out.println("boundedloopstatementx_" + _i + ".test = unaryexpressionx_" + unaryexpressions.indexOf(boundedloopstatementx_.gettest())); } 
    if (boundedloopstatementx_.gettest() instanceof BasicExpression)
    { out.println("boundedloopstatementx_" + _i + ".test = basicexpressionx_" + basicexpressions.indexOf(boundedloopstatementx_.gettest())); } 
    if (boundedloopstatementx_.gettest() instanceof BinaryExpression)
    { out.println("boundedloopstatementx_" + _i + ".test = binaryexpressionx_" + binaryexpressions.indexOf(boundedloopstatementx_.gettest())); } 
    if (boundedloopstatementx_.gettest() instanceof CollectionExpression)
    { out.println("boundedloopstatementx_" + _i + ".test = collectionexpressionx_" + collectionexpressions.indexOf(boundedloopstatementx_.gettest())); } 
    if (boundedloopstatementx_.getbody() instanceof ReturnStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = returnstatementx_" + returnstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof BreakStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = breakstatementx_" + breakstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof OperationCallStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = operationcallstatementx_" + operationcallstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof ImplicitCallStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = implicitcallstatementx_" + implicitcallstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof SequenceStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = sequencestatementx_" + sequencestatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof ConditionalStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = conditionalstatementx_" + conditionalstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof AssignStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = assignstatementx_" + assignstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof CreationStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = creationstatementx_" + creationstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof BoundedLoopStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = boundedloopstatementx_" + boundedloopstatements.indexOf(boundedloopstatementx_.getbody())); } 
    if (boundedloopstatementx_.getbody() instanceof UnboundedLoopStatement)
    { out.println("boundedloopstatementx_" + _i + ".body = unboundedloopstatementx_" + unboundedloopstatements.indexOf(boundedloopstatementx_.getbody())); } 
  }
  for (int _i = 0; _i < unboundedloopstatements.size(); _i++)
  { UnboundedLoopStatement unboundedloopstatementx_ = (UnboundedLoopStatement) unboundedloopstatements.get(_i);
    if (unboundedloopstatementx_.gettest() instanceof UnaryExpression)
    { out.println("unboundedloopstatementx_" + _i + ".test = unaryexpressionx_" + unaryexpressions.indexOf(unboundedloopstatementx_.gettest())); } 
    if (unboundedloopstatementx_.gettest() instanceof BasicExpression)
    { out.println("unboundedloopstatementx_" + _i + ".test = basicexpressionx_" + basicexpressions.indexOf(unboundedloopstatementx_.gettest())); } 
    if (unboundedloopstatementx_.gettest() instanceof BinaryExpression)
    { out.println("unboundedloopstatementx_" + _i + ".test = binaryexpressionx_" + binaryexpressions.indexOf(unboundedloopstatementx_.gettest())); } 
    if (unboundedloopstatementx_.gettest() instanceof CollectionExpression)
    { out.println("unboundedloopstatementx_" + _i + ".test = collectionexpressionx_" + collectionexpressions.indexOf(unboundedloopstatementx_.gettest())); } 
    if (unboundedloopstatementx_.getbody() instanceof ReturnStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = returnstatementx_" + returnstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof BreakStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = breakstatementx_" + breakstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof OperationCallStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = operationcallstatementx_" + operationcallstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof ImplicitCallStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = implicitcallstatementx_" + implicitcallstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof SequenceStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = sequencestatementx_" + sequencestatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof ConditionalStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = conditionalstatementx_" + conditionalstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof AssignStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = assignstatementx_" + assignstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof CreationStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = creationstatementx_" + creationstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof BoundedLoopStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = boundedloopstatementx_" + boundedloopstatements.indexOf(unboundedloopstatementx_.getbody())); } 
    if (unboundedloopstatementx_.getbody() instanceof UnboundedLoopStatement)
    { out.println("unboundedloopstatementx_" + _i + ".body = unboundedloopstatementx_" + unboundedloopstatements.indexOf(unboundedloopstatementx_.getbody())); } 
  }
  for (int _i = 0; _i < assignstatements.size(); _i++)
  { AssignStatement assignstatementx_ = (AssignStatement) assignstatements.get(_i);
    List assignstatement_type_Type = assignstatementx_.gettype();
    for (int _k = 0; _k < assignstatement_type_Type.size(); _k++)
    { if (assignstatement_type_Type.get(_k) instanceof Entity)
      { out.println("entityx_" + entitys.indexOf(assignstatement_type_Type.get(_k)) + " : assignstatementx_" + _i + ".type"); }
 if (assignstatement_type_Type.get(_k) instanceof PrimitiveType)
      { out.println("primitivetypex_" + primitivetypes.indexOf(assignstatement_type_Type.get(_k)) + " : assignstatementx_" + _i + ".type"); }
 if (assignstatement_type_Type.get(_k) instanceof CollectionType)
      { out.println("collectiontypex_" + collectiontypes.indexOf(assignstatement_type_Type.get(_k)) + " : assignstatementx_" + _i + ".type"); }
  }
    if (assignstatementx_.getleft() instanceof UnaryExpression)
    { out.println("assignstatementx_" + _i + ".left = unaryexpressionx_" + unaryexpressions.indexOf(assignstatementx_.getleft())); } 
    if (assignstatementx_.getleft() instanceof BasicExpression)
    { out.println("assignstatementx_" + _i + ".left = basicexpressionx_" + basicexpressions.indexOf(assignstatementx_.getleft())); } 
    if (assignstatementx_.getleft() instanceof BinaryExpression)
    { out.println("assignstatementx_" + _i + ".left = binaryexpressionx_" + binaryexpressions.indexOf(assignstatementx_.getleft())); } 
    if (assignstatementx_.getleft() instanceof CollectionExpression)
    { out.println("assignstatementx_" + _i + ".left = collectionexpressionx_" + collectionexpressions.indexOf(assignstatementx_.getleft())); } 
    if (assignstatementx_.getright() instanceof UnaryExpression)
    { out.println("assignstatementx_" + _i + ".right = unaryexpressionx_" + unaryexpressions.indexOf(assignstatementx_.getright())); } 
    if (assignstatementx_.getright() instanceof BasicExpression)
    { out.println("assignstatementx_" + _i + ".right = basicexpressionx_" + basicexpressions.indexOf(assignstatementx_.getright())); } 
    if (assignstatementx_.getright() instanceof BinaryExpression)
    { out.println("assignstatementx_" + _i + ".right = binaryexpressionx_" + binaryexpressions.indexOf(assignstatementx_.getright())); } 
    if (assignstatementx_.getright() instanceof CollectionExpression)
    { out.println("assignstatementx_" + _i + ".right = collectionexpressionx_" + collectionexpressions.indexOf(assignstatementx_.getright())); } 
  }
  for (int _i = 0; _i < sequencestatements.size(); _i++)
  { SequenceStatement sequencestatementx_ = (SequenceStatement) sequencestatements.get(_i);
    List sequencestatement_statements_Statement = sequencestatementx_.getstatements();
    for (int _k = 0; _k < sequencestatement_statements_Statement.size(); _k++)
    { if (sequencestatement_statements_Statement.get(_k) instanceof ReturnStatement)
      { out.println("returnstatementx_" + returnstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof BreakStatement)
      { out.println("breakstatementx_" + breakstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof OperationCallStatement)
      { out.println("operationcallstatementx_" + operationcallstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof ImplicitCallStatement)
      { out.println("implicitcallstatementx_" + implicitcallstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof SequenceStatement)
      { out.println("sequencestatementx_" + sequencestatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof ConditionalStatement)
      { out.println("conditionalstatementx_" + conditionalstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof AssignStatement)
      { out.println("assignstatementx_" + assignstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof CreationStatement)
      { out.println("creationstatementx_" + creationstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof BoundedLoopStatement)
      { out.println("boundedloopstatementx_" + boundedloopstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
 if (sequencestatement_statements_Statement.get(_k) instanceof UnboundedLoopStatement)
      { out.println("unboundedloopstatementx_" + unboundedloopstatements.indexOf(sequencestatement_statements_Statement.get(_k)) + " : sequencestatementx_" + _i + ".statements"); }
  }
  }
  for (int _i = 0; _i < conditionalstatements.size(); _i++)
  { ConditionalStatement conditionalstatementx_ = (ConditionalStatement) conditionalstatements.get(_i);
    if (conditionalstatementx_.gettest() instanceof UnaryExpression)
    { out.println("conditionalstatementx_" + _i + ".test = unaryexpressionx_" + unaryexpressions.indexOf(conditionalstatementx_.gettest())); } 
    if (conditionalstatementx_.gettest() instanceof BasicExpression)
    { out.println("conditionalstatementx_" + _i + ".test = basicexpressionx_" + basicexpressions.indexOf(conditionalstatementx_.gettest())); } 
    if (conditionalstatementx_.gettest() instanceof BinaryExpression)
    { out.println("conditionalstatementx_" + _i + ".test = binaryexpressionx_" + binaryexpressions.indexOf(conditionalstatementx_.gettest())); } 
    if (conditionalstatementx_.gettest() instanceof CollectionExpression)
    { out.println("conditionalstatementx_" + _i + ".test = collectionexpressionx_" + collectionexpressions.indexOf(conditionalstatementx_.gettest())); } 
    if (conditionalstatementx_.getifPart() instanceof ReturnStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = returnstatementx_" + returnstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof BreakStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = breakstatementx_" + breakstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof OperationCallStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = operationcallstatementx_" + operationcallstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof ImplicitCallStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = implicitcallstatementx_" + implicitcallstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof SequenceStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = sequencestatementx_" + sequencestatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof ConditionalStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = conditionalstatementx_" + conditionalstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof AssignStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = assignstatementx_" + assignstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof CreationStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = creationstatementx_" + creationstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof BoundedLoopStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = boundedloopstatementx_" + boundedloopstatements.indexOf(conditionalstatementx_.getifPart())); } 
    if (conditionalstatementx_.getifPart() instanceof UnboundedLoopStatement)
    { out.println("conditionalstatementx_" + _i + ".ifPart = unboundedloopstatementx_" + unboundedloopstatements.indexOf(conditionalstatementx_.getifPart())); } 
    List conditionalstatement_elsePart_Statement = conditionalstatementx_.getelsePart();
    for (int _k = 0; _k < conditionalstatement_elsePart_Statement.size(); _k++)
    { if (conditionalstatement_elsePart_Statement.get(_k) instanceof ReturnStatement)
      { out.println("returnstatementx_" + returnstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof BreakStatement)
      { out.println("breakstatementx_" + breakstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof OperationCallStatement)
      { out.println("operationcallstatementx_" + operationcallstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof ImplicitCallStatement)
      { out.println("implicitcallstatementx_" + implicitcallstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof SequenceStatement)
      { out.println("sequencestatementx_" + sequencestatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof ConditionalStatement)
      { out.println("conditionalstatementx_" + conditionalstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof AssignStatement)
      { out.println("assignstatementx_" + assignstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof CreationStatement)
      { out.println("creationstatementx_" + creationstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof BoundedLoopStatement)
      { out.println("boundedloopstatementx_" + boundedloopstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
 if (conditionalstatement_elsePart_Statement.get(_k) instanceof UnboundedLoopStatement)
      { out.println("unboundedloopstatementx_" + unboundedloopstatements.indexOf(conditionalstatement_elsePart_Statement.get(_k)) + " : conditionalstatementx_" + _i + ".elsePart"); }
  }
  }
  for (int _i = 0; _i < creationstatements.size(); _i++)
  { CreationStatement creationstatementx_ = (CreationStatement) creationstatements.get(_i);
    if (creationstatementx_.gettype() instanceof Entity)
    { out.println("creationstatementx_" + _i + ".type = entityx_" + entitys.indexOf(creationstatementx_.gettype())); } 
    if (creationstatementx_.gettype() instanceof PrimitiveType)
    { out.println("creationstatementx_" + _i + ".type = primitivetypex_" + primitivetypes.indexOf(creationstatementx_.gettype())); } 
    if (creationstatementx_.gettype() instanceof CollectionType)
    { out.println("creationstatementx_" + _i + ".type = collectiontypex_" + collectiontypes.indexOf(creationstatementx_.gettype())); } 
    if (creationstatementx_.getelementType() instanceof Entity)
    { out.println("creationstatementx_" + _i + ".elementType = entityx_" + entitys.indexOf(creationstatementx_.getelementType())); } 
    if (creationstatementx_.getelementType() instanceof PrimitiveType)
    { out.println("creationstatementx_" + _i + ".elementType = primitivetypex_" + primitivetypes.indexOf(creationstatementx_.getelementType())); } 
    if (creationstatementx_.getelementType() instanceof CollectionType)
    { out.println("creationstatementx_" + _i + ".elementType = collectiontypex_" + collectiontypes.indexOf(creationstatementx_.getelementType())); } 
  }
  for (int _i = 0; _i < creturnstatements.size(); _i++)
  { CReturnStatement creturnstatementx_ = (CReturnStatement) creturnstatements.get(_i);
    List creturnstatement_returnValue_CExpression = creturnstatementx_.getreturnValue();
    for (int _k = 0; _k < creturnstatement_returnValue_CExpression.size(); _k++)
    { if (creturnstatement_returnValue_CExpression.get(_k) instanceof CUnaryExpression)
      { out.println("cunaryexpressionx_" + cunaryexpressions.indexOf(creturnstatement_returnValue_CExpression.get(_k)) + " : creturnstatementx_" + _i + ".returnValue"); }
 if (creturnstatement_returnValue_CExpression.get(_k) instanceof CBasicExpression)
      { out.println("cbasicexpressionx_" + cbasicexpressions.indexOf(creturnstatement_returnValue_CExpression.get(_k)) + " : creturnstatementx_" + _i + ".returnValue"); }
 if (creturnstatement_returnValue_CExpression.get(_k) instanceof CBinaryExpression)
      { out.println("cbinaryexpressionx_" + cbinaryexpressions.indexOf(creturnstatement_returnValue_CExpression.get(_k)) + " : creturnstatementx_" + _i + ".returnValue"); }
  }
  }
  for (int _i = 0; _i < opcallstatements.size(); _i++)
  { OpCallStatement opcallstatementx_ = (OpCallStatement) opcallstatements.get(_i);
    if (opcallstatementx_.getcallExp() instanceof CUnaryExpression)
    { out.println("opcallstatementx_" + _i + ".callExp = cunaryexpressionx_" + cunaryexpressions.indexOf(opcallstatementx_.getcallExp())); } 
    if (opcallstatementx_.getcallExp() instanceof CBasicExpression)
    { out.println("opcallstatementx_" + _i + ".callExp = cbasicexpressionx_" + cbasicexpressions.indexOf(opcallstatementx_.getcallExp())); } 
    if (opcallstatementx_.getcallExp() instanceof CBinaryExpression)
    { out.println("opcallstatementx_" + _i + ".callExp = cbinaryexpressionx_" + cbinaryexpressions.indexOf(opcallstatementx_.getcallExp())); } 
  }
  for (int _i = 0; _i < forloops.size(); _i++)
  { ForLoop forloopx_ = (ForLoop) forloops.get(_i);
    out.println("forloopx_" + _i + ".increment = csequencestatementx_" + csequencestatements.indexOf(((ForLoop) forloops.get(_i)).getincrement()));
    if (forloopx_.getloopVar() instanceof CUnaryExpression)
    { out.println("forloopx_" + _i + ".loopVar = cunaryexpressionx_" + cunaryexpressions.indexOf(forloopx_.getloopVar())); } 
    if (forloopx_.getloopVar() instanceof CBasicExpression)
    { out.println("forloopx_" + _i + ".loopVar = cbasicexpressionx_" + cbasicexpressions.indexOf(forloopx_.getloopVar())); } 
    if (forloopx_.getloopVar() instanceof CBinaryExpression)
    { out.println("forloopx_" + _i + ".loopVar = cbinaryexpressionx_" + cbinaryexpressions.indexOf(forloopx_.getloopVar())); } 
    if (forloopx_.getloopRange() instanceof CUnaryExpression)
    { out.println("forloopx_" + _i + ".loopRange = cunaryexpressionx_" + cunaryexpressions.indexOf(forloopx_.getloopRange())); } 
    if (forloopx_.getloopRange() instanceof CBasicExpression)
    { out.println("forloopx_" + _i + ".loopRange = cbasicexpressionx_" + cbasicexpressions.indexOf(forloopx_.getloopRange())); } 
    if (forloopx_.getloopRange() instanceof CBinaryExpression)
    { out.println("forloopx_" + _i + ".loopRange = cbinaryexpressionx_" + cbinaryexpressions.indexOf(forloopx_.getloopRange())); } 
    if (forloopx_.gettest() instanceof CUnaryExpression)
    { out.println("forloopx_" + _i + ".test = cunaryexpressionx_" + cunaryexpressions.indexOf(forloopx_.gettest())); } 
    if (forloopx_.gettest() instanceof CBasicExpression)
    { out.println("forloopx_" + _i + ".test = cbasicexpressionx_" + cbasicexpressions.indexOf(forloopx_.gettest())); } 
    if (forloopx_.gettest() instanceof CBinaryExpression)
    { out.println("forloopx_" + _i + ".test = cbinaryexpressionx_" + cbinaryexpressions.indexOf(forloopx_.gettest())); } 
    if (forloopx_.getbody() instanceof CReturnStatement)
    { out.println("forloopx_" + _i + ".body = creturnstatementx_" + creturnstatements.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof CBreakStatement)
    { out.println("forloopx_" + _i + ".body = cbreakstatementx_" + cbreakstatements.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof OpCallStatement)
    { out.println("forloopx_" + _i + ".body = opcallstatementx_" + opcallstatements.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof CSequenceStatement)
    { out.println("forloopx_" + _i + ".body = csequencestatementx_" + csequencestatements.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof IfStatement)
    { out.println("forloopx_" + _i + ".body = ifstatementx_" + ifstatements.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof CAssignment)
    { out.println("forloopx_" + _i + ".body = cassignmentx_" + cassignments.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof DeclarationStatement)
    { out.println("forloopx_" + _i + ".body = declarationstatementx_" + declarationstatements.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof ForLoop)
    { out.println("forloopx_" + _i + ".body = forloopx_" + forloops.indexOf(forloopx_.getbody())); } 
    if (forloopx_.getbody() instanceof WhileLoop)
    { out.println("forloopx_" + _i + ".body = whileloopx_" + whileloops.indexOf(forloopx_.getbody())); } 
  }
  for (int _i = 0; _i < whileloops.size(); _i++)
  { WhileLoop whileloopx_ = (WhileLoop) whileloops.get(_i);
    if (whileloopx_.gettest() instanceof CUnaryExpression)
    { out.println("whileloopx_" + _i + ".test = cunaryexpressionx_" + cunaryexpressions.indexOf(whileloopx_.gettest())); } 
    if (whileloopx_.gettest() instanceof CBasicExpression)
    { out.println("whileloopx_" + _i + ".test = cbasicexpressionx_" + cbasicexpressions.indexOf(whileloopx_.gettest())); } 
    if (whileloopx_.gettest() instanceof CBinaryExpression)
    { out.println("whileloopx_" + _i + ".test = cbinaryexpressionx_" + cbinaryexpressions.indexOf(whileloopx_.gettest())); } 
    if (whileloopx_.getbody() instanceof CReturnStatement)
    { out.println("whileloopx_" + _i + ".body = creturnstatementx_" + creturnstatements.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof CBreakStatement)
    { out.println("whileloopx_" + _i + ".body = cbreakstatementx_" + cbreakstatements.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof OpCallStatement)
    { out.println("whileloopx_" + _i + ".body = opcallstatementx_" + opcallstatements.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof CSequenceStatement)
    { out.println("whileloopx_" + _i + ".body = csequencestatementx_" + csequencestatements.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof IfStatement)
    { out.println("whileloopx_" + _i + ".body = ifstatementx_" + ifstatements.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof CAssignment)
    { out.println("whileloopx_" + _i + ".body = cassignmentx_" + cassignments.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof DeclarationStatement)
    { out.println("whileloopx_" + _i + ".body = declarationstatementx_" + declarationstatements.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof ForLoop)
    { out.println("whileloopx_" + _i + ".body = forloopx_" + forloops.indexOf(whileloopx_.getbody())); } 
    if (whileloopx_.getbody() instanceof WhileLoop)
    { out.println("whileloopx_" + _i + ".body = whileloopx_" + whileloops.indexOf(whileloopx_.getbody())); } 
  }
  for (int _i = 0; _i < cassignments.size(); _i++)
  { CAssignment cassignmentx_ = (CAssignment) cassignments.get(_i);
    List cassignment_type_CType = cassignmentx_.gettype();
    for (int _k = 0; _k < cassignment_type_CType.size(); _k++)
    { if (cassignment_type_CType.get(_k) instanceof CFunctionPointerType)
      { out.println("cfunctionpointertypex_" + cfunctionpointertypes.indexOf(cassignment_type_CType.get(_k)) + " : cassignmentx_" + _i + ".type"); }
 if (cassignment_type_CType.get(_k) instanceof CStruct)
      { out.println("cstructx_" + cstructs.indexOf(cassignment_type_CType.get(_k)) + " : cassignmentx_" + _i + ".type"); }
 if (cassignment_type_CType.get(_k) instanceof CPrimitiveType)
      { out.println("cprimitivetypex_" + cprimitivetypes.indexOf(cassignment_type_CType.get(_k)) + " : cassignmentx_" + _i + ".type"); }
 if (cassignment_type_CType.get(_k) instanceof CPointerType)
      { out.println("cpointertypex_" + cpointertypes.indexOf(cassignment_type_CType.get(_k)) + " : cassignmentx_" + _i + ".type"); }
 if (cassignment_type_CType.get(_k) instanceof CArrayType)
      { out.println("carraytypex_" + carraytypes.indexOf(cassignment_type_CType.get(_k)) + " : cassignmentx_" + _i + ".type"); }
  }
    if (cassignmentx_.getleft() instanceof CUnaryExpression)
    { out.println("cassignmentx_" + _i + ".left = cunaryexpressionx_" + cunaryexpressions.indexOf(cassignmentx_.getleft())); } 
    if (cassignmentx_.getleft() instanceof CBasicExpression)
    { out.println("cassignmentx_" + _i + ".left = cbasicexpressionx_" + cbasicexpressions.indexOf(cassignmentx_.getleft())); } 
    if (cassignmentx_.getleft() instanceof CBinaryExpression)
    { out.println("cassignmentx_" + _i + ".left = cbinaryexpressionx_" + cbinaryexpressions.indexOf(cassignmentx_.getleft())); } 
    if (cassignmentx_.getright() instanceof CUnaryExpression)
    { out.println("cassignmentx_" + _i + ".right = cunaryexpressionx_" + cunaryexpressions.indexOf(cassignmentx_.getright())); } 
    if (cassignmentx_.getright() instanceof CBasicExpression)
    { out.println("cassignmentx_" + _i + ".right = cbasicexpressionx_" + cbasicexpressions.indexOf(cassignmentx_.getright())); } 
    if (cassignmentx_.getright() instanceof CBinaryExpression)
    { out.println("cassignmentx_" + _i + ".right = cbinaryexpressionx_" + cbinaryexpressions.indexOf(cassignmentx_.getright())); } 
  }
  for (int _i = 0; _i < csequencestatements.size(); _i++)
  { CSequenceStatement csequencestatementx_ = (CSequenceStatement) csequencestatements.get(_i);
    List csequencestatement_statements_CStatement = csequencestatementx_.getstatements();
    for (int _k = 0; _k < csequencestatement_statements_CStatement.size(); _k++)
    { if (csequencestatement_statements_CStatement.get(_k) instanceof CReturnStatement)
      { out.println("creturnstatementx_" + creturnstatements.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof CBreakStatement)
      { out.println("cbreakstatementx_" + cbreakstatements.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof OpCallStatement)
      { out.println("opcallstatementx_" + opcallstatements.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof CSequenceStatement)
      { out.println("csequencestatementx_" + csequencestatements.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof IfStatement)
      { out.println("ifstatementx_" + ifstatements.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof CAssignment)
      { out.println("cassignmentx_" + cassignments.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof DeclarationStatement)
      { out.println("declarationstatementx_" + declarationstatements.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof ForLoop)
      { out.println("forloopx_" + forloops.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
 if (csequencestatement_statements_CStatement.get(_k) instanceof WhileLoop)
      { out.println("whileloopx_" + whileloops.indexOf(csequencestatement_statements_CStatement.get(_k)) + " : csequencestatementx_" + _i + ".statements"); }
  }
  }
  for (int _i = 0; _i < ifstatements.size(); _i++)
  { IfStatement ifstatementx_ = (IfStatement) ifstatements.get(_i);
    if (ifstatementx_.gettest() instanceof CUnaryExpression)
    { out.println("ifstatementx_" + _i + ".test = cunaryexpressionx_" + cunaryexpressions.indexOf(ifstatementx_.gettest())); } 
    if (ifstatementx_.gettest() instanceof CBasicExpression)
    { out.println("ifstatementx_" + _i + ".test = cbasicexpressionx_" + cbasicexpressions.indexOf(ifstatementx_.gettest())); } 
    if (ifstatementx_.gettest() instanceof CBinaryExpression)
    { out.println("ifstatementx_" + _i + ".test = cbinaryexpressionx_" + cbinaryexpressions.indexOf(ifstatementx_.gettest())); } 
    if (ifstatementx_.getifPart() instanceof CReturnStatement)
    { out.println("ifstatementx_" + _i + ".ifPart = creturnstatementx_" + creturnstatements.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof CBreakStatement)
    { out.println("ifstatementx_" + _i + ".ifPart = cbreakstatementx_" + cbreakstatements.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof OpCallStatement)
    { out.println("ifstatementx_" + _i + ".ifPart = opcallstatementx_" + opcallstatements.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof CSequenceStatement)
    { out.println("ifstatementx_" + _i + ".ifPart = csequencestatementx_" + csequencestatements.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof IfStatement)
    { out.println("ifstatementx_" + _i + ".ifPart = ifstatementx_" + ifstatements.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof CAssignment)
    { out.println("ifstatementx_" + _i + ".ifPart = cassignmentx_" + cassignments.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof DeclarationStatement)
    { out.println("ifstatementx_" + _i + ".ifPart = declarationstatementx_" + declarationstatements.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof ForLoop)
    { out.println("ifstatementx_" + _i + ".ifPart = forloopx_" + forloops.indexOf(ifstatementx_.getifPart())); } 
    if (ifstatementx_.getifPart() instanceof WhileLoop)
    { out.println("ifstatementx_" + _i + ".ifPart = whileloopx_" + whileloops.indexOf(ifstatementx_.getifPart())); } 
    List ifstatement_elsePart_CStatement = ifstatementx_.getelsePart();
    for (int _k = 0; _k < ifstatement_elsePart_CStatement.size(); _k++)
    { if (ifstatement_elsePart_CStatement.get(_k) instanceof CReturnStatement)
      { out.println("creturnstatementx_" + creturnstatements.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof CBreakStatement)
      { out.println("cbreakstatementx_" + cbreakstatements.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof OpCallStatement)
      { out.println("opcallstatementx_" + opcallstatements.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof CSequenceStatement)
      { out.println("csequencestatementx_" + csequencestatements.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof IfStatement)
      { out.println("ifstatementx_" + ifstatements.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof CAssignment)
      { out.println("cassignmentx_" + cassignments.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof DeclarationStatement)
      { out.println("declarationstatementx_" + declarationstatements.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof ForLoop)
      { out.println("forloopx_" + forloops.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
 if (ifstatement_elsePart_CStatement.get(_k) instanceof WhileLoop)
      { out.println("whileloopx_" + whileloops.indexOf(ifstatement_elsePart_CStatement.get(_k)) + " : ifstatementx_" + _i + ".elsePart"); }
  }
  }
  for (int _i = 0; _i < declarationstatements.size(); _i++)
  { DeclarationStatement declarationstatementx_ = (DeclarationStatement) declarationstatements.get(_i);
    if (declarationstatementx_.gettype() instanceof CFunctionPointerType)
    { out.println("declarationstatementx_" + _i + ".type = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(declarationstatementx_.gettype())); } 
    if (declarationstatementx_.gettype() instanceof CStruct)
    { out.println("declarationstatementx_" + _i + ".type = cstructx_" + cstructs.indexOf(declarationstatementx_.gettype())); } 
    if (declarationstatementx_.gettype() instanceof CPrimitiveType)
    { out.println("declarationstatementx_" + _i + ".type = cprimitivetypex_" + cprimitivetypes.indexOf(declarationstatementx_.gettype())); } 
    if (declarationstatementx_.gettype() instanceof CPointerType)
    { out.println("declarationstatementx_" + _i + ".type = cpointertypex_" + cpointertypes.indexOf(declarationstatementx_.gettype())); } 
    if (declarationstatementx_.gettype() instanceof CArrayType)
    { out.println("declarationstatementx_" + _i + ".type = carraytypex_" + carraytypes.indexOf(declarationstatementx_.gettype())); } 
    if (declarationstatementx_.getelementType() instanceof CFunctionPointerType)
    { out.println("declarationstatementx_" + _i + ".elementType = cfunctionpointertypex_" + cfunctionpointertypes.indexOf(declarationstatementx_.getelementType())); } 
    if (declarationstatementx_.getelementType() instanceof CStruct)
    { out.println("declarationstatementx_" + _i + ".elementType = cstructx_" + cstructs.indexOf(declarationstatementx_.getelementType())); } 
    if (declarationstatementx_.getelementType() instanceof CPrimitiveType)
    { out.println("declarationstatementx_" + _i + ".elementType = cprimitivetypex_" + cprimitivetypes.indexOf(declarationstatementx_.getelementType())); } 
    if (declarationstatementx_.getelementType() instanceof CPointerType)
    { out.println("declarationstatementx_" + _i + ".elementType = cpointertypex_" + cpointertypes.indexOf(declarationstatementx_.getelementType())); } 
    if (declarationstatementx_.getelementType() instanceof CArrayType)
    { out.println("declarationstatementx_" + _i + ".elementType = carraytypex_" + carraytypes.indexOf(declarationstatementx_.getelementType())); } 
  }
    out.close(); 
  }


  public static void loadXSI()
  { boolean __eof = false;
    String __s = "";
    String xmlstring = "";
    BufferedReader __br = null;
    try
    { File _classmodel = new File("in.xmi");
      __br = new BufferedReader(new FileReader(_classmodel));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { xmlstring = xmlstring + __s; }
      } 
      __br.close();
    } 
    catch (Exception _x) { }
    Vector res = convertXsiToVector(xmlstring);
    File outfile = new File("_in.txt");
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    for (int i = 0; i < res.size(); i++)
    { String r = (String) res.get(i); 
      out.println(r);
    } 
    out.close();
    loadModel("_in.txt");
  }

  public static Vector convertXsiToVector(String xmlstring)
  { Vector res = new Vector();
    XMLParser comp = new XMLParser();
    comp.nospacelexicalanalysisxml(xmlstring);
    XMLNode xml = comp.parseXML();
    if (xml == null) { return res; } 
    java.util.Map instancemap = new java.util.HashMap(); // String --> Vector
    java.util.Map entmap = new java.util.HashMap();       // String --> String
    Vector entcodes = new Vector(); 
    java.util.Map allattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map stringattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map onerolesmap = new java.util.HashMap(); // String --> Vector
    java.util.Map actualtype = new java.util.HashMap(); // XMLNode --> String
    Vector eallatts = new Vector();
    instancemap.put("cexpressions", new Vector()); 
    instancemap.put("cexpression",new Vector()); 
    entcodes.add("cexpressions");
    entcodes.add("cexpression");
    entmap.put("cexpressions","CExpression");
    entmap.put("cexpression","CExpression");
    eallatts = new Vector();
    eallatts.add("needsBracket");
    eallatts.add("kind");
    eallatts.add("cexpId");
    eallatts.add("isStatic");
    allattsmap.put("CExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("kind");
    eallatts.add("cexpId");
    stringattsmap.put("CExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("CExpression", eallatts);
    instancemap.put("cbinaryexpressions", new Vector()); 
    instancemap.put("cbinaryexpression",new Vector()); 
    entcodes.add("cbinaryexpressions");
    entcodes.add("cbinaryexpression");
    entmap.put("cbinaryexpressions","CBinaryExpression");
    entmap.put("cbinaryexpression","CBinaryExpression");
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("needsBracket");
    eallatts.add("kind");
    eallatts.add("cexpId");
    eallatts.add("isStatic");
    allattsmap.put("CBinaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("kind");
    eallatts.add("cexpId");
    stringattsmap.put("CBinaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("left");
    eallatts.add("right");
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("CBinaryExpression", eallatts);
    instancemap.put("cunaryexpressions", new Vector()); 
    instancemap.put("cunaryexpression",new Vector()); 
    entcodes.add("cunaryexpressions");
    entcodes.add("cunaryexpression");
    entmap.put("cunaryexpressions","CUnaryExpression");
    entmap.put("cunaryexpression","CUnaryExpression");
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("needsBracket");
    eallatts.add("kind");
    eallatts.add("cexpId");
    eallatts.add("isStatic");
    allattsmap.put("CUnaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("kind");
    eallatts.add("cexpId");
    stringattsmap.put("CUnaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("argument");
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("CUnaryExpression", eallatts);
    instancemap.put("ctypes", new Vector()); 
    instancemap.put("ctype",new Vector()); 
    entcodes.add("ctypes");
    entcodes.add("ctype");
    entmap.put("ctypes","CType");
    entmap.put("ctype","CType");
    eallatts = new Vector();
    eallatts.add("ctypeId");
    eallatts.add("name");
    allattsmap.put("CType", eallatts);
    eallatts = new Vector();
    eallatts.add("ctypeId");
    eallatts.add("name");
    stringattsmap.put("CType", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CType", eallatts);
    instancemap.put("cbasicexpressions", new Vector()); 
    instancemap.put("cbasicexpression",new Vector()); 
    entcodes.add("cbasicexpressions");
    entcodes.add("cbasicexpression");
    entmap.put("cbasicexpressions","CBasicExpression");
    entmap.put("cbasicexpression","CBasicExpression");
    eallatts = new Vector();
    eallatts.add("data");
    eallatts.add("needsBracket");
    eallatts.add("kind");
    eallatts.add("cexpId");
    eallatts.add("isStatic");
    allattsmap.put("CBasicExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("data");
    eallatts.add("kind");
    eallatts.add("cexpId");
    stringattsmap.put("CBasicExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("CBasicExpression", eallatts);
    instancemap.put("types", new Vector()); 
    instancemap.put("type",new Vector()); 
    entcodes.add("types");
    entcodes.add("type");
    entmap.put("types","Type");
    entmap.put("type","Type");
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    allattsmap.put("Type", eallatts);
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    stringattsmap.put("Type", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Type", eallatts);
    instancemap.put("classifiers", new Vector()); 
    instancemap.put("classifier",new Vector()); 
    entcodes.add("classifiers");
    entcodes.add("classifier");
    entmap.put("classifiers","Classifier");
    entmap.put("classifier","Classifier");
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    allattsmap.put("Classifier", eallatts);
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    stringattsmap.put("Classifier", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Classifier", eallatts);
    instancemap.put("datatypes", new Vector()); 
    instancemap.put("datatype",new Vector()); 
    entcodes.add("datatypes");
    entcodes.add("datatype");
    entmap.put("datatypes","DataType");
    entmap.put("datatype","DataType");
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    allattsmap.put("DataType", eallatts);
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    stringattsmap.put("DataType", eallatts);
    eallatts = new Vector();
    onerolesmap.put("DataType", eallatts);
    instancemap.put("primitivetypes", new Vector()); 
    instancemap.put("primitivetype",new Vector()); 
    entcodes.add("primitivetypes");
    entcodes.add("primitivetype");
    entmap.put("primitivetypes","PrimitiveType");
    entmap.put("primitivetype","PrimitiveType");
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    allattsmap.put("PrimitiveType", eallatts);
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    stringattsmap.put("PrimitiveType", eallatts);
    eallatts = new Vector();
    onerolesmap.put("PrimitiveType", eallatts);
    instancemap.put("entitys", new Vector()); 
    instancemap.put("entity",new Vector()); 
    entcodes.add("entitys");
    entcodes.add("entity");
    entmap.put("entitys","Entity");
    entmap.put("entity","Entity");
    eallatts = new Vector();
    eallatts.add("isAbstract");
    eallatts.add("isInterface");
    eallatts.add("typeId");
    eallatts.add("name");
    allattsmap.put("Entity", eallatts);
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    stringattsmap.put("Entity", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Entity", eallatts);
    instancemap.put("collectiontypes", new Vector()); 
    instancemap.put("collectiontype",new Vector()); 
    entcodes.add("collectiontypes");
    entcodes.add("collectiontype");
    entmap.put("collectiontypes","CollectionType");
    entmap.put("collectiontype","CollectionType");
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    allattsmap.put("CollectionType", eallatts);
    eallatts = new Vector();
    eallatts.add("typeId");
    eallatts.add("name");
    stringattsmap.put("CollectionType", eallatts);
    eallatts = new Vector();
    eallatts.add("elementType");
    eallatts.add("keyType");
    onerolesmap.put("CollectionType", eallatts);
    instancemap.put("expressions", new Vector()); 
    instancemap.put("expression",new Vector()); 
    entcodes.add("expressions");
    entcodes.add("expression");
    entmap.put("expressions","Expression");
    entmap.put("expression","Expression");
    eallatts = new Vector();
    eallatts.add("needsBracket");
    eallatts.add("umlKind");
    eallatts.add("expId");
    eallatts.add("isStatic");
    allattsmap.put("Expression", eallatts);
    eallatts = new Vector();
    eallatts.add("expId");
    stringattsmap.put("Expression", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("Expression", eallatts);
    instancemap.put("binaryexpressions", new Vector()); 
    instancemap.put("binaryexpression",new Vector()); 
    entcodes.add("binaryexpressions");
    entcodes.add("binaryexpression");
    entmap.put("binaryexpressions","BinaryExpression");
    entmap.put("binaryexpression","BinaryExpression");
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("variable");
    eallatts.add("needsBracket");
    eallatts.add("umlKind");
    eallatts.add("expId");
    eallatts.add("isStatic");
    allattsmap.put("BinaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("variable");
    eallatts.add("expId");
    stringattsmap.put("BinaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("left");
    eallatts.add("right");
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("BinaryExpression", eallatts);
    instancemap.put("unaryexpressions", new Vector()); 
    instancemap.put("unaryexpression",new Vector()); 
    entcodes.add("unaryexpressions");
    entcodes.add("unaryexpression");
    entmap.put("unaryexpressions","UnaryExpression");
    entmap.put("unaryexpression","UnaryExpression");
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("variable");
    eallatts.add("needsBracket");
    eallatts.add("umlKind");
    eallatts.add("expId");
    eallatts.add("isStatic");
    allattsmap.put("UnaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("operator");
    eallatts.add("variable");
    eallatts.add("expId");
    stringattsmap.put("UnaryExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("argument");
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("UnaryExpression", eallatts);
    instancemap.put("collectionexpressions", new Vector()); 
    instancemap.put("collectionexpression",new Vector()); 
    entcodes.add("collectionexpressions");
    entcodes.add("collectionexpression");
    entmap.put("collectionexpressions","CollectionExpression");
    entmap.put("collectionexpression","CollectionExpression");
    eallatts = new Vector();
    eallatts.add("isOrdered");
    eallatts.add("needsBracket");
    eallatts.add("umlKind");
    eallatts.add("expId");
    eallatts.add("isStatic");
    allattsmap.put("CollectionExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("expId");
    stringattsmap.put("CollectionExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("CollectionExpression", eallatts);
    instancemap.put("basicexpressions", new Vector()); 
    instancemap.put("basicexpression",new Vector()); 
    entcodes.add("basicexpressions");
    entcodes.add("basicexpression");
    entmap.put("basicexpressions","BasicExpression");
    entmap.put("basicexpression","BasicExpression");
    eallatts = new Vector();
    eallatts.add("data");
    eallatts.add("prestate");
    eallatts.add("needsBracket");
    eallatts.add("umlKind");
    eallatts.add("expId");
    eallatts.add("isStatic");
    allattsmap.put("BasicExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("data");
    eallatts.add("expId");
    stringattsmap.put("BasicExpression", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("BasicExpression", eallatts);
    instancemap.put("propertys", new Vector()); 
    instancemap.put("property",new Vector()); 
    entcodes.add("propertys");
    entcodes.add("property");
    entmap.put("propertys","Property");
    entmap.put("property","Property");
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("lower");
    eallatts.add("upper");
    eallatts.add("isOrdered");
    eallatts.add("isUnique");
    eallatts.add("isDerived");
    eallatts.add("isReadOnly");
    eallatts.add("isStatic");
    allattsmap.put("Property", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    stringattsmap.put("Property", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("initialValue");
    eallatts.add("owner");
    onerolesmap.put("Property", eallatts);
    instancemap.put("exp2cs", new Vector()); 
    instancemap.put("exp2c",new Vector()); 
    entcodes.add("exp2cs");
    entcodes.add("exp2c");
    entmap.put("exp2cs","Exp2C");
    entmap.put("exp2c","Exp2C");
    eallatts = new Vector();
    allattsmap.put("Exp2C", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Exp2C", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Exp2C", eallatts);
    instancemap.put("cprimitivetypes", new Vector()); 
    instancemap.put("cprimitivetype",new Vector()); 
    entcodes.add("cprimitivetypes");
    entcodes.add("cprimitivetype");
    entmap.put("cprimitivetypes","CPrimitiveType");
    entmap.put("cprimitivetype","CPrimitiveType");
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("ctypeId");
    eallatts.add("name");
    allattsmap.put("CPrimitiveType", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("ctypeId");
    eallatts.add("name");
    stringattsmap.put("CPrimitiveType", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CPrimitiveType", eallatts);
    instancemap.put("carraytypes", new Vector()); 
    instancemap.put("carraytype",new Vector()); 
    entcodes.add("carraytypes");
    entcodes.add("carraytype");
    entmap.put("carraytypes","CArrayType");
    entmap.put("carraytype","CArrayType");
    eallatts = new Vector();
    eallatts.add("duplicates");
    eallatts.add("ctypeId");
    eallatts.add("name");
    allattsmap.put("CArrayType", eallatts);
    eallatts = new Vector();
    eallatts.add("ctypeId");
    eallatts.add("name");
    stringattsmap.put("CArrayType", eallatts);
    eallatts = new Vector();
    eallatts.add("componentType");
    onerolesmap.put("CArrayType", eallatts);
    instancemap.put("cpointertypes", new Vector()); 
    instancemap.put("cpointertype",new Vector()); 
    entcodes.add("cpointertypes");
    entcodes.add("cpointertype");
    entmap.put("cpointertypes","CPointerType");
    entmap.put("cpointertype","CPointerType");
    eallatts = new Vector();
    eallatts.add("ctypeId");
    eallatts.add("name");
    allattsmap.put("CPointerType", eallatts);
    eallatts = new Vector();
    eallatts.add("ctypeId");
    eallatts.add("name");
    stringattsmap.put("CPointerType", eallatts);
    eallatts = new Vector();
    eallatts.add("pointsTo");
    onerolesmap.put("CPointerType", eallatts);
    instancemap.put("cstructs", new Vector()); 
    instancemap.put("cstruct",new Vector()); 
    entcodes.add("cstructs");
    entcodes.add("cstruct");
    entmap.put("cstructs","CStruct");
    entmap.put("cstruct","CStruct");
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("ctypeId");
    eallatts.add("name");
    allattsmap.put("CStruct", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("ctypeId");
    eallatts.add("name");
    stringattsmap.put("CStruct", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CStruct", eallatts);
    instancemap.put("cmembers", new Vector()); 
    instancemap.put("cmember",new Vector()); 
    entcodes.add("cmembers");
    entcodes.add("cmember");
    entmap.put("cmembers","CMember");
    entmap.put("cmember","CMember");
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("isKey");
    allattsmap.put("CMember", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    stringattsmap.put("CMember", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    onerolesmap.put("CMember", eallatts);
    instancemap.put("cvariables", new Vector()); 
    instancemap.put("cvariable",new Vector()); 
    entcodes.add("cvariables");
    entcodes.add("cvariable");
    entmap.put("cvariables","CVariable");
    entmap.put("cvariable","CVariable");
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("kind");
    eallatts.add("initialisation");
    allattsmap.put("CVariable", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("kind");
    eallatts.add("initialisation");
    stringattsmap.put("CVariable", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    onerolesmap.put("CVariable", eallatts);
    instancemap.put("cprograms", new Vector()); 
    instancemap.put("cprogram",new Vector()); 
    entcodes.add("cprograms");
    entcodes.add("cprogram");
    entmap.put("cprograms","CProgram");
    entmap.put("cprogram","CProgram");
    eallatts = new Vector();
    allattsmap.put("CProgram", eallatts);
    eallatts = new Vector();
    stringattsmap.put("CProgram", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CProgram", eallatts);
    instancemap.put("cfunctionpointertypes", new Vector()); 
    instancemap.put("cfunctionpointertype",new Vector()); 
    entcodes.add("cfunctionpointertypes");
    entcodes.add("cfunctionpointertype");
    entmap.put("cfunctionpointertypes","CFunctionPointerType");
    entmap.put("cfunctionpointertype","CFunctionPointerType");
    eallatts = new Vector();
    eallatts.add("ctypeId");
    eallatts.add("name");
    allattsmap.put("CFunctionPointerType", eallatts);
    eallatts = new Vector();
    eallatts.add("ctypeId");
    eallatts.add("name");
    stringattsmap.put("CFunctionPointerType", eallatts);
    eallatts = new Vector();
    eallatts.add("domainType");
    eallatts.add("rangeType");
    onerolesmap.put("CFunctionPointerType", eallatts);
    instancemap.put("coperations", new Vector()); 
    instancemap.put("coperation",new Vector()); 
    entcodes.add("coperations");
    entcodes.add("coperation");
    entmap.put("coperations","COperation");
    entmap.put("coperation","COperation");
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("opId");
    eallatts.add("isStatic");
    eallatts.add("scope");
    eallatts.add("isQuery");
    allattsmap.put("COperation", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("opId");
    eallatts.add("scope");
    stringattsmap.put("COperation", eallatts);
    eallatts = new Vector();
    eallatts.add("returnType");
    eallatts.add("code");
    onerolesmap.put("COperation", eallatts);
    instancemap.put("statements", new Vector()); 
    instancemap.put("statement",new Vector()); 
    entcodes.add("statements");
    entcodes.add("statement");
    entmap.put("statements","Statement");
    entmap.put("statement","Statement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("Statement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("Statement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Statement", eallatts);
    instancemap.put("returnstatements", new Vector()); 
    instancemap.put("returnstatement",new Vector()); 
    entcodes.add("returnstatements");
    entcodes.add("returnstatement");
    entmap.put("returnstatements","ReturnStatement");
    entmap.put("returnstatement","ReturnStatement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("ReturnStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("ReturnStatement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("ReturnStatement", eallatts);
    instancemap.put("behaviouralfeatures", new Vector()); 
    instancemap.put("behaviouralfeature",new Vector()); 
    entcodes.add("behaviouralfeatures");
    entcodes.add("behaviouralfeature");
    entmap.put("behaviouralfeatures","BehaviouralFeature");
    entmap.put("behaviouralfeature","BehaviouralFeature");
    eallatts = new Vector();
    eallatts.add("name");
    eallatts.add("isStatic");
    allattsmap.put("BehaviouralFeature", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    stringattsmap.put("BehaviouralFeature", eallatts);
    eallatts = new Vector();
    eallatts.add("activity");
    onerolesmap.put("BehaviouralFeature", eallatts);
    instancemap.put("operations", new Vector()); 
    instancemap.put("operation",new Vector()); 
    entcodes.add("operations");
    entcodes.add("operation");
    entmap.put("operations","Operation");
    entmap.put("operation","Operation");
    eallatts = new Vector();
    eallatts.add("isQuery");
    eallatts.add("isCached");
    eallatts.add("isStatic");
    eallatts.add("name");
    eallatts.add("isStatic");
    allattsmap.put("Operation", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    stringattsmap.put("Operation", eallatts);
    eallatts = new Vector();
    eallatts.add("owner");
    eallatts.add("activity");
    onerolesmap.put("Operation", eallatts);
    instancemap.put("usecases", new Vector()); 
    instancemap.put("usecase",new Vector()); 
    entcodes.add("usecases");
    entcodes.add("usecase");
    entmap.put("usecases","UseCase");
    entmap.put("usecase","UseCase");
    eallatts = new Vector();
    eallatts.add("name");
    allattsmap.put("UseCase", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    stringattsmap.put("UseCase", eallatts);
    eallatts = new Vector();
    eallatts.add("resultType");
    eallatts.add("classifierBehaviour");
    onerolesmap.put("UseCase", eallatts);
    instancemap.put("breakstatements", new Vector()); 
    instancemap.put("breakstatement",new Vector()); 
    entcodes.add("breakstatements");
    entcodes.add("breakstatement");
    entmap.put("breakstatements","BreakStatement");
    entmap.put("breakstatement","BreakStatement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("BreakStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("BreakStatement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("BreakStatement", eallatts);
    instancemap.put("operationcallstatements", new Vector()); 
    instancemap.put("operationcallstatement",new Vector()); 
    entcodes.add("operationcallstatements");
    entcodes.add("operationcallstatement");
    entmap.put("operationcallstatements","OperationCallStatement");
    entmap.put("operationcallstatement","OperationCallStatement");
    eallatts = new Vector();
    eallatts.add("assignsTo");
    eallatts.add("statId");
    allattsmap.put("OperationCallStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("assignsTo");
    eallatts.add("statId");
    stringattsmap.put("OperationCallStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("callExp");
    onerolesmap.put("OperationCallStatement", eallatts);
    instancemap.put("implicitcallstatements", new Vector()); 
    instancemap.put("implicitcallstatement",new Vector()); 
    entcodes.add("implicitcallstatements");
    entcodes.add("implicitcallstatement");
    entmap.put("implicitcallstatements","ImplicitCallStatement");
    entmap.put("implicitcallstatement","ImplicitCallStatement");
    eallatts = new Vector();
    eallatts.add("assignsTo");
    eallatts.add("statId");
    allattsmap.put("ImplicitCallStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("assignsTo");
    eallatts.add("statId");
    stringattsmap.put("ImplicitCallStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("callExp");
    onerolesmap.put("ImplicitCallStatement", eallatts);
    instancemap.put("loopstatements", new Vector()); 
    instancemap.put("loopstatement",new Vector()); 
    entcodes.add("loopstatements");
    entcodes.add("loopstatement");
    entmap.put("loopstatements","LoopStatement");
    entmap.put("loopstatement","LoopStatement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("LoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("LoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("test");
    eallatts.add("body");
    onerolesmap.put("LoopStatement", eallatts);
    instancemap.put("boundedloopstatements", new Vector()); 
    instancemap.put("boundedloopstatement",new Vector()); 
    entcodes.add("boundedloopstatements");
    entcodes.add("boundedloopstatement");
    entmap.put("boundedloopstatements","BoundedLoopStatement");
    entmap.put("boundedloopstatement","BoundedLoopStatement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("BoundedLoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("BoundedLoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("loopRange");
    eallatts.add("loopVar");
    eallatts.add("test");
    eallatts.add("body");
    onerolesmap.put("BoundedLoopStatement", eallatts);
    instancemap.put("unboundedloopstatements", new Vector()); 
    instancemap.put("unboundedloopstatement",new Vector()); 
    entcodes.add("unboundedloopstatements");
    entcodes.add("unboundedloopstatement");
    entmap.put("unboundedloopstatements","UnboundedLoopStatement");
    entmap.put("unboundedloopstatement","UnboundedLoopStatement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("UnboundedLoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("UnboundedLoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("test");
    eallatts.add("body");
    onerolesmap.put("UnboundedLoopStatement", eallatts);
    instancemap.put("assignstatements", new Vector()); 
    instancemap.put("assignstatement",new Vector()); 
    entcodes.add("assignstatements");
    entcodes.add("assignstatement");
    entmap.put("assignstatements","AssignStatement");
    entmap.put("assignstatement","AssignStatement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("AssignStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("AssignStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("left");
    eallatts.add("right");
    onerolesmap.put("AssignStatement", eallatts);
    instancemap.put("sequencestatements", new Vector()); 
    instancemap.put("sequencestatement",new Vector()); 
    entcodes.add("sequencestatements");
    entcodes.add("sequencestatement");
    entmap.put("sequencestatements","SequenceStatement");
    entmap.put("sequencestatement","SequenceStatement");
    eallatts = new Vector();
    eallatts.add("kind");
    eallatts.add("statId");
    allattsmap.put("SequenceStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("SequenceStatement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("SequenceStatement", eallatts);
    instancemap.put("conditionalstatements", new Vector()); 
    instancemap.put("conditionalstatement",new Vector()); 
    entcodes.add("conditionalstatements");
    entcodes.add("conditionalstatement");
    entmap.put("conditionalstatements","ConditionalStatement");
    entmap.put("conditionalstatement","ConditionalStatement");
    eallatts = new Vector();
    eallatts.add("statId");
    allattsmap.put("ConditionalStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("statId");
    stringattsmap.put("ConditionalStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("test");
    eallatts.add("ifPart");
    onerolesmap.put("ConditionalStatement", eallatts);
    instancemap.put("creationstatements", new Vector()); 
    instancemap.put("creationstatement",new Vector()); 
    entcodes.add("creationstatements");
    entcodes.add("creationstatement");
    entmap.put("creationstatements","CreationStatement");
    entmap.put("creationstatement","CreationStatement");
    eallatts = new Vector();
    eallatts.add("createsInstanceOf");
    eallatts.add("assignsTo");
    eallatts.add("statId");
    allattsmap.put("CreationStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("createsInstanceOf");
    eallatts.add("assignsTo");
    eallatts.add("statId");
    stringattsmap.put("CreationStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("CreationStatement", eallatts);
    instancemap.put("cstatements", new Vector()); 
    instancemap.put("cstatement",new Vector()); 
    entcodes.add("cstatements");
    entcodes.add("cstatement");
    entmap.put("cstatements","CStatement");
    entmap.put("cstatement","CStatement");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("CStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("CStatement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CStatement", eallatts);
    instancemap.put("creturnstatements", new Vector()); 
    instancemap.put("creturnstatement",new Vector()); 
    entcodes.add("creturnstatements");
    entcodes.add("creturnstatement");
    entmap.put("creturnstatements","CReturnStatement");
    entmap.put("creturnstatement","CReturnStatement");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("CReturnStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("CReturnStatement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CReturnStatement", eallatts);
    instancemap.put("cbreakstatements", new Vector()); 
    instancemap.put("cbreakstatement",new Vector()); 
    entcodes.add("cbreakstatements");
    entcodes.add("cbreakstatement");
    entmap.put("cbreakstatements","CBreakStatement");
    entmap.put("cbreakstatement","CBreakStatement");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("CBreakStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("CBreakStatement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CBreakStatement", eallatts);
    instancemap.put("opcallstatements", new Vector()); 
    instancemap.put("opcallstatement",new Vector()); 
    entcodes.add("opcallstatements");
    entcodes.add("opcallstatement");
    entmap.put("opcallstatements","OpCallStatement");
    entmap.put("opcallstatement","OpCallStatement");
    eallatts = new Vector();
    eallatts.add("assignsTo");
    eallatts.add("cstatId");
    allattsmap.put("OpCallStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("assignsTo");
    eallatts.add("cstatId");
    stringattsmap.put("OpCallStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("callExp");
    onerolesmap.put("OpCallStatement", eallatts);
    instancemap.put("cloopstatements", new Vector()); 
    instancemap.put("cloopstatement",new Vector()); 
    entcodes.add("cloopstatements");
    entcodes.add("cloopstatement");
    entmap.put("cloopstatements","CLoopStatement");
    entmap.put("cloopstatement","CLoopStatement");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("CLoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("CLoopStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("test");
    eallatts.add("body");
    onerolesmap.put("CLoopStatement", eallatts);
    instancemap.put("forloops", new Vector()); 
    instancemap.put("forloop",new Vector()); 
    entcodes.add("forloops");
    entcodes.add("forloop");
    entmap.put("forloops","ForLoop");
    entmap.put("forloop","ForLoop");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("ForLoop", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("ForLoop", eallatts);
    eallatts = new Vector();
    eallatts.add("increment");
    eallatts.add("loopVar");
    eallatts.add("loopRange");
    eallatts.add("test");
    eallatts.add("body");
    onerolesmap.put("ForLoop", eallatts);
    instancemap.put("whileloops", new Vector()); 
    instancemap.put("whileloop",new Vector()); 
    entcodes.add("whileloops");
    entcodes.add("whileloop");
    entmap.put("whileloops","WhileLoop");
    entmap.put("whileloop","WhileLoop");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("WhileLoop", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("WhileLoop", eallatts);
    eallatts = new Vector();
    eallatts.add("test");
    eallatts.add("body");
    onerolesmap.put("WhileLoop", eallatts);
    instancemap.put("cassignments", new Vector()); 
    instancemap.put("cassignment",new Vector()); 
    entcodes.add("cassignments");
    entcodes.add("cassignment");
    entmap.put("cassignments","CAssignment");
    entmap.put("cassignment","CAssignment");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("CAssignment", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("CAssignment", eallatts);
    eallatts = new Vector();
    eallatts.add("left");
    eallatts.add("right");
    onerolesmap.put("CAssignment", eallatts);
    instancemap.put("csequencestatements", new Vector()); 
    instancemap.put("csequencestatement",new Vector()); 
    entcodes.add("csequencestatements");
    entcodes.add("csequencestatement");
    entmap.put("csequencestatements","CSequenceStatement");
    entmap.put("csequencestatement","CSequenceStatement");
    eallatts = new Vector();
    eallatts.add("kind");
    eallatts.add("cstatId");
    allattsmap.put("CSequenceStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("CSequenceStatement", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CSequenceStatement", eallatts);
    instancemap.put("ifstatements", new Vector()); 
    instancemap.put("ifstatement",new Vector()); 
    entcodes.add("ifstatements");
    entcodes.add("ifstatement");
    entmap.put("ifstatements","IfStatement");
    entmap.put("ifstatement","IfStatement");
    eallatts = new Vector();
    eallatts.add("cstatId");
    allattsmap.put("IfStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("cstatId");
    stringattsmap.put("IfStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("test");
    eallatts.add("ifPart");
    onerolesmap.put("IfStatement", eallatts);
    instancemap.put("declarationstatements", new Vector()); 
    instancemap.put("declarationstatement",new Vector()); 
    entcodes.add("declarationstatements");
    entcodes.add("declarationstatement");
    entmap.put("declarationstatements","DeclarationStatement");
    entmap.put("declarationstatement","DeclarationStatement");
    eallatts = new Vector();
    eallatts.add("createsInstanceOf");
    eallatts.add("assignsTo");
    eallatts.add("cstatId");
    allattsmap.put("DeclarationStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("createsInstanceOf");
    eallatts.add("assignsTo");
    eallatts.add("cstatId");
    stringattsmap.put("DeclarationStatement", eallatts);
    eallatts = new Vector();
    eallatts.add("type");
    eallatts.add("elementType");
    onerolesmap.put("DeclarationStatement", eallatts);
    instancemap.put("printcodes", new Vector()); 
    instancemap.put("printcode",new Vector()); 
    entcodes.add("printcodes");
    entcodes.add("printcode");
    entmap.put("printcodes","Printcode");
    entmap.put("printcode","Printcode");
    eallatts = new Vector();
    allattsmap.put("Printcode", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Printcode", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Printcode", eallatts);
    eallatts = new Vector();
  Vector enodes = xml.getSubnodes();
  for (int i = 0; i < enodes.size(); i++)
  { XMLNode enode = (XMLNode) enodes.get(i);
    String cname = enode.getTag();
    Vector einstances = (Vector) instancemap.get(cname); 
    if (einstances == null) 
    { einstances = (Vector) instancemap.get(cname + "s"); }
    if (einstances != null) 
    { einstances.add(enode); }
  }
  for (int j = 0; j < entcodes.size(); j++)
  { String ename = (String) entcodes.get(j);
    Vector elems = (Vector) instancemap.get(ename);
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = enode.getAttributeValue("xsi:type"); 
      if (tname == null) 
      { tname = (String) entmap.get(ename); } 
      else 
      { int colonind = tname.indexOf(":"); 
        if (colonind >= 0)
        { tname = tname.substring(colonind + 1,tname.length()); }
      }
      res.add(ename + k + " : " + tname);
      actualtype.put(enode,tname);
    }   
  }
  for (int j = 0; j < entcodes.size(); j++) 
  { String ename = (String) entcodes.get(j); 
    Vector elems = (Vector) instancemap.get(ename); 
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = (String) actualtype.get(enode);
      Vector tallatts = (Vector)  allattsmap.get(tname);
      Vector tstringatts = (Vector)  stringattsmap.get(tname);
      Vector toneroles = (Vector)  onerolesmap.get(tname);
      Vector atts = enode.getAttributes();
      for (int p = 0; p < atts.size(); p++) 
      { XMLAttribute patt = (XMLAttribute) atts.get(p); 
        if (patt.getName().equals("xsi:type") || patt.getName().equals("xmi:id")) {} 
        else 
        { patt.getDataDeclarationFromXsi(res,tallatts,tstringatts,toneroles,ename + k, (String) entmap.get(ename)); } 
      }
    } 
  }  
  return res; } 

  public void saveXSI(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    out.println("<UMLRSDS:model xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\">");
    for (int _i = 0; _i < cbinaryexpressions.size(); _i++)
    { CBinaryExpression cbinaryexpressionx_ = (CBinaryExpression) cbinaryexpressions.get(_i);
       out.print("<cbinaryexpressions xsi:type=\"My:CBinaryExpression\"");
    out.print(" operator=\"" + cbinaryexpressionx_.getoperator() + "\" ");
    out.print(" needsBracket=\"" + cbinaryexpressionx_.getneedsBracket() + "\" ");
    out.print(" kind=\"" + cbinaryexpressionx_.getkind() + "\" ");
    out.print(" cexpId=\"" + cbinaryexpressionx_.getcexpId() + "\" ");
    out.print(" isStatic=\"" + cbinaryexpressionx_.getisStatic() + "\" ");
    if (cbinaryexpressionx_.getleft() instanceof CUnaryExpression)
    {   out.print(" left=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getleft()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getleft() instanceof CBasicExpression)
    {   out.print(" left=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getleft()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getleft() instanceof CBinaryExpression)
    {   out.print(" left=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getleft()));
    out.print("\""); }
    if (cbinaryexpressionx_.getright() instanceof CUnaryExpression)
    {   out.print(" right=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getright()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getright() instanceof CBasicExpression)
    {   out.print(" right=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getright()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getright() instanceof CBinaryExpression)
    {   out.print(" right=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getright()));
    out.print("\""); }
    if (cbinaryexpressionx_.gettype() instanceof CFunctionPointerType)
    {   out.print(" type=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.gettype() instanceof CStruct)
    {   out.print(" type=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.gettype() instanceof CPrimitiveType)
    {   out.print(" type=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.gettype() instanceof CPointerType)
    {   out.print(" type=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.gettype() instanceof CArrayType)
    {   out.print(" type=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).gettype()));
    out.print("\""); }
    if (cbinaryexpressionx_.getelementType() instanceof CFunctionPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getelementType() instanceof CStruct)
    {   out.print(" elementType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getelementType() instanceof CPrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getelementType() instanceof CPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbinaryexpressionx_.getelementType() instanceof CArrayType)
    {   out.print(" elementType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CBinaryExpression) cbinaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < cunaryexpressions.size(); _i++)
    { CUnaryExpression cunaryexpressionx_ = (CUnaryExpression) cunaryexpressions.get(_i);
       out.print("<cunaryexpressions xsi:type=\"My:CUnaryExpression\"");
    out.print(" operator=\"" + cunaryexpressionx_.getoperator() + "\" ");
    out.print(" needsBracket=\"" + cunaryexpressionx_.getneedsBracket() + "\" ");
    out.print(" kind=\"" + cunaryexpressionx_.getkind() + "\" ");
    out.print(" cexpId=\"" + cunaryexpressionx_.getcexpId() + "\" ");
    out.print(" isStatic=\"" + cunaryexpressionx_.getisStatic() + "\" ");
    if (cunaryexpressionx_.getargument() instanceof CUnaryExpression)
    {   out.print(" argument=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getargument()));
    out.print("\""); }
 else    if (cunaryexpressionx_.getargument() instanceof CBasicExpression)
    {   out.print(" argument=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getargument()));
    out.print("\""); }
 else    if (cunaryexpressionx_.getargument() instanceof CBinaryExpression)
    {   out.print(" argument=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getargument()));
    out.print("\""); }
    if (cunaryexpressionx_.gettype() instanceof CFunctionPointerType)
    {   out.print(" type=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cunaryexpressionx_.gettype() instanceof CStruct)
    {   out.print(" type=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cunaryexpressionx_.gettype() instanceof CPrimitiveType)
    {   out.print(" type=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cunaryexpressionx_.gettype() instanceof CPointerType)
    {   out.print(" type=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cunaryexpressionx_.gettype() instanceof CArrayType)
    {   out.print(" type=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).gettype()));
    out.print("\""); }
    if (cunaryexpressionx_.getelementType() instanceof CFunctionPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cunaryexpressionx_.getelementType() instanceof CStruct)
    {   out.print(" elementType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cunaryexpressionx_.getelementType() instanceof CPrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cunaryexpressionx_.getelementType() instanceof CPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cunaryexpressionx_.getelementType() instanceof CArrayType)
    {   out.print(" elementType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CUnaryExpression) cunaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < cbasicexpressions.size(); _i++)
    { CBasicExpression cbasicexpressionx_ = (CBasicExpression) cbasicexpressions.get(_i);
       out.print("<cbasicexpressions xsi:type=\"My:CBasicExpression\"");
    out.print(" data=\"" + cbasicexpressionx_.getdata() + "\" ");
    out.print(" needsBracket=\"" + cbasicexpressionx_.getneedsBracket() + "\" ");
    out.print(" kind=\"" + cbasicexpressionx_.getkind() + "\" ");
    out.print(" cexpId=\"" + cbasicexpressionx_.getcexpId() + "\" ");
    out.print(" isStatic=\"" + cbasicexpressionx_.getisStatic() + "\" ");
    out.print(" parameters = \"");
    List cbasicexpression_parameters = cbasicexpressionx_.getparameters();
    for (int _k = 0; _k < cbasicexpression_parameters.size(); _k++)
    {      if (cbasicexpression_parameters.get(_k) instanceof CUnaryExpression)
      { out.print(" //@cunaryexpressions." + cunaryexpressions.indexOf(cbasicexpression_parameters.get(_k)));
    }
 else      if (cbasicexpression_parameters.get(_k) instanceof CBasicExpression)
      { out.print(" //@cbasicexpressions." + cbasicexpressions.indexOf(cbasicexpression_parameters.get(_k)));
    }
 else      if (cbasicexpression_parameters.get(_k) instanceof CBinaryExpression)
      { out.print(" //@cbinaryexpressions." + cbinaryexpressions.indexOf(cbasicexpression_parameters.get(_k)));
    }
  }
    out.print("\"");
    out.print(" arrayIndex = \"");
    List cbasicexpression_arrayIndex = cbasicexpressionx_.getarrayIndex();
    for (int _j = 0; _j < cbasicexpression_arrayIndex.size(); _j++)
    { out.print(" //@cbasicexpressions." + cbasicexpressions.indexOf(cbasicexpression_arrayIndex.get(_j)));
    }
    out.print("\"");
    out.print(" reference = \"");
    List cbasicexpression_reference = cbasicexpressionx_.getreference();
    for (int _j = 0; _j < cbasicexpression_reference.size(); _j++)
    { out.print(" //@cbasicexpressions." + cbasicexpressions.indexOf(cbasicexpression_reference.get(_j)));
    }
    out.print("\"");
    if (cbasicexpressionx_.gettype() instanceof CFunctionPointerType)
    {   out.print(" type=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbasicexpressionx_.gettype() instanceof CStruct)
    {   out.print(" type=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbasicexpressionx_.gettype() instanceof CPrimitiveType)
    {   out.print(" type=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbasicexpressionx_.gettype() instanceof CPointerType)
    {   out.print(" type=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (cbasicexpressionx_.gettype() instanceof CArrayType)
    {   out.print(" type=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).gettype()));
    out.print("\""); }
    if (cbasicexpressionx_.getelementType() instanceof CFunctionPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbasicexpressionx_.getelementType() instanceof CStruct)
    {   out.print(" elementType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbasicexpressionx_.getelementType() instanceof CPrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbasicexpressionx_.getelementType() instanceof CPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (cbasicexpressionx_.getelementType() instanceof CArrayType)
    {   out.print(" elementType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CBasicExpression) cbasicexpressions.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < primitivetypes.size(); _i++)
    { PrimitiveType primitivetypex_ = (PrimitiveType) primitivetypes.get(_i);
       out.print("<primitivetypes xsi:type=\"My:PrimitiveType\"");
    out.print(" typeId=\"" + primitivetypex_.gettypeId() + "\" ");
    out.print(" name=\"" + primitivetypex_.getname() + "\" ");
    out.println(" />");
  }

    for (int _i = 0; _i < entitys.size(); _i++)
    { Entity entityx_ = (Entity) entitys.get(_i);
       out.print("<entitys xsi:type=\"My:Entity\"");
    out.print(" isAbstract=\"" + entityx_.getisAbstract() + "\" ");
    out.print(" isInterface=\"" + entityx_.getisInterface() + "\" ");
    out.print(" typeId=\"" + entityx_.gettypeId() + "\" ");
    out.print(" name=\"" + entityx_.getname() + "\" ");
    out.print(" ownedOperation = \"");
    List entity_ownedOperation = entityx_.getownedOperation();
    for (int _j = 0; _j < entity_ownedOperation.size(); _j++)
    { out.print(" //@operations." + operations.indexOf(entity_ownedOperation.get(_j)));
    }
    out.print("\"");
    out.print(" ownedAttribute = \"");
    List entity_ownedAttribute = entityx_.getownedAttribute();
    for (int _j = 0; _j < entity_ownedAttribute.size(); _j++)
    { out.print(" //@propertys." + propertys.indexOf(entity_ownedAttribute.get(_j)));
    }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < collectiontypes.size(); _i++)
    { CollectionType collectiontypex_ = (CollectionType) collectiontypes.get(_i);
       out.print("<collectiontypes xsi:type=\"My:CollectionType\"");
    out.print(" typeId=\"" + collectiontypex_.gettypeId() + "\" ");
    out.print(" name=\"" + collectiontypex_.getname() + "\" ");
    if (collectiontypex_.getelementType() instanceof Entity)
    {   out.print(" elementType=\"");
    out.print("//@entitys." + entitys.indexOf(((CollectionType) collectiontypes.get(_i)).getelementType()));
    out.print("\""); }
 else    if (collectiontypex_.getelementType() instanceof PrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((CollectionType) collectiontypes.get(_i)).getelementType()));
    out.print("\""); }
 else    if (collectiontypex_.getelementType() instanceof CollectionType)
    {   out.print(" elementType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((CollectionType) collectiontypes.get(_i)).getelementType()));
    out.print("\""); }
    if (collectiontypex_.getkeyType() instanceof Entity)
    {   out.print(" keyType=\"");
    out.print("//@entitys." + entitys.indexOf(((CollectionType) collectiontypes.get(_i)).getkeyType()));
    out.print("\""); }
 else    if (collectiontypex_.getkeyType() instanceof PrimitiveType)
    {   out.print(" keyType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((CollectionType) collectiontypes.get(_i)).getkeyType()));
    out.print("\""); }
 else    if (collectiontypex_.getkeyType() instanceof CollectionType)
    {   out.print(" keyType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((CollectionType) collectiontypes.get(_i)).getkeyType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < binaryexpressions.size(); _i++)
    { BinaryExpression binaryexpressionx_ = (BinaryExpression) binaryexpressions.get(_i);
       out.print("<binaryexpressions xsi:type=\"My:BinaryExpression\"");
    out.print(" operator=\"" + binaryexpressionx_.getoperator() + "\" ");
    out.print(" variable=\"" + binaryexpressionx_.getvariable() + "\" ");
    out.print(" needsBracket=\"" + binaryexpressionx_.getneedsBracket() + "\" ");
    out.print(" umlKind=\"" + binaryexpressionx_.getumlKind() + "\" ");
    out.print(" expId=\"" + binaryexpressionx_.getexpId() + "\" ");
    out.print(" isStatic=\"" + binaryexpressionx_.getisStatic() + "\" ");
    if (binaryexpressionx_.getleft() instanceof UnaryExpression)
    {   out.print(" left=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getleft()));
    out.print("\""); }
 else    if (binaryexpressionx_.getleft() instanceof BasicExpression)
    {   out.print(" left=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getleft()));
    out.print("\""); }
 else    if (binaryexpressionx_.getleft() instanceof BinaryExpression)
    {   out.print(" left=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getleft()));
    out.print("\""); }
 else    if (binaryexpressionx_.getleft() instanceof CollectionExpression)
    {   out.print(" left=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getleft()));
    out.print("\""); }
    if (binaryexpressionx_.getright() instanceof UnaryExpression)
    {   out.print(" right=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getright()));
    out.print("\""); }
 else    if (binaryexpressionx_.getright() instanceof BasicExpression)
    {   out.print(" right=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getright()));
    out.print("\""); }
 else    if (binaryexpressionx_.getright() instanceof BinaryExpression)
    {   out.print(" right=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getright()));
    out.print("\""); }
 else    if (binaryexpressionx_.getright() instanceof CollectionExpression)
    {   out.print(" right=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getright()));
    out.print("\""); }
    if (binaryexpressionx_.gettype() instanceof Entity)
    {   out.print(" type=\"");
    out.print("//@entitys." + entitys.indexOf(((BinaryExpression) binaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (binaryexpressionx_.gettype() instanceof PrimitiveType)
    {   out.print(" type=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((BinaryExpression) binaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (binaryexpressionx_.gettype() instanceof CollectionType)
    {   out.print(" type=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((BinaryExpression) binaryexpressions.get(_i)).gettype()));
    out.print("\""); }
    if (binaryexpressionx_.getelementType() instanceof Entity)
    {   out.print(" elementType=\"");
    out.print("//@entitys." + entitys.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (binaryexpressionx_.getelementType() instanceof PrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (binaryexpressionx_.getelementType() instanceof CollectionType)
    {   out.print(" elementType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((BinaryExpression) binaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < unaryexpressions.size(); _i++)
    { UnaryExpression unaryexpressionx_ = (UnaryExpression) unaryexpressions.get(_i);
       out.print("<unaryexpressions xsi:type=\"My:UnaryExpression\"");
    out.print(" operator=\"" + unaryexpressionx_.getoperator() + "\" ");
    out.print(" variable=\"" + unaryexpressionx_.getvariable() + "\" ");
    out.print(" needsBracket=\"" + unaryexpressionx_.getneedsBracket() + "\" ");
    out.print(" umlKind=\"" + unaryexpressionx_.getumlKind() + "\" ");
    out.print(" expId=\"" + unaryexpressionx_.getexpId() + "\" ");
    out.print(" isStatic=\"" + unaryexpressionx_.getisStatic() + "\" ");
    if (unaryexpressionx_.getargument() instanceof UnaryExpression)
    {   out.print(" argument=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((UnaryExpression) unaryexpressions.get(_i)).getargument()));
    out.print("\""); }
 else    if (unaryexpressionx_.getargument() instanceof BasicExpression)
    {   out.print(" argument=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((UnaryExpression) unaryexpressions.get(_i)).getargument()));
    out.print("\""); }
 else    if (unaryexpressionx_.getargument() instanceof BinaryExpression)
    {   out.print(" argument=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((UnaryExpression) unaryexpressions.get(_i)).getargument()));
    out.print("\""); }
 else    if (unaryexpressionx_.getargument() instanceof CollectionExpression)
    {   out.print(" argument=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((UnaryExpression) unaryexpressions.get(_i)).getargument()));
    out.print("\""); }
    if (unaryexpressionx_.gettype() instanceof Entity)
    {   out.print(" type=\"");
    out.print("//@entitys." + entitys.indexOf(((UnaryExpression) unaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (unaryexpressionx_.gettype() instanceof PrimitiveType)
    {   out.print(" type=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((UnaryExpression) unaryexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (unaryexpressionx_.gettype() instanceof CollectionType)
    {   out.print(" type=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((UnaryExpression) unaryexpressions.get(_i)).gettype()));
    out.print("\""); }
    if (unaryexpressionx_.getelementType() instanceof Entity)
    {   out.print(" elementType=\"");
    out.print("//@entitys." + entitys.indexOf(((UnaryExpression) unaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (unaryexpressionx_.getelementType() instanceof PrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((UnaryExpression) unaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (unaryexpressionx_.getelementType() instanceof CollectionType)
    {   out.print(" elementType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((UnaryExpression) unaryexpressions.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < collectionexpressions.size(); _i++)
    { CollectionExpression collectionexpressionx_ = (CollectionExpression) collectionexpressions.get(_i);
       out.print("<collectionexpressions xsi:type=\"My:CollectionExpression\"");
    out.print(" isOrdered=\"" + collectionexpressionx_.getisOrdered() + "\" ");
    out.print(" needsBracket=\"" + collectionexpressionx_.getneedsBracket() + "\" ");
    out.print(" umlKind=\"" + collectionexpressionx_.getumlKind() + "\" ");
    out.print(" expId=\"" + collectionexpressionx_.getexpId() + "\" ");
    out.print(" isStatic=\"" + collectionexpressionx_.getisStatic() + "\" ");
    out.print(" elements = \"");
    List collectionexpression_elements = collectionexpressionx_.getelements();
    for (int _k = 0; _k < collectionexpression_elements.size(); _k++)
    {      if (collectionexpression_elements.get(_k) instanceof UnaryExpression)
      { out.print(" //@unaryexpressions." + unaryexpressions.indexOf(collectionexpression_elements.get(_k)));
    }
 else      if (collectionexpression_elements.get(_k) instanceof BasicExpression)
      { out.print(" //@basicexpressions." + basicexpressions.indexOf(collectionexpression_elements.get(_k)));
    }
 else      if (collectionexpression_elements.get(_k) instanceof BinaryExpression)
      { out.print(" //@binaryexpressions." + binaryexpressions.indexOf(collectionexpression_elements.get(_k)));
    }
 else      if (collectionexpression_elements.get(_k) instanceof CollectionExpression)
      { out.print(" //@collectionexpressions." + collectionexpressions.indexOf(collectionexpression_elements.get(_k)));
    }
  }
    out.print("\"");
    if (collectionexpressionx_.gettype() instanceof Entity)
    {   out.print(" type=\"");
    out.print("//@entitys." + entitys.indexOf(((CollectionExpression) collectionexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (collectionexpressionx_.gettype() instanceof PrimitiveType)
    {   out.print(" type=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((CollectionExpression) collectionexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (collectionexpressionx_.gettype() instanceof CollectionType)
    {   out.print(" type=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((CollectionExpression) collectionexpressions.get(_i)).gettype()));
    out.print("\""); }
    if (collectionexpressionx_.getelementType() instanceof Entity)
    {   out.print(" elementType=\"");
    out.print("//@entitys." + entitys.indexOf(((CollectionExpression) collectionexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (collectionexpressionx_.getelementType() instanceof PrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((CollectionExpression) collectionexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (collectionexpressionx_.getelementType() instanceof CollectionType)
    {   out.print(" elementType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((CollectionExpression) collectionexpressions.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < basicexpressions.size(); _i++)
    { BasicExpression basicexpressionx_ = (BasicExpression) basicexpressions.get(_i);
       out.print("<basicexpressions xsi:type=\"My:BasicExpression\"");
    out.print(" data=\"" + basicexpressionx_.getdata() + "\" ");
    out.print(" prestate=\"" + basicexpressionx_.getprestate() + "\" ");
    out.print(" needsBracket=\"" + basicexpressionx_.getneedsBracket() + "\" ");
    out.print(" umlKind=\"" + basicexpressionx_.getumlKind() + "\" ");
    out.print(" expId=\"" + basicexpressionx_.getexpId() + "\" ");
    out.print(" isStatic=\"" + basicexpressionx_.getisStatic() + "\" ");
    out.print(" parameters = \"");
    List basicexpression_parameters = basicexpressionx_.getparameters();
    for (int _k = 0; _k < basicexpression_parameters.size(); _k++)
    {      if (basicexpression_parameters.get(_k) instanceof UnaryExpression)
      { out.print(" //@unaryexpressions." + unaryexpressions.indexOf(basicexpression_parameters.get(_k)));
    }
 else      if (basicexpression_parameters.get(_k) instanceof BasicExpression)
      { out.print(" //@basicexpressions." + basicexpressions.indexOf(basicexpression_parameters.get(_k)));
    }
 else      if (basicexpression_parameters.get(_k) instanceof BinaryExpression)
      { out.print(" //@binaryexpressions." + binaryexpressions.indexOf(basicexpression_parameters.get(_k)));
    }
 else      if (basicexpression_parameters.get(_k) instanceof CollectionExpression)
      { out.print(" //@collectionexpressions." + collectionexpressions.indexOf(basicexpression_parameters.get(_k)));
    }
  }
    out.print("\"");
    out.print(" referredProperty = \"");
    List basicexpression_referredProperty = basicexpressionx_.getreferredProperty();
    for (int _j = 0; _j < basicexpression_referredProperty.size(); _j++)
    { out.print(" //@propertys." + propertys.indexOf(basicexpression_referredProperty.get(_j)));
    }
    out.print("\"");
    out.print(" context = \"");
    List basicexpression_context = basicexpressionx_.getcontext();
    for (int _j = 0; _j < basicexpression_context.size(); _j++)
    { out.print(" //@entitys." + entitys.indexOf(basicexpression_context.get(_j)));
    }
    out.print("\"");
    out.print(" arrayIndex = \"");
    List basicexpression_arrayIndex = basicexpressionx_.getarrayIndex();
    for (int _j = 0; _j < basicexpression_arrayIndex.size(); _j++)
    { out.print(" //@basicexpressions." + basicexpressions.indexOf(basicexpression_arrayIndex.get(_j)));
    }
    out.print("\"");
    out.print(" objectRef = \"");
    List basicexpression_objectRef = basicexpressionx_.getobjectRef();
    for (int _j = 0; _j < basicexpression_objectRef.size(); _j++)
    { out.print(" //@basicexpressions." + basicexpressions.indexOf(basicexpression_objectRef.get(_j)));
    }
    out.print("\"");
    if (basicexpressionx_.gettype() instanceof Entity)
    {   out.print(" type=\"");
    out.print("//@entitys." + entitys.indexOf(((BasicExpression) basicexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (basicexpressionx_.gettype() instanceof PrimitiveType)
    {   out.print(" type=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((BasicExpression) basicexpressions.get(_i)).gettype()));
    out.print("\""); }
 else    if (basicexpressionx_.gettype() instanceof CollectionType)
    {   out.print(" type=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((BasicExpression) basicexpressions.get(_i)).gettype()));
    out.print("\""); }
    if (basicexpressionx_.getelementType() instanceof Entity)
    {   out.print(" elementType=\"");
    out.print("//@entitys." + entitys.indexOf(((BasicExpression) basicexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (basicexpressionx_.getelementType() instanceof PrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((BasicExpression) basicexpressions.get(_i)).getelementType()));
    out.print("\""); }
 else    if (basicexpressionx_.getelementType() instanceof CollectionType)
    {   out.print(" elementType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((BasicExpression) basicexpressions.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < propertys.size(); _i++)
    { Property propertyx_ = (Property) propertys.get(_i);
       out.print("<propertys xsi:type=\"My:Property\"");
    out.print(" name=\"" + propertyx_.getname() + "\" ");
    out.print(" lower=\"" + propertyx_.getlower() + "\" ");
    out.print(" upper=\"" + propertyx_.getupper() + "\" ");
    out.print(" isOrdered=\"" + propertyx_.getisOrdered() + "\" ");
    out.print(" isUnique=\"" + propertyx_.getisUnique() + "\" ");
    out.print(" isDerived=\"" + propertyx_.getisDerived() + "\" ");
    out.print(" isReadOnly=\"" + propertyx_.getisReadOnly() + "\" ");
    out.print(" isStatic=\"" + propertyx_.getisStatic() + "\" ");
    if (propertyx_.gettype() instanceof Entity)
    {   out.print(" type=\"");
    out.print("//@entitys." + entitys.indexOf(((Property) propertys.get(_i)).gettype()));
    out.print("\""); }
 else    if (propertyx_.gettype() instanceof PrimitiveType)
    {   out.print(" type=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((Property) propertys.get(_i)).gettype()));
    out.print("\""); }
 else    if (propertyx_.gettype() instanceof CollectionType)
    {   out.print(" type=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((Property) propertys.get(_i)).gettype()));
    out.print("\""); }
    if (propertyx_.getinitialValue() instanceof UnaryExpression)
    {   out.print(" initialValue=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((Property) propertys.get(_i)).getinitialValue()));
    out.print("\""); }
 else    if (propertyx_.getinitialValue() instanceof BasicExpression)
    {   out.print(" initialValue=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((Property) propertys.get(_i)).getinitialValue()));
    out.print("\""); }
 else    if (propertyx_.getinitialValue() instanceof BinaryExpression)
    {   out.print(" initialValue=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((Property) propertys.get(_i)).getinitialValue()));
    out.print("\""); }
 else    if (propertyx_.getinitialValue() instanceof CollectionExpression)
    {   out.print(" initialValue=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((Property) propertys.get(_i)).getinitialValue()));
    out.print("\""); }
    out.print(" owner=\"");
    out.print("//@entitys." + entitys.indexOf(((Property) propertys.get(_i)).getowner()));
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < exp2cs.size(); _i++)
    { Exp2C exp2cx_ = (Exp2C) exp2cs.get(_i);
       out.print("<exp2cs xsi:type=\"My:Exp2C\"");
    out.println(" />");
  }

    for (int _i = 0; _i < cprimitivetypes.size(); _i++)
    { CPrimitiveType cprimitivetypex_ = (CPrimitiveType) cprimitivetypes.get(_i);
       out.print("<cprimitivetypes xsi:type=\"My:CPrimitiveType\"");
    out.print(" name=\"" + cprimitivetypex_.getname() + "\" ");
    out.print(" ctypeId=\"" + cprimitivetypex_.getctypeId() + "\" ");
    out.print(" name=\"" + cprimitivetypex_.getname() + "\" ");
    out.println(" />");
  }

    for (int _i = 0; _i < carraytypes.size(); _i++)
    { CArrayType carraytypex_ = (CArrayType) carraytypes.get(_i);
       out.print("<carraytypes xsi:type=\"My:CArrayType\"");
    out.print(" duplicates=\"" + carraytypex_.getduplicates() + "\" ");
    out.print(" ctypeId=\"" + carraytypex_.getctypeId() + "\" ");
    out.print(" name=\"" + carraytypex_.getname() + "\" ");
    if (carraytypex_.getcomponentType() instanceof CFunctionPointerType)
    {   out.print(" componentType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CArrayType) carraytypes.get(_i)).getcomponentType()));
    out.print("\""); }
 else    if (carraytypex_.getcomponentType() instanceof CStruct)
    {   out.print(" componentType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CArrayType) carraytypes.get(_i)).getcomponentType()));
    out.print("\""); }
 else    if (carraytypex_.getcomponentType() instanceof CPrimitiveType)
    {   out.print(" componentType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CArrayType) carraytypes.get(_i)).getcomponentType()));
    out.print("\""); }
 else    if (carraytypex_.getcomponentType() instanceof CPointerType)
    {   out.print(" componentType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CArrayType) carraytypes.get(_i)).getcomponentType()));
    out.print("\""); }
 else    if (carraytypex_.getcomponentType() instanceof CArrayType)
    {   out.print(" componentType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CArrayType) carraytypes.get(_i)).getcomponentType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < cpointertypes.size(); _i++)
    { CPointerType cpointertypex_ = (CPointerType) cpointertypes.get(_i);
       out.print("<cpointertypes xsi:type=\"My:CPointerType\"");
    out.print(" ctypeId=\"" + cpointertypex_.getctypeId() + "\" ");
    out.print(" name=\"" + cpointertypex_.getname() + "\" ");
    if (cpointertypex_.getpointsTo() instanceof CFunctionPointerType)
    {   out.print(" pointsTo=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CPointerType) cpointertypes.get(_i)).getpointsTo()));
    out.print("\""); }
 else    if (cpointertypex_.getpointsTo() instanceof CStruct)
    {   out.print(" pointsTo=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CPointerType) cpointertypes.get(_i)).getpointsTo()));
    out.print("\""); }
 else    if (cpointertypex_.getpointsTo() instanceof CPrimitiveType)
    {   out.print(" pointsTo=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CPointerType) cpointertypes.get(_i)).getpointsTo()));
    out.print("\""); }
 else    if (cpointertypex_.getpointsTo() instanceof CPointerType)
    {   out.print(" pointsTo=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CPointerType) cpointertypes.get(_i)).getpointsTo()));
    out.print("\""); }
 else    if (cpointertypex_.getpointsTo() instanceof CArrayType)
    {   out.print(" pointsTo=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CPointerType) cpointertypes.get(_i)).getpointsTo()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < cstructs.size(); _i++)
    { CStruct cstructx_ = (CStruct) cstructs.get(_i);
       out.print("<cstructs xsi:type=\"My:CStruct\"");
    out.print(" name=\"" + cstructx_.getname() + "\" ");
    out.print(" ctypeId=\"" + cstructx_.getctypeId() + "\" ");
    out.print(" name=\"" + cstructx_.getname() + "\" ");
    out.print(" members = \"");
    List cstruct_members = cstructx_.getmembers();
    for (int _j = 0; _j < cstruct_members.size(); _j++)
    { out.print(" //@cmembers." + cmembers.indexOf(cstruct_members.get(_j)));
    }
    out.print("\"");
    out.print(" allMembers = \"");
    List cstruct_allMembers = cstructx_.getallMembers();
    for (int _j = 0; _j < cstruct_allMembers.size(); _j++)
    { out.print(" //@cmembers." + cmembers.indexOf(cstruct_allMembers.get(_j)));
    }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < cmembers.size(); _i++)
    { CMember cmemberx_ = (CMember) cmembers.get(_i);
       out.print("<cmembers xsi:type=\"My:CMember\"");
    out.print(" name=\"" + cmemberx_.getname() + "\" ");
    out.print(" isKey=\"" + cmemberx_.getisKey() + "\" ");
    if (cmemberx_.gettype() instanceof CFunctionPointerType)
    {   out.print(" type=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CMember) cmembers.get(_i)).gettype()));
    out.print("\""); }
 else    if (cmemberx_.gettype() instanceof CStruct)
    {   out.print(" type=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CMember) cmembers.get(_i)).gettype()));
    out.print("\""); }
 else    if (cmemberx_.gettype() instanceof CPrimitiveType)
    {   out.print(" type=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CMember) cmembers.get(_i)).gettype()));
    out.print("\""); }
 else    if (cmemberx_.gettype() instanceof CPointerType)
    {   out.print(" type=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CMember) cmembers.get(_i)).gettype()));
    out.print("\""); }
 else    if (cmemberx_.gettype() instanceof CArrayType)
    {   out.print(" type=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CMember) cmembers.get(_i)).gettype()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < cvariables.size(); _i++)
    { CVariable cvariablex_ = (CVariable) cvariables.get(_i);
       out.print("<cvariables xsi:type=\"My:CVariable\"");
    out.print(" name=\"" + cvariablex_.getname() + "\" ");
    out.print(" kind=\"" + cvariablex_.getkind() + "\" ");
    out.print(" initialisation=\"" + cvariablex_.getinitialisation() + "\" ");
    if (cvariablex_.gettype() instanceof CFunctionPointerType)
    {   out.print(" type=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CVariable) cvariables.get(_i)).gettype()));
    out.print("\""); }
 else    if (cvariablex_.gettype() instanceof CStruct)
    {   out.print(" type=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CVariable) cvariables.get(_i)).gettype()));
    out.print("\""); }
 else    if (cvariablex_.gettype() instanceof CPrimitiveType)
    {   out.print(" type=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CVariable) cvariables.get(_i)).gettype()));
    out.print("\""); }
 else    if (cvariablex_.gettype() instanceof CPointerType)
    {   out.print(" type=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CVariable) cvariables.get(_i)).gettype()));
    out.print("\""); }
 else    if (cvariablex_.gettype() instanceof CArrayType)
    {   out.print(" type=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CVariable) cvariables.get(_i)).gettype()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < cprograms.size(); _i++)
    { CProgram cprogramx_ = (CProgram) cprograms.get(_i);
       out.print("<cprograms xsi:type=\"My:CProgram\"");
    out.print(" operations = \"");
    List cprogram_operations = cprogramx_.getoperations();
    for (int _j = 0; _j < cprogram_operations.size(); _j++)
    { out.print(" //@coperations." + coperations.indexOf(cprogram_operations.get(_j)));
    }
    out.print("\"");
    out.print(" variables = \"");
    List cprogram_variables = cprogramx_.getvariables();
    for (int _j = 0; _j < cprogram_variables.size(); _j++)
    { out.print(" //@cvariables." + cvariables.indexOf(cprogram_variables.get(_j)));
    }
    out.print("\"");
    out.print(" structs = \"");
    List cprogram_structs = cprogramx_.getstructs();
    for (int _j = 0; _j < cprogram_structs.size(); _j++)
    { out.print(" //@cstructs." + cstructs.indexOf(cprogram_structs.get(_j)));
    }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < cfunctionpointertypes.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex_ = (CFunctionPointerType) cfunctionpointertypes.get(_i);
       out.print("<cfunctionpointertypes xsi:type=\"My:CFunctionPointerType\"");
    out.print(" ctypeId=\"" + cfunctionpointertypex_.getctypeId() + "\" ");
    out.print(" name=\"" + cfunctionpointertypex_.getname() + "\" ");
    if (cfunctionpointertypex_.getdomainType() instanceof CFunctionPointerType)
    {   out.print(" domainType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getdomainType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getdomainType() instanceof CStruct)
    {   out.print(" domainType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getdomainType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getdomainType() instanceof CPrimitiveType)
    {   out.print(" domainType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getdomainType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getdomainType() instanceof CPointerType)
    {   out.print(" domainType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getdomainType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getdomainType() instanceof CArrayType)
    {   out.print(" domainType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getdomainType()));
    out.print("\""); }
    if (cfunctionpointertypex_.getrangeType() instanceof CFunctionPointerType)
    {   out.print(" rangeType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getrangeType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getrangeType() instanceof CStruct)
    {   out.print(" rangeType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getrangeType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getrangeType() instanceof CPrimitiveType)
    {   out.print(" rangeType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getrangeType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getrangeType() instanceof CPointerType)
    {   out.print(" rangeType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getrangeType()));
    out.print("\""); }
 else    if (cfunctionpointertypex_.getrangeType() instanceof CArrayType)
    {   out.print(" rangeType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((CFunctionPointerType) cfunctionpointertypes.get(_i)).getrangeType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < coperations.size(); _i++)
    { COperation coperationx_ = (COperation) coperations.get(_i);
       out.print("<coperations xsi:type=\"My:COperation\"");
    out.print(" name=\"" + coperationx_.getname() + "\" ");
    out.print(" opId=\"" + coperationx_.getopId() + "\" ");
    out.print(" isStatic=\"" + coperationx_.getisStatic() + "\" ");
    out.print(" scope=\"" + coperationx_.getscope() + "\" ");
    out.print(" isQuery=\"" + coperationx_.getisQuery() + "\" ");
    out.print(" parameters = \"");
    List coperation_parameters = coperationx_.getparameters();
    for (int _j = 0; _j < coperation_parameters.size(); _j++)
    { out.print(" //@cvariables." + cvariables.indexOf(coperation_parameters.get(_j)));
    }
    out.print("\"");
    if (coperationx_.getreturnType() instanceof CFunctionPointerType)
    {   out.print(" returnType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((COperation) coperations.get(_i)).getreturnType()));
    out.print("\""); }
 else    if (coperationx_.getreturnType() instanceof CStruct)
    {   out.print(" returnType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((COperation) coperations.get(_i)).getreturnType()));
    out.print("\""); }
 else    if (coperationx_.getreturnType() instanceof CPrimitiveType)
    {   out.print(" returnType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((COperation) coperations.get(_i)).getreturnType()));
    out.print("\""); }
 else    if (coperationx_.getreturnType() instanceof CPointerType)
    {   out.print(" returnType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((COperation) coperations.get(_i)).getreturnType()));
    out.print("\""); }
 else    if (coperationx_.getreturnType() instanceof CArrayType)
    {   out.print(" returnType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((COperation) coperations.get(_i)).getreturnType()));
    out.print("\""); }
    if (coperationx_.getcode() instanceof CReturnStatement)
    {   out.print(" code=\"");
    out.print("//@creturnstatements." + creturnstatements.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof CBreakStatement)
    {   out.print(" code=\"");
    out.print("//@cbreakstatements." + cbreakstatements.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof OpCallStatement)
    {   out.print(" code=\"");
    out.print("//@opcallstatements." + opcallstatements.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof CSequenceStatement)
    {   out.print(" code=\"");
    out.print("//@csequencestatements." + csequencestatements.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof IfStatement)
    {   out.print(" code=\"");
    out.print("//@ifstatements." + ifstatements.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof CAssignment)
    {   out.print(" code=\"");
    out.print("//@cassignments." + cassignments.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof DeclarationStatement)
    {   out.print(" code=\"");
    out.print("//@declarationstatements." + declarationstatements.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof ForLoop)
    {   out.print(" code=\"");
    out.print("//@forloops." + forloops.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
 else    if (coperationx_.getcode() instanceof WhileLoop)
    {   out.print(" code=\"");
    out.print("//@whileloops." + whileloops.indexOf(((COperation) coperations.get(_i)).getcode()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < returnstatements.size(); _i++)
    { ReturnStatement returnstatementx_ = (ReturnStatement) returnstatements.get(_i);
       out.print("<returnstatements xsi:type=\"My:ReturnStatement\"");
    out.print(" statId=\"" + returnstatementx_.getstatId() + "\" ");
    out.print(" returnValue = \"");
    List returnstatement_returnValue = returnstatementx_.getreturnValue();
    for (int _k = 0; _k < returnstatement_returnValue.size(); _k++)
    {      if (returnstatement_returnValue.get(_k) instanceof UnaryExpression)
      { out.print(" //@unaryexpressions." + unaryexpressions.indexOf(returnstatement_returnValue.get(_k)));
    }
 else      if (returnstatement_returnValue.get(_k) instanceof BasicExpression)
      { out.print(" //@basicexpressions." + basicexpressions.indexOf(returnstatement_returnValue.get(_k)));
    }
 else      if (returnstatement_returnValue.get(_k) instanceof BinaryExpression)
      { out.print(" //@binaryexpressions." + binaryexpressions.indexOf(returnstatement_returnValue.get(_k)));
    }
 else      if (returnstatement_returnValue.get(_k) instanceof CollectionExpression)
      { out.print(" //@collectionexpressions." + collectionexpressions.indexOf(returnstatement_returnValue.get(_k)));
    }
  }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < operations.size(); _i++)
    { Operation operationx_ = (Operation) operations.get(_i);
       out.print("<operations xsi:type=\"My:Operation\"");
    out.print(" isQuery=\"" + operationx_.getisQuery() + "\" ");
    out.print(" isCached=\"" + operationx_.getisCached() + "\" ");
    out.print(" isStatic=\"" + operationx_.getisStatic() + "\" ");
    out.print(" name=\"" + operationx_.getname() + "\" ");
    out.print(" isStatic=\"" + operationx_.getisStatic() + "\" ");
    out.print(" owner=\"");
    out.print("//@entitys." + entitys.indexOf(((Operation) operations.get(_i)).getowner()));
    out.print("\"");
    if (operationx_.getactivity() instanceof ReturnStatement)
    {   out.print(" activity=\"");
    out.print("//@returnstatements." + returnstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof BreakStatement)
    {   out.print(" activity=\"");
    out.print("//@breakstatements." + breakstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof OperationCallStatement)
    {   out.print(" activity=\"");
    out.print("//@operationcallstatements." + operationcallstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof ImplicitCallStatement)
    {   out.print(" activity=\"");
    out.print("//@implicitcallstatements." + implicitcallstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof SequenceStatement)
    {   out.print(" activity=\"");
    out.print("//@sequencestatements." + sequencestatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof ConditionalStatement)
    {   out.print(" activity=\"");
    out.print("//@conditionalstatements." + conditionalstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof AssignStatement)
    {   out.print(" activity=\"");
    out.print("//@assignstatements." + assignstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof CreationStatement)
    {   out.print(" activity=\"");
    out.print("//@creationstatements." + creationstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof BoundedLoopStatement)
    {   out.print(" activity=\"");
    out.print("//@boundedloopstatements." + boundedloopstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
 else    if (operationx_.getactivity() instanceof UnboundedLoopStatement)
    {   out.print(" activity=\"");
    out.print("//@unboundedloopstatements." + unboundedloopstatements.indexOf(((Operation) operations.get(_i)).getactivity()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < usecases.size(); _i++)
    { UseCase usecasex_ = (UseCase) usecases.get(_i);
       out.print("<usecases xsi:type=\"My:UseCase\"");
    out.print(" name=\"" + usecasex_.getname() + "\" ");
    out.print(" parameters = \"");
    List usecase_parameters = usecasex_.getparameters();
    for (int _j = 0; _j < usecase_parameters.size(); _j++)
    { out.print(" //@propertys." + propertys.indexOf(usecase_parameters.get(_j)));
    }
    out.print("\"");
    if (usecasex_.getresultType() instanceof Entity)
    {   out.print(" resultType=\"");
    out.print("//@entitys." + entitys.indexOf(((UseCase) usecases.get(_i)).getresultType()));
    out.print("\""); }
 else    if (usecasex_.getresultType() instanceof PrimitiveType)
    {   out.print(" resultType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((UseCase) usecases.get(_i)).getresultType()));
    out.print("\""); }
 else    if (usecasex_.getresultType() instanceof CollectionType)
    {   out.print(" resultType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((UseCase) usecases.get(_i)).getresultType()));
    out.print("\""); }
    if (usecasex_.getclassifierBehaviour() instanceof ReturnStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@returnstatements." + returnstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof BreakStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@breakstatements." + breakstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof OperationCallStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@operationcallstatements." + operationcallstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof ImplicitCallStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@implicitcallstatements." + implicitcallstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof SequenceStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@sequencestatements." + sequencestatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof ConditionalStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@conditionalstatements." + conditionalstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof AssignStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@assignstatements." + assignstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof CreationStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@creationstatements." + creationstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof BoundedLoopStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@boundedloopstatements." + boundedloopstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
 else    if (usecasex_.getclassifierBehaviour() instanceof UnboundedLoopStatement)
    {   out.print(" classifierBehaviour=\"");
    out.print("//@unboundedloopstatements." + unboundedloopstatements.indexOf(((UseCase) usecases.get(_i)).getclassifierBehaviour()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < breakstatements.size(); _i++)
    { BreakStatement breakstatementx_ = (BreakStatement) breakstatements.get(_i);
       out.print("<breakstatements xsi:type=\"My:BreakStatement\"");
    out.print(" statId=\"" + breakstatementx_.getstatId() + "\" ");
    out.println(" />");
  }

    for (int _i = 0; _i < operationcallstatements.size(); _i++)
    { OperationCallStatement operationcallstatementx_ = (OperationCallStatement) operationcallstatements.get(_i);
       out.print("<operationcallstatements xsi:type=\"My:OperationCallStatement\"");
    out.print(" assignsTo=\"" + operationcallstatementx_.getassignsTo() + "\" ");
    out.print(" statId=\"" + operationcallstatementx_.getstatId() + "\" ");
    if (operationcallstatementx_.getcallExp() instanceof UnaryExpression)
    {   out.print(" callExp=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((OperationCallStatement) operationcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (operationcallstatementx_.getcallExp() instanceof BasicExpression)
    {   out.print(" callExp=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((OperationCallStatement) operationcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (operationcallstatementx_.getcallExp() instanceof BinaryExpression)
    {   out.print(" callExp=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((OperationCallStatement) operationcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (operationcallstatementx_.getcallExp() instanceof CollectionExpression)
    {   out.print(" callExp=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((OperationCallStatement) operationcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < implicitcallstatements.size(); _i++)
    { ImplicitCallStatement implicitcallstatementx_ = (ImplicitCallStatement) implicitcallstatements.get(_i);
       out.print("<implicitcallstatements xsi:type=\"My:ImplicitCallStatement\"");
    out.print(" assignsTo=\"" + implicitcallstatementx_.getassignsTo() + "\" ");
    out.print(" statId=\"" + implicitcallstatementx_.getstatId() + "\" ");
    if (implicitcallstatementx_.getcallExp() instanceof UnaryExpression)
    {   out.print(" callExp=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((ImplicitCallStatement) implicitcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (implicitcallstatementx_.getcallExp() instanceof BasicExpression)
    {   out.print(" callExp=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((ImplicitCallStatement) implicitcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (implicitcallstatementx_.getcallExp() instanceof BinaryExpression)
    {   out.print(" callExp=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((ImplicitCallStatement) implicitcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (implicitcallstatementx_.getcallExp() instanceof CollectionExpression)
    {   out.print(" callExp=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((ImplicitCallStatement) implicitcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < boundedloopstatements.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx_ = (BoundedLoopStatement) boundedloopstatements.get(_i);
       out.print("<boundedloopstatements xsi:type=\"My:BoundedLoopStatement\"");
    out.print(" statId=\"" + boundedloopstatementx_.getstatId() + "\" ");
    if (boundedloopstatementx_.getloopRange() instanceof UnaryExpression)
    {   out.print(" loopRange=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopRange()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getloopRange() instanceof BasicExpression)
    {   out.print(" loopRange=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopRange()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getloopRange() instanceof BinaryExpression)
    {   out.print(" loopRange=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopRange()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getloopRange() instanceof CollectionExpression)
    {   out.print(" loopRange=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopRange()));
    out.print("\""); }
    if (boundedloopstatementx_.getloopVar() instanceof UnaryExpression)
    {   out.print(" loopVar=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopVar()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getloopVar() instanceof BasicExpression)
    {   out.print(" loopVar=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopVar()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getloopVar() instanceof BinaryExpression)
    {   out.print(" loopVar=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopVar()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getloopVar() instanceof CollectionExpression)
    {   out.print(" loopVar=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getloopVar()));
    out.print("\""); }
    if (boundedloopstatementx_.gettest() instanceof UnaryExpression)
    {   out.print(" test=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (boundedloopstatementx_.gettest() instanceof BasicExpression)
    {   out.print(" test=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (boundedloopstatementx_.gettest() instanceof BinaryExpression)
    {   out.print(" test=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (boundedloopstatementx_.gettest() instanceof CollectionExpression)
    {   out.print(" test=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
    if (boundedloopstatementx_.getbody() instanceof ReturnStatement)
    {   out.print(" body=\"");
    out.print("//@returnstatements." + returnstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof BreakStatement)
    {   out.print(" body=\"");
    out.print("//@breakstatements." + breakstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof OperationCallStatement)
    {   out.print(" body=\"");
    out.print("//@operationcallstatements." + operationcallstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof ImplicitCallStatement)
    {   out.print(" body=\"");
    out.print("//@implicitcallstatements." + implicitcallstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof SequenceStatement)
    {   out.print(" body=\"");
    out.print("//@sequencestatements." + sequencestatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof ConditionalStatement)
    {   out.print(" body=\"");
    out.print("//@conditionalstatements." + conditionalstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof AssignStatement)
    {   out.print(" body=\"");
    out.print("//@assignstatements." + assignstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof CreationStatement)
    {   out.print(" body=\"");
    out.print("//@creationstatements." + creationstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof BoundedLoopStatement)
    {   out.print(" body=\"");
    out.print("//@boundedloopstatements." + boundedloopstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (boundedloopstatementx_.getbody() instanceof UnboundedLoopStatement)
    {   out.print(" body=\"");
    out.print("//@unboundedloopstatements." + unboundedloopstatements.indexOf(((BoundedLoopStatement) boundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < unboundedloopstatements.size(); _i++)
    { UnboundedLoopStatement unboundedloopstatementx_ = (UnboundedLoopStatement) unboundedloopstatements.get(_i);
       out.print("<unboundedloopstatements xsi:type=\"My:UnboundedLoopStatement\"");
    out.print(" statId=\"" + unboundedloopstatementx_.getstatId() + "\" ");
    if (unboundedloopstatementx_.gettest() instanceof UnaryExpression)
    {   out.print(" test=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.gettest() instanceof BasicExpression)
    {   out.print(" test=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.gettest() instanceof BinaryExpression)
    {   out.print(" test=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.gettest() instanceof CollectionExpression)
    {   out.print(" test=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).gettest()));
    out.print("\""); }
    if (unboundedloopstatementx_.getbody() instanceof ReturnStatement)
    {   out.print(" body=\"");
    out.print("//@returnstatements." + returnstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof BreakStatement)
    {   out.print(" body=\"");
    out.print("//@breakstatements." + breakstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof OperationCallStatement)
    {   out.print(" body=\"");
    out.print("//@operationcallstatements." + operationcallstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof ImplicitCallStatement)
    {   out.print(" body=\"");
    out.print("//@implicitcallstatements." + implicitcallstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof SequenceStatement)
    {   out.print(" body=\"");
    out.print("//@sequencestatements." + sequencestatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof ConditionalStatement)
    {   out.print(" body=\"");
    out.print("//@conditionalstatements." + conditionalstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof AssignStatement)
    {   out.print(" body=\"");
    out.print("//@assignstatements." + assignstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof CreationStatement)
    {   out.print(" body=\"");
    out.print("//@creationstatements." + creationstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof BoundedLoopStatement)
    {   out.print(" body=\"");
    out.print("//@boundedloopstatements." + boundedloopstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
 else    if (unboundedloopstatementx_.getbody() instanceof UnboundedLoopStatement)
    {   out.print(" body=\"");
    out.print("//@unboundedloopstatements." + unboundedloopstatements.indexOf(((UnboundedLoopStatement) unboundedloopstatements.get(_i)).getbody()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < assignstatements.size(); _i++)
    { AssignStatement assignstatementx_ = (AssignStatement) assignstatements.get(_i);
       out.print("<assignstatements xsi:type=\"My:AssignStatement\"");
    out.print(" statId=\"" + assignstatementx_.getstatId() + "\" ");
    out.print(" type = \"");
    List assignstatement_type = assignstatementx_.gettype();
    for (int _k = 0; _k < assignstatement_type.size(); _k++)
    {      if (assignstatement_type.get(_k) instanceof Entity)
      { out.print(" //@entitys." + entitys.indexOf(assignstatement_type.get(_k)));
    }
 else      if (assignstatement_type.get(_k) instanceof PrimitiveType)
      { out.print(" //@primitivetypes." + primitivetypes.indexOf(assignstatement_type.get(_k)));
    }
 else      if (assignstatement_type.get(_k) instanceof CollectionType)
      { out.print(" //@collectiontypes." + collectiontypes.indexOf(assignstatement_type.get(_k)));
    }
  }
    out.print("\"");
    if (assignstatementx_.getleft() instanceof UnaryExpression)
    {   out.print(" left=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getleft()));
    out.print("\""); }
 else    if (assignstatementx_.getleft() instanceof BasicExpression)
    {   out.print(" left=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getleft()));
    out.print("\""); }
 else    if (assignstatementx_.getleft() instanceof BinaryExpression)
    {   out.print(" left=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getleft()));
    out.print("\""); }
 else    if (assignstatementx_.getleft() instanceof CollectionExpression)
    {   out.print(" left=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getleft()));
    out.print("\""); }
    if (assignstatementx_.getright() instanceof UnaryExpression)
    {   out.print(" right=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getright()));
    out.print("\""); }
 else    if (assignstatementx_.getright() instanceof BasicExpression)
    {   out.print(" right=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getright()));
    out.print("\""); }
 else    if (assignstatementx_.getright() instanceof BinaryExpression)
    {   out.print(" right=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getright()));
    out.print("\""); }
 else    if (assignstatementx_.getright() instanceof CollectionExpression)
    {   out.print(" right=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((AssignStatement) assignstatements.get(_i)).getright()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < sequencestatements.size(); _i++)
    { SequenceStatement sequencestatementx_ = (SequenceStatement) sequencestatements.get(_i);
       out.print("<sequencestatements xsi:type=\"My:SequenceStatement\"");
    out.print(" kind=\"" + sequencestatementx_.getkind() + "\" ");
    out.print(" statId=\"" + sequencestatementx_.getstatId() + "\" ");
    out.print(" statements = \"");
    List sequencestatement_statements = sequencestatementx_.getstatements();
    for (int _k = 0; _k < sequencestatement_statements.size(); _k++)
    {      if (sequencestatement_statements.get(_k) instanceof ReturnStatement)
      { out.print(" //@returnstatements." + returnstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof BreakStatement)
      { out.print(" //@breakstatements." + breakstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof OperationCallStatement)
      { out.print(" //@operationcallstatements." + operationcallstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof ImplicitCallStatement)
      { out.print(" //@implicitcallstatements." + implicitcallstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof SequenceStatement)
      { out.print(" //@sequencestatements." + sequencestatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof ConditionalStatement)
      { out.print(" //@conditionalstatements." + conditionalstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof AssignStatement)
      { out.print(" //@assignstatements." + assignstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof CreationStatement)
      { out.print(" //@creationstatements." + creationstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof BoundedLoopStatement)
      { out.print(" //@boundedloopstatements." + boundedloopstatements.indexOf(sequencestatement_statements.get(_k)));
    }
 else      if (sequencestatement_statements.get(_k) instanceof UnboundedLoopStatement)
      { out.print(" //@unboundedloopstatements." + unboundedloopstatements.indexOf(sequencestatement_statements.get(_k)));
    }
  }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < conditionalstatements.size(); _i++)
    { ConditionalStatement conditionalstatementx_ = (ConditionalStatement) conditionalstatements.get(_i);
       out.print("<conditionalstatements xsi:type=\"My:ConditionalStatement\"");
    out.print(" statId=\"" + conditionalstatementx_.getstatId() + "\" ");
    if (conditionalstatementx_.gettest() instanceof UnaryExpression)
    {   out.print(" test=\"");
    out.print("//@unaryexpressions." + unaryexpressions.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (conditionalstatementx_.gettest() instanceof BasicExpression)
    {   out.print(" test=\"");
    out.print("//@basicexpressions." + basicexpressions.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (conditionalstatementx_.gettest() instanceof BinaryExpression)
    {   out.print(" test=\"");
    out.print("//@binaryexpressions." + binaryexpressions.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (conditionalstatementx_.gettest() instanceof CollectionExpression)
    {   out.print(" test=\"");
    out.print("//@collectionexpressions." + collectionexpressions.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).gettest()));
    out.print("\""); }
    if (conditionalstatementx_.getifPart() instanceof ReturnStatement)
    {   out.print(" ifPart=\"");
    out.print("//@returnstatements." + returnstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof BreakStatement)
    {   out.print(" ifPart=\"");
    out.print("//@breakstatements." + breakstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof OperationCallStatement)
    {   out.print(" ifPart=\"");
    out.print("//@operationcallstatements." + operationcallstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof ImplicitCallStatement)
    {   out.print(" ifPart=\"");
    out.print("//@implicitcallstatements." + implicitcallstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof SequenceStatement)
    {   out.print(" ifPart=\"");
    out.print("//@sequencestatements." + sequencestatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof ConditionalStatement)
    {   out.print(" ifPart=\"");
    out.print("//@conditionalstatements." + conditionalstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof AssignStatement)
    {   out.print(" ifPart=\"");
    out.print("//@assignstatements." + assignstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof CreationStatement)
    {   out.print(" ifPart=\"");
    out.print("//@creationstatements." + creationstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof BoundedLoopStatement)
    {   out.print(" ifPart=\"");
    out.print("//@boundedloopstatements." + boundedloopstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (conditionalstatementx_.getifPart() instanceof UnboundedLoopStatement)
    {   out.print(" ifPart=\"");
    out.print("//@unboundedloopstatements." + unboundedloopstatements.indexOf(((ConditionalStatement) conditionalstatements.get(_i)).getifPart()));
    out.print("\""); }
    out.print(" elsePart = \"");
    List conditionalstatement_elsePart = conditionalstatementx_.getelsePart();
    for (int _k = 0; _k < conditionalstatement_elsePart.size(); _k++)
    {      if (conditionalstatement_elsePart.get(_k) instanceof ReturnStatement)
      { out.print(" //@returnstatements." + returnstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof BreakStatement)
      { out.print(" //@breakstatements." + breakstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof OperationCallStatement)
      { out.print(" //@operationcallstatements." + operationcallstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof ImplicitCallStatement)
      { out.print(" //@implicitcallstatements." + implicitcallstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof SequenceStatement)
      { out.print(" //@sequencestatements." + sequencestatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof ConditionalStatement)
      { out.print(" //@conditionalstatements." + conditionalstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof AssignStatement)
      { out.print(" //@assignstatements." + assignstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof CreationStatement)
      { out.print(" //@creationstatements." + creationstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof BoundedLoopStatement)
      { out.print(" //@boundedloopstatements." + boundedloopstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
 else      if (conditionalstatement_elsePart.get(_k) instanceof UnboundedLoopStatement)
      { out.print(" //@unboundedloopstatements." + unboundedloopstatements.indexOf(conditionalstatement_elsePart.get(_k)));
    }
  }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < creationstatements.size(); _i++)
    { CreationStatement creationstatementx_ = (CreationStatement) creationstatements.get(_i);
       out.print("<creationstatements xsi:type=\"My:CreationStatement\"");
    out.print(" createsInstanceOf=\"" + creationstatementx_.getcreatesInstanceOf() + "\" ");
    out.print(" assignsTo=\"" + creationstatementx_.getassignsTo() + "\" ");
    out.print(" statId=\"" + creationstatementx_.getstatId() + "\" ");
    if (creationstatementx_.gettype() instanceof Entity)
    {   out.print(" type=\"");
    out.print("//@entitys." + entitys.indexOf(((CreationStatement) creationstatements.get(_i)).gettype()));
    out.print("\""); }
 else    if (creationstatementx_.gettype() instanceof PrimitiveType)
    {   out.print(" type=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((CreationStatement) creationstatements.get(_i)).gettype()));
    out.print("\""); }
 else    if (creationstatementx_.gettype() instanceof CollectionType)
    {   out.print(" type=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((CreationStatement) creationstatements.get(_i)).gettype()));
    out.print("\""); }
    if (creationstatementx_.getelementType() instanceof Entity)
    {   out.print(" elementType=\"");
    out.print("//@entitys." + entitys.indexOf(((CreationStatement) creationstatements.get(_i)).getelementType()));
    out.print("\""); }
 else    if (creationstatementx_.getelementType() instanceof PrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@primitivetypes." + primitivetypes.indexOf(((CreationStatement) creationstatements.get(_i)).getelementType()));
    out.print("\""); }
 else    if (creationstatementx_.getelementType() instanceof CollectionType)
    {   out.print(" elementType=\"");
    out.print("//@collectiontypes." + collectiontypes.indexOf(((CreationStatement) creationstatements.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < creturnstatements.size(); _i++)
    { CReturnStatement creturnstatementx_ = (CReturnStatement) creturnstatements.get(_i);
       out.print("<creturnstatements xsi:type=\"My:CReturnStatement\"");
    out.print(" cstatId=\"" + creturnstatementx_.getcstatId() + "\" ");
    out.print(" returnValue = \"");
    List creturnstatement_returnValue = creturnstatementx_.getreturnValue();
    for (int _k = 0; _k < creturnstatement_returnValue.size(); _k++)
    {      if (creturnstatement_returnValue.get(_k) instanceof CUnaryExpression)
      { out.print(" //@cunaryexpressions." + cunaryexpressions.indexOf(creturnstatement_returnValue.get(_k)));
    }
 else      if (creturnstatement_returnValue.get(_k) instanceof CBasicExpression)
      { out.print(" //@cbasicexpressions." + cbasicexpressions.indexOf(creturnstatement_returnValue.get(_k)));
    }
 else      if (creturnstatement_returnValue.get(_k) instanceof CBinaryExpression)
      { out.print(" //@cbinaryexpressions." + cbinaryexpressions.indexOf(creturnstatement_returnValue.get(_k)));
    }
  }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < cbreakstatements.size(); _i++)
    { CBreakStatement cbreakstatementx_ = (CBreakStatement) cbreakstatements.get(_i);
       out.print("<cbreakstatements xsi:type=\"My:CBreakStatement\"");
    out.print(" cstatId=\"" + cbreakstatementx_.getcstatId() + "\" ");
    out.println(" />");
  }

    for (int _i = 0; _i < opcallstatements.size(); _i++)
    { OpCallStatement opcallstatementx_ = (OpCallStatement) opcallstatements.get(_i);
       out.print("<opcallstatements xsi:type=\"My:OpCallStatement\"");
    out.print(" assignsTo=\"" + opcallstatementx_.getassignsTo() + "\" ");
    out.print(" cstatId=\"" + opcallstatementx_.getcstatId() + "\" ");
    if (opcallstatementx_.getcallExp() instanceof CUnaryExpression)
    {   out.print(" callExp=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((OpCallStatement) opcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (opcallstatementx_.getcallExp() instanceof CBasicExpression)
    {   out.print(" callExp=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((OpCallStatement) opcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
 else    if (opcallstatementx_.getcallExp() instanceof CBinaryExpression)
    {   out.print(" callExp=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((OpCallStatement) opcallstatements.get(_i)).getcallExp()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < forloops.size(); _i++)
    { ForLoop forloopx_ = (ForLoop) forloops.get(_i);
       out.print("<forloops xsi:type=\"My:ForLoop\"");
    out.print(" cstatId=\"" + forloopx_.getcstatId() + "\" ");
    out.print(" increment=\"");
    out.print("//@csequencestatements." + csequencestatements.indexOf(((ForLoop) forloops.get(_i)).getincrement()));
    out.print("\"");
    if (forloopx_.getloopVar() instanceof CUnaryExpression)
    {   out.print(" loopVar=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((ForLoop) forloops.get(_i)).getloopVar()));
    out.print("\""); }
 else    if (forloopx_.getloopVar() instanceof CBasicExpression)
    {   out.print(" loopVar=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((ForLoop) forloops.get(_i)).getloopVar()));
    out.print("\""); }
 else    if (forloopx_.getloopVar() instanceof CBinaryExpression)
    {   out.print(" loopVar=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((ForLoop) forloops.get(_i)).getloopVar()));
    out.print("\""); }
    if (forloopx_.getloopRange() instanceof CUnaryExpression)
    {   out.print(" loopRange=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((ForLoop) forloops.get(_i)).getloopRange()));
    out.print("\""); }
 else    if (forloopx_.getloopRange() instanceof CBasicExpression)
    {   out.print(" loopRange=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((ForLoop) forloops.get(_i)).getloopRange()));
    out.print("\""); }
 else    if (forloopx_.getloopRange() instanceof CBinaryExpression)
    {   out.print(" loopRange=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((ForLoop) forloops.get(_i)).getloopRange()));
    out.print("\""); }
    if (forloopx_.gettest() instanceof CUnaryExpression)
    {   out.print(" test=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((ForLoop) forloops.get(_i)).gettest()));
    out.print("\""); }
 else    if (forloopx_.gettest() instanceof CBasicExpression)
    {   out.print(" test=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((ForLoop) forloops.get(_i)).gettest()));
    out.print("\""); }
 else    if (forloopx_.gettest() instanceof CBinaryExpression)
    {   out.print(" test=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((ForLoop) forloops.get(_i)).gettest()));
    out.print("\""); }
    if (forloopx_.getbody() instanceof CReturnStatement)
    {   out.print(" body=\"");
    out.print("//@creturnstatements." + creturnstatements.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof CBreakStatement)
    {   out.print(" body=\"");
    out.print("//@cbreakstatements." + cbreakstatements.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof OpCallStatement)
    {   out.print(" body=\"");
    out.print("//@opcallstatements." + opcallstatements.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof CSequenceStatement)
    {   out.print(" body=\"");
    out.print("//@csequencestatements." + csequencestatements.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof IfStatement)
    {   out.print(" body=\"");
    out.print("//@ifstatements." + ifstatements.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof CAssignment)
    {   out.print(" body=\"");
    out.print("//@cassignments." + cassignments.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof DeclarationStatement)
    {   out.print(" body=\"");
    out.print("//@declarationstatements." + declarationstatements.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof ForLoop)
    {   out.print(" body=\"");
    out.print("//@forloops." + forloops.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (forloopx_.getbody() instanceof WhileLoop)
    {   out.print(" body=\"");
    out.print("//@whileloops." + whileloops.indexOf(((ForLoop) forloops.get(_i)).getbody()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < whileloops.size(); _i++)
    { WhileLoop whileloopx_ = (WhileLoop) whileloops.get(_i);
       out.print("<whileloops xsi:type=\"My:WhileLoop\"");
    out.print(" cstatId=\"" + whileloopx_.getcstatId() + "\" ");
    if (whileloopx_.gettest() instanceof CUnaryExpression)
    {   out.print(" test=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((WhileLoop) whileloops.get(_i)).gettest()));
    out.print("\""); }
 else    if (whileloopx_.gettest() instanceof CBasicExpression)
    {   out.print(" test=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((WhileLoop) whileloops.get(_i)).gettest()));
    out.print("\""); }
 else    if (whileloopx_.gettest() instanceof CBinaryExpression)
    {   out.print(" test=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((WhileLoop) whileloops.get(_i)).gettest()));
    out.print("\""); }
    if (whileloopx_.getbody() instanceof CReturnStatement)
    {   out.print(" body=\"");
    out.print("//@creturnstatements." + creturnstatements.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof CBreakStatement)
    {   out.print(" body=\"");
    out.print("//@cbreakstatements." + cbreakstatements.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof OpCallStatement)
    {   out.print(" body=\"");
    out.print("//@opcallstatements." + opcallstatements.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof CSequenceStatement)
    {   out.print(" body=\"");
    out.print("//@csequencestatements." + csequencestatements.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof IfStatement)
    {   out.print(" body=\"");
    out.print("//@ifstatements." + ifstatements.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof CAssignment)
    {   out.print(" body=\"");
    out.print("//@cassignments." + cassignments.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof DeclarationStatement)
    {   out.print(" body=\"");
    out.print("//@declarationstatements." + declarationstatements.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof ForLoop)
    {   out.print(" body=\"");
    out.print("//@forloops." + forloops.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
 else    if (whileloopx_.getbody() instanceof WhileLoop)
    {   out.print(" body=\"");
    out.print("//@whileloops." + whileloops.indexOf(((WhileLoop) whileloops.get(_i)).getbody()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < cassignments.size(); _i++)
    { CAssignment cassignmentx_ = (CAssignment) cassignments.get(_i);
       out.print("<cassignments xsi:type=\"My:CAssignment\"");
    out.print(" cstatId=\"" + cassignmentx_.getcstatId() + "\" ");
    out.print(" type = \"");
    List cassignment_type = cassignmentx_.gettype();
    for (int _k = 0; _k < cassignment_type.size(); _k++)
    {      if (cassignment_type.get(_k) instanceof CFunctionPointerType)
      { out.print(" //@cfunctionpointertypes." + cfunctionpointertypes.indexOf(cassignment_type.get(_k)));
    }
 else      if (cassignment_type.get(_k) instanceof CStruct)
      { out.print(" //@cstructs." + cstructs.indexOf(cassignment_type.get(_k)));
    }
 else      if (cassignment_type.get(_k) instanceof CPrimitiveType)
      { out.print(" //@cprimitivetypes." + cprimitivetypes.indexOf(cassignment_type.get(_k)));
    }
 else      if (cassignment_type.get(_k) instanceof CPointerType)
      { out.print(" //@cpointertypes." + cpointertypes.indexOf(cassignment_type.get(_k)));
    }
 else      if (cassignment_type.get(_k) instanceof CArrayType)
      { out.print(" //@carraytypes." + carraytypes.indexOf(cassignment_type.get(_k)));
    }
  }
    out.print("\"");
    if (cassignmentx_.getleft() instanceof CUnaryExpression)
    {   out.print(" left=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((CAssignment) cassignments.get(_i)).getleft()));
    out.print("\""); }
 else    if (cassignmentx_.getleft() instanceof CBasicExpression)
    {   out.print(" left=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((CAssignment) cassignments.get(_i)).getleft()));
    out.print("\""); }
 else    if (cassignmentx_.getleft() instanceof CBinaryExpression)
    {   out.print(" left=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((CAssignment) cassignments.get(_i)).getleft()));
    out.print("\""); }
    if (cassignmentx_.getright() instanceof CUnaryExpression)
    {   out.print(" right=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((CAssignment) cassignments.get(_i)).getright()));
    out.print("\""); }
 else    if (cassignmentx_.getright() instanceof CBasicExpression)
    {   out.print(" right=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((CAssignment) cassignments.get(_i)).getright()));
    out.print("\""); }
 else    if (cassignmentx_.getright() instanceof CBinaryExpression)
    {   out.print(" right=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((CAssignment) cassignments.get(_i)).getright()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < csequencestatements.size(); _i++)
    { CSequenceStatement csequencestatementx_ = (CSequenceStatement) csequencestatements.get(_i);
       out.print("<csequencestatements xsi:type=\"My:CSequenceStatement\"");
    out.print(" kind=\"" + csequencestatementx_.getkind() + "\" ");
    out.print(" cstatId=\"" + csequencestatementx_.getcstatId() + "\" ");
    out.print(" statements = \"");
    List csequencestatement_statements = csequencestatementx_.getstatements();
    for (int _k = 0; _k < csequencestatement_statements.size(); _k++)
    {      if (csequencestatement_statements.get(_k) instanceof CReturnStatement)
      { out.print(" //@creturnstatements." + creturnstatements.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof CBreakStatement)
      { out.print(" //@cbreakstatements." + cbreakstatements.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof OpCallStatement)
      { out.print(" //@opcallstatements." + opcallstatements.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof CSequenceStatement)
      { out.print(" //@csequencestatements." + csequencestatements.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof IfStatement)
      { out.print(" //@ifstatements." + ifstatements.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof CAssignment)
      { out.print(" //@cassignments." + cassignments.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof DeclarationStatement)
      { out.print(" //@declarationstatements." + declarationstatements.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof ForLoop)
      { out.print(" //@forloops." + forloops.indexOf(csequencestatement_statements.get(_k)));
    }
 else      if (csequencestatement_statements.get(_k) instanceof WhileLoop)
      { out.print(" //@whileloops." + whileloops.indexOf(csequencestatement_statements.get(_k)));
    }
  }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < ifstatements.size(); _i++)
    { IfStatement ifstatementx_ = (IfStatement) ifstatements.get(_i);
       out.print("<ifstatements xsi:type=\"My:IfStatement\"");
    out.print(" cstatId=\"" + ifstatementx_.getcstatId() + "\" ");
    if (ifstatementx_.gettest() instanceof CUnaryExpression)
    {   out.print(" test=\"");
    out.print("//@cunaryexpressions." + cunaryexpressions.indexOf(((IfStatement) ifstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (ifstatementx_.gettest() instanceof CBasicExpression)
    {   out.print(" test=\"");
    out.print("//@cbasicexpressions." + cbasicexpressions.indexOf(((IfStatement) ifstatements.get(_i)).gettest()));
    out.print("\""); }
 else    if (ifstatementx_.gettest() instanceof CBinaryExpression)
    {   out.print(" test=\"");
    out.print("//@cbinaryexpressions." + cbinaryexpressions.indexOf(((IfStatement) ifstatements.get(_i)).gettest()));
    out.print("\""); }
    if (ifstatementx_.getifPart() instanceof CReturnStatement)
    {   out.print(" ifPart=\"");
    out.print("//@creturnstatements." + creturnstatements.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof CBreakStatement)
    {   out.print(" ifPart=\"");
    out.print("//@cbreakstatements." + cbreakstatements.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof OpCallStatement)
    {   out.print(" ifPart=\"");
    out.print("//@opcallstatements." + opcallstatements.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof CSequenceStatement)
    {   out.print(" ifPart=\"");
    out.print("//@csequencestatements." + csequencestatements.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof IfStatement)
    {   out.print(" ifPart=\"");
    out.print("//@ifstatements." + ifstatements.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof CAssignment)
    {   out.print(" ifPart=\"");
    out.print("//@cassignments." + cassignments.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof DeclarationStatement)
    {   out.print(" ifPart=\"");
    out.print("//@declarationstatements." + declarationstatements.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof ForLoop)
    {   out.print(" ifPart=\"");
    out.print("//@forloops." + forloops.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
 else    if (ifstatementx_.getifPart() instanceof WhileLoop)
    {   out.print(" ifPart=\"");
    out.print("//@whileloops." + whileloops.indexOf(((IfStatement) ifstatements.get(_i)).getifPart()));
    out.print("\""); }
    out.print(" elsePart = \"");
    List ifstatement_elsePart = ifstatementx_.getelsePart();
    for (int _k = 0; _k < ifstatement_elsePart.size(); _k++)
    {      if (ifstatement_elsePart.get(_k) instanceof CReturnStatement)
      { out.print(" //@creturnstatements." + creturnstatements.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof CBreakStatement)
      { out.print(" //@cbreakstatements." + cbreakstatements.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof OpCallStatement)
      { out.print(" //@opcallstatements." + opcallstatements.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof CSequenceStatement)
      { out.print(" //@csequencestatements." + csequencestatements.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof IfStatement)
      { out.print(" //@ifstatements." + ifstatements.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof CAssignment)
      { out.print(" //@cassignments." + cassignments.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof DeclarationStatement)
      { out.print(" //@declarationstatements." + declarationstatements.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof ForLoop)
      { out.print(" //@forloops." + forloops.indexOf(ifstatement_elsePart.get(_k)));
    }
 else      if (ifstatement_elsePart.get(_k) instanceof WhileLoop)
      { out.print(" //@whileloops." + whileloops.indexOf(ifstatement_elsePart.get(_k)));
    }
  }
    out.print("\"");
    out.println(" />");
  }

    for (int _i = 0; _i < declarationstatements.size(); _i++)
    { DeclarationStatement declarationstatementx_ = (DeclarationStatement) declarationstatements.get(_i);
       out.print("<declarationstatements xsi:type=\"My:DeclarationStatement\"");
    out.print(" createsInstanceOf=\"" + declarationstatementx_.getcreatesInstanceOf() + "\" ");
    out.print(" assignsTo=\"" + declarationstatementx_.getassignsTo() + "\" ");
    out.print(" cstatId=\"" + declarationstatementx_.getcstatId() + "\" ");
    if (declarationstatementx_.gettype() instanceof CFunctionPointerType)
    {   out.print(" type=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).gettype()));
    out.print("\""); }
 else    if (declarationstatementx_.gettype() instanceof CStruct)
    {   out.print(" type=\"");
    out.print("//@cstructs." + cstructs.indexOf(((DeclarationStatement) declarationstatements.get(_i)).gettype()));
    out.print("\""); }
 else    if (declarationstatementx_.gettype() instanceof CPrimitiveType)
    {   out.print(" type=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).gettype()));
    out.print("\""); }
 else    if (declarationstatementx_.gettype() instanceof CPointerType)
    {   out.print(" type=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).gettype()));
    out.print("\""); }
 else    if (declarationstatementx_.gettype() instanceof CArrayType)
    {   out.print(" type=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).gettype()));
    out.print("\""); }
    if (declarationstatementx_.getelementType() instanceof CFunctionPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cfunctionpointertypes." + cfunctionpointertypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).getelementType()));
    out.print("\""); }
 else    if (declarationstatementx_.getelementType() instanceof CStruct)
    {   out.print(" elementType=\"");
    out.print("//@cstructs." + cstructs.indexOf(((DeclarationStatement) declarationstatements.get(_i)).getelementType()));
    out.print("\""); }
 else    if (declarationstatementx_.getelementType() instanceof CPrimitiveType)
    {   out.print(" elementType=\"");
    out.print("//@cprimitivetypes." + cprimitivetypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).getelementType()));
    out.print("\""); }
 else    if (declarationstatementx_.getelementType() instanceof CPointerType)
    {   out.print(" elementType=\"");
    out.print("//@cpointertypes." + cpointertypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).getelementType()));
    out.print("\""); }
 else    if (declarationstatementx_.getelementType() instanceof CArrayType)
    {   out.print(" elementType=\"");
    out.print("//@carraytypes." + carraytypes.indexOf(((DeclarationStatement) declarationstatements.get(_i)).getelementType()));
    out.print("\""); }
    out.println(" />");
  }

    for (int _i = 0; _i < printcodes.size(); _i++)
    { Printcode printcodex_ = (Printcode) printcodes.get(_i);
       out.print("<printcodes xsi:type=\"My:Printcode\"");
    out.println(" />");
  }

    out.println("</UMLRSDS:model>");
    out.close(); 
  }


  public void saveCSVModel()
  { try {
      File _cbinaryexpression = new File("CBinaryExpression.csv");
      PrintWriter _out_cbinaryexpression = new PrintWriter(new BufferedWriter(new FileWriter(_cbinaryexpression)));
      for (int __i = 0; __i < cbinaryexpressions.size(); __i++)
      { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressions.get(__i);
        cbinaryexpressionx.writeCSV(_out_cbinaryexpression);
      }
      _out_cbinaryexpression.close();
      File _cunaryexpression = new File("CUnaryExpression.csv");
      PrintWriter _out_cunaryexpression = new PrintWriter(new BufferedWriter(new FileWriter(_cunaryexpression)));
      for (int __i = 0; __i < cunaryexpressions.size(); __i++)
      { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressions.get(__i);
        cunaryexpressionx.writeCSV(_out_cunaryexpression);
      }
      _out_cunaryexpression.close();
      File _cbasicexpression = new File("CBasicExpression.csv");
      PrintWriter _out_cbasicexpression = new PrintWriter(new BufferedWriter(new FileWriter(_cbasicexpression)));
      for (int __i = 0; __i < cbasicexpressions.size(); __i++)
      { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressions.get(__i);
        cbasicexpressionx.writeCSV(_out_cbasicexpression);
      }
      _out_cbasicexpression.close();
      File _primitivetype = new File("PrimitiveType.csv");
      PrintWriter _out_primitivetype = new PrintWriter(new BufferedWriter(new FileWriter(_primitivetype)));
      for (int __i = 0; __i < primitivetypes.size(); __i++)
      { PrimitiveType primitivetypex = (PrimitiveType) primitivetypes.get(__i);
        primitivetypex.writeCSV(_out_primitivetype);
      }
      _out_primitivetype.close();
      File _entity = new File("Entity.csv");
      PrintWriter _out_entity = new PrintWriter(new BufferedWriter(new FileWriter(_entity)));
      for (int __i = 0; __i < entitys.size(); __i++)
      { Entity entityx = (Entity) entitys.get(__i);
        entityx.writeCSV(_out_entity);
      }
      _out_entity.close();
      File _collectiontype = new File("CollectionType.csv");
      PrintWriter _out_collectiontype = new PrintWriter(new BufferedWriter(new FileWriter(_collectiontype)));
      for (int __i = 0; __i < collectiontypes.size(); __i++)
      { CollectionType collectiontypex = (CollectionType) collectiontypes.get(__i);
        collectiontypex.writeCSV(_out_collectiontype);
      }
      _out_collectiontype.close();
      File _binaryexpression = new File("BinaryExpression.csv");
      PrintWriter _out_binaryexpression = new PrintWriter(new BufferedWriter(new FileWriter(_binaryexpression)));
      for (int __i = 0; __i < binaryexpressions.size(); __i++)
      { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressions.get(__i);
        binaryexpressionx.writeCSV(_out_binaryexpression);
      }
      _out_binaryexpression.close();
      File _unaryexpression = new File("UnaryExpression.csv");
      PrintWriter _out_unaryexpression = new PrintWriter(new BufferedWriter(new FileWriter(_unaryexpression)));
      for (int __i = 0; __i < unaryexpressions.size(); __i++)
      { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressions.get(__i);
        unaryexpressionx.writeCSV(_out_unaryexpression);
      }
      _out_unaryexpression.close();
      File _collectionexpression = new File("CollectionExpression.csv");
      PrintWriter _out_collectionexpression = new PrintWriter(new BufferedWriter(new FileWriter(_collectionexpression)));
      for (int __i = 0; __i < collectionexpressions.size(); __i++)
      { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressions.get(__i);
        collectionexpressionx.writeCSV(_out_collectionexpression);
      }
      _out_collectionexpression.close();
      File _basicexpression = new File("BasicExpression.csv");
      PrintWriter _out_basicexpression = new PrintWriter(new BufferedWriter(new FileWriter(_basicexpression)));
      for (int __i = 0; __i < basicexpressions.size(); __i++)
      { BasicExpression basicexpressionx = (BasicExpression) basicexpressions.get(__i);
        basicexpressionx.writeCSV(_out_basicexpression);
      }
      _out_basicexpression.close();
      File _property = new File("Property.csv");
      PrintWriter _out_property = new PrintWriter(new BufferedWriter(new FileWriter(_property)));
      for (int __i = 0; __i < propertys.size(); __i++)
      { Property propertyx = (Property) propertys.get(__i);
        propertyx.writeCSV(_out_property);
      }
      _out_property.close();
      File _exp2c = new File("Exp2C.csv");
      PrintWriter _out_exp2c = new PrintWriter(new BufferedWriter(new FileWriter(_exp2c)));
      for (int __i = 0; __i < exp2cs.size(); __i++)
      { Exp2C exp2cx = (Exp2C) exp2cs.get(__i);
        exp2cx.writeCSV(_out_exp2c);
      }
      _out_exp2c.close();
      File _cprimitivetype = new File("CPrimitiveType.csv");
      PrintWriter _out_cprimitivetype = new PrintWriter(new BufferedWriter(new FileWriter(_cprimitivetype)));
      for (int __i = 0; __i < cprimitivetypes.size(); __i++)
      { CPrimitiveType cprimitivetypex = (CPrimitiveType) cprimitivetypes.get(__i);
        cprimitivetypex.writeCSV(_out_cprimitivetype);
      }
      _out_cprimitivetype.close();
      File _carraytype = new File("CArrayType.csv");
      PrintWriter _out_carraytype = new PrintWriter(new BufferedWriter(new FileWriter(_carraytype)));
      for (int __i = 0; __i < carraytypes.size(); __i++)
      { CArrayType carraytypex = (CArrayType) carraytypes.get(__i);
        carraytypex.writeCSV(_out_carraytype);
      }
      _out_carraytype.close();
      File _cpointertype = new File("CPointerType.csv");
      PrintWriter _out_cpointertype = new PrintWriter(new BufferedWriter(new FileWriter(_cpointertype)));
      for (int __i = 0; __i < cpointertypes.size(); __i++)
      { CPointerType cpointertypex = (CPointerType) cpointertypes.get(__i);
        cpointertypex.writeCSV(_out_cpointertype);
      }
      _out_cpointertype.close();
      File _cstruct = new File("CStruct.csv");
      PrintWriter _out_cstruct = new PrintWriter(new BufferedWriter(new FileWriter(_cstruct)));
      for (int __i = 0; __i < cstructs.size(); __i++)
      { CStruct cstructx = (CStruct) cstructs.get(__i);
        cstructx.writeCSV(_out_cstruct);
      }
      _out_cstruct.close();
      File _cmember = new File("CMember.csv");
      PrintWriter _out_cmember = new PrintWriter(new BufferedWriter(new FileWriter(_cmember)));
      for (int __i = 0; __i < cmembers.size(); __i++)
      { CMember cmemberx = (CMember) cmembers.get(__i);
        cmemberx.writeCSV(_out_cmember);
      }
      _out_cmember.close();
      File _cvariable = new File("CVariable.csv");
      PrintWriter _out_cvariable = new PrintWriter(new BufferedWriter(new FileWriter(_cvariable)));
      for (int __i = 0; __i < cvariables.size(); __i++)
      { CVariable cvariablex = (CVariable) cvariables.get(__i);
        cvariablex.writeCSV(_out_cvariable);
      }
      _out_cvariable.close();
      File _cprogram = new File("CProgram.csv");
      PrintWriter _out_cprogram = new PrintWriter(new BufferedWriter(new FileWriter(_cprogram)));
      for (int __i = 0; __i < cprograms.size(); __i++)
      { CProgram cprogramx = (CProgram) cprograms.get(__i);
        cprogramx.writeCSV(_out_cprogram);
      }
      _out_cprogram.close();
      File _cfunctionpointertype = new File("CFunctionPointerType.csv");
      PrintWriter _out_cfunctionpointertype = new PrintWriter(new BufferedWriter(new FileWriter(_cfunctionpointertype)));
      for (int __i = 0; __i < cfunctionpointertypes.size(); __i++)
      { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypes.get(__i);
        cfunctionpointertypex.writeCSV(_out_cfunctionpointertype);
      }
      _out_cfunctionpointertype.close();
      File _coperation = new File("COperation.csv");
      PrintWriter _out_coperation = new PrintWriter(new BufferedWriter(new FileWriter(_coperation)));
      for (int __i = 0; __i < coperations.size(); __i++)
      { COperation coperationx = (COperation) coperations.get(__i);
        coperationx.writeCSV(_out_coperation);
      }
      _out_coperation.close();
      File _returnstatement = new File("ReturnStatement.csv");
      PrintWriter _out_returnstatement = new PrintWriter(new BufferedWriter(new FileWriter(_returnstatement)));
      for (int __i = 0; __i < returnstatements.size(); __i++)
      { ReturnStatement returnstatementx = (ReturnStatement) returnstatements.get(__i);
        returnstatementx.writeCSV(_out_returnstatement);
      }
      _out_returnstatement.close();
      File _operation = new File("Operation.csv");
      PrintWriter _out_operation = new PrintWriter(new BufferedWriter(new FileWriter(_operation)));
      for (int __i = 0; __i < operations.size(); __i++)
      { Operation operationx = (Operation) operations.get(__i);
        operationx.writeCSV(_out_operation);
      }
      _out_operation.close();
      File _usecase = new File("UseCase.csv");
      PrintWriter _out_usecase = new PrintWriter(new BufferedWriter(new FileWriter(_usecase)));
      for (int __i = 0; __i < usecases.size(); __i++)
      { UseCase usecasex = (UseCase) usecases.get(__i);
        usecasex.writeCSV(_out_usecase);
      }
      _out_usecase.close();
      File _breakstatement = new File("BreakStatement.csv");
      PrintWriter _out_breakstatement = new PrintWriter(new BufferedWriter(new FileWriter(_breakstatement)));
      for (int __i = 0; __i < breakstatements.size(); __i++)
      { BreakStatement breakstatementx = (BreakStatement) breakstatements.get(__i);
        breakstatementx.writeCSV(_out_breakstatement);
      }
      _out_breakstatement.close();
      File _operationcallstatement = new File("OperationCallStatement.csv");
      PrintWriter _out_operationcallstatement = new PrintWriter(new BufferedWriter(new FileWriter(_operationcallstatement)));
      for (int __i = 0; __i < operationcallstatements.size(); __i++)
      { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatements.get(__i);
        operationcallstatementx.writeCSV(_out_operationcallstatement);
      }
      _out_operationcallstatement.close();
      File _implicitcallstatement = new File("ImplicitCallStatement.csv");
      PrintWriter _out_implicitcallstatement = new PrintWriter(new BufferedWriter(new FileWriter(_implicitcallstatement)));
      for (int __i = 0; __i < implicitcallstatements.size(); __i++)
      { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatements.get(__i);
        implicitcallstatementx.writeCSV(_out_implicitcallstatement);
      }
      _out_implicitcallstatement.close();
      File _boundedloopstatement = new File("BoundedLoopStatement.csv");
      PrintWriter _out_boundedloopstatement = new PrintWriter(new BufferedWriter(new FileWriter(_boundedloopstatement)));
      for (int __i = 0; __i < boundedloopstatements.size(); __i++)
      { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatements.get(__i);
        boundedloopstatementx.writeCSV(_out_boundedloopstatement);
      }
      _out_boundedloopstatement.close();
      File _unboundedloopstatement = new File("UnboundedLoopStatement.csv");
      PrintWriter _out_unboundedloopstatement = new PrintWriter(new BufferedWriter(new FileWriter(_unboundedloopstatement)));
      for (int __i = 0; __i < unboundedloopstatements.size(); __i++)
      { UnboundedLoopStatement unboundedloopstatementx = (UnboundedLoopStatement) unboundedloopstatements.get(__i);
        unboundedloopstatementx.writeCSV(_out_unboundedloopstatement);
      }
      _out_unboundedloopstatement.close();
      File _assignstatement = new File("AssignStatement.csv");
      PrintWriter _out_assignstatement = new PrintWriter(new BufferedWriter(new FileWriter(_assignstatement)));
      for (int __i = 0; __i < assignstatements.size(); __i++)
      { AssignStatement assignstatementx = (AssignStatement) assignstatements.get(__i);
        assignstatementx.writeCSV(_out_assignstatement);
      }
      _out_assignstatement.close();
      File _sequencestatement = new File("SequenceStatement.csv");
      PrintWriter _out_sequencestatement = new PrintWriter(new BufferedWriter(new FileWriter(_sequencestatement)));
      for (int __i = 0; __i < sequencestatements.size(); __i++)
      { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatements.get(__i);
        sequencestatementx.writeCSV(_out_sequencestatement);
      }
      _out_sequencestatement.close();
      File _conditionalstatement = new File("ConditionalStatement.csv");
      PrintWriter _out_conditionalstatement = new PrintWriter(new BufferedWriter(new FileWriter(_conditionalstatement)));
      for (int __i = 0; __i < conditionalstatements.size(); __i++)
      { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatements.get(__i);
        conditionalstatementx.writeCSV(_out_conditionalstatement);
      }
      _out_conditionalstatement.close();
      File _creationstatement = new File("CreationStatement.csv");
      PrintWriter _out_creationstatement = new PrintWriter(new BufferedWriter(new FileWriter(_creationstatement)));
      for (int __i = 0; __i < creationstatements.size(); __i++)
      { CreationStatement creationstatementx = (CreationStatement) creationstatements.get(__i);
        creationstatementx.writeCSV(_out_creationstatement);
      }
      _out_creationstatement.close();
      File _creturnstatement = new File("CReturnStatement.csv");
      PrintWriter _out_creturnstatement = new PrintWriter(new BufferedWriter(new FileWriter(_creturnstatement)));
      for (int __i = 0; __i < creturnstatements.size(); __i++)
      { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatements.get(__i);
        creturnstatementx.writeCSV(_out_creturnstatement);
      }
      _out_creturnstatement.close();
      File _cbreakstatement = new File("CBreakStatement.csv");
      PrintWriter _out_cbreakstatement = new PrintWriter(new BufferedWriter(new FileWriter(_cbreakstatement)));
      for (int __i = 0; __i < cbreakstatements.size(); __i++)
      { CBreakStatement cbreakstatementx = (CBreakStatement) cbreakstatements.get(__i);
        cbreakstatementx.writeCSV(_out_cbreakstatement);
      }
      _out_cbreakstatement.close();
      File _opcallstatement = new File("OpCallStatement.csv");
      PrintWriter _out_opcallstatement = new PrintWriter(new BufferedWriter(new FileWriter(_opcallstatement)));
      for (int __i = 0; __i < opcallstatements.size(); __i++)
      { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatements.get(__i);
        opcallstatementx.writeCSV(_out_opcallstatement);
      }
      _out_opcallstatement.close();
      File _forloop = new File("ForLoop.csv");
      PrintWriter _out_forloop = new PrintWriter(new BufferedWriter(new FileWriter(_forloop)));
      for (int __i = 0; __i < forloops.size(); __i++)
      { ForLoop forloopx = (ForLoop) forloops.get(__i);
        forloopx.writeCSV(_out_forloop);
      }
      _out_forloop.close();
      File _whileloop = new File("WhileLoop.csv");
      PrintWriter _out_whileloop = new PrintWriter(new BufferedWriter(new FileWriter(_whileloop)));
      for (int __i = 0; __i < whileloops.size(); __i++)
      { WhileLoop whileloopx = (WhileLoop) whileloops.get(__i);
        whileloopx.writeCSV(_out_whileloop);
      }
      _out_whileloop.close();
      File _cassignment = new File("CAssignment.csv");
      PrintWriter _out_cassignment = new PrintWriter(new BufferedWriter(new FileWriter(_cassignment)));
      for (int __i = 0; __i < cassignments.size(); __i++)
      { CAssignment cassignmentx = (CAssignment) cassignments.get(__i);
        cassignmentx.writeCSV(_out_cassignment);
      }
      _out_cassignment.close();
      File _csequencestatement = new File("CSequenceStatement.csv");
      PrintWriter _out_csequencestatement = new PrintWriter(new BufferedWriter(new FileWriter(_csequencestatement)));
      for (int __i = 0; __i < csequencestatements.size(); __i++)
      { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatements.get(__i);
        csequencestatementx.writeCSV(_out_csequencestatement);
      }
      _out_csequencestatement.close();
      File _ifstatement = new File("IfStatement.csv");
      PrintWriter _out_ifstatement = new PrintWriter(new BufferedWriter(new FileWriter(_ifstatement)));
      for (int __i = 0; __i < ifstatements.size(); __i++)
      { IfStatement ifstatementx = (IfStatement) ifstatements.get(__i);
        ifstatementx.writeCSV(_out_ifstatement);
      }
      _out_ifstatement.close();
      File _declarationstatement = new File("DeclarationStatement.csv");
      PrintWriter _out_declarationstatement = new PrintWriter(new BufferedWriter(new FileWriter(_declarationstatement)));
      for (int __i = 0; __i < declarationstatements.size(); __i++)
      { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatements.get(__i);
        declarationstatementx.writeCSV(_out_declarationstatement);
      }
      _out_declarationstatement.close();
      File _printcode = new File("Printcode.csv");
      PrintWriter _out_printcode = new PrintWriter(new BufferedWriter(new FileWriter(_printcode)));
      for (int __i = 0; __i < printcodes.size(); __i++)
      { Printcode printcodex = (Printcode) printcodes.get(__i);
        printcodex.writeCSV(_out_printcode);
      }
      _out_printcode.close();
    }
    catch(Exception __e) { }
  }



  public void addCExpression(CExpression oo) { cexpressions.add(oo); }

  public CExpression getCExpressionByPK(String cexpIdx)
  {  return (CExpression) cexpressioncexpIdindex.get(cexpIdx); }

  public List getCExpressionByPK(List cexpIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cexpIdx.size(); _i++)
    { CExpression cexpressionx = getCExpressionByPK((String) cexpIdx.get(_i));
      if (cexpressionx != null) { res.add(cexpressionx); }
    }
    return res; 
  }

  public void addCBinaryExpression(CBinaryExpression oo) { cbinaryexpressions.add(oo); addCExpression(oo); }

  public CBinaryExpression getCBinaryExpressionByPK(String cexpIdx)
  { if (!(cexpressioncexpIdindex.get(cexpIdx) instanceof CBinaryExpression)) { return null; }
  return (CBinaryExpression) cexpressioncexpIdindex.get(cexpIdx); }

  public List getCBinaryExpressionByPK(List cexpIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cexpIdx.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = getCBinaryExpressionByPK((String) cexpIdx.get(_i));
      if (cbinaryexpressionx != null) { res.add(cbinaryexpressionx); }
    }
    return res; 
  }

  public void addCUnaryExpression(CUnaryExpression oo) { cunaryexpressions.add(oo); addCExpression(oo); }

  public CUnaryExpression getCUnaryExpressionByPK(String cexpIdx)
  { if (!(cexpressioncexpIdindex.get(cexpIdx) instanceof CUnaryExpression)) { return null; }
  return (CUnaryExpression) cexpressioncexpIdindex.get(cexpIdx); }

  public List getCUnaryExpressionByPK(List cexpIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cexpIdx.size(); _i++)
    { CUnaryExpression cunaryexpressionx = getCUnaryExpressionByPK((String) cexpIdx.get(_i));
      if (cunaryexpressionx != null) { res.add(cunaryexpressionx); }
    }
    return res; 
  }

  public void addCType(CType oo) { ctypes.add(oo); }

  public CType getCTypeByPK(String ctypeIdx)
  {  return (CType) ctypectypeIdindex.get(ctypeIdx); }

  public List getCTypeByPK(List ctypeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < ctypeIdx.size(); _i++)
    { CType ctypex = getCTypeByPK((String) ctypeIdx.get(_i));
      if (ctypex != null) { res.add(ctypex); }
    }
    return res; 
  }

  public void addCBasicExpression(CBasicExpression oo) { cbasicexpressions.add(oo); addCExpression(oo); }

  public CBasicExpression getCBasicExpressionByPK(String cexpIdx)
  { if (!(cexpressioncexpIdindex.get(cexpIdx) instanceof CBasicExpression)) { return null; }
  return (CBasicExpression) cexpressioncexpIdindex.get(cexpIdx); }

  public List getCBasicExpressionByPK(List cexpIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cexpIdx.size(); _i++)
    { CBasicExpression cbasicexpressionx = getCBasicExpressionByPK((String) cexpIdx.get(_i));
      if (cbasicexpressionx != null) { res.add(cbasicexpressionx); }
    }
    return res; 
  }

  public void addType(Type oo) { types.add(oo); }

  public Type getTypeByPK(String typeIdx)
  {  return (Type) typetypeIdindex.get(typeIdx); }

  public List getTypeByPK(List typeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < typeIdx.size(); _i++)
    { Type typex = getTypeByPK((String) typeIdx.get(_i));
      if (typex != null) { res.add(typex); }
    }
    return res; 
  }

  public void addClassifier(Classifier oo) { classifiers.add(oo); addType(oo); }

  public Classifier getClassifierByPK(String typeIdx)
  { if (!(typetypeIdindex.get(typeIdx) instanceof Classifier)) { return null; }
  return (Classifier) typetypeIdindex.get(typeIdx); }

  public List getClassifierByPK(List typeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < typeIdx.size(); _i++)
    { Classifier classifierx = getClassifierByPK((String) typeIdx.get(_i));
      if (classifierx != null) { res.add(classifierx); }
    }
    return res; 
  }

  public void addDataType(DataType oo) { datatypes.add(oo); addClassifier(oo); }

  public DataType getDataTypeByPK(String typeIdx)
  { if (!(typetypeIdindex.get(typeIdx) instanceof DataType)) { return null; }
  return (DataType) typetypeIdindex.get(typeIdx); }

  public List getDataTypeByPK(List typeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < typeIdx.size(); _i++)
    { DataType datatypex = getDataTypeByPK((String) typeIdx.get(_i));
      if (datatypex != null) { res.add(datatypex); }
    }
    return res; 
  }

  public void addPrimitiveType(PrimitiveType oo) { primitivetypes.add(oo); addDataType(oo); }

  public PrimitiveType getPrimitiveTypeByPK(String typeIdx)
  { if (!(typetypeIdindex.get(typeIdx) instanceof PrimitiveType)) { return null; }
  return (PrimitiveType) typetypeIdindex.get(typeIdx); }

  public List getPrimitiveTypeByPK(List typeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < typeIdx.size(); _i++)
    { PrimitiveType primitivetypex = getPrimitiveTypeByPK((String) typeIdx.get(_i));
      if (primitivetypex != null) { res.add(primitivetypex); }
    }
    return res; 
  }

  public void addEntity(Entity oo) { entitys.add(oo); addClassifier(oo); }

  public Entity getEntityByPK(String typeIdx)
  { if (!(typetypeIdindex.get(typeIdx) instanceof Entity)) { return null; }
  return (Entity) typetypeIdindex.get(typeIdx); }

  public List getEntityByPK(List typeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < typeIdx.size(); _i++)
    { Entity entityx = getEntityByPK((String) typeIdx.get(_i));
      if (entityx != null) { res.add(entityx); }
    }
    return res; 
  }

  public void addCollectionType(CollectionType oo) { collectiontypes.add(oo); addDataType(oo); }

  public CollectionType getCollectionTypeByPK(String typeIdx)
  { if (!(typetypeIdindex.get(typeIdx) instanceof CollectionType)) { return null; }
  return (CollectionType) typetypeIdindex.get(typeIdx); }

  public List getCollectionTypeByPK(List typeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < typeIdx.size(); _i++)
    { CollectionType collectiontypex = getCollectionTypeByPK((String) typeIdx.get(_i));
      if (collectiontypex != null) { res.add(collectiontypex); }
    }
    return res; 
  }

  public void addExpression(Expression oo) { expressions.add(oo); }

  public Expression getExpressionByPK(String expIdx)
  {  return (Expression) expressionexpIdindex.get(expIdx); }

  public List getExpressionByPK(List expIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < expIdx.size(); _i++)
    { Expression expressionx = getExpressionByPK((String) expIdx.get(_i));
      if (expressionx != null) { res.add(expressionx); }
    }
    return res; 
  }

  public void addBinaryExpression(BinaryExpression oo) { binaryexpressions.add(oo); addExpression(oo); }

  public BinaryExpression getBinaryExpressionByPK(String expIdx)
  { if (!(expressionexpIdindex.get(expIdx) instanceof BinaryExpression)) { return null; }
  return (BinaryExpression) expressionexpIdindex.get(expIdx); }

  public List getBinaryExpressionByPK(List expIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < expIdx.size(); _i++)
    { BinaryExpression binaryexpressionx = getBinaryExpressionByPK((String) expIdx.get(_i));
      if (binaryexpressionx != null) { res.add(binaryexpressionx); }
    }
    return res; 
  }

  public void addUnaryExpression(UnaryExpression oo) { unaryexpressions.add(oo); addExpression(oo); }

  public UnaryExpression getUnaryExpressionByPK(String expIdx)
  { if (!(expressionexpIdindex.get(expIdx) instanceof UnaryExpression)) { return null; }
  return (UnaryExpression) expressionexpIdindex.get(expIdx); }

  public List getUnaryExpressionByPK(List expIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < expIdx.size(); _i++)
    { UnaryExpression unaryexpressionx = getUnaryExpressionByPK((String) expIdx.get(_i));
      if (unaryexpressionx != null) { res.add(unaryexpressionx); }
    }
    return res; 
  }

  public void addCollectionExpression(CollectionExpression oo) { collectionexpressions.add(oo); addExpression(oo); }

  public CollectionExpression getCollectionExpressionByPK(String expIdx)
  { if (!(expressionexpIdindex.get(expIdx) instanceof CollectionExpression)) { return null; }
  return (CollectionExpression) expressionexpIdindex.get(expIdx); }

  public List getCollectionExpressionByPK(List expIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < expIdx.size(); _i++)
    { CollectionExpression collectionexpressionx = getCollectionExpressionByPK((String) expIdx.get(_i));
      if (collectionexpressionx != null) { res.add(collectionexpressionx); }
    }
    return res; 
  }

  public void addBasicExpression(BasicExpression oo) { basicexpressions.add(oo); addExpression(oo); }

  public BasicExpression getBasicExpressionByPK(String expIdx)
  { if (!(expressionexpIdindex.get(expIdx) instanceof BasicExpression)) { return null; }
  return (BasicExpression) expressionexpIdindex.get(expIdx); }

  public List getBasicExpressionByPK(List expIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < expIdx.size(); _i++)
    { BasicExpression basicexpressionx = getBasicExpressionByPK((String) expIdx.get(_i));
      if (basicexpressionx != null) { res.add(basicexpressionx); }
    }
    return res; 
  }

  public void addProperty(Property oo) { propertys.add(oo); }

  public void addExp2C(Exp2C oo) { exp2cs.add(oo); }

  public void addCPrimitiveType(CPrimitiveType oo) { cprimitivetypes.add(oo); addCType(oo); }

  public CPrimitiveType getCPrimitiveTypeByPK(String ctypeIdx)
  { if (!(ctypectypeIdindex.get(ctypeIdx) instanceof CPrimitiveType)) { return null; }
  return (CPrimitiveType) ctypectypeIdindex.get(ctypeIdx); }

  public List getCPrimitiveTypeByPK(List ctypeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < ctypeIdx.size(); _i++)
    { CPrimitiveType cprimitivetypex = getCPrimitiveTypeByPK((String) ctypeIdx.get(_i));
      if (cprimitivetypex != null) { res.add(cprimitivetypex); }
    }
    return res; 
  }

  public void addCArrayType(CArrayType oo) { carraytypes.add(oo); addCType(oo); }

  public CArrayType getCArrayTypeByPK(String ctypeIdx)
  { if (!(ctypectypeIdindex.get(ctypeIdx) instanceof CArrayType)) { return null; }
  return (CArrayType) ctypectypeIdindex.get(ctypeIdx); }

  public List getCArrayTypeByPK(List ctypeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < ctypeIdx.size(); _i++)
    { CArrayType carraytypex = getCArrayTypeByPK((String) ctypeIdx.get(_i));
      if (carraytypex != null) { res.add(carraytypex); }
    }
    return res; 
  }

  public void addCPointerType(CPointerType oo) { cpointertypes.add(oo); addCType(oo); }

  public CPointerType getCPointerTypeByPK(String ctypeIdx)
  { if (!(ctypectypeIdindex.get(ctypeIdx) instanceof CPointerType)) { return null; }
  return (CPointerType) ctypectypeIdindex.get(ctypeIdx); }

  public List getCPointerTypeByPK(List ctypeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < ctypeIdx.size(); _i++)
    { CPointerType cpointertypex = getCPointerTypeByPK((String) ctypeIdx.get(_i));
      if (cpointertypex != null) { res.add(cpointertypex); }
    }
    return res; 
  }

  public void addCStruct(CStruct oo) { cstructs.add(oo); addCType(oo); }

  public CStruct getCStructByPK(String namex)
  {  return (CStruct) cstructnameindex.get(namex); }

  public List getCStructByPK(List namex)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < namex.size(); _i++)
    { CStruct cstructx = getCStructByPK((String) namex.get(_i));
      if (cstructx != null) { res.add(cstructx); }
    }
    return res; 
  }

  public void addCMember(CMember oo) { cmembers.add(oo); }

  public void addCVariable(CVariable oo) { cvariables.add(oo); }

  public void addCProgram(CProgram oo) { cprograms.add(oo); }

  public void addCFunctionPointerType(CFunctionPointerType oo) { cfunctionpointertypes.add(oo); addCType(oo); }

  public CFunctionPointerType getCFunctionPointerTypeByPK(String ctypeIdx)
  { if (!(ctypectypeIdindex.get(ctypeIdx) instanceof CFunctionPointerType)) { return null; }
  return (CFunctionPointerType) ctypectypeIdindex.get(ctypeIdx); }

  public List getCFunctionPointerTypeByPK(List ctypeIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < ctypeIdx.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = getCFunctionPointerTypeByPK((String) ctypeIdx.get(_i));
      if (cfunctionpointertypex != null) { res.add(cfunctionpointertypex); }
    }
    return res; 
  }

  public void addCOperation(COperation oo) { coperations.add(oo); }

  public COperation getCOperationByPK(String opIdx)
  {  return (COperation) coperationopIdindex.get(opIdx); }

  public List getCOperationByPK(List opIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < opIdx.size(); _i++)
    { COperation coperationx = getCOperationByPK((String) opIdx.get(_i));
      if (coperationx != null) { res.add(coperationx); }
    }
    return res; 
  }

  public void addStatement(Statement oo) { statements.add(oo); }

  public Statement getStatementByPK(String statIdx)
  {  return (Statement) statementstatIdindex.get(statIdx); }

  public List getStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { Statement statementx = getStatementByPK((String) statIdx.get(_i));
      if (statementx != null) { res.add(statementx); }
    }
    return res; 
  }

  public void addReturnStatement(ReturnStatement oo) { returnstatements.add(oo); addStatement(oo); }

  public ReturnStatement getReturnStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof ReturnStatement)) { return null; }
  return (ReturnStatement) statementstatIdindex.get(statIdx); }

  public List getReturnStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { ReturnStatement returnstatementx = getReturnStatementByPK((String) statIdx.get(_i));
      if (returnstatementx != null) { res.add(returnstatementx); }
    }
    return res; 
  }

  public void addBehaviouralFeature(BehaviouralFeature oo) { behaviouralfeatures.add(oo); }

  public void addOperation(Operation oo) { operations.add(oo); addBehaviouralFeature(oo); }

  public void addUseCase(UseCase oo) { usecases.add(oo); }

  public void addBreakStatement(BreakStatement oo) { breakstatements.add(oo); addStatement(oo); }

  public BreakStatement getBreakStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof BreakStatement)) { return null; }
  return (BreakStatement) statementstatIdindex.get(statIdx); }

  public List getBreakStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { BreakStatement breakstatementx = getBreakStatementByPK((String) statIdx.get(_i));
      if (breakstatementx != null) { res.add(breakstatementx); }
    }
    return res; 
  }

  public void addOperationCallStatement(OperationCallStatement oo) { operationcallstatements.add(oo); addStatement(oo); }

  public OperationCallStatement getOperationCallStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof OperationCallStatement)) { return null; }
  return (OperationCallStatement) statementstatIdindex.get(statIdx); }

  public List getOperationCallStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { OperationCallStatement operationcallstatementx = getOperationCallStatementByPK((String) statIdx.get(_i));
      if (operationcallstatementx != null) { res.add(operationcallstatementx); }
    }
    return res; 
  }

  public void addImplicitCallStatement(ImplicitCallStatement oo) { implicitcallstatements.add(oo); addStatement(oo); }

  public ImplicitCallStatement getImplicitCallStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof ImplicitCallStatement)) { return null; }
  return (ImplicitCallStatement) statementstatIdindex.get(statIdx); }

  public List getImplicitCallStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { ImplicitCallStatement implicitcallstatementx = getImplicitCallStatementByPK((String) statIdx.get(_i));
      if (implicitcallstatementx != null) { res.add(implicitcallstatementx); }
    }
    return res; 
  }

  public void addLoopStatement(LoopStatement oo) { loopstatements.add(oo); addStatement(oo); }

  public LoopStatement getLoopStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof LoopStatement)) { return null; }
  return (LoopStatement) statementstatIdindex.get(statIdx); }

  public List getLoopStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { LoopStatement loopstatementx = getLoopStatementByPK((String) statIdx.get(_i));
      if (loopstatementx != null) { res.add(loopstatementx); }
    }
    return res; 
  }

  public void addBoundedLoopStatement(BoundedLoopStatement oo) { boundedloopstatements.add(oo); addLoopStatement(oo); }

  public BoundedLoopStatement getBoundedLoopStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof BoundedLoopStatement)) { return null; }
  return (BoundedLoopStatement) statementstatIdindex.get(statIdx); }

  public List getBoundedLoopStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = getBoundedLoopStatementByPK((String) statIdx.get(_i));
      if (boundedloopstatementx != null) { res.add(boundedloopstatementx); }
    }
    return res; 
  }

  public void addUnboundedLoopStatement(UnboundedLoopStatement oo) { unboundedloopstatements.add(oo); addLoopStatement(oo); }

  public UnboundedLoopStatement getUnboundedLoopStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof UnboundedLoopStatement)) { return null; }
  return (UnboundedLoopStatement) statementstatIdindex.get(statIdx); }

  public List getUnboundedLoopStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { UnboundedLoopStatement unboundedloopstatementx = getUnboundedLoopStatementByPK((String) statIdx.get(_i));
      if (unboundedloopstatementx != null) { res.add(unboundedloopstatementx); }
    }
    return res; 
  }

  public void addAssignStatement(AssignStatement oo) { assignstatements.add(oo); addStatement(oo); }

  public AssignStatement getAssignStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof AssignStatement)) { return null; }
  return (AssignStatement) statementstatIdindex.get(statIdx); }

  public List getAssignStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { AssignStatement assignstatementx = getAssignStatementByPK((String) statIdx.get(_i));
      if (assignstatementx != null) { res.add(assignstatementx); }
    }
    return res; 
  }

  public void addSequenceStatement(SequenceStatement oo) { sequencestatements.add(oo); addStatement(oo); }

  public SequenceStatement getSequenceStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof SequenceStatement)) { return null; }
  return (SequenceStatement) statementstatIdindex.get(statIdx); }

  public List getSequenceStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { SequenceStatement sequencestatementx = getSequenceStatementByPK((String) statIdx.get(_i));
      if (sequencestatementx != null) { res.add(sequencestatementx); }
    }
    return res; 
  }

  public void addConditionalStatement(ConditionalStatement oo) { conditionalstatements.add(oo); addStatement(oo); }

  public ConditionalStatement getConditionalStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof ConditionalStatement)) { return null; }
  return (ConditionalStatement) statementstatIdindex.get(statIdx); }

  public List getConditionalStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { ConditionalStatement conditionalstatementx = getConditionalStatementByPK((String) statIdx.get(_i));
      if (conditionalstatementx != null) { res.add(conditionalstatementx); }
    }
    return res; 
  }

  public void addCreationStatement(CreationStatement oo) { creationstatements.add(oo); addStatement(oo); }

  public CreationStatement getCreationStatementByPK(String statIdx)
  { if (!(statementstatIdindex.get(statIdx) instanceof CreationStatement)) { return null; }
  return (CreationStatement) statementstatIdindex.get(statIdx); }

  public List getCreationStatementByPK(List statIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < statIdx.size(); _i++)
    { CreationStatement creationstatementx = getCreationStatementByPK((String) statIdx.get(_i));
      if (creationstatementx != null) { res.add(creationstatementx); }
    }
    return res; 
  }

  public void addCStatement(CStatement oo) { cstatements.add(oo); }

  public CStatement getCStatementByPK(String cstatIdx)
  {  return (CStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getCStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { CStatement cstatementx = getCStatementByPK((String) cstatIdx.get(_i));
      if (cstatementx != null) { res.add(cstatementx); }
    }
    return res; 
  }

  public void addCReturnStatement(CReturnStatement oo) { creturnstatements.add(oo); addCStatement(oo); }

  public CReturnStatement getCReturnStatementByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof CReturnStatement)) { return null; }
  return (CReturnStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getCReturnStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { CReturnStatement creturnstatementx = getCReturnStatementByPK((String) cstatIdx.get(_i));
      if (creturnstatementx != null) { res.add(creturnstatementx); }
    }
    return res; 
  }

  public void addCBreakStatement(CBreakStatement oo) { cbreakstatements.add(oo); addCStatement(oo); }

  public CBreakStatement getCBreakStatementByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof CBreakStatement)) { return null; }
  return (CBreakStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getCBreakStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { CBreakStatement cbreakstatementx = getCBreakStatementByPK((String) cstatIdx.get(_i));
      if (cbreakstatementx != null) { res.add(cbreakstatementx); }
    }
    return res; 
  }

  public void addOpCallStatement(OpCallStatement oo) { opcallstatements.add(oo); addCStatement(oo); }

  public OpCallStatement getOpCallStatementByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof OpCallStatement)) { return null; }
  return (OpCallStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getOpCallStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { OpCallStatement opcallstatementx = getOpCallStatementByPK((String) cstatIdx.get(_i));
      if (opcallstatementx != null) { res.add(opcallstatementx); }
    }
    return res; 
  }

  public void addCLoopStatement(CLoopStatement oo) { cloopstatements.add(oo); addCStatement(oo); }

  public CLoopStatement getCLoopStatementByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof CLoopStatement)) { return null; }
  return (CLoopStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getCLoopStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { CLoopStatement cloopstatementx = getCLoopStatementByPK((String) cstatIdx.get(_i));
      if (cloopstatementx != null) { res.add(cloopstatementx); }
    }
    return res; 
  }

  public void addForLoop(ForLoop oo) { forloops.add(oo); addCLoopStatement(oo); }

  public ForLoop getForLoopByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof ForLoop)) { return null; }
  return (ForLoop) cstatementcstatIdindex.get(cstatIdx); }

  public List getForLoopByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { ForLoop forloopx = getForLoopByPK((String) cstatIdx.get(_i));
      if (forloopx != null) { res.add(forloopx); }
    }
    return res; 
  }

  public void addWhileLoop(WhileLoop oo) { whileloops.add(oo); addCLoopStatement(oo); }

  public WhileLoop getWhileLoopByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof WhileLoop)) { return null; }
  return (WhileLoop) cstatementcstatIdindex.get(cstatIdx); }

  public List getWhileLoopByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { WhileLoop whileloopx = getWhileLoopByPK((String) cstatIdx.get(_i));
      if (whileloopx != null) { res.add(whileloopx); }
    }
    return res; 
  }

  public void addCAssignment(CAssignment oo) { cassignments.add(oo); addCStatement(oo); }

  public CAssignment getCAssignmentByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof CAssignment)) { return null; }
  return (CAssignment) cstatementcstatIdindex.get(cstatIdx); }

  public List getCAssignmentByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { CAssignment cassignmentx = getCAssignmentByPK((String) cstatIdx.get(_i));
      if (cassignmentx != null) { res.add(cassignmentx); }
    }
    return res; 
  }

  public void addCSequenceStatement(CSequenceStatement oo) { csequencestatements.add(oo); addCStatement(oo); }

  public CSequenceStatement getCSequenceStatementByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof CSequenceStatement)) { return null; }
  return (CSequenceStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getCSequenceStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { CSequenceStatement csequencestatementx = getCSequenceStatementByPK((String) cstatIdx.get(_i));
      if (csequencestatementx != null) { res.add(csequencestatementx); }
    }
    return res; 
  }

  public void addIfStatement(IfStatement oo) { ifstatements.add(oo); addCStatement(oo); }

  public IfStatement getIfStatementByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof IfStatement)) { return null; }
  return (IfStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getIfStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { IfStatement ifstatementx = getIfStatementByPK((String) cstatIdx.get(_i));
      if (ifstatementx != null) { res.add(ifstatementx); }
    }
    return res; 
  }

  public void addDeclarationStatement(DeclarationStatement oo) { declarationstatements.add(oo); addCStatement(oo); }

  public DeclarationStatement getDeclarationStatementByPK(String cstatIdx)
  { if (!(cstatementcstatIdindex.get(cstatIdx) instanceof DeclarationStatement)) { return null; }
  return (DeclarationStatement) cstatementcstatIdindex.get(cstatIdx); }

  public List getDeclarationStatementByPK(List cstatIdx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < cstatIdx.size(); _i++)
    { DeclarationStatement declarationstatementx = getDeclarationStatementByPK((String) cstatIdx.get(_i));
      if (declarationstatementx != null) { res.add(declarationstatementx); }
    }
    return res; 
  }

  public void addPrintcode(Printcode oo) { printcodes.add(oo); }



  public CBinaryExpression createCBinaryExpression()
  { CBinaryExpression cbinaryexpressionx = new CBinaryExpression();
    addCBinaryExpression(cbinaryexpressionx);
    return cbinaryexpressionx;
  }

  public CUnaryExpression createCUnaryExpression()
  { CUnaryExpression cunaryexpressionx = new CUnaryExpression();
    addCUnaryExpression(cunaryexpressionx);
    return cunaryexpressionx;
  }

  public CBasicExpression createCBasicExpression()
  { CBasicExpression cbasicexpressionx = new CBasicExpression();
    addCBasicExpression(cbasicexpressionx);
    return cbasicexpressionx;
  }

  public PrimitiveType createPrimitiveType()
  { PrimitiveType primitivetypex = new PrimitiveType();
    addPrimitiveType(primitivetypex);
    return primitivetypex;
  }

  public Entity createEntity()
  { Entity entityx = new Entity();
    addEntity(entityx);
    return entityx;
  }

  public CollectionType createCollectionType()
  { CollectionType collectiontypex = new CollectionType();
    addCollectionType(collectiontypex);
    return collectiontypex;
  }

  public BinaryExpression createBinaryExpression()
  { BinaryExpression binaryexpressionx = new BinaryExpression();
    addBinaryExpression(binaryexpressionx);
    return binaryexpressionx;
  }

  public UnaryExpression createUnaryExpression()
  { UnaryExpression unaryexpressionx = new UnaryExpression();
    addUnaryExpression(unaryexpressionx);
    return unaryexpressionx;
  }

  public CollectionExpression createCollectionExpression()
  { CollectionExpression collectionexpressionx = new CollectionExpression();
    addCollectionExpression(collectionexpressionx);
    return collectionexpressionx;
  }

  public BasicExpression createBasicExpression()
  { BasicExpression basicexpressionx = new BasicExpression();
    addBasicExpression(basicexpressionx);
    return basicexpressionx;
  }

  public Property createProperty()
  { Property propertyx = new Property();
    addProperty(propertyx);
    return propertyx;
  }

  public Exp2C createExp2C()
  { Exp2C exp2cx = new Exp2C();
    addExp2C(exp2cx);
    return exp2cx;
  }

  public CPrimitiveType createCPrimitiveType()
  { CPrimitiveType cprimitivetypex = new CPrimitiveType();
    addCPrimitiveType(cprimitivetypex);
    return cprimitivetypex;
  }

  public CArrayType createCArrayType()
  { CArrayType carraytypex = new CArrayType();
    addCArrayType(carraytypex);
    return carraytypex;
  }

  public CPointerType createCPointerType()
  { CPointerType cpointertypex = new CPointerType();
    addCPointerType(cpointertypex);
    return cpointertypex;
  }

  public CStruct createCStruct()
  { CStruct cstructx = new CStruct();
    addCStruct(cstructx);
    return cstructx;
  }

  public CMember createCMember()
  { CMember cmemberx = new CMember();
    addCMember(cmemberx);
    return cmemberx;
  }

  public CVariable createCVariable()
  { CVariable cvariablex = new CVariable();
    addCVariable(cvariablex);
    return cvariablex;
  }

  public CProgram createCProgram()
  { CProgram cprogramx = new CProgram();
    addCProgram(cprogramx);
    return cprogramx;
  }

  public CFunctionPointerType createCFunctionPointerType()
  { CFunctionPointerType cfunctionpointertypex = new CFunctionPointerType();
    addCFunctionPointerType(cfunctionpointertypex);
    return cfunctionpointertypex;
  }

  public COperation createCOperation()
  { COperation coperationx = new COperation();
    addCOperation(coperationx);
    return coperationx;
  }

  public ReturnStatement createReturnStatement()
  { ReturnStatement returnstatementx = new ReturnStatement();
    addReturnStatement(returnstatementx);
    return returnstatementx;
  }

  public Operation createOperation()
  { Operation operationx = new Operation();
    addOperation(operationx);
    return operationx;
  }

  public UseCase createUseCase()
  { UseCase usecasex = new UseCase();
    addUseCase(usecasex);
    return usecasex;
  }

  public BreakStatement createBreakStatement()
  { BreakStatement breakstatementx = new BreakStatement();
    addBreakStatement(breakstatementx);
    return breakstatementx;
  }

  public OperationCallStatement createOperationCallStatement()
  { OperationCallStatement operationcallstatementx = new OperationCallStatement();
    addOperationCallStatement(operationcallstatementx);
    return operationcallstatementx;
  }

  public ImplicitCallStatement createImplicitCallStatement()
  { ImplicitCallStatement implicitcallstatementx = new ImplicitCallStatement();
    addImplicitCallStatement(implicitcallstatementx);
    return implicitcallstatementx;
  }

  public BoundedLoopStatement createBoundedLoopStatement()
  { BoundedLoopStatement boundedloopstatementx = new BoundedLoopStatement();
    addBoundedLoopStatement(boundedloopstatementx);
    return boundedloopstatementx;
  }

  public UnboundedLoopStatement createUnboundedLoopStatement()
  { UnboundedLoopStatement unboundedloopstatementx = new UnboundedLoopStatement();
    addUnboundedLoopStatement(unboundedloopstatementx);
    return unboundedloopstatementx;
  }

  public AssignStatement createAssignStatement()
  { AssignStatement assignstatementx = new AssignStatement();
    addAssignStatement(assignstatementx);
    return assignstatementx;
  }

  public SequenceStatement createSequenceStatement()
  { SequenceStatement sequencestatementx = new SequenceStatement();
    addSequenceStatement(sequencestatementx);
    return sequencestatementx;
  }

  public ConditionalStatement createConditionalStatement()
  { ConditionalStatement conditionalstatementx = new ConditionalStatement();
    addConditionalStatement(conditionalstatementx);
    return conditionalstatementx;
  }

  public CreationStatement createCreationStatement()
  { CreationStatement creationstatementx = new CreationStatement();
    addCreationStatement(creationstatementx);
    return creationstatementx;
  }

  public CReturnStatement createCReturnStatement()
  { CReturnStatement creturnstatementx = new CReturnStatement();
    addCReturnStatement(creturnstatementx);
    return creturnstatementx;
  }

  public CBreakStatement createCBreakStatement()
  { CBreakStatement cbreakstatementx = new CBreakStatement();
    addCBreakStatement(cbreakstatementx);
    return cbreakstatementx;
  }

  public OpCallStatement createOpCallStatement()
  { OpCallStatement opcallstatementx = new OpCallStatement();
    addOpCallStatement(opcallstatementx);
    return opcallstatementx;
  }

  public ForLoop createForLoop()
  { ForLoop forloopx = new ForLoop();
    addForLoop(forloopx);
    return forloopx;
  }

  public WhileLoop createWhileLoop()
  { WhileLoop whileloopx = new WhileLoop();
    addWhileLoop(whileloopx);
    return whileloopx;
  }

  public CAssignment createCAssignment()
  { CAssignment cassignmentx = new CAssignment();
    addCAssignment(cassignmentx);
    return cassignmentx;
  }

  public CSequenceStatement createCSequenceStatement()
  { CSequenceStatement csequencestatementx = new CSequenceStatement();
    addCSequenceStatement(csequencestatementx);
    return csequencestatementx;
  }

  public IfStatement createIfStatement()
  { IfStatement ifstatementx = new IfStatement();
    addIfStatement(ifstatementx);
    return ifstatementx;
  }

  public DeclarationStatement createDeclarationStatement()
  { DeclarationStatement declarationstatementx = new DeclarationStatement();
    addDeclarationStatement(declarationstatementx);
    return declarationstatementx;
  }

  public Printcode createPrintcode()
  { Printcode printcodex = new Printcode();
    addPrintcode(printcodex);
    return printcodex;
  }


public void setneedsBracket(CExpression cexpressionx, boolean needsBracket_x) 
  { cexpressionx.setneedsBracket(needsBracket_x);
    }


public void setkind(CExpression cexpressionx, String kind_x) 
  { cexpressionx.setkind(kind_x);
    }


public void setcexpId(CExpression cexpressionx, String cexpId_x) 
  { if (cexpressioncexpIdindex.get(cexpId_x) != null) { return; }
  cexpressioncexpIdindex.remove(cexpressionx.getcexpId());
  cexpressionx.setcexpId(cexpId_x);
  cexpressioncexpIdindex.put(cexpId_x,cexpressionx);
    }


public void setisStatic(CExpression cexpressionx, boolean isStatic_x) 
  { cexpressionx.setisStatic(isStatic_x);
    }


  public void settype(CExpression cexpressionx, CType typexx) 
  {   if (cexpressionx.gettype() == typexx) { return; }
    cexpressionx.settype(typexx);
      }


  public void setelementType(CExpression cexpressionx, CType elementTypexx) 
  {   if (cexpressionx.getelementType() == elementTypexx) { return; }
    cexpressionx.setelementType(elementTypexx);
      }


public void setoperator(CBinaryExpression cbinaryexpressionx, String operator_x) 
  { cbinaryexpressionx.setoperator(operator_x);
    }


  public void setleft(CBinaryExpression cbinaryexpressionx, CExpression leftxx) 
  {   if (cbinaryexpressionx.getleft() == leftxx) { return; }
    cbinaryexpressionx.setleft(leftxx);
      }


  public void setright(CBinaryExpression cbinaryexpressionx, CExpression rightxx) 
  {   if (cbinaryexpressionx.getright() == rightxx) { return; }
    cbinaryexpressionx.setright(rightxx);
      }


public void setoperator(CUnaryExpression cunaryexpressionx, String operator_x) 
  { cunaryexpressionx.setoperator(operator_x);
    }


  public void setargument(CUnaryExpression cunaryexpressionx, CExpression argumentxx) 
  {   if (cunaryexpressionx.getargument() == argumentxx) { return; }
    for (int _q = 0; _q < cunaryexpressions.size(); _q++)
    { CUnaryExpression _q_E1x = (CUnaryExpression) cunaryexpressions.get(_q);
      if (_q_E1x.getargument() == argumentxx)
      { _q_E1x.setargument(null); }
    }
    cunaryexpressionx.setargument(argumentxx);
      }


public void setctypeId(CType ctypex, String ctypeId_x) 
  { if (ctypectypeIdindex.get(ctypeId_x) != null) { return; }
  ctypectypeIdindex.remove(ctypex.getctypeId());
  ctypex.setctypeId(ctypeId_x);
  ctypectypeIdindex.put(ctypeId_x,ctypex);
    }


public void setname(CType ctypex, String name_x) 
  { ctypex.setname(name_x);
    }


public void setdata(CBasicExpression cbasicexpressionx, String data_x) 
  { cbasicexpressionx.setdata(data_x);
    }


  public void setparameters(CBasicExpression cbasicexpressionx, List parametersxx) 
  {     cbasicexpressionx.setparameters(parametersxx);
      }


  public void setparameters(CBasicExpression cbasicexpressionx, int _ind, CExpression cexpressionx) 
  { cbasicexpressionx.setparameters(_ind,cexpressionx); }
  
  public void addparameters(CBasicExpression cbasicexpressionx, CExpression parametersxx) 
  {     cbasicexpressionx.addparameters(parametersxx);
   }


  public void removeparameters(CBasicExpression cbasicexpressionx, CExpression parametersxx) 
  { cbasicexpressionx.removeparameters(parametersxx);
    }


 public void unionparameters(CBasicExpression cbasicexpressionx, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { CExpression cexpressionxparameters = (CExpression) parametersx.get(_i);
      addparameters(cbasicexpressionx, cexpressionxparameters);
     } } 


 public void subtractparameters(CBasicExpression cbasicexpressionx, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { CExpression cexpressionxparameters = (CExpression) parametersx.get(_i);
      removeparameters(cbasicexpressionx, cexpressionxparameters);
     } } 


  public void setarrayIndex(CBasicExpression cbasicexpressionx, List arrayIndexxx) 
  {   if (arrayIndexxx.size() > 1) { return; }
  List _oldarrayIndexxx = cbasicexpressionx.getarrayIndex();
  for (int _i = 0; _i < arrayIndexxx.size(); _i++)
  { CBasicExpression _xx = (CBasicExpression) arrayIndexxx.get(_i);
    if (_oldarrayIndexxx.contains(_xx)) { }
    else { CBasicExpression.removeAllarrayIndex(cbasicexpressions, _xx); }
  }
    cbasicexpressionx.setarrayIndex(arrayIndexxx);
      }


  public void addarrayIndex(CBasicExpression cbasicexpressionx, CBasicExpression arrayIndexxx) 
  { if (cbasicexpressionx.getarrayIndex().contains(arrayIndexxx)) { return; }
      if (cbasicexpressionx.getarrayIndex().size() > 0)
    { CBasicExpression cbasicexpression_xx = (CBasicExpression) cbasicexpressionx.getarrayIndex().get(0);
      cbasicexpressionx.removearrayIndex(cbasicexpression_xx);
      }
    CBasicExpression.removeAllarrayIndex(cbasicexpressions,arrayIndexxx);
    cbasicexpressionx.addarrayIndex(arrayIndexxx);
   }


  public void removearrayIndex(CBasicExpression cbasicexpressionx, CBasicExpression arrayIndexxx) 
  { cbasicexpressionx.removearrayIndex(arrayIndexxx);
    }


 public void unionarrayIndex(CBasicExpression cbasicexpressionx, List arrayIndexx)
  { for (int _i = 0; _i < arrayIndexx.size(); _i++)
    { CBasicExpression cbasicexpressionxarrayIndex = (CBasicExpression) arrayIndexx.get(_i);
      addarrayIndex(cbasicexpressionx, cbasicexpressionxarrayIndex);
     } } 


 public void subtractarrayIndex(CBasicExpression cbasicexpressionx, List arrayIndexx)
  { for (int _i = 0; _i < arrayIndexx.size(); _i++)
    { CBasicExpression cbasicexpressionxarrayIndex = (CBasicExpression) arrayIndexx.get(_i);
      removearrayIndex(cbasicexpressionx, cbasicexpressionxarrayIndex);
     } } 


  public void setreference(CBasicExpression cbasicexpressionx, List referencexx) 
  {   if (referencexx.size() > 1) { return; }
  List _oldreferencexx = cbasicexpressionx.getreference();
  for (int _i = 0; _i < referencexx.size(); _i++)
  { CBasicExpression _xx = (CBasicExpression) referencexx.get(_i);
    if (_oldreferencexx.contains(_xx)) { }
    else { CBasicExpression.removeAllreference(cbasicexpressions, _xx); }
  }
    cbasicexpressionx.setreference(referencexx);
      }


  public void addreference(CBasicExpression cbasicexpressionx, CBasicExpression referencexx) 
  { if (cbasicexpressionx.getreference().contains(referencexx)) { return; }
      if (cbasicexpressionx.getreference().size() > 0)
    { CBasicExpression cbasicexpression_xx = (CBasicExpression) cbasicexpressionx.getreference().get(0);
      cbasicexpressionx.removereference(cbasicexpression_xx);
      }
    CBasicExpression.removeAllreference(cbasicexpressions,referencexx);
    cbasicexpressionx.addreference(referencexx);
   }


  public void removereference(CBasicExpression cbasicexpressionx, CBasicExpression referencexx) 
  { cbasicexpressionx.removereference(referencexx);
    }


 public void unionreference(CBasicExpression cbasicexpressionx, List referencex)
  { for (int _i = 0; _i < referencex.size(); _i++)
    { CBasicExpression cbasicexpressionxreference = (CBasicExpression) referencex.get(_i);
      addreference(cbasicexpressionx, cbasicexpressionxreference);
     } } 


 public void subtractreference(CBasicExpression cbasicexpressionx, List referencex)
  { for (int _i = 0; _i < referencex.size(); _i++)
    { CBasicExpression cbasicexpressionxreference = (CBasicExpression) referencex.get(_i);
      removereference(cbasicexpressionx, cbasicexpressionxreference);
     } } 


public void settypeId(Type typex, String typeId_x) 
  { if (typetypeIdindex.get(typeId_x) != null) { return; }
  typetypeIdindex.remove(typex.gettypeId());
  typex.settypeId(typeId_x);
  typetypeIdindex.put(typeId_x,typex);
    }


public void setname(Type typex, String name_x) 
  { typex.setname(name_x);
    }


public void setisAbstract(Entity entityx, boolean isAbstract_x) 
  { entityx.setisAbstract(isAbstract_x);
    }


public void setisInterface(Entity entityx, boolean isInterface_x) 
  { entityx.setisInterface(isInterface_x);
    }


  public void setownedOperation(Entity entityx, List ownedOperationxx) 
  {   List _oldownedOperationxx = entityx.getownedOperation();
    for (int _j = 0; _j < _oldownedOperationxx.size(); _j++)
    { Operation _yy = (Operation) _oldownedOperationxx.get(_j);
      if (ownedOperationxx.contains(_yy)) { }
      else { _yy.setowner(null); }
    }
  for (int _i = 0; _i < ownedOperationxx.size(); _i++)
  { Operation _xx = (Operation) ownedOperationxx.get(_i);
    if (_oldownedOperationxx.contains(_xx)) { }
    else { if (_xx.getowner() != null) { _xx.getowner().removeownedOperation(_xx); }  }
    _xx.setowner(entityx);
  }
    entityx.setownedOperation(ownedOperationxx);
      }


  public void setownedOperation(Entity entityx, int _ind, Operation operationx) 
  { entityx.setownedOperation(_ind,operationx); }
  
  public void addownedOperation(Entity entityx, Operation ownedOperationxx) 
  {   if (ownedOperationxx.getowner() != null) { ownedOperationxx.getowner().removeownedOperation(ownedOperationxx); }
  ownedOperationxx.setowner(entityx);
    entityx.addownedOperation(ownedOperationxx);
   }


  public void removeownedOperation(Entity entityx, Operation ownedOperationxx) 
  { entityx.removeownedOperation(ownedOperationxx);
      ownedOperationxx.setowner(null);
  }


 public void unionownedOperation(Entity entityx, List ownedOperationx)
  { for (int _i = 0; _i < ownedOperationx.size(); _i++)
    { Operation operationxownedOperation = (Operation) ownedOperationx.get(_i);
      addownedOperation(entityx, operationxownedOperation);
     } } 


 public void subtractownedOperation(Entity entityx, List ownedOperationx)
  { for (int _i = 0; _i < ownedOperationx.size(); _i++)
    { Operation operationxownedOperation = (Operation) ownedOperationx.get(_i);
      removeownedOperation(entityx, operationxownedOperation);
     } } 


  public void setownedAttribute(Entity entityx, List ownedAttributexx) 
  {   List _oldownedAttributexx = entityx.getownedAttribute();
    for (int _j = 0; _j < _oldownedAttributexx.size(); _j++)
    { Property _yy = (Property) _oldownedAttributexx.get(_j);
      if (ownedAttributexx.contains(_yy)) { }
      else { _yy.setowner(null); }
    }
  for (int _i = 0; _i < ownedAttributexx.size(); _i++)
  { Property _xx = (Property) ownedAttributexx.get(_i);
    if (_oldownedAttributexx.contains(_xx)) { }
    else { if (_xx.getowner() != null) { _xx.getowner().removeownedAttribute(_xx); }  }
    _xx.setowner(entityx);
  }
    entityx.setownedAttribute(ownedAttributexx);
      }


  public void addownedAttribute(Entity entityx, Property ownedAttributexx) 
  { if (entityx.getownedAttribute().contains(ownedAttributexx)) { return; }
    if (ownedAttributexx.getowner() != null) { ownedAttributexx.getowner().removeownedAttribute(ownedAttributexx); }
  ownedAttributexx.setowner(entityx);
    entityx.addownedAttribute(ownedAttributexx);
   }


  public void removeownedAttribute(Entity entityx, Property ownedAttributexx) 
  { entityx.removeownedAttribute(ownedAttributexx);
      ownedAttributexx.setowner(null);
  }


 public void unionownedAttribute(Entity entityx, List ownedAttributex)
  { for (int _i = 0; _i < ownedAttributex.size(); _i++)
    { Property propertyxownedAttribute = (Property) ownedAttributex.get(_i);
      addownedAttribute(entityx, propertyxownedAttribute);
     } } 


 public void subtractownedAttribute(Entity entityx, List ownedAttributex)
  { for (int _i = 0; _i < ownedAttributex.size(); _i++)
    { Property propertyxownedAttribute = (Property) ownedAttributex.get(_i);
      removeownedAttribute(entityx, propertyxownedAttribute);
     } } 


  public void setelementType(CollectionType collectiontypex, Type elementTypexx) 
  {   if (collectiontypex.getelementType() == elementTypexx) { return; }
    collectiontypex.setelementType(elementTypexx);
      }


  public void setkeyType(CollectionType collectiontypex, Type keyTypexx) 
  {   if (collectiontypex.getkeyType() == keyTypexx) { return; }
    collectiontypex.setkeyType(keyTypexx);
      }


public void setneedsBracket(Expression expressionx, boolean needsBracket_x) 
  { expressionx.setneedsBracket(needsBracket_x);
    }


public void setumlKind(Expression expressionx, int umlKind_x) 
  { expressionx.setumlKind(umlKind_x);
    }


public void setexpId(Expression expressionx, String expId_x) 
  { if (expressionexpIdindex.get(expId_x) != null) { return; }
  expressionexpIdindex.remove(expressionx.getexpId());
  expressionx.setexpId(expId_x);
  expressionexpIdindex.put(expId_x,expressionx);
    }


public void setisStatic(Expression expressionx, boolean isStatic_x) 
  { expressionx.setisStatic(isStatic_x);
    }


  public void settype(Expression expressionx, Type typexx) 
  {   if (expressionx.gettype() == typexx) { return; }
    expressionx.settype(typexx);
      }


  public void setelementType(Expression expressionx, Type elementTypexx) 
  {   if (expressionx.getelementType() == elementTypexx) { return; }
    expressionx.setelementType(elementTypexx);
      }


public void setoperator(BinaryExpression binaryexpressionx, String operator_x) 
  { binaryexpressionx.setoperator(operator_x);
    }


public void setvariable(BinaryExpression binaryexpressionx, String variable_x) 
  { binaryexpressionx.setvariable(variable_x);
    }


  public void setleft(BinaryExpression binaryexpressionx, Expression leftxx) 
  {   if (binaryexpressionx.getleft() == leftxx) { return; }
    binaryexpressionx.setleft(leftxx);
      }


  public void setright(BinaryExpression binaryexpressionx, Expression rightxx) 
  {   if (binaryexpressionx.getright() == rightxx) { return; }
    binaryexpressionx.setright(rightxx);
      }


public void setoperator(UnaryExpression unaryexpressionx, String operator_x) 
  { unaryexpressionx.setoperator(operator_x);
    }


public void setvariable(UnaryExpression unaryexpressionx, String variable_x) 
  { unaryexpressionx.setvariable(variable_x);
    }


  public void setargument(UnaryExpression unaryexpressionx, Expression argumentxx) 
  {   if (unaryexpressionx.getargument() == argumentxx) { return; }
    for (int _q = 0; _q < unaryexpressions.size(); _q++)
    { UnaryExpression _q_E1x = (UnaryExpression) unaryexpressions.get(_q);
      if (_q_E1x.getargument() == argumentxx)
      { _q_E1x.setargument(null); }
    }
    unaryexpressionx.setargument(argumentxx);
      }


public void setisOrdered(CollectionExpression collectionexpressionx, boolean isOrdered_x) 
  { collectionexpressionx.setisOrdered(isOrdered_x);
    }


  public void setelements(CollectionExpression collectionexpressionx, List elementsxx) 
  {     collectionexpressionx.setelements(elementsxx);
      }


  public void addelements(CollectionExpression collectionexpressionx, Expression elementsxx) 
  { if (collectionexpressionx.getelements().contains(elementsxx)) { return; }
      collectionexpressionx.addelements(elementsxx);
   }


  public void removeelements(CollectionExpression collectionexpressionx, Expression elementsxx) 
  { collectionexpressionx.removeelements(elementsxx);
    }


 public void unionelements(CollectionExpression collectionexpressionx, List elementsx)
  { for (int _i = 0; _i < elementsx.size(); _i++)
    { Expression expressionxelements = (Expression) elementsx.get(_i);
      addelements(collectionexpressionx, expressionxelements);
     } } 


 public void subtractelements(CollectionExpression collectionexpressionx, List elementsx)
  { for (int _i = 0; _i < elementsx.size(); _i++)
    { Expression expressionxelements = (Expression) elementsx.get(_i);
      removeelements(collectionexpressionx, expressionxelements);
     } } 


public void setdata(BasicExpression basicexpressionx, String data_x) 
  { basicexpressionx.setdata(data_x);
    }


public void setprestate(BasicExpression basicexpressionx, boolean prestate_x) 
  { basicexpressionx.setprestate(prestate_x);
    }


  public void setparameters(BasicExpression basicexpressionx, List parametersxx) 
  {     basicexpressionx.setparameters(parametersxx);
      }


  public void setparameters(BasicExpression basicexpressionx, int _ind, Expression expressionx) 
  { basicexpressionx.setparameters(_ind,expressionx); }
  
  public void addparameters(BasicExpression basicexpressionx, Expression parametersxx) 
  {     basicexpressionx.addparameters(parametersxx);
   }


  public void removeparameters(BasicExpression basicexpressionx, Expression parametersxx) 
  { basicexpressionx.removeparameters(parametersxx);
    }


 public void unionparameters(BasicExpression basicexpressionx, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { Expression expressionxparameters = (Expression) parametersx.get(_i);
      addparameters(basicexpressionx, expressionxparameters);
     } } 


 public void subtractparameters(BasicExpression basicexpressionx, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { Expression expressionxparameters = (Expression) parametersx.get(_i);
      removeparameters(basicexpressionx, expressionxparameters);
     } } 


  public void setreferredProperty(BasicExpression basicexpressionx, List referredPropertyxx) 
  {   if (referredPropertyxx.size() > 1) { return; }
    basicexpressionx.setreferredProperty(referredPropertyxx);
      }


  public void addreferredProperty(BasicExpression basicexpressionx, Property referredPropertyxx) 
  { if (basicexpressionx.getreferredProperty().contains(referredPropertyxx)) { return; }
      if (basicexpressionx.getreferredProperty().size() > 0)
    { Property property_xx = (Property) basicexpressionx.getreferredProperty().get(0);
      basicexpressionx.removereferredProperty(property_xx);
      }
      basicexpressionx.addreferredProperty(referredPropertyxx);
   }


  public void removereferredProperty(BasicExpression basicexpressionx, Property referredPropertyxx) 
  { basicexpressionx.removereferredProperty(referredPropertyxx);
    }


 public void unionreferredProperty(BasicExpression basicexpressionx, List referredPropertyx)
  { for (int _i = 0; _i < referredPropertyx.size(); _i++)
    { Property propertyxreferredProperty = (Property) referredPropertyx.get(_i);
      addreferredProperty(basicexpressionx, propertyxreferredProperty);
     } } 


 public void subtractreferredProperty(BasicExpression basicexpressionx, List referredPropertyx)
  { for (int _i = 0; _i < referredPropertyx.size(); _i++)
    { Property propertyxreferredProperty = (Property) referredPropertyx.get(_i);
      removereferredProperty(basicexpressionx, propertyxreferredProperty);
     } } 


  public void setcontext(BasicExpression basicexpressionx, List contextxx) 
  {     basicexpressionx.setcontext(contextxx);
      }


  public void addcontext(BasicExpression basicexpressionx, Entity contextxx) 
  { if (basicexpressionx.getcontext().contains(contextxx)) { return; }
      basicexpressionx.addcontext(contextxx);
   }


  public void removecontext(BasicExpression basicexpressionx, Entity contextxx) 
  { basicexpressionx.removecontext(contextxx);
    }


 public void unioncontext(BasicExpression basicexpressionx, List contextx)
  { for (int _i = 0; _i < contextx.size(); _i++)
    { Entity entityxcontext = (Entity) contextx.get(_i);
      addcontext(basicexpressionx, entityxcontext);
     } } 


 public void subtractcontext(BasicExpression basicexpressionx, List contextx)
  { for (int _i = 0; _i < contextx.size(); _i++)
    { Entity entityxcontext = (Entity) contextx.get(_i);
      removecontext(basicexpressionx, entityxcontext);
     } } 


  public void setarrayIndex(BasicExpression basicexpressionx, List arrayIndexxx) 
  {   if (arrayIndexxx.size() > 1) { return; }
  List _oldarrayIndexxx = basicexpressionx.getarrayIndex();
  for (int _i = 0; _i < arrayIndexxx.size(); _i++)
  { BasicExpression _xx = (BasicExpression) arrayIndexxx.get(_i);
    if (_oldarrayIndexxx.contains(_xx)) { }
    else { BasicExpression.removeAllarrayIndex(basicexpressions, _xx); }
  }
    basicexpressionx.setarrayIndex(arrayIndexxx);
      }


  public void addarrayIndex(BasicExpression basicexpressionx, BasicExpression arrayIndexxx) 
  { if (basicexpressionx.getarrayIndex().contains(arrayIndexxx)) { return; }
      if (basicexpressionx.getarrayIndex().size() > 0)
    { BasicExpression basicexpression_xx = (BasicExpression) basicexpressionx.getarrayIndex().get(0);
      basicexpressionx.removearrayIndex(basicexpression_xx);
      }
    BasicExpression.removeAllarrayIndex(basicexpressions,arrayIndexxx);
    basicexpressionx.addarrayIndex(arrayIndexxx);
   }


  public void removearrayIndex(BasicExpression basicexpressionx, BasicExpression arrayIndexxx) 
  { basicexpressionx.removearrayIndex(arrayIndexxx);
    }


 public void unionarrayIndex(BasicExpression basicexpressionx, List arrayIndexx)
  { for (int _i = 0; _i < arrayIndexx.size(); _i++)
    { BasicExpression basicexpressionxarrayIndex = (BasicExpression) arrayIndexx.get(_i);
      addarrayIndex(basicexpressionx, basicexpressionxarrayIndex);
     } } 


 public void subtractarrayIndex(BasicExpression basicexpressionx, List arrayIndexx)
  { for (int _i = 0; _i < arrayIndexx.size(); _i++)
    { BasicExpression basicexpressionxarrayIndex = (BasicExpression) arrayIndexx.get(_i);
      removearrayIndex(basicexpressionx, basicexpressionxarrayIndex);
     } } 


  public void setobjectRef(BasicExpression basicexpressionx, List objectRefxx) 
  {   if (objectRefxx.size() > 1) { return; }
  List _oldobjectRefxx = basicexpressionx.getobjectRef();
  for (int _i = 0; _i < objectRefxx.size(); _i++)
  { BasicExpression _xx = (BasicExpression) objectRefxx.get(_i);
    if (_oldobjectRefxx.contains(_xx)) { }
    else { BasicExpression.removeAllobjectRef(basicexpressions, _xx); }
  }
    basicexpressionx.setobjectRef(objectRefxx);
      }


  public void addobjectRef(BasicExpression basicexpressionx, BasicExpression objectRefxx) 
  { if (basicexpressionx.getobjectRef().contains(objectRefxx)) { return; }
      if (basicexpressionx.getobjectRef().size() > 0)
    { BasicExpression basicexpression_xx = (BasicExpression) basicexpressionx.getobjectRef().get(0);
      basicexpressionx.removeobjectRef(basicexpression_xx);
      }
    BasicExpression.removeAllobjectRef(basicexpressions,objectRefxx);
    basicexpressionx.addobjectRef(objectRefxx);
   }


  public void removeobjectRef(BasicExpression basicexpressionx, BasicExpression objectRefxx) 
  { basicexpressionx.removeobjectRef(objectRefxx);
    }


 public void unionobjectRef(BasicExpression basicexpressionx, List objectRefx)
  { for (int _i = 0; _i < objectRefx.size(); _i++)
    { BasicExpression basicexpressionxobjectRef = (BasicExpression) objectRefx.get(_i);
      addobjectRef(basicexpressionx, basicexpressionxobjectRef);
     } } 


 public void subtractobjectRef(BasicExpression basicexpressionx, List objectRefx)
  { for (int _i = 0; _i < objectRefx.size(); _i++)
    { BasicExpression basicexpressionxobjectRef = (BasicExpression) objectRefx.get(_i);
      removeobjectRef(basicexpressionx, basicexpressionxobjectRef);
     } } 


public void setname(Property propertyx, String name_x) 
  { propertyx.setname(name_x);
    }


public void setlower(Property propertyx, int lower_x) 
  { propertyx.setlower(lower_x);
    }


public void setupper(Property propertyx, int upper_x) 
  { propertyx.setupper(upper_x);
    }


public void setisOrdered(Property propertyx, boolean isOrdered_x) 
  { propertyx.setisOrdered(isOrdered_x);
    }


public void setisUnique(Property propertyx, boolean isUnique_x) 
  { propertyx.setisUnique(isUnique_x);
    }


public void setisDerived(Property propertyx, boolean isDerived_x) 
  { propertyx.setisDerived(isDerived_x);
    }


public void setisReadOnly(Property propertyx, boolean isReadOnly_x) 
  { propertyx.setisReadOnly(isReadOnly_x);
    }


public void setisStatic(Property propertyx, boolean isStatic_x) 
  { propertyx.setisStatic(isStatic_x);
    }


  public void settype(Property propertyx, Type typexx) 
  {   if (propertyx.gettype() == typexx) { return; }
    propertyx.settype(typexx);
      }


  public void setinitialValue(Property propertyx, Expression initialValuexx) 
  {   if (propertyx.getinitialValue() == initialValuexx) { return; }
    for (int _q = 0; _q < propertys.size(); _q++)
    { Property _q_E1x = (Property) propertys.get(_q);
      if (_q_E1x.getinitialValue() == initialValuexx)
      { _q_E1x.setinitialValue(null); }
    }
    propertyx.setinitialValue(initialValuexx);
      }


  public void setowner(Property propertyx, Entity ownerxx) 
  {   if (propertyx.getowner() == ownerxx) { return; }
    if (propertyx.getowner() != null)
    { Entity old_value = propertyx.getowner();
      old_value.removeownedAttribute(propertyx); } 
    if (ownerxx != null) { ownerxx.addownedAttribute(propertyx); }
    propertyx.setowner(ownerxx);
      }


public void setname(CPrimitiveType cprimitivetypex, String name_x) 
  { cprimitivetypex.setname(name_x);
    }


public void setduplicates(CArrayType carraytypex, boolean duplicates_x) 
  { carraytypex.setduplicates(duplicates_x);
    }


  public void setcomponentType(CArrayType carraytypex, CType componentTypexx) 
  {   if (carraytypex.getcomponentType() == componentTypexx) { return; }
    carraytypex.setcomponentType(componentTypexx);
      }


  public void setpointsTo(CPointerType cpointertypex, CType pointsToxx) 
  {   if (cpointertypex.getpointsTo() == pointsToxx) { return; }
    cpointertypex.setpointsTo(pointsToxx);
      }


public void setname(CStruct cstructx, String name_x) 
  { if (cstructnameindex.get(name_x) != null) { return; }
  cstructnameindex.remove(cstructx.getname());
  cstructx.setname(name_x);
  cstructnameindex.put(name_x,cstructx);
    }


  public void setmembers(CStruct cstructx, List membersxx) 
  {   List _oldmembersxx = cstructx.getmembers();
  for (int _i = 0; _i < membersxx.size(); _i++)
  { CMember _xx = (CMember) membersxx.get(_i);
    if (_oldmembersxx.contains(_xx)) { }
    else { CStruct.removeAllmembers(cstructs, _xx); }
  }
    cstructx.setmembers(membersxx);
      }


  public void setmembers(CStruct cstructx, int _ind, CMember cmemberx) 
  { cstructx.setmembers(_ind,cmemberx); }
  
  public void addmembers(CStruct cstructx, CMember membersxx) 
  {   CStruct.removeAllmembers(cstructs,membersxx);
    cstructx.addmembers(membersxx);
   }


  public void removemembers(CStruct cstructx, CMember membersxx) 
  { cstructx.removemembers(membersxx);
    }


 public void unionmembers(CStruct cstructx, List membersx)
  { for (int _i = 0; _i < membersx.size(); _i++)
    { CMember cmemberxmembers = (CMember) membersx.get(_i);
      addmembers(cstructx, cmemberxmembers);
     } } 


 public void subtractmembers(CStruct cstructx, List membersx)
  { for (int _i = 0; _i < membersx.size(); _i++)
    { CMember cmemberxmembers = (CMember) membersx.get(_i);
      removemembers(cstructx, cmemberxmembers);
     } } 


  public void setallMembers(CStruct cstructx, List allMembersxx) 
  {     cstructx.setallMembers(allMembersxx);
      }


  public void addallMembers(CStruct cstructx, CMember allMembersxx) 
  { if (cstructx.getallMembers().contains(allMembersxx)) { return; }
      cstructx.addallMembers(allMembersxx);
   }


  public void removeallMembers(CStruct cstructx, CMember allMembersxx) 
  { cstructx.removeallMembers(allMembersxx);
    }


 public void unionallMembers(CStruct cstructx, List allMembersx)
  { for (int _i = 0; _i < allMembersx.size(); _i++)
    { CMember cmemberxallMembers = (CMember) allMembersx.get(_i);
      addallMembers(cstructx, cmemberxallMembers);
     } } 


 public void subtractallMembers(CStruct cstructx, List allMembersx)
  { for (int _i = 0; _i < allMembersx.size(); _i++)
    { CMember cmemberxallMembers = (CMember) allMembersx.get(_i);
      removeallMembers(cstructx, cmemberxallMembers);
     } } 


public void setname(CMember cmemberx, String name_x) 
  { cmemberx.setname(name_x);
    }


public void setisKey(CMember cmemberx, boolean isKey_x) 
  { cmemberx.setisKey(isKey_x);
    }


  public void settype(CMember cmemberx, CType typexx) 
  {   if (cmemberx.gettype() == typexx) { return; }
    cmemberx.settype(typexx);
      }


public void setname(CVariable cvariablex, String name_x) 
  { cvariablex.setname(name_x);
    }


public void setkind(CVariable cvariablex, String kind_x) 
  { cvariablex.setkind(kind_x);
    }


public void setinitialisation(CVariable cvariablex, String initialisation_x) 
  { cvariablex.setinitialisation(initialisation_x);
    }


  public void settype(CVariable cvariablex, CType typexx) 
  {   if (cvariablex.gettype() == typexx) { return; }
    cvariablex.settype(typexx);
      }


  public void setoperations(CProgram cprogramx, List operationsxx) 
  {   List _oldoperationsxx = cprogramx.getoperations();
  for (int _i = 0; _i < operationsxx.size(); _i++)
  { COperation _xx = (COperation) operationsxx.get(_i);
    if (_oldoperationsxx.contains(_xx)) { }
    else { CProgram.removeAlloperations(cprograms, _xx); }
  }
    cprogramx.setoperations(operationsxx);
      }


  public void addoperations(CProgram cprogramx, COperation operationsxx) 
  { if (cprogramx.getoperations().contains(operationsxx)) { return; }
    CProgram.removeAlloperations(cprograms,operationsxx);
    cprogramx.addoperations(operationsxx);
   }


  public void removeoperations(CProgram cprogramx, COperation operationsxx) 
  { cprogramx.removeoperations(operationsxx);
    }


 public void unionoperations(CProgram cprogramx, List operationsx)
  { for (int _i = 0; _i < operationsx.size(); _i++)
    { COperation coperationxoperations = (COperation) operationsx.get(_i);
      addoperations(cprogramx, coperationxoperations);
     } } 


 public void subtractoperations(CProgram cprogramx, List operationsx)
  { for (int _i = 0; _i < operationsx.size(); _i++)
    { COperation coperationxoperations = (COperation) operationsx.get(_i);
      removeoperations(cprogramx, coperationxoperations);
     } } 


  public void setvariables(CProgram cprogramx, List variablesxx) 
  {   List _oldvariablesxx = cprogramx.getvariables();
  for (int _i = 0; _i < variablesxx.size(); _i++)
  { CVariable _xx = (CVariable) variablesxx.get(_i);
    if (_oldvariablesxx.contains(_xx)) { }
    else { CProgram.removeAllvariables(cprograms, _xx); }
  }
    cprogramx.setvariables(variablesxx);
      }


  public void addvariables(CProgram cprogramx, CVariable variablesxx) 
  { if (cprogramx.getvariables().contains(variablesxx)) { return; }
    CProgram.removeAllvariables(cprograms,variablesxx);
    cprogramx.addvariables(variablesxx);
   }


  public void removevariables(CProgram cprogramx, CVariable variablesxx) 
  { cprogramx.removevariables(variablesxx);
    }


 public void unionvariables(CProgram cprogramx, List variablesx)
  { for (int _i = 0; _i < variablesx.size(); _i++)
    { CVariable cvariablexvariables = (CVariable) variablesx.get(_i);
      addvariables(cprogramx, cvariablexvariables);
     } } 


 public void subtractvariables(CProgram cprogramx, List variablesx)
  { for (int _i = 0; _i < variablesx.size(); _i++)
    { CVariable cvariablexvariables = (CVariable) variablesx.get(_i);
      removevariables(cprogramx, cvariablexvariables);
     } } 


  public void setstructs(CProgram cprogramx, List structsxx) 
  {   List _oldstructsxx = cprogramx.getstructs();
  for (int _i = 0; _i < structsxx.size(); _i++)
  { CStruct _xx = (CStruct) structsxx.get(_i);
    if (_oldstructsxx.contains(_xx)) { }
    else { CProgram.removeAllstructs(cprograms, _xx); }
  }
    cprogramx.setstructs(structsxx);
      }


  public void addstructs(CProgram cprogramx, CStruct structsxx) 
  { if (cprogramx.getstructs().contains(structsxx)) { return; }
    CProgram.removeAllstructs(cprograms,structsxx);
    cprogramx.addstructs(structsxx);
   }


  public void removestructs(CProgram cprogramx, CStruct structsxx) 
  { cprogramx.removestructs(structsxx);
    }


 public void unionstructs(CProgram cprogramx, List structsx)
  { for (int _i = 0; _i < structsx.size(); _i++)
    { CStruct cstructxstructs = (CStruct) structsx.get(_i);
      addstructs(cprogramx, cstructxstructs);
     } } 


 public void subtractstructs(CProgram cprogramx, List structsx)
  { for (int _i = 0; _i < structsx.size(); _i++)
    { CStruct cstructxstructs = (CStruct) structsx.get(_i);
      removestructs(cprogramx, cstructxstructs);
     } } 


  public void setdomainType(CFunctionPointerType cfunctionpointertypex, CType domainTypexx) 
  {   if (cfunctionpointertypex.getdomainType() == domainTypexx) { return; }
    cfunctionpointertypex.setdomainType(domainTypexx);
      }


  public void setrangeType(CFunctionPointerType cfunctionpointertypex, CType rangeTypexx) 
  {   if (cfunctionpointertypex.getrangeType() == rangeTypexx) { return; }
    cfunctionpointertypex.setrangeType(rangeTypexx);
      }


public void setname(COperation coperationx, String name_x) 
  { coperationx.setname(name_x);
    }


public void setopId(COperation coperationx, String opId_x) 
  { if (coperationopIdindex.get(opId_x) != null) { return; }
  coperationopIdindex.remove(coperationx.getopId());
  coperationx.setopId(opId_x);
  coperationopIdindex.put(opId_x,coperationx);
    }


public void setisStatic(COperation coperationx, boolean isStatic_x) 
  { coperationx.setisStatic(isStatic_x);
    }


public void setscope(COperation coperationx, String scope_x) 
  { coperationx.setscope(scope_x);
    }


public void setisQuery(COperation coperationx, boolean isQuery_x) 
  { coperationx.setisQuery(isQuery_x);
    }


  public void setparameters(COperation coperationx, List parametersxx) 
  {   List _oldparametersxx = coperationx.getparameters();
  for (int _i = 0; _i < parametersxx.size(); _i++)
  { CVariable _xx = (CVariable) parametersxx.get(_i);
    if (_oldparametersxx.contains(_xx)) { }
    else { COperation.removeAllparameters(coperations, _xx); }
  }
    coperationx.setparameters(parametersxx);
      }


  public void setparameters(COperation coperationx, int _ind, CVariable cvariablex) 
  { coperationx.setparameters(_ind,cvariablex); }
  
  public void addparameters(COperation coperationx, CVariable parametersxx) 
  {   COperation.removeAllparameters(coperations,parametersxx);
    coperationx.addparameters(parametersxx);
   }


  public void removeparameters(COperation coperationx, CVariable parametersxx) 
  { coperationx.removeparameters(parametersxx);
    }


 public void unionparameters(COperation coperationx, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { CVariable cvariablexparameters = (CVariable) parametersx.get(_i);
      addparameters(coperationx, cvariablexparameters);
     } } 


 public void subtractparameters(COperation coperationx, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { CVariable cvariablexparameters = (CVariable) parametersx.get(_i);
      removeparameters(coperationx, cvariablexparameters);
     } } 


  public void setreturnType(COperation coperationx, CType returnTypexx) 
  {   if (coperationx.getreturnType() == returnTypexx) { return; }
    coperationx.setreturnType(returnTypexx);
      }


  public void setcode(COperation coperationx, CStatement codexx) 
  {   if (coperationx.getcode() == codexx) { return; }
    for (int _q = 0; _q < coperations.size(); _q++)
    { COperation _q_E1x = (COperation) coperations.get(_q);
      if (_q_E1x.getcode() == codexx)
      { _q_E1x.setcode(null); }
    }
    coperationx.setcode(codexx);
      }


public void setstatId(Statement statementx, String statId_x) 
  { if (statementstatIdindex.get(statId_x) != null) { return; }
  statementstatIdindex.remove(statementx.getstatId());
  statementx.setstatId(statId_x);
  statementstatIdindex.put(statId_x,statementx);
    }


  public void setreturnValue(ReturnStatement returnstatementx, List returnValuexx) 
  {   if (returnValuexx.size() > 1) { return; }
  List _oldreturnValuexx = returnstatementx.getreturnValue();
  for (int _i = 0; _i < returnValuexx.size(); _i++)
  { Expression _xx = (Expression) returnValuexx.get(_i);
    if (_oldreturnValuexx.contains(_xx)) { }
    else { ReturnStatement.removeAllreturnValue(returnstatements, _xx); }
  }
    returnstatementx.setreturnValue(returnValuexx);
      }


  public void addreturnValue(ReturnStatement returnstatementx, Expression returnValuexx) 
  { if (returnstatementx.getreturnValue().contains(returnValuexx)) { return; }
      if (returnstatementx.getreturnValue().size() > 0)
    { Expression expression_xx = (Expression) returnstatementx.getreturnValue().get(0);
      returnstatementx.removereturnValue(expression_xx);
      }
    ReturnStatement.removeAllreturnValue(returnstatements,returnValuexx);
    returnstatementx.addreturnValue(returnValuexx);
   }


  public void removereturnValue(ReturnStatement returnstatementx, Expression returnValuexx) 
  { returnstatementx.removereturnValue(returnValuexx);
    }


 public void unionreturnValue(ReturnStatement returnstatementx, List returnValuex)
  { for (int _i = 0; _i < returnValuex.size(); _i++)
    { Expression expressionxreturnValue = (Expression) returnValuex.get(_i);
      addreturnValue(returnstatementx, expressionxreturnValue);
     } } 


 public void subtractreturnValue(ReturnStatement returnstatementx, List returnValuex)
  { for (int _i = 0; _i < returnValuex.size(); _i++)
    { Expression expressionxreturnValue = (Expression) returnValuex.get(_i);
      removereturnValue(returnstatementx, expressionxreturnValue);
     } } 


public void setname(BehaviouralFeature behaviouralfeaturex, String name_x) 
  { behaviouralfeaturex.setname(name_x);
    }


public void setisStatic(BehaviouralFeature behaviouralfeaturex, boolean isStatic_x) 
  { behaviouralfeaturex.setisStatic(isStatic_x);
    }


  public void setactivity(BehaviouralFeature behaviouralfeaturex, Statement activityxx) 
  {   if (behaviouralfeaturex.getactivity() == activityxx) { return; }
    for (int _q = 0; _q < behaviouralfeatures.size(); _q++)
    { BehaviouralFeature _q_E1x = (BehaviouralFeature) behaviouralfeatures.get(_q);
      if (_q_E1x.getactivity() == activityxx)
      { _q_E1x.setactivity(null); }
    }
    behaviouralfeaturex.setactivity(activityxx);
      }


public void setisQuery(Operation operationx, boolean isQuery_x) 
  { operationx.setisQuery(isQuery_x);
    }


public void setisCached(Operation operationx, boolean isCached_x) 
  { operationx.setisCached(isCached_x);
    }


public void setisStatic(Operation operationx, boolean isStatic_x) 
  { operationx.setisStatic(isStatic_x);
    }


  public void setowner(Operation operationx, Entity ownerxx) 
  {   if (operationx.getowner() == ownerxx) { return; }
    if (operationx.getowner() != null)
    { Entity old_value = operationx.getowner();
      old_value.removeownedOperation(operationx); } 
    if (ownerxx != null) { ownerxx.addownedOperation(operationx); }
    operationx.setowner(ownerxx);
      }


public void setname(UseCase usecasex, String name_x) 
  { usecasex.setname(name_x);
    }


  public void setparameters(UseCase usecasex, List parametersxx) 
  {   List _oldparametersxx = usecasex.getparameters();
  for (int _i = 0; _i < parametersxx.size(); _i++)
  { Property _xx = (Property) parametersxx.get(_i);
    if (_oldparametersxx.contains(_xx)) { }
    else { UseCase.removeAllparameters(usecases, _xx); }
  }
    usecasex.setparameters(parametersxx);
      }


  public void setparameters(UseCase usecasex, int _ind, Property propertyx) 
  { usecasex.setparameters(_ind,propertyx); }
  
  public void addparameters(UseCase usecasex, Property parametersxx) 
  {   UseCase.removeAllparameters(usecases,parametersxx);
    usecasex.addparameters(parametersxx);
   }


  public void removeparameters(UseCase usecasex, Property parametersxx) 
  { usecasex.removeparameters(parametersxx);
    }


 public void unionparameters(UseCase usecasex, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { Property propertyxparameters = (Property) parametersx.get(_i);
      addparameters(usecasex, propertyxparameters);
     } } 


 public void subtractparameters(UseCase usecasex, List parametersx)
  { for (int _i = 0; _i < parametersx.size(); _i++)
    { Property propertyxparameters = (Property) parametersx.get(_i);
      removeparameters(usecasex, propertyxparameters);
     } } 


  public void setresultType(UseCase usecasex, Type resultTypexx) 
  {   if (usecasex.getresultType() == resultTypexx) { return; }
    usecasex.setresultType(resultTypexx);
      }


  public void setclassifierBehaviour(UseCase usecasex, Statement classifierBehaviourxx) 
  {   if (usecasex.getclassifierBehaviour() == classifierBehaviourxx) { return; }
    for (int _q = 0; _q < usecases.size(); _q++)
    { UseCase _q_E1x = (UseCase) usecases.get(_q);
      if (_q_E1x.getclassifierBehaviour() == classifierBehaviourxx)
      { _q_E1x.setclassifierBehaviour(null); }
    }
    usecasex.setclassifierBehaviour(classifierBehaviourxx);
      }


public void setassignsTo(OperationCallStatement operationcallstatementx, String assignsTo_x) 
  { operationcallstatementx.setassignsTo(assignsTo_x);
    }


  public void setcallExp(OperationCallStatement operationcallstatementx, Expression callExpxx) 
  {   if (operationcallstatementx.getcallExp() == callExpxx) { return; }
    for (int _q = 0; _q < operationcallstatements.size(); _q++)
    { OperationCallStatement _q_E1x = (OperationCallStatement) operationcallstatements.get(_q);
      if (_q_E1x.getcallExp() == callExpxx)
      { _q_E1x.setcallExp(null); }
    }
    operationcallstatementx.setcallExp(callExpxx);
      }


public void setassignsTo(ImplicitCallStatement implicitcallstatementx, String assignsTo_x) 
  { implicitcallstatementx.setassignsTo(assignsTo_x);
    }


  public void setcallExp(ImplicitCallStatement implicitcallstatementx, Expression callExpxx) 
  {   if (implicitcallstatementx.getcallExp() == callExpxx) { return; }
    for (int _q = 0; _q < implicitcallstatements.size(); _q++)
    { ImplicitCallStatement _q_E1x = (ImplicitCallStatement) implicitcallstatements.get(_q);
      if (_q_E1x.getcallExp() == callExpxx)
      { _q_E1x.setcallExp(null); }
    }
    implicitcallstatementx.setcallExp(callExpxx);
      }


  public void settest(LoopStatement loopstatementx, Expression testxx) 
  {   if (loopstatementx.gettest() == testxx) { return; }
    for (int _q = 0; _q < loopstatements.size(); _q++)
    { LoopStatement _q_E1x = (LoopStatement) loopstatements.get(_q);
      if (_q_E1x.gettest() == testxx)
      { _q_E1x.settest(null); }
    }
    loopstatementx.settest(testxx);
      }


  public void setbody(LoopStatement loopstatementx, Statement bodyxx) 
  {   if (loopstatementx.getbody() == bodyxx) { return; }
    for (int _q = 0; _q < loopstatements.size(); _q++)
    { LoopStatement _q_E1x = (LoopStatement) loopstatements.get(_q);
      if (_q_E1x.getbody() == bodyxx)
      { _q_E1x.setbody(null); }
    }
    loopstatementx.setbody(bodyxx);
      }


  public void setloopRange(BoundedLoopStatement boundedloopstatementx, Expression loopRangexx) 
  {   if (boundedloopstatementx.getloopRange() == loopRangexx) { return; }
    for (int _q = 0; _q < boundedloopstatements.size(); _q++)
    { BoundedLoopStatement _q_E1x = (BoundedLoopStatement) boundedloopstatements.get(_q);
      if (_q_E1x.getloopRange() == loopRangexx)
      { _q_E1x.setloopRange(null); }
    }
    boundedloopstatementx.setloopRange(loopRangexx);
      }


  public void setloopVar(BoundedLoopStatement boundedloopstatementx, Expression loopVarxx) 
  {   if (boundedloopstatementx.getloopVar() == loopVarxx) { return; }
    for (int _q = 0; _q < boundedloopstatements.size(); _q++)
    { BoundedLoopStatement _q_E1x = (BoundedLoopStatement) boundedloopstatements.get(_q);
      if (_q_E1x.getloopVar() == loopVarxx)
      { _q_E1x.setloopVar(null); }
    }
    boundedloopstatementx.setloopVar(loopVarxx);
      }


  public void settype(AssignStatement assignstatementx, List typexx) 
  {   if (typexx.size() > 1) { return; }
    assignstatementx.settype(typexx);
      }


  public void addtype(AssignStatement assignstatementx, Type typexx) 
  { if (assignstatementx.gettype().contains(typexx)) { return; }
      if (assignstatementx.gettype().size() > 0)
    { Type type_xx = (Type) assignstatementx.gettype().get(0);
      assignstatementx.removetype(type_xx);
      }
      assignstatementx.addtype(typexx);
   }


  public void removetype(AssignStatement assignstatementx, Type typexx) 
  { assignstatementx.removetype(typexx);
    }


 public void uniontype(AssignStatement assignstatementx, List typex)
  { for (int _i = 0; _i < typex.size(); _i++)
    { Type typextype = (Type) typex.get(_i);
      addtype(assignstatementx, typextype);
     } } 


 public void subtracttype(AssignStatement assignstatementx, List typex)
  { for (int _i = 0; _i < typex.size(); _i++)
    { Type typextype = (Type) typex.get(_i);
      removetype(assignstatementx, typextype);
     } } 


  public void setleft(AssignStatement assignstatementx, Expression leftxx) 
  {   if (assignstatementx.getleft() == leftxx) { return; }
    for (int _q = 0; _q < assignstatements.size(); _q++)
    { AssignStatement _q_E1x = (AssignStatement) assignstatements.get(_q);
      if (_q_E1x.getleft() == leftxx)
      { _q_E1x.setleft(null); }
    }
    assignstatementx.setleft(leftxx);
      }


  public void setright(AssignStatement assignstatementx, Expression rightxx) 
  {   if (assignstatementx.getright() == rightxx) { return; }
    for (int _q = 0; _q < assignstatements.size(); _q++)
    { AssignStatement _q_E1x = (AssignStatement) assignstatements.get(_q);
      if (_q_E1x.getright() == rightxx)
      { _q_E1x.setright(null); }
    }
    assignstatementx.setright(rightxx);
      }


public void setkind(SequenceStatement sequencestatementx, int kind_x) 
  { sequencestatementx.setkind(kind_x);
    }


  public void setstatements(SequenceStatement sequencestatementx, List statementsxx) 
  {   List _oldstatementsxx = sequencestatementx.getstatements();
  for (int _i = 0; _i < statementsxx.size(); _i++)
  { Statement _xx = (Statement) statementsxx.get(_i);
    if (_oldstatementsxx.contains(_xx)) { }
    else { SequenceStatement.removeAllstatements(sequencestatements, _xx); }
  }
    sequencestatementx.setstatements(statementsxx);
      }


  public void setstatements(SequenceStatement sequencestatementx, int _ind, Statement statementx) 
  { sequencestatementx.setstatements(_ind,statementx); }
  
  public void addstatements(SequenceStatement sequencestatementx, Statement statementsxx) 
  {   SequenceStatement.removeAllstatements(sequencestatements,statementsxx);
    sequencestatementx.addstatements(statementsxx);
   }


  public void removestatements(SequenceStatement sequencestatementx, Statement statementsxx) 
  { sequencestatementx.removestatements(statementsxx);
    }


 public void unionstatements(SequenceStatement sequencestatementx, List statementsx)
  { for (int _i = 0; _i < statementsx.size(); _i++)
    { Statement statementxstatements = (Statement) statementsx.get(_i);
      addstatements(sequencestatementx, statementxstatements);
     } } 


 public void subtractstatements(SequenceStatement sequencestatementx, List statementsx)
  { for (int _i = 0; _i < statementsx.size(); _i++)
    { Statement statementxstatements = (Statement) statementsx.get(_i);
      removestatements(sequencestatementx, statementxstatements);
     } } 


  public void settest(ConditionalStatement conditionalstatementx, Expression testxx) 
  {   if (conditionalstatementx.gettest() == testxx) { return; }
    for (int _q = 0; _q < conditionalstatements.size(); _q++)
    { ConditionalStatement _q_E1x = (ConditionalStatement) conditionalstatements.get(_q);
      if (_q_E1x.gettest() == testxx)
      { _q_E1x.settest(null); }
    }
    conditionalstatementx.settest(testxx);
      }


  public void setifPart(ConditionalStatement conditionalstatementx, Statement ifPartxx) 
  {   if (conditionalstatementx.getifPart() == ifPartxx) { return; }
    for (int _q = 0; _q < conditionalstatements.size(); _q++)
    { ConditionalStatement _q_E1x = (ConditionalStatement) conditionalstatements.get(_q);
      if (_q_E1x.getifPart() == ifPartxx)
      { _q_E1x.setifPart(null); }
    }
    conditionalstatementx.setifPart(ifPartxx);
      }


  public void setelsePart(ConditionalStatement conditionalstatementx, List elsePartxx) 
  {   if (elsePartxx.size() > 1) { return; }
  List _oldelsePartxx = conditionalstatementx.getelsePart();
  for (int _i = 0; _i < elsePartxx.size(); _i++)
  { Statement _xx = (Statement) elsePartxx.get(_i);
    if (_oldelsePartxx.contains(_xx)) { }
    else { ConditionalStatement.removeAllelsePart(conditionalstatements, _xx); }
  }
    conditionalstatementx.setelsePart(elsePartxx);
      }


  public void addelsePart(ConditionalStatement conditionalstatementx, Statement elsePartxx) 
  { if (conditionalstatementx.getelsePart().contains(elsePartxx)) { return; }
      if (conditionalstatementx.getelsePart().size() > 0)
    { Statement statement_xx = (Statement) conditionalstatementx.getelsePart().get(0);
      conditionalstatementx.removeelsePart(statement_xx);
      }
    ConditionalStatement.removeAllelsePart(conditionalstatements,elsePartxx);
    conditionalstatementx.addelsePart(elsePartxx);
   }


  public void removeelsePart(ConditionalStatement conditionalstatementx, Statement elsePartxx) 
  { conditionalstatementx.removeelsePart(elsePartxx);
    }


 public void unionelsePart(ConditionalStatement conditionalstatementx, List elsePartx)
  { for (int _i = 0; _i < elsePartx.size(); _i++)
    { Statement statementxelsePart = (Statement) elsePartx.get(_i);
      addelsePart(conditionalstatementx, statementxelsePart);
     } } 


 public void subtractelsePart(ConditionalStatement conditionalstatementx, List elsePartx)
  { for (int _i = 0; _i < elsePartx.size(); _i++)
    { Statement statementxelsePart = (Statement) elsePartx.get(_i);
      removeelsePart(conditionalstatementx, statementxelsePart);
     } } 


public void setcreatesInstanceOf(CreationStatement creationstatementx, String createsInstanceOf_x) 
  { creationstatementx.setcreatesInstanceOf(createsInstanceOf_x);
    }


public void setassignsTo(CreationStatement creationstatementx, String assignsTo_x) 
  { creationstatementx.setassignsTo(assignsTo_x);
    }


  public void settype(CreationStatement creationstatementx, Type typexx) 
  {   if (creationstatementx.gettype() == typexx) { return; }
    creationstatementx.settype(typexx);
      }


  public void setelementType(CreationStatement creationstatementx, Type elementTypexx) 
  {   if (creationstatementx.getelementType() == elementTypexx) { return; }
    creationstatementx.setelementType(elementTypexx);
      }


public void setcstatId(CStatement cstatementx, String cstatId_x) 
  { if (cstatementcstatIdindex.get(cstatId_x) != null) { return; }
  cstatementcstatIdindex.remove(cstatementx.getcstatId());
  cstatementx.setcstatId(cstatId_x);
  cstatementcstatIdindex.put(cstatId_x,cstatementx);
    }


  public void setreturnValue(CReturnStatement creturnstatementx, List returnValuexx) 
  {   if (returnValuexx.size() > 1) { return; }
  List _oldreturnValuexx = creturnstatementx.getreturnValue();
  for (int _i = 0; _i < returnValuexx.size(); _i++)
  { CExpression _xx = (CExpression) returnValuexx.get(_i);
    if (_oldreturnValuexx.contains(_xx)) { }
    else { CReturnStatement.removeAllreturnValue(creturnstatements, _xx); }
  }
    creturnstatementx.setreturnValue(returnValuexx);
      }


  public void addreturnValue(CReturnStatement creturnstatementx, CExpression returnValuexx) 
  { if (creturnstatementx.getreturnValue().contains(returnValuexx)) { return; }
      if (creturnstatementx.getreturnValue().size() > 0)
    { CExpression cexpression_xx = (CExpression) creturnstatementx.getreturnValue().get(0);
      creturnstatementx.removereturnValue(cexpression_xx);
      }
    CReturnStatement.removeAllreturnValue(creturnstatements,returnValuexx);
    creturnstatementx.addreturnValue(returnValuexx);
   }


  public void removereturnValue(CReturnStatement creturnstatementx, CExpression returnValuexx) 
  { creturnstatementx.removereturnValue(returnValuexx);
    }


 public void unionreturnValue(CReturnStatement creturnstatementx, List returnValuex)
  { for (int _i = 0; _i < returnValuex.size(); _i++)
    { CExpression cexpressionxreturnValue = (CExpression) returnValuex.get(_i);
      addreturnValue(creturnstatementx, cexpressionxreturnValue);
     } } 


 public void subtractreturnValue(CReturnStatement creturnstatementx, List returnValuex)
  { for (int _i = 0; _i < returnValuex.size(); _i++)
    { CExpression cexpressionxreturnValue = (CExpression) returnValuex.get(_i);
      removereturnValue(creturnstatementx, cexpressionxreturnValue);
     } } 


public void setassignsTo(OpCallStatement opcallstatementx, String assignsTo_x) 
  { opcallstatementx.setassignsTo(assignsTo_x);
    }


  public void setcallExp(OpCallStatement opcallstatementx, CExpression callExpxx) 
  {   if (opcallstatementx.getcallExp() == callExpxx) { return; }
    for (int _q = 0; _q < opcallstatements.size(); _q++)
    { OpCallStatement _q_E1x = (OpCallStatement) opcallstatements.get(_q);
      if (_q_E1x.getcallExp() == callExpxx)
      { _q_E1x.setcallExp(null); }
    }
    opcallstatementx.setcallExp(callExpxx);
      }


  public void settest(CLoopStatement cloopstatementx, CExpression testxx) 
  {   if (cloopstatementx.gettest() == testxx) { return; }
    for (int _q = 0; _q < cloopstatements.size(); _q++)
    { CLoopStatement _q_E1x = (CLoopStatement) cloopstatements.get(_q);
      if (_q_E1x.gettest() == testxx)
      { _q_E1x.settest(null); }
    }
    cloopstatementx.settest(testxx);
      }


  public void setbody(CLoopStatement cloopstatementx, CStatement bodyxx) 
  {   if (cloopstatementx.getbody() == bodyxx) { return; }
    for (int _q = 0; _q < cloopstatements.size(); _q++)
    { CLoopStatement _q_E1x = (CLoopStatement) cloopstatements.get(_q);
      if (_q_E1x.getbody() == bodyxx)
      { _q_E1x.setbody(null); }
    }
    cloopstatementx.setbody(bodyxx);
      }


  public void setincrement(ForLoop forloopx, CSequenceStatement incrementxx) 
  {   if (forloopx.getincrement() == incrementxx) { return; }
    for (int _q = 0; _q < forloops.size(); _q++)
    { ForLoop _q_E1x = (ForLoop) forloops.get(_q);
      if (_q_E1x.getincrement() == incrementxx)
      { _q_E1x.setincrement(null); }
    }
    forloopx.setincrement(incrementxx);
      }


  public void setloopVar(ForLoop forloopx, CExpression loopVarxx) 
  {   if (forloopx.getloopVar() == loopVarxx) { return; }
    forloopx.setloopVar(loopVarxx);
      }


  public void setloopRange(ForLoop forloopx, CExpression loopRangexx) 
  {   if (forloopx.getloopRange() == loopRangexx) { return; }
    forloopx.setloopRange(loopRangexx);
      }


  public void settype(CAssignment cassignmentx, List typexx) 
  {   if (typexx.size() > 1) { return; }
    cassignmentx.settype(typexx);
      }


  public void addtype(CAssignment cassignmentx, CType typexx) 
  { if (cassignmentx.gettype().contains(typexx)) { return; }
      if (cassignmentx.gettype().size() > 0)
    { CType ctype_xx = (CType) cassignmentx.gettype().get(0);
      cassignmentx.removetype(ctype_xx);
      }
      cassignmentx.addtype(typexx);
   }


  public void removetype(CAssignment cassignmentx, CType typexx) 
  { cassignmentx.removetype(typexx);
    }


 public void uniontype(CAssignment cassignmentx, List typex)
  { for (int _i = 0; _i < typex.size(); _i++)
    { CType ctypextype = (CType) typex.get(_i);
      addtype(cassignmentx, ctypextype);
     } } 


 public void subtracttype(CAssignment cassignmentx, List typex)
  { for (int _i = 0; _i < typex.size(); _i++)
    { CType ctypextype = (CType) typex.get(_i);
      removetype(cassignmentx, ctypextype);
     } } 


  public void setleft(CAssignment cassignmentx, CExpression leftxx) 
  {   if (cassignmentx.getleft() == leftxx) { return; }
    for (int _q = 0; _q < cassignments.size(); _q++)
    { CAssignment _q_E1x = (CAssignment) cassignments.get(_q);
      if (_q_E1x.getleft() == leftxx)
      { _q_E1x.setleft(null); }
    }
    cassignmentx.setleft(leftxx);
      }


  public void setright(CAssignment cassignmentx, CExpression rightxx) 
  {   if (cassignmentx.getright() == rightxx) { return; }
    for (int _q = 0; _q < cassignments.size(); _q++)
    { CAssignment _q_E1x = (CAssignment) cassignments.get(_q);
      if (_q_E1x.getright() == rightxx)
      { _q_E1x.setright(null); }
    }
    cassignmentx.setright(rightxx);
      }


public void setkind(CSequenceStatement csequencestatementx, int kind_x) 
  { csequencestatementx.setkind(kind_x);
    }


  public void setstatements(CSequenceStatement csequencestatementx, List statementsxx) 
  {   List _oldstatementsxx = csequencestatementx.getstatements();
  for (int _i = 0; _i < statementsxx.size(); _i++)
  { CStatement _xx = (CStatement) statementsxx.get(_i);
    if (_oldstatementsxx.contains(_xx)) { }
    else { CSequenceStatement.removeAllstatements(csequencestatements, _xx); }
  }
    csequencestatementx.setstatements(statementsxx);
      }


  public void setstatements(CSequenceStatement csequencestatementx, int _ind, CStatement cstatementx) 
  { csequencestatementx.setstatements(_ind,cstatementx); }
  
  public void addstatements(CSequenceStatement csequencestatementx, CStatement statementsxx) 
  {   CSequenceStatement.removeAllstatements(csequencestatements,statementsxx);
    csequencestatementx.addstatements(statementsxx);
   }


  public void removestatements(CSequenceStatement csequencestatementx, CStatement statementsxx) 
  { csequencestatementx.removestatements(statementsxx);
    }


 public void unionstatements(CSequenceStatement csequencestatementx, List statementsx)
  { for (int _i = 0; _i < statementsx.size(); _i++)
    { CStatement cstatementxstatements = (CStatement) statementsx.get(_i);
      addstatements(csequencestatementx, cstatementxstatements);
     } } 


 public void subtractstatements(CSequenceStatement csequencestatementx, List statementsx)
  { for (int _i = 0; _i < statementsx.size(); _i++)
    { CStatement cstatementxstatements = (CStatement) statementsx.get(_i);
      removestatements(csequencestatementx, cstatementxstatements);
     } } 


  public void settest(IfStatement ifstatementx, CExpression testxx) 
  {   if (ifstatementx.gettest() == testxx) { return; }
    for (int _q = 0; _q < ifstatements.size(); _q++)
    { IfStatement _q_E1x = (IfStatement) ifstatements.get(_q);
      if (_q_E1x.gettest() == testxx)
      { _q_E1x.settest(null); }
    }
    ifstatementx.settest(testxx);
      }


  public void setifPart(IfStatement ifstatementx, CStatement ifPartxx) 
  {   if (ifstatementx.getifPart() == ifPartxx) { return; }
    for (int _q = 0; _q < ifstatements.size(); _q++)
    { IfStatement _q_E1x = (IfStatement) ifstatements.get(_q);
      if (_q_E1x.getifPart() == ifPartxx)
      { _q_E1x.setifPart(null); }
    }
    ifstatementx.setifPart(ifPartxx);
      }


  public void setelsePart(IfStatement ifstatementx, List elsePartxx) 
  {   if (elsePartxx.size() > 1) { return; }
  List _oldelsePartxx = ifstatementx.getelsePart();
  for (int _i = 0; _i < elsePartxx.size(); _i++)
  { CStatement _xx = (CStatement) elsePartxx.get(_i);
    if (_oldelsePartxx.contains(_xx)) { }
    else { IfStatement.removeAllelsePart(ifstatements, _xx); }
  }
    ifstatementx.setelsePart(elsePartxx);
      }


  public void addelsePart(IfStatement ifstatementx, CStatement elsePartxx) 
  { if (ifstatementx.getelsePart().contains(elsePartxx)) { return; }
      if (ifstatementx.getelsePart().size() > 0)
    { CStatement cstatement_xx = (CStatement) ifstatementx.getelsePart().get(0);
      ifstatementx.removeelsePart(cstatement_xx);
      }
    IfStatement.removeAllelsePart(ifstatements,elsePartxx);
    ifstatementx.addelsePart(elsePartxx);
   }


  public void removeelsePart(IfStatement ifstatementx, CStatement elsePartxx) 
  { ifstatementx.removeelsePart(elsePartxx);
    }


 public void unionelsePart(IfStatement ifstatementx, List elsePartx)
  { for (int _i = 0; _i < elsePartx.size(); _i++)
    { CStatement cstatementxelsePart = (CStatement) elsePartx.get(_i);
      addelsePart(ifstatementx, cstatementxelsePart);
     } } 


 public void subtractelsePart(IfStatement ifstatementx, List elsePartx)
  { for (int _i = 0; _i < elsePartx.size(); _i++)
    { CStatement cstatementxelsePart = (CStatement) elsePartx.get(_i);
      removeelsePart(ifstatementx, cstatementxelsePart);
     } } 


public void setcreatesInstanceOf(DeclarationStatement declarationstatementx, String createsInstanceOf_x) 
  { declarationstatementx.setcreatesInstanceOf(createsInstanceOf_x);
    }


public void setassignsTo(DeclarationStatement declarationstatementx, String assignsTo_x) 
  { declarationstatementx.setassignsTo(assignsTo_x);
    }


  public void settype(DeclarationStatement declarationstatementx, CType typexx) 
  {   if (declarationstatementx.gettype() == typexx) { return; }
    declarationstatementx.settype(typexx);
      }


  public void setelementType(DeclarationStatement declarationstatementx, CType elementTypexx) 
  {   if (declarationstatementx.getelementType() == elementTypexx) { return; }
    declarationstatementx.setelementType(elementTypexx);
      }



  public  List AllCExpressiontoString(List cexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cexpressionxs.size(); _i++)
    { CExpression cexpressionx = (CExpression) cexpressionxs.get(_i);
      result.add(cexpressionx.toString());
    }
    return result; 
  }

  public  List AllCBinaryExpressiontoString(List cbinaryexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cbinaryexpressionxs.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) cbinaryexpressionxs.get(_i);
      result.add(cbinaryexpressionx.toString());
    }
    return result; 
  }

  public  List AllCUnaryExpressiontoString(List cunaryexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cunaryexpressionxs.size(); _i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) cunaryexpressionxs.get(_i);
      result.add(cunaryexpressionx.toString());
    }
    return result; 
  }

  public  List AllCBasicExpressionparameterString(List cbasicexpressionxs,List p)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cbasicexpressionxs.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressionxs.get(_i);
      result.add(cbasicexpressionx.parameterString(p));
    }
    return result; 
  }

  public  List AllCBasicExpressionparString(List cbasicexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cbasicexpressionxs.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressionxs.get(_i);
      result.add(cbasicexpressionx.parString());
    }
    return result; 
  }

  public  List AllCBasicExpressiontoString(List cbasicexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cbasicexpressionxs.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) cbasicexpressionxs.get(_i);
      result.add(cbasicexpressionx.toString());
    }
    return result; 
  }

  public CExpression mapExpression(Expression expressionx)
  { 
   CExpression result = null;
   result =   expressionx.mapExpression();
     return result;  }

  public  List AllExpressionmapExpression(List expressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < expressionxs.size(); _i++)
    { Expression expressionx = (Expression) expressionxs.get(_i);
      result.add(mapExpression(expressionx));
    }
    return result; 
  }

  public CBasicExpression createCOpCall(Expression expressionx,String id,String name)
  { 
   CBasicExpression result = null;
   result =   expressionx.createCOpCall(id, name);
     return result;  }

  public  List AllExpressioncreateCOpCall(List expressionxs,String id,String name)
  { 
    List result = new Vector();
    for (int _i = 0; _i < expressionxs.size(); _i++)
    { Expression expressionx = (Expression) expressionxs.get(_i);
      result.add(createCOpCall(expressionx,id, name));
    }
    return result; 
  }

  public CBasicExpression createCUnaryOpCall(Expression expressionx,String id,String name,CExpression arg)
  { 
   CBasicExpression result = null;
   result =   expressionx.createCUnaryOpCall(id, name, arg);
     return result;  }

  public  List AllExpressioncreateCUnaryOpCall(List expressionxs,String id,String name,CExpression arg)
  { 
    List result = new Vector();
    for (int _i = 0; _i < expressionxs.size(); _i++)
    { Expression expressionx = (Expression) expressionxs.get(_i);
      result.add(createCUnaryOpCall(expressionx,id, name, arg));
    }
    return result; 
  }

  public CBasicExpression createCBinOpCall(Expression expressionx,String id,String name,CExpression le,CExpression re)
  { 
   CBasicExpression result = null;
   result =   expressionx.createCBinOpCall(id, name, le, re);
     return result;  }

  public  List AllExpressioncreateCBinOpCall(List expressionxs,String id,String name,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < expressionxs.size(); _i++)
    { Expression expressionx = (Expression) expressionxs.get(_i);
      result.add(createCBinOpCall(expressionx,id, name, le, re));
    }
    return result; 
  }

  public CBasicExpression createCTernaryOpCall(Expression expressionx,String id,String name,CExpression arg,CExpression le,CExpression re)
  { 
   CBasicExpression result = null;
   result =   expressionx.createCTernaryOpCall(id, name, arg, le, re);
     return result;  }

  public  List AllExpressioncreateCTernaryOpCall(List expressionxs,String id,String name,CExpression arg,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < expressionxs.size(); _i++)
    { Expression expressionx = (Expression) expressionxs.get(_i);
      result.add(createCTernaryOpCall(expressionx,id, name, arg, le, re));
    }
    return result; 
  }

 public static CUnaryExpression cast(String typ,CExpression e)
 { return Expression.cast(typ, e); }

  public  List AllExpressionclength(List expressionxs,CExpression cexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < expressionxs.size(); _i++)
    { Expression expressionx = (Expression) expressionxs.get(_i);
      result.add(expressionx.clength(cexp));
    }
    return result; 
  }

  public  List AllExpressionmapAssignment(List expressionxs,Statement stat,CExpression cexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < expressionxs.size(); _i++)
    { Expression expressionx = (Expression) expressionxs.get(_i);
      result.add(expressionx.mapAssignment(stat, cexp));
    }
    return result; 
  }

  public CExpression mapIteratorExpression(BinaryExpression binaryexpressionx,String op,CExpression le,CExpression re)
  { 
   CExpression result = null;
   result =   binaryexpressionx.mapIteratorExpression(op, le, re);
     return result;  }

  public  List AllBinaryExpressionmapIteratorExpression(List binaryexpressionxs,String op,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(mapIteratorExpression(binaryexpressionx,op, le, re));
    }
    return result; 
  }

  public CExpression mapMapIteratorExpression(BinaryExpression binaryexpressionx,String op,CExpression le,CExpression re)
  { 
   CExpression result = null;
   result =   binaryexpressionx.mapMapIteratorExpression(op, le, re);
     return result;  }

  public  List AllBinaryExpressionmapMapIteratorExpression(List binaryexpressionxs,String op,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(mapMapIteratorExpression(binaryexpressionx,op, le, re));
    }
    return result; 
  }

  public CExpression mapCollectExpression(BinaryExpression binaryexpressionx,String op,CExpression le,CExpression re)
  { 
   CExpression result = null;
   result =   binaryexpressionx.mapCollectExpression(op, le, re);
     return result;  }

  public  List AllBinaryExpressionmapCollectExpression(List binaryexpressionxs,String op,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(mapCollectExpression(binaryexpressionx,op, le, re));
    }
    return result; 
  }

  public CExpression mapMapCollectExpression(BinaryExpression binaryexpressionx,String op,CExpression le,CExpression re)
  { 
   CExpression result = null;
   result =   binaryexpressionx.mapMapCollectExpression(op, le, re);
     return result;  }

  public  List AllBinaryExpressionmapMapCollectExpression(List binaryexpressionxs,String op,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(mapMapCollectExpression(binaryexpressionx,op, le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapAddExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapAddExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapSubtractExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapSubtractExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapComparitorExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapComparitorExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapEqualityExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapEqualityExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapInclusionExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapInclusionExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapExclusionExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapExclusionExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapStringExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapStringExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapCollectionExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapCollectionExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapMapExpression(List binaryexpressionxs,CExpression le,CExpression re)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapMapExpression(le, re));
    }
    return result; 
  }

  public  List AllBinaryExpressionmapBinaryExpression(List binaryexpressionxs,CExpression lexp,CExpression rexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.mapBinaryExpression(lexp, rexp));
    }
    return result; 
  }

  public CExpression mapExpression(BinaryExpression binaryexpressionx)
  { 
   CExpression result = null;
   result =   binaryexpressionx.mapExpression();
     return result;  }

  public  List AllBinaryExpressionmapExpression(List binaryexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(mapExpression(binaryexpressionx));
    }
    return result; 
  }

  public  List AllBinaryExpressionclength(List binaryexpressionxs,CExpression cexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < binaryexpressionxs.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) binaryexpressionxs.get(_i);
      result.add(binaryexpressionx.clength(cexp));
    }
    return result; 
  }

  public  List AllUnaryExpressionmapReduceExpression(List unaryexpressionxs,CExpression arg)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unaryexpressionxs.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressionxs.get(_i);
      result.add(unaryexpressionx.mapReduceExpression(arg));
    }
    return result; 
  }

  public  List AllUnaryExpressionmapStringExpression(List unaryexpressionxs,CExpression arg)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unaryexpressionxs.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressionxs.get(_i);
      result.add(unaryexpressionx.mapStringExpression(arg));
    }
    return result; 
  }

  public  List AllUnaryExpressionmapCollectionExpression(List unaryexpressionxs,CExpression arg)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unaryexpressionxs.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressionxs.get(_i);
      result.add(unaryexpressionx.mapCollectionExpression(arg));
    }
    return result; 
  }

  public  List AllUnaryExpressionmapMapExpression(List unaryexpressionxs,CExpression arg)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unaryexpressionxs.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressionxs.get(_i);
      result.add(unaryexpressionx.mapMapExpression(arg));
    }
    return result; 
  }

  public  List AllUnaryExpressionmapSortExpression(List unaryexpressionxs,CExpression arg)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unaryexpressionxs.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressionxs.get(_i);
      result.add(unaryexpressionx.mapSortExpression(arg));
    }
    return result; 
  }

  public  List AllUnaryExpressionmapUnaryExpression(List unaryexpressionxs,CExpression arg)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unaryexpressionxs.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressionxs.get(_i);
      result.add(unaryexpressionx.mapUnaryExpression(arg));
    }
    return result; 
  }

  public CExpression mapExpression(UnaryExpression unaryexpressionx)
  { 
   CExpression result = null;
   result =   unaryexpressionx.mapExpression();
     return result;  }

  public  List AllUnaryExpressionmapExpression(List unaryexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unaryexpressionxs.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) unaryexpressionxs.get(_i);
      result.add(mapExpression(unaryexpressionx));
    }
    return result; 
  }

  public  List AllCollectionExpressionmapCollectionMapExpression(List collectionexpressionxs,String id,List elems)
  { 
    List result = new Vector();
    for (int _i = 0; _i < collectionexpressionxs.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressionxs.get(_i);
      result.add(collectionexpressionx.mapCollectionMapExpression(id, elems));
    }
    return result; 
  }

  public  List AllCollectionExpressionmapCollectionExpression(List collectionexpressionxs,String id,List elems)
  { 
    List result = new Vector();
    for (int _i = 0; _i < collectionexpressionxs.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressionxs.get(_i);
      result.add(collectionexpressionx.mapCollectionExpression(id, elems));
    }
    return result; 
  }

  public  List AllCollectionExpressionclength(List collectionexpressionxs,CExpression cexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < collectionexpressionxs.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressionxs.get(_i);
      result.add(collectionexpressionx.clength(cexp));
    }
    return result; 
  }

  public CExpression mapExpression(CollectionExpression collectionexpressionx)
  { 
   CExpression result = null;
   result =   collectionexpressionx.mapExpression();
     return result;  }

  public  List AllCollectionExpressionmapExpression(List collectionexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < collectionexpressionxs.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) collectionexpressionxs.get(_i);
      result.add(mapExpression(collectionexpressionx));
    }
    return result; 
  }

  public  List AllBasicExpressionclength(List basicexpressionxs,CExpression cexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.clength(cexp));
    }
    return result; 
  }

  public CExpression mapValueExpression(BasicExpression basicexpressionx,List aind)
  { 
   CExpression result = null;
    //  if (!(basicexpressionx.getumlKind() == value)) { return result; } 
   result =   basicexpressionx.mapValueExpression(aind);
     return result;  }

  public  List AllBasicExpressionmapValueExpression(List basicexpressionxs,List aind)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(mapValueExpression(basicexpressionx,aind));
    }
    return result; 
  }

  public CBasicExpression mapVariableExpression(BasicExpression basicexpressionx,List aind,List pars)
  { 
   CBasicExpression result = null;
    //  if (!(basicexpressionx.getumlKind() == variable)) { return result; } 
   result =   basicexpressionx.mapVariableExpression(aind, pars);
     return result;  }

  public  List AllBasicExpressionmapVariableExpression(List basicexpressionxs,List aind,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(mapVariableExpression(basicexpressionx,aind, pars));
    }
    return result; 
  }

  public  List AllBasicExpressionmapAttributeExpression(List basicexpressionxs,List obs,List aind,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapAttributeExpression(obs, aind, pars));
    }
    return result; 
  }

  public  List AllBasicExpressionmapRoleExpression(List basicexpressionxs,List obs,List aind,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapRoleExpression(obs, aind, pars));
    }
    return result; 
  }

  public  List AllBasicExpressionmapOperationExpression(List basicexpressionxs,List obs,List aind,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapOperationExpression(obs, aind, pars));
    }
    return result; 
  }

  public  List AllBasicExpressionmapClassExpression(List basicexpressionxs,List obs,List aind,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapClassExpression(obs, aind, pars));
    }
    return result; 
  }

  public  List AllBasicExpressionmapSubrangeExpression(List basicexpressionxs,List obs,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapSubrangeExpression(obs, pars));
    }
    return result; 
  }

  public  List AllBasicExpressionmapFunctionExpression(List basicexpressionxs,List obs,List aind,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapFunctionExpression(obs, aind, pars));
    }
    return result; 
  }

  public  List AllBasicExpressionmapIndexedAssignment(List basicexpressionxs,Statement stat,CExpression cexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapIndexedAssignment(stat, cexp));
    }
    return result; 
  }

  public  List AllBasicExpressionmapAssignment(List basicexpressionxs,Statement stat,CExpression cexp)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapAssignment(stat, cexp));
    }
    return result; 
  }

  public  List AllBasicExpressionmapBasicExpression(List basicexpressionxs,List ob,List aind,List pars)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(basicexpressionx.mapBasicExpression(ob, aind, pars));
    }
    return result; 
  }

  public CExpression mapExpression(BasicExpression basicexpressionx)
  { 
   CExpression result = null;
   result =   basicexpressionx.mapExpression();
     return result;  }

  public  List AllBasicExpressionmapExpression(List basicexpressionxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < basicexpressionxs.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) basicexpressionxs.get(_i);
      result.add(mapExpression(basicexpressionx));
    }
    return result; 
  }

  public void exp2C(Exp2C exp2cx)
  {   exp2cx.exp2C();
   }

  public  List AllExp2Cexp2C(List exp2cxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < exp2cxs.size(); _i++)
    { Exp2C exp2cx = (Exp2C) exp2cxs.get(_i);
      exp2C(exp2cx);
    }
    return result; 
  }

  public  List AllCPrimitiveTypetoString(List cprimitivetypexs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cprimitivetypexs.size(); _i++)
    { CPrimitiveType cprimitivetypex = (CPrimitiveType) cprimitivetypexs.get(_i);
      result.add(cprimitivetypex.toString());
    }
    return result; 
  }

  public  List AllCArrayTypetoString(List carraytypexs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < carraytypexs.size(); _i++)
    { CArrayType carraytypex = (CArrayType) carraytypexs.get(_i);
      result.add(carraytypex.toString());
    }
    return result; 
  }

  public  List AllCPointerTypetoString(List cpointertypexs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cpointertypexs.size(); _i++)
    { CPointerType cpointertypex = (CPointerType) cpointertypexs.get(_i);
      result.add(cpointertypex.toString());
    }
    return result; 
  }

  public  List AllCStructtoString(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.toString());
    }
    return result; 
  }

  public  List AllCStructallCMembers(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.addAll(cstructx.allCMembers());
    }
    return result; 
  }

  public  List AllCStructcreateOp(List cstructxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.createOp(ent));
    }
    return result; 
  }

  public  List AllCStructcreatePKOp(List cstructxs,String ent,String key)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.createPKOp(ent, key));
    }
    return result; 
  }

  public  List AllCStructconcatenateOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.concatenateOp());
    }
    return result; 
  }

  public  List AllCStructintersectionOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.intersectionOp());
    }
    return result; 
  }

  public  List AllCStructinsertAtOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.insertAtOp());
    }
    return result; 
  }

  public  List AllCStructexists1Op(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.exists1Op());
    }
    return result; 
  }

  public  List AllCStructisUniqueOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.isUniqueOp());
    }
    return result; 
  }

  public  List AllCStructfrontOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.frontOp());
    }
    return result; 
  }

  public  List AllCStructtailOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.tailOp());
    }
    return result; 
  }

  public  List AllCStructremoveAllOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.removeAllOp());
    }
    return result; 
  }

  public  List AllCStructasSetOp(List cstructxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstructxs.size(); _i++)
    { CStruct cstructx = (CStruct) cstructxs.get(_i);
      result.add(cstructx.asSetOp());
    }
    return result; 
  }

  public void printcode2(CStruct cstructx)
  {   cstructx.printcode2();
   }

  public void printcode3(CStruct cstructx)
  {   cstructx.printcode3();
   }

  public void printcode4(CStruct cstructx)
  {   cstructx.printcode4();
   }

  public void printcode5(CStruct cstructx,CMember f)
  {   cstructx.printcode5(f);
   }

  public void printcode5outer(CStruct cstructx)
  {   cstructx.printcode5outer();
   }

  public void printcode6(CStruct cstructx,CMember f)
  {   cstructx.printcode6(f);
   }

  public void printcode6outer(CStruct cstructx)
  {   cstructx.printcode6outer();
   }

  public void printcode7(CStruct cstructx,CMember f)
  {   cstructx.printcode7(f);
   }

  public void printcode7outer(CStruct cstructx)
  {   cstructx.printcode7outer();
   }

  public void printcode8(CStruct cstructx,CMember f)
  {   cstructx.printcode8(f);
   }

  public void printcode8outer(CStruct cstructx)
  {   cstructx.printcode8outer();
   }

  public void printcode9(CStruct cstructx,CMember f)
  {   cstructx.printcode9(f);
   }

  public void printcode9outer(CStruct cstructx)
  {   cstructx.printcode9outer();
   }

  public void printcode10(CStruct cstructx,CMember f)
  {   cstructx.printcode10(f);
   }

  public void printcode10outer(CStruct cstructx)
  {   cstructx.printcode10outer();
   }

  public void printcode11(CStruct cstructx,CMember key)
  {   cstructx.printcode11(key);
   }

  public void printcode11outer(CStruct cstructx)
  {   cstructx.printcode11outer();
   }

  public void printcode12(CStruct cstructx)
  {   cstructx.printcode12();
   }

  public void printcode13(CStruct cstructx,CMember key)
  {   cstructx.printcode13(key);
   }

  public void printcode13outer(CStruct cstructx)
  {   cstructx.printcode13outer();
   }

  public void printcode14(CStruct cstructx)
  {   cstructx.printcode14();
   }

  public void printcode15(CStruct cstructx)
  {   cstructx.printcode15();
   }

  public void printcode16(CStruct cstructx)
  {   cstructx.printcode16();
   }

  public void printcode17(CStruct cstructx)
  {   cstructx.printcode17();
   }

  public void printcode18(CStruct cstructx)
  {   cstructx.printcode18();
   }

  public void printcode19(CStruct cstructx)
  {   cstructx.printcode19();
   }

  public void printcode20(CStruct cstructx)
  {   cstructx.printcode20();
   }

  public void printcode21(CStruct cstructx)
  {   cstructx.printcode21();
   }

  public void printcode22(CStruct cstructx)
  {   cstructx.printcode22();
   }

  public void printcode23(CStruct cstructx)
  {   cstructx.printcode23();
   }

  public void printcode24(CStruct cstructx)
  {   cstructx.printcode24();
   }

  public void printcode25(CStruct cstructx)
  {   cstructx.printcode25();
   }

  public void printcode26(CStruct cstructx)
  {   cstructx.printcode26();
   }

  public void printcode27(CStruct cstructx)
  {   cstructx.printcode27();
   }

  public void printcode28(CStruct cstructx)
  {   cstructx.printcode28();
   }

  public void printcode29(CStruct cstructx)
  {   cstructx.printcode29();
   }

  public void printcode30(CStruct cstructx)
  {   cstructx.printcode30();
   }

  public void printcode31(CStruct cstructx)
  {   cstructx.printcode31();
   }

  public void printcode32(CStruct cstructx)
  {   cstructx.printcode32();
   }

  public void printcode33(CStruct cstructx)
  {   cstructx.printcode33();
   }

  public  List AllCMemberinheritedCMembers(List cmemberxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.addAll(cmemberx.inheritedCMembers());
    }
    return result; 
  }

  public  List AllCMembergetterOp(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.getterOp(ent));
    }
    return result; 
  }

  public  List AllCMemberinheritedGetterOp(List cmemberxs,String ent,String sup)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.inheritedGetterOp(ent, sup));
    }
    return result; 
  }

  public  List AllCMemberancestorGetterOps(List cmemberxs,String ent,String sup)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.ancestorGetterOps(ent, sup));
    }
    return result; 
  }

  public  List AllCMemberinheritedGetterOps(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.inheritedGetterOps(ent));
    }
    return result; 
  }

  public  List AllCMembersetterOp(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.setterOp(ent));
    }
    return result; 
  }

  public  List AllCMemberinheritedSetterOp(List cmemberxs,String ent,String sup)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.inheritedSetterOp(ent, sup));
    }
    return result; 
  }

  public  List AllCMemberancestorSetterOps(List cmemberxs,String ent,String sup)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.ancestorSetterOps(ent, sup));
    }
    return result; 
  }

  public  List AllCMemberinheritedSetterOps(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.inheritedSetterOps(ent));
    }
    return result; 
  }

  public  List AllCMembergetAllOp(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.getAllOp(ent));
    }
    return result; 
  }

  public  List AllCMembergetAllOp1(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.getAllOp1(ent));
    }
    return result; 
  }

  public  List AllCMemberinheritedAllOp(List cmemberxs,String ent,String sup)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.inheritedAllOp(ent, sup));
    }
    return result; 
  }

  public  List AllCMemberancestorAllOps(List cmemberxs,String ent,String sup)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.ancestorAllOps(ent, sup));
    }
    return result; 
  }

  public  List AllCMemberinheritedAllOps(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.inheritedAllOps(ent));
    }
    return result; 
  }

  public  List AllCMembergetPKOp(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.getPKOp(ent));
    }
    return result; 
  }

  public  List AllCMembergetPKsOp(List cmemberxs,String ent)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.getPKsOp(ent));
    }
    return result; 
  }

  public  List AllCMemberinitialiser(List cmemberxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cmemberxs.size(); _i++)
    { CMember cmemberx = (CMember) cmemberxs.get(_i);
      result.add(cmemberx.initialiser());
    }
    return result; 
  }

  public  List AllCVariableparameterDeclaration(List cvariablexs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cvariablexs.size(); _i++)
    { CVariable cvariablex = (CVariable) cvariablexs.get(_i);
      result.add(cvariablex.parameterDeclaration());
    }
    return result; 
  }

  public  List AllCProgramdefineCOp(List cprogramxs,CExpression b,String par,CType pt)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cprogramxs.size(); _i++)
    { CProgram cprogramx = (CProgram) cprogramxs.get(_i);
      result.add(cprogramx.defineCOp(b, par, pt));
    }
    return result; 
  }

  public void printOperations(CProgram cprogramx)
  {   cprogramx.printOperations();
   }

  public  List AllCProgramprintOperations(List cprogramxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cprogramxs.size(); _i++)
    { CProgram cprogramx = (CProgram) cprogramxs.get(_i);
      printOperations(cprogramx);
    }
    return result; 
  }

  public void printProgramHeader(CProgram cprogramx)
  {   cprogramx.printProgramHeader();
   }

  public  List AllCProgramprintProgramHeader(List cprogramxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cprogramxs.size(); _i++)
    { CProgram cprogramx = (CProgram) cprogramxs.get(_i);
      printProgramHeader(cprogramx);
    }
    return result; 
  }

  public void exp2c6(CProgram cprogramx)
  {   cprogramx.exp2c6();
   }

  public void printcode1(CProgram cprogramx)
  {   cprogramx.printcode1();
   }

  public  List AllCFunctionPointerTypetoString(List cfunctionpointertypexs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cfunctionpointertypexs.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) cfunctionpointertypexs.get(_i);
      result.add(cfunctionpointertypex.toString());
    }
    return result; 
  }

  public  List AllCOperationtoString(List coperationxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < coperationxs.size(); _i++)
    { COperation coperationx = (COperation) coperationxs.get(_i);
      result.add(coperationx.toString());
    }
    return result; 
  }

  public  List AllCOperationtoUseCaseDefinition(List coperationxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < coperationxs.size(); _i++)
    { COperation coperationx = (COperation) coperationxs.get(_i);
      result.add(coperationx.toUseCaseDefinition());
    }
    return result; 
  }

  public  List AllCOperationgetDeclaration(List coperationxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < coperationxs.size(); _i++)
    { COperation coperationx = (COperation) coperationxs.get(_i);
      result.add(coperationx.getDeclaration());
    }
    return result; 
  }

  public void exp2c3(COperation coperationx)
  {   coperationx.exp2c3();
   }

  public void exp2c4(COperation coperationx)
  {   coperationx.exp2c4();
   }

  public void exp2c5(COperation coperationx)
  {   coperationx.exp2c5();
   }

  public CStatement mapStatement(Statement statementx)
  { 
   CStatement result = null;
   result =   statementx.mapStatement();
     return result;  }

  public  List AllStatementmapStatement(List statementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < statementxs.size(); _i++)
    { Statement statementx = (Statement) statementxs.get(_i);
      result.add(mapStatement(statementx));
    }
    return result; 
  }

  public CStatement mapStatement(ReturnStatement returnstatementx)
  { 
   CStatement result = null;
   result =   returnstatementx.mapStatement();
     return result;  }

  public  List AllReturnStatementmapStatement(List returnstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < returnstatementxs.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) returnstatementxs.get(_i);
      result.add(mapStatement(returnstatementx));
    }
    return result; 
  }

  public void exp2c1(Operation operationx)
  {   operationx.exp2c1();
   }

  public void exp2c2(UseCase usecasex)
  {   usecasex.exp2c2();
   }

  public CStatement mapStatement(BreakStatement breakstatementx)
  { 
   CStatement result = null;
   result =   breakstatementx.mapStatement();
     return result;  }

  public  List AllBreakStatementmapStatement(List breakstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < breakstatementxs.size(); _i++)
    { BreakStatement breakstatementx = (BreakStatement) breakstatementxs.get(_i);
      result.add(mapStatement(breakstatementx));
    }
    return result; 
  }

  public CStatement mapStatement(OperationCallStatement operationcallstatementx)
  { 
   CStatement result = null;
   result =   operationcallstatementx.mapStatement();
     return result;  }

  public  List AllOperationCallStatementmapStatement(List operationcallstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < operationcallstatementxs.size(); _i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) operationcallstatementxs.get(_i);
      result.add(mapStatement(operationcallstatementx));
    }
    return result; 
  }

  public CStatement mapStatement(ImplicitCallStatement implicitcallstatementx)
  { 
   CStatement result = null;
   result =   implicitcallstatementx.mapStatement();
     return result;  }

  public  List AllImplicitCallStatementmapStatement(List implicitcallstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < implicitcallstatementxs.size(); _i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) implicitcallstatementxs.get(_i);
      result.add(mapStatement(implicitcallstatementx));
    }
    return result; 
  }

  public CStatement mapBoundedLoopStatement(BoundedLoopStatement boundedloopstatementx,CStatement bdy)
  { 
   CStatement result = null;
   result =   boundedloopstatementx.mapBoundedLoopStatement(bdy);
     return result;  }

  public  List AllBoundedLoopStatementmapBoundedLoopStatement(List boundedloopstatementxs,CStatement bdy)
  { 
    List result = new Vector();
    for (int _i = 0; _i < boundedloopstatementxs.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatementxs.get(_i);
      result.add(mapBoundedLoopStatement(boundedloopstatementx,bdy));
    }
    return result; 
  }

  public CStatement mapStatement(BoundedLoopStatement boundedloopstatementx)
  { 
   CStatement result = null;
   result =   boundedloopstatementx.mapStatement();
     return result;  }

  public  List AllBoundedLoopStatementmapStatement(List boundedloopstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < boundedloopstatementxs.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) boundedloopstatementxs.get(_i);
      result.add(mapStatement(boundedloopstatementx));
    }
    return result; 
  }

  public CStatement mapUnboundedLoopStatement(UnboundedLoopStatement unboundedloopstatementx,CStatement bdy)
  { 
   CStatement result = null;
   result =   unboundedloopstatementx.mapUnboundedLoopStatement(bdy);
     return result;  }

  public  List AllUnboundedLoopStatementmapUnboundedLoopStatement(List unboundedloopstatementxs,CStatement bdy)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unboundedloopstatementxs.size(); _i++)
    { UnboundedLoopStatement unboundedloopstatementx = (UnboundedLoopStatement) unboundedloopstatementxs.get(_i);
      result.add(mapUnboundedLoopStatement(unboundedloopstatementx,bdy));
    }
    return result; 
  }

  public CStatement mapStatement(UnboundedLoopStatement unboundedloopstatementx)
  { 
   CStatement result = null;
   result =   unboundedloopstatementx.mapStatement();
     return result;  }

  public  List AllUnboundedLoopStatementmapStatement(List unboundedloopstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < unboundedloopstatementxs.size(); _i++)
    { UnboundedLoopStatement unboundedloopstatementx = (UnboundedLoopStatement) unboundedloopstatementxs.get(_i);
      result.add(mapStatement(unboundedloopstatementx));
    }
    return result; 
  }

  public CStatement mapStatement(AssignStatement assignstatementx)
  { 
   CStatement result = null;
   result =   assignstatementx.mapStatement();
     return result;  }

  public  List AllAssignStatementmapStatement(List assignstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < assignstatementxs.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) assignstatementxs.get(_i);
      result.add(mapStatement(assignstatementx));
    }
    return result; 
  }

  public CStatement mapSequenceStatement(SequenceStatement sequencestatementx,List css)
  { 
   CStatement result = null;
   result =   sequencestatementx.mapSequenceStatement(css);
     return result;  }

  public  List AllSequenceStatementmapSequenceStatement(List sequencestatementxs,List css)
  { 
    List result = new Vector();
    for (int _i = 0; _i < sequencestatementxs.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatementxs.get(_i);
      result.add(mapSequenceStatement(sequencestatementx,css));
    }
    return result; 
  }

  public CStatement mapStatement(SequenceStatement sequencestatementx)
  { 
   CStatement result = null;
   result =   sequencestatementx.mapStatement();
     return result;  }

  public  List AllSequenceStatementmapStatement(List sequencestatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < sequencestatementxs.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) sequencestatementxs.get(_i);
      result.add(mapStatement(sequencestatementx));
    }
    return result; 
  }

  public CStatement mapConditionalStatement(ConditionalStatement conditionalstatementx,CStatement ifP,List elseP)
  { 
   CStatement result = null;
   result =   conditionalstatementx.mapConditionalStatement(ifP, elseP);
     return result;  }

  public  List AllConditionalStatementmapConditionalStatement(List conditionalstatementxs,CStatement ifP,List elseP)
  { 
    List result = new Vector();
    for (int _i = 0; _i < conditionalstatementxs.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatementxs.get(_i);
      result.add(mapConditionalStatement(conditionalstatementx,ifP, elseP));
    }
    return result; 
  }

  public CStatement mapStatement(ConditionalStatement conditionalstatementx)
  { 
   CStatement result = null;
   result =   conditionalstatementx.mapStatement();
     return result;  }

  public  List AllConditionalStatementmapStatement(List conditionalstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < conditionalstatementxs.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) conditionalstatementxs.get(_i);
      result.add(mapStatement(conditionalstatementx));
    }
    return result; 
  }

  public CStatement mapStatement(CreationStatement creationstatementx)
  { 
   CStatement result = null;
   result =   creationstatementx.mapStatement();
     return result;  }

  public  List AllCreationStatementmapStatement(List creationstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < creationstatementxs.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) creationstatementxs.get(_i);
      result.add(mapStatement(creationstatementx));
    }
    return result; 
  }

  public  List AllCStatementtoString(List cstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cstatementxs.size(); _i++)
    { CStatement cstatementx = (CStatement) cstatementxs.get(_i);
      result.add(cstatementx.toString());
    }
    return result; 
  }

  public  List AllCReturnStatementtoString(List creturnstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < creturnstatementxs.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) creturnstatementxs.get(_i);
      result.add(creturnstatementx.toString());
    }
    return result; 
  }

  public  List AllCBreakStatementtoString(List cbreakstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cbreakstatementxs.size(); _i++)
    { CBreakStatement cbreakstatementx = (CBreakStatement) cbreakstatementxs.get(_i);
      result.add(cbreakstatementx.toString());
    }
    return result; 
  }

  public  List AllOpCallStatementtoString(List opcallstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < opcallstatementxs.size(); _i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) opcallstatementxs.get(_i);
      result.add(opcallstatementx.toString());
    }
    return result; 
  }

  public  List AllForLooptoString(List forloopxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < forloopxs.size(); _i++)
    { ForLoop forloopx = (ForLoop) forloopxs.get(_i);
      result.add(forloopx.toString());
    }
    return result; 
  }

  public  List AllWhileLooptoString(List whileloopxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < whileloopxs.size(); _i++)
    { WhileLoop whileloopx = (WhileLoop) whileloopxs.get(_i);
      result.add(whileloopx.toString());
    }
    return result; 
  }

  public  List AllCAssignmenttoString(List cassignmentxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cassignmentxs.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) cassignmentxs.get(_i);
      result.add(cassignmentx.toString());
    }
    return result; 
  }

  public  List AllCSequenceStatementtoString(List csequencestatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < csequencestatementxs.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) csequencestatementxs.get(_i);
      result.add(csequencestatementx.toString());
    }
    return result; 
  }

  public  List AllIfStatementtoString(List ifstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < ifstatementxs.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) ifstatementxs.get(_i);
      result.add(ifstatementx.toString());
    }
    return result; 
  }

  public  List AllDeclarationStatementtoString(List declarationstatementxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < declarationstatementxs.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) declarationstatementxs.get(_i);
      result.add(declarationstatementx.toString());
    }
    return result; 
  }

  public void printcode(Printcode printcodex)
  {   printcodex.printcode();
   }

  public  List AllPrintcodeprintcode(List printcodexs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < printcodexs.size(); _i++)
    { Printcode printcodex = (Printcode) printcodexs.get(_i);
      printcode(printcodex);
    }
    return result; 
  }



  public void killAllCExpression(List cexpressionxx)
  { for (int _i = 0; _i < cexpressionxx.size(); _i++)
    { killCExpression((CExpression) cexpressionxx.get(_i)); }
  }

  public void killCExpression(CExpression cexpressionxx)
  { if (cexpressionxx == null) { return; }
   cexpressions.remove(cexpressionxx);
    Vector _1removedleftCBinaryExpression = new Vector();
    Vector _1removedrightCBinaryExpression = new Vector();
    Vector _1removedargumentCUnaryExpression = new Vector();
    Vector _1removedcallExpOpCallStatement = new Vector();
    Vector _1removedtestCLoopStatement = new Vector();
    Vector _1removedleftCAssignment = new Vector();
    Vector _1removedrightCAssignment = new Vector();
    Vector _1removedtestIfStatement = new Vector();
    Vector _1removedloopVarForLoop = new Vector();
    Vector _1removedloopRangeForLoop = new Vector();
    Vector _1qrangeleftCBinaryExpression = new Vector();
    _1qrangeleftCBinaryExpression.addAll(cbinaryexpressions);
    for (int _i = 0; _i < _1qrangeleftCBinaryExpression.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) _1qrangeleftCBinaryExpression.get(_i);
      if (cbinaryexpressionx != null && cexpressionxx.equals(cbinaryexpressionx.getleft()))
      { _1removedleftCBinaryExpression.add(cbinaryexpressionx);
        cbinaryexpressionx.setleft(null);
      }
    }
    Vector _1qrangerightCBinaryExpression = new Vector();
    _1qrangerightCBinaryExpression.addAll(cbinaryexpressions);
    for (int _i = 0; _i < _1qrangerightCBinaryExpression.size(); _i++)
    { CBinaryExpression cbinaryexpressionx = (CBinaryExpression) _1qrangerightCBinaryExpression.get(_i);
      if (cbinaryexpressionx != null && cexpressionxx.equals(cbinaryexpressionx.getright()))
      { _1removedrightCBinaryExpression.add(cbinaryexpressionx);
        cbinaryexpressionx.setright(null);
      }
    }
    Vector _1qrangeparametersCBasicExpression = new Vector();
    _1qrangeparametersCBasicExpression.addAll(cbasicexpressions);
    for (int _i = 0; _i < _1qrangeparametersCBasicExpression.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) _1qrangeparametersCBasicExpression.get(_i);
      if (cbasicexpressionx != null && cbasicexpressionx.getparameters().contains(cexpressionxx))
      { removeparameters(cbasicexpressionx,cexpressionxx); }
    }
    Vector _1qrangeargumentCUnaryExpression = new Vector();
    _1qrangeargumentCUnaryExpression.addAll(cunaryexpressions);
    for (int _i = 0; _i < _1qrangeargumentCUnaryExpression.size(); _i++)
    { CUnaryExpression cunaryexpressionx = (CUnaryExpression) _1qrangeargumentCUnaryExpression.get(_i);
      if (cunaryexpressionx != null && cexpressionxx.equals(cunaryexpressionx.getargument()))
      { _1removedargumentCUnaryExpression.add(cunaryexpressionx);
        cunaryexpressionx.setargument(null);
      }
    }
    Vector _1qrangereturnValueCReturnStatement = new Vector();
    _1qrangereturnValueCReturnStatement.addAll(creturnstatements);
    for (int _i = 0; _i < _1qrangereturnValueCReturnStatement.size(); _i++)
    { CReturnStatement creturnstatementx = (CReturnStatement) _1qrangereturnValueCReturnStatement.get(_i);
      if (creturnstatementx != null && creturnstatementx.getreturnValue().contains(cexpressionxx))
      { removereturnValue(creturnstatementx,cexpressionxx); }
    }
    Vector _1qrangecallExpOpCallStatement = new Vector();
    _1qrangecallExpOpCallStatement.addAll(opcallstatements);
    for (int _i = 0; _i < _1qrangecallExpOpCallStatement.size(); _i++)
    { OpCallStatement opcallstatementx = (OpCallStatement) _1qrangecallExpOpCallStatement.get(_i);
      if (opcallstatementx != null && cexpressionxx.equals(opcallstatementx.getcallExp()))
      { _1removedcallExpOpCallStatement.add(opcallstatementx);
        opcallstatementx.setcallExp(null);
      }
    }
    Vector _1qrangetestCLoopStatement = new Vector();
    _1qrangetestCLoopStatement.addAll(cloopstatements);
    for (int _i = 0; _i < _1qrangetestCLoopStatement.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) _1qrangetestCLoopStatement.get(_i);
      if (cloopstatementx != null && cexpressionxx.equals(cloopstatementx.gettest()))
      { _1removedtestCLoopStatement.add(cloopstatementx);
        cloopstatementx.settest(null);
      }
    }
    Vector _1qrangeleftCAssignment = new Vector();
    _1qrangeleftCAssignment.addAll(cassignments);
    for (int _i = 0; _i < _1qrangeleftCAssignment.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) _1qrangeleftCAssignment.get(_i);
      if (cassignmentx != null && cexpressionxx.equals(cassignmentx.getleft()))
      { _1removedleftCAssignment.add(cassignmentx);
        cassignmentx.setleft(null);
      }
    }
    Vector _1qrangerightCAssignment = new Vector();
    _1qrangerightCAssignment.addAll(cassignments);
    for (int _i = 0; _i < _1qrangerightCAssignment.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) _1qrangerightCAssignment.get(_i);
      if (cassignmentx != null && cexpressionxx.equals(cassignmentx.getright()))
      { _1removedrightCAssignment.add(cassignmentx);
        cassignmentx.setright(null);
      }
    }
    Vector _1qrangetestIfStatement = new Vector();
    _1qrangetestIfStatement.addAll(ifstatements);
    for (int _i = 0; _i < _1qrangetestIfStatement.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) _1qrangetestIfStatement.get(_i);
      if (ifstatementx != null && cexpressionxx.equals(ifstatementx.gettest()))
      { _1removedtestIfStatement.add(ifstatementx);
        ifstatementx.settest(null);
      }
    }
    Vector _1qrangeloopVarForLoop = new Vector();
    _1qrangeloopVarForLoop.addAll(forloops);
    for (int _i = 0; _i < _1qrangeloopVarForLoop.size(); _i++)
    { ForLoop forloopx = (ForLoop) _1qrangeloopVarForLoop.get(_i);
      if (forloopx != null && cexpressionxx.equals(forloopx.getloopVar()))
      { _1removedloopVarForLoop.add(forloopx);
        forloopx.setloopVar(null);
      }
    }
    Vector _1qrangeloopRangeForLoop = new Vector();
    _1qrangeloopRangeForLoop.addAll(forloops);
    for (int _i = 0; _i < _1qrangeloopRangeForLoop.size(); _i++)
    { ForLoop forloopx = (ForLoop) _1qrangeloopRangeForLoop.get(_i);
      if (forloopx != null && cexpressionxx.equals(forloopx.getloopRange()))
      { _1removedloopRangeForLoop.add(forloopx);
        forloopx.setloopRange(null);
      }
    }
    cexpressioncexpIdindex.remove(cexpressionxx.getcexpId());
    for (int _i = 0; _i < _1removedleftCBinaryExpression.size(); _i++)
    { killCBinaryExpression((CBinaryExpression) _1removedleftCBinaryExpression.get(_i)); }
    for (int _i = 0; _i < _1removedrightCBinaryExpression.size(); _i++)
    { killCBinaryExpression((CBinaryExpression) _1removedrightCBinaryExpression.get(_i)); }
    for (int _i = 0; _i < _1removedargumentCUnaryExpression.size(); _i++)
    { killCUnaryExpression((CUnaryExpression) _1removedargumentCUnaryExpression.get(_i)); }
    for (int _i = 0; _i < _1removedcallExpOpCallStatement.size(); _i++)
    { killOpCallStatement((OpCallStatement) _1removedcallExpOpCallStatement.get(_i)); }
    for (int _i = 0; _i < _1removedtestCLoopStatement.size(); _i++)
    { killAbstractCLoopStatement((CLoopStatement) _1removedtestCLoopStatement.get(_i)); }
    for (int _i = 0; _i < _1removedleftCAssignment.size(); _i++)
    { killCAssignment((CAssignment) _1removedleftCAssignment.get(_i)); }
    for (int _i = 0; _i < _1removedrightCAssignment.size(); _i++)
    { killCAssignment((CAssignment) _1removedrightCAssignment.get(_i)); }
    for (int _i = 0; _i < _1removedtestIfStatement.size(); _i++)
    { killIfStatement((IfStatement) _1removedtestIfStatement.get(_i)); }
    for (int _i = 0; _i < _1removedloopVarForLoop.size(); _i++)
    { killForLoop((ForLoop) _1removedloopVarForLoop.get(_i)); }
    for (int _i = 0; _i < _1removedloopRangeForLoop.size(); _i++)
    { killForLoop((ForLoop) _1removedloopRangeForLoop.get(_i)); }
  }

  public void killAbstractCExpression(CExpression cexpressionxx)
  {
    if (cexpressionxx instanceof CUnaryExpression)
    { killCUnaryExpression((CUnaryExpression) cexpressionxx); }
    if (cexpressionxx instanceof CBasicExpression)
    { killCBasicExpression((CBasicExpression) cexpressionxx); }
    if (cexpressionxx instanceof CBinaryExpression)
    { killCBinaryExpression((CBinaryExpression) cexpressionxx); }
  }

  public void killAbstractCExpression(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { CExpression _e = (CExpression) _l.get(_i);
      killAbstractCExpression(_e);
    }
  }



  public void killAllCBinaryExpression(List cbinaryexpressionxx)
  { for (int _i = 0; _i < cbinaryexpressionxx.size(); _i++)
    { killCBinaryExpression((CBinaryExpression) cbinaryexpressionxx.get(_i)); }
  }

  public void killCBinaryExpression(CBinaryExpression cbinaryexpressionxx)
  { if (cbinaryexpressionxx == null) { return; }
   cbinaryexpressions.remove(cbinaryexpressionxx);
  killCExpression(cbinaryexpressionxx);
  }



  public void killAllCUnaryExpression(List cunaryexpressionxx)
  { for (int _i = 0; _i < cunaryexpressionxx.size(); _i++)
    { killCUnaryExpression((CUnaryExpression) cunaryexpressionxx.get(_i)); }
  }

  public void killCUnaryExpression(CUnaryExpression cunaryexpressionxx)
  { if (cunaryexpressionxx == null) { return; }
   cunaryexpressions.remove(cunaryexpressionxx);
  killCExpression(cunaryexpressionxx);
  }



  public void killAllCType(List ctypexx)
  { for (int _i = 0; _i < ctypexx.size(); _i++)
    { killCType((CType) ctypexx.get(_i)); }
  }

  public void killCType(CType ctypexx)
  { if (ctypexx == null) { return; }
   ctypes.remove(ctypexx);
    Vector _1removedtypeCExpression = new Vector();
    Vector _1removedelementTypeCExpression = new Vector();
    Vector _1removedcomponentTypeCArrayType = new Vector();
    Vector _1removedpointsToCPointerType = new Vector();
    Vector _1removedtypeCMember = new Vector();
    Vector _1removeddomainTypeCFunctionPointerType = new Vector();
    Vector _1removedrangeTypeCFunctionPointerType = new Vector();
    Vector _1removedtypeCVariable = new Vector();
    Vector _1removedreturnTypeCOperation = new Vector();
    Vector _1removedtypeDeclarationStatement = new Vector();
    Vector _1removedelementTypeDeclarationStatement = new Vector();
    Vector _1qrangetypeCExpression = new Vector();
    _1qrangetypeCExpression.addAll(cexpressions);
    for (int _i = 0; _i < _1qrangetypeCExpression.size(); _i++)
    { CExpression cexpressionx = (CExpression) _1qrangetypeCExpression.get(_i);
      if (cexpressionx != null && ctypexx.equals(cexpressionx.gettype()))
      { _1removedtypeCExpression.add(cexpressionx);
        cexpressionx.settype(null);
      }
    }
    Vector _1qrangeelementTypeCExpression = new Vector();
    _1qrangeelementTypeCExpression.addAll(cexpressions);
    for (int _i = 0; _i < _1qrangeelementTypeCExpression.size(); _i++)
    { CExpression cexpressionx = (CExpression) _1qrangeelementTypeCExpression.get(_i);
      if (cexpressionx != null && ctypexx.equals(cexpressionx.getelementType()))
      { _1removedelementTypeCExpression.add(cexpressionx);
        cexpressionx.setelementType(null);
      }
    }
    Vector _1qrangecomponentTypeCArrayType = new Vector();
    _1qrangecomponentTypeCArrayType.addAll(carraytypes);
    for (int _i = 0; _i < _1qrangecomponentTypeCArrayType.size(); _i++)
    { CArrayType carraytypex = (CArrayType) _1qrangecomponentTypeCArrayType.get(_i);
      if (carraytypex != null && ctypexx.equals(carraytypex.getcomponentType()))
      { _1removedcomponentTypeCArrayType.add(carraytypex);
        carraytypex.setcomponentType(null);
      }
    }
    Vector _1qrangepointsToCPointerType = new Vector();
    _1qrangepointsToCPointerType.addAll(cpointertypes);
    for (int _i = 0; _i < _1qrangepointsToCPointerType.size(); _i++)
    { CPointerType cpointertypex = (CPointerType) _1qrangepointsToCPointerType.get(_i);
      if (cpointertypex != null && ctypexx.equals(cpointertypex.getpointsTo()))
      { _1removedpointsToCPointerType.add(cpointertypex);
        cpointertypex.setpointsTo(null);
      }
    }
    Vector _1qrangetypeCMember = new Vector();
    _1qrangetypeCMember.addAll(cmembers);
    for (int _i = 0; _i < _1qrangetypeCMember.size(); _i++)
    { CMember cmemberx = (CMember) _1qrangetypeCMember.get(_i);
      if (cmemberx != null && ctypexx.equals(cmemberx.gettype()))
      { _1removedtypeCMember.add(cmemberx);
        cmemberx.settype(null);
      }
    }
    Vector _1qrangedomainTypeCFunctionPointerType = new Vector();
    _1qrangedomainTypeCFunctionPointerType.addAll(cfunctionpointertypes);
    for (int _i = 0; _i < _1qrangedomainTypeCFunctionPointerType.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) _1qrangedomainTypeCFunctionPointerType.get(_i);
      if (cfunctionpointertypex != null && ctypexx.equals(cfunctionpointertypex.getdomainType()))
      { _1removeddomainTypeCFunctionPointerType.add(cfunctionpointertypex);
        cfunctionpointertypex.setdomainType(null);
      }
    }
    Vector _1qrangerangeTypeCFunctionPointerType = new Vector();
    _1qrangerangeTypeCFunctionPointerType.addAll(cfunctionpointertypes);
    for (int _i = 0; _i < _1qrangerangeTypeCFunctionPointerType.size(); _i++)
    { CFunctionPointerType cfunctionpointertypex = (CFunctionPointerType) _1qrangerangeTypeCFunctionPointerType.get(_i);
      if (cfunctionpointertypex != null && ctypexx.equals(cfunctionpointertypex.getrangeType()))
      { _1removedrangeTypeCFunctionPointerType.add(cfunctionpointertypex);
        cfunctionpointertypex.setrangeType(null);
      }
    }
    Vector _1qrangetypeCVariable = new Vector();
    _1qrangetypeCVariable.addAll(cvariables);
    for (int _i = 0; _i < _1qrangetypeCVariable.size(); _i++)
    { CVariable cvariablex = (CVariable) _1qrangetypeCVariable.get(_i);
      if (cvariablex != null && ctypexx.equals(cvariablex.gettype()))
      { _1removedtypeCVariable.add(cvariablex);
        cvariablex.settype(null);
      }
    }
    Vector _1qrangereturnTypeCOperation = new Vector();
    _1qrangereturnTypeCOperation.addAll(coperations);
    for (int _i = 0; _i < _1qrangereturnTypeCOperation.size(); _i++)
    { COperation coperationx = (COperation) _1qrangereturnTypeCOperation.get(_i);
      if (coperationx != null && ctypexx.equals(coperationx.getreturnType()))
      { _1removedreturnTypeCOperation.add(coperationx);
        coperationx.setreturnType(null);
      }
    }
    Vector _1qrangetypeCAssignment = new Vector();
    _1qrangetypeCAssignment.addAll(cassignments);
    for (int _i = 0; _i < _1qrangetypeCAssignment.size(); _i++)
    { CAssignment cassignmentx = (CAssignment) _1qrangetypeCAssignment.get(_i);
      if (cassignmentx != null && cassignmentx.gettype().contains(ctypexx))
      { removetype(cassignmentx,ctypexx); }
    }
    Vector _1qrangetypeDeclarationStatement = new Vector();
    _1qrangetypeDeclarationStatement.addAll(declarationstatements);
    for (int _i = 0; _i < _1qrangetypeDeclarationStatement.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) _1qrangetypeDeclarationStatement.get(_i);
      if (declarationstatementx != null && ctypexx.equals(declarationstatementx.gettype()))
      { _1removedtypeDeclarationStatement.add(declarationstatementx);
        declarationstatementx.settype(null);
      }
    }
    Vector _1qrangeelementTypeDeclarationStatement = new Vector();
    _1qrangeelementTypeDeclarationStatement.addAll(declarationstatements);
    for (int _i = 0; _i < _1qrangeelementTypeDeclarationStatement.size(); _i++)
    { DeclarationStatement declarationstatementx = (DeclarationStatement) _1qrangeelementTypeDeclarationStatement.get(_i);
      if (declarationstatementx != null && ctypexx.equals(declarationstatementx.getelementType()))
      { _1removedelementTypeDeclarationStatement.add(declarationstatementx);
        declarationstatementx.setelementType(null);
      }
    }
    ctypectypeIdindex.remove(ctypexx.getctypeId());
    for (int _i = 0; _i < _1removedtypeCExpression.size(); _i++)
    { killAbstractCExpression((CExpression) _1removedtypeCExpression.get(_i)); }
    for (int _i = 0; _i < _1removedelementTypeCExpression.size(); _i++)
    { killAbstractCExpression((CExpression) _1removedelementTypeCExpression.get(_i)); }
    for (int _i = 0; _i < _1removedcomponentTypeCArrayType.size(); _i++)
    { killCArrayType((CArrayType) _1removedcomponentTypeCArrayType.get(_i)); }
    for (int _i = 0; _i < _1removedpointsToCPointerType.size(); _i++)
    { killCPointerType((CPointerType) _1removedpointsToCPointerType.get(_i)); }
    for (int _i = 0; _i < _1removedtypeCMember.size(); _i++)
    { killCMember((CMember) _1removedtypeCMember.get(_i)); }
    for (int _i = 0; _i < _1removeddomainTypeCFunctionPointerType.size(); _i++)
    { killCFunctionPointerType((CFunctionPointerType) _1removeddomainTypeCFunctionPointerType.get(_i)); }
    for (int _i = 0; _i < _1removedrangeTypeCFunctionPointerType.size(); _i++)
    { killCFunctionPointerType((CFunctionPointerType) _1removedrangeTypeCFunctionPointerType.get(_i)); }
    for (int _i = 0; _i < _1removedtypeCVariable.size(); _i++)
    { killCVariable((CVariable) _1removedtypeCVariable.get(_i)); }
    for (int _i = 0; _i < _1removedreturnTypeCOperation.size(); _i++)
    { killCOperation((COperation) _1removedreturnTypeCOperation.get(_i)); }
    for (int _i = 0; _i < _1removedtypeDeclarationStatement.size(); _i++)
    { killDeclarationStatement((DeclarationStatement) _1removedtypeDeclarationStatement.get(_i)); }
    for (int _i = 0; _i < _1removedelementTypeDeclarationStatement.size(); _i++)
    { killDeclarationStatement((DeclarationStatement) _1removedelementTypeDeclarationStatement.get(_i)); }
  }

  public void killAbstractCType(CType ctypexx)
  {
    if (ctypexx instanceof CFunctionPointerType)
    { killCFunctionPointerType((CFunctionPointerType) ctypexx); }
    if (ctypexx instanceof CStruct)
    { killCStruct((CStruct) ctypexx); }
    if (ctypexx instanceof CPrimitiveType)
    { killCPrimitiveType((CPrimitiveType) ctypexx); }
    if (ctypexx instanceof CPointerType)
    { killCPointerType((CPointerType) ctypexx); }
    if (ctypexx instanceof CArrayType)
    { killCArrayType((CArrayType) ctypexx); }
  }

  public void killAbstractCType(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { CType _e = (CType) _l.get(_i);
      killAbstractCType(_e);
    }
  }



  public void killAllCBasicExpression(List cbasicexpressionxx)
  { for (int _i = 0; _i < cbasicexpressionxx.size(); _i++)
    { killCBasicExpression((CBasicExpression) cbasicexpressionxx.get(_i)); }
  }

  public void killCBasicExpression(CBasicExpression cbasicexpressionxx)
  { if (cbasicexpressionxx == null) { return; }
   cbasicexpressions.remove(cbasicexpressionxx);
    Vector _1qrangearrayIndexCBasicExpression = new Vector();
    _1qrangearrayIndexCBasicExpression.addAll(cbasicexpressions);
    for (int _i = 0; _i < _1qrangearrayIndexCBasicExpression.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) _1qrangearrayIndexCBasicExpression.get(_i);
      if (cbasicexpressionx != null && cbasicexpressionx.getarrayIndex().contains(cbasicexpressionxx))
      { removearrayIndex(cbasicexpressionx,cbasicexpressionxx); }
    }
    Vector _1qrangereferenceCBasicExpression = new Vector();
    _1qrangereferenceCBasicExpression.addAll(cbasicexpressions);
    for (int _i = 0; _i < _1qrangereferenceCBasicExpression.size(); _i++)
    { CBasicExpression cbasicexpressionx = (CBasicExpression) _1qrangereferenceCBasicExpression.get(_i);
      if (cbasicexpressionx != null && cbasicexpressionx.getreference().contains(cbasicexpressionxx))
      { removereference(cbasicexpressionx,cbasicexpressionxx); }
    }
  killCExpression(cbasicexpressionxx);
  }



  public void killAllType(List typexx)
  { for (int _i = 0; _i < typexx.size(); _i++)
    { killType((Type) typexx.get(_i)); }
  }

  public void killType(Type typexx)
  { if (typexx == null) { return; }
   types.remove(typexx);
    Vector _1removedtypeProperty = new Vector();
    Vector _1removedelementTypeCollectionType = new Vector();
    Vector _1removedkeyTypeCollectionType = new Vector();
    Vector _1removedtypeExpression = new Vector();
    Vector _1removedelementTypeExpression = new Vector();
    Vector _1removedresultTypeUseCase = new Vector();
    Vector _1removedtypeCreationStatement = new Vector();
    Vector _1removedelementTypeCreationStatement = new Vector();
    Vector _1qrangetypeProperty = new Vector();
    _1qrangetypeProperty.addAll(propertys);
    for (int _i = 0; _i < _1qrangetypeProperty.size(); _i++)
    { Property propertyx = (Property) _1qrangetypeProperty.get(_i);
      if (propertyx != null && typexx.equals(propertyx.gettype()))
      { _1removedtypeProperty.add(propertyx);
        propertyx.settype(null);
      }
    }
    Vector _1qrangeelementTypeCollectionType = new Vector();
    _1qrangeelementTypeCollectionType.addAll(collectiontypes);
    for (int _i = 0; _i < _1qrangeelementTypeCollectionType.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) _1qrangeelementTypeCollectionType.get(_i);
      if (collectiontypex != null && typexx.equals(collectiontypex.getelementType()))
      { _1removedelementTypeCollectionType.add(collectiontypex);
        collectiontypex.setelementType(null);
      }
    }
    Vector _1qrangekeyTypeCollectionType = new Vector();
    _1qrangekeyTypeCollectionType.addAll(collectiontypes);
    for (int _i = 0; _i < _1qrangekeyTypeCollectionType.size(); _i++)
    { CollectionType collectiontypex = (CollectionType) _1qrangekeyTypeCollectionType.get(_i);
      if (collectiontypex != null && typexx.equals(collectiontypex.getkeyType()))
      { _1removedkeyTypeCollectionType.add(collectiontypex);
        collectiontypex.setkeyType(null);
      }
    }
    Vector _1qrangetypeExpression = new Vector();
    _1qrangetypeExpression.addAll(expressions);
    for (int _i = 0; _i < _1qrangetypeExpression.size(); _i++)
    { Expression expressionx = (Expression) _1qrangetypeExpression.get(_i);
      if (expressionx != null && typexx.equals(expressionx.gettype()))
      { _1removedtypeExpression.add(expressionx);
        expressionx.settype(null);
      }
    }
    Vector _1qrangeelementTypeExpression = new Vector();
    _1qrangeelementTypeExpression.addAll(expressions);
    for (int _i = 0; _i < _1qrangeelementTypeExpression.size(); _i++)
    { Expression expressionx = (Expression) _1qrangeelementTypeExpression.get(_i);
      if (expressionx != null && typexx.equals(expressionx.getelementType()))
      { _1removedelementTypeExpression.add(expressionx);
        expressionx.setelementType(null);
      }
    }
    Vector _1qrangeresultTypeUseCase = new Vector();
    _1qrangeresultTypeUseCase.addAll(usecases);
    for (int _i = 0; _i < _1qrangeresultTypeUseCase.size(); _i++)
    { UseCase usecasex = (UseCase) _1qrangeresultTypeUseCase.get(_i);
      if (usecasex != null && typexx.equals(usecasex.getresultType()))
      { _1removedresultTypeUseCase.add(usecasex);
        usecasex.setresultType(null);
      }
    }
    Vector _1qrangetypeAssignStatement = new Vector();
    _1qrangetypeAssignStatement.addAll(assignstatements);
    for (int _i = 0; _i < _1qrangetypeAssignStatement.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) _1qrangetypeAssignStatement.get(_i);
      if (assignstatementx != null && assignstatementx.gettype().contains(typexx))
      { removetype(assignstatementx,typexx); }
    }
    Vector _1qrangetypeCreationStatement = new Vector();
    _1qrangetypeCreationStatement.addAll(creationstatements);
    for (int _i = 0; _i < _1qrangetypeCreationStatement.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) _1qrangetypeCreationStatement.get(_i);
      if (creationstatementx != null && typexx.equals(creationstatementx.gettype()))
      { _1removedtypeCreationStatement.add(creationstatementx);
        creationstatementx.settype(null);
      }
    }
    Vector _1qrangeelementTypeCreationStatement = new Vector();
    _1qrangeelementTypeCreationStatement.addAll(creationstatements);
    for (int _i = 0; _i < _1qrangeelementTypeCreationStatement.size(); _i++)
    { CreationStatement creationstatementx = (CreationStatement) _1qrangeelementTypeCreationStatement.get(_i);
      if (creationstatementx != null && typexx.equals(creationstatementx.getelementType()))
      { _1removedelementTypeCreationStatement.add(creationstatementx);
        creationstatementx.setelementType(null);
      }
    }
    typetypeIdindex.remove(typexx.gettypeId());
    for (int _i = 0; _i < _1removedtypeProperty.size(); _i++)
    { killProperty((Property) _1removedtypeProperty.get(_i)); }
    for (int _i = 0; _i < _1removedelementTypeCollectionType.size(); _i++)
    { killCollectionType((CollectionType) _1removedelementTypeCollectionType.get(_i)); }
    for (int _i = 0; _i < _1removedkeyTypeCollectionType.size(); _i++)
    { killCollectionType((CollectionType) _1removedkeyTypeCollectionType.get(_i)); }
    for (int _i = 0; _i < _1removedtypeExpression.size(); _i++)
    { killAbstractExpression((Expression) _1removedtypeExpression.get(_i)); }
    for (int _i = 0; _i < _1removedelementTypeExpression.size(); _i++)
    { killAbstractExpression((Expression) _1removedelementTypeExpression.get(_i)); }
    for (int _i = 0; _i < _1removedresultTypeUseCase.size(); _i++)
    { killUseCase((UseCase) _1removedresultTypeUseCase.get(_i)); }
    for (int _i = 0; _i < _1removedtypeCreationStatement.size(); _i++)
    { killCreationStatement((CreationStatement) _1removedtypeCreationStatement.get(_i)); }
    for (int _i = 0; _i < _1removedelementTypeCreationStatement.size(); _i++)
    { killCreationStatement((CreationStatement) _1removedelementTypeCreationStatement.get(_i)); }
  }

  public void killAbstractType(Type typexx)
  {
    if (typexx instanceof Entity)
    { killEntity((Entity) typexx); }
    if (typexx instanceof PrimitiveType)
    { killPrimitiveType((PrimitiveType) typexx); }
    if (typexx instanceof CollectionType)
    { killCollectionType((CollectionType) typexx); }
  }

  public void killAbstractType(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { Type _e = (Type) _l.get(_i);
      killAbstractType(_e);
    }
  }



  public void killAllClassifier(List classifierxx)
  { for (int _i = 0; _i < classifierxx.size(); _i++)
    { killClassifier((Classifier) classifierxx.get(_i)); }
  }

  public void killClassifier(Classifier classifierxx)
  { if (classifierxx == null) { return; }
   classifiers.remove(classifierxx);
  killType(classifierxx);
  }

  public void killAbstractClassifier(Classifier classifierxx)
  {
    if (classifierxx instanceof Entity)
    { killEntity((Entity) classifierxx); }
    if (classifierxx instanceof PrimitiveType)
    { killPrimitiveType((PrimitiveType) classifierxx); }
    if (classifierxx instanceof CollectionType)
    { killCollectionType((CollectionType) classifierxx); }
  }

  public void killAbstractClassifier(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { Classifier _e = (Classifier) _l.get(_i);
      killAbstractClassifier(_e);
    }
  }



  public void killAllDataType(List datatypexx)
  { for (int _i = 0; _i < datatypexx.size(); _i++)
    { killDataType((DataType) datatypexx.get(_i)); }
  }

  public void killDataType(DataType datatypexx)
  { if (datatypexx == null) { return; }
   datatypes.remove(datatypexx);
  killClassifier(datatypexx);
  }

  public void killAbstractDataType(DataType datatypexx)
  {
    if (datatypexx instanceof PrimitiveType)
    { killPrimitiveType((PrimitiveType) datatypexx); }
    if (datatypexx instanceof CollectionType)
    { killCollectionType((CollectionType) datatypexx); }
  }

  public void killAbstractDataType(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { DataType _e = (DataType) _l.get(_i);
      killAbstractDataType(_e);
    }
  }



  public void killAllPrimitiveType(List primitivetypexx)
  { for (int _i = 0; _i < primitivetypexx.size(); _i++)
    { killPrimitiveType((PrimitiveType) primitivetypexx.get(_i)); }
  }

  public void killPrimitiveType(PrimitiveType primitivetypexx)
  { if (primitivetypexx == null) { return; }
   primitivetypes.remove(primitivetypexx);
  killDataType(primitivetypexx);
  }



  public void killAllEntity(List entityxx)
  { for (int _i = 0; _i < entityxx.size(); _i++)
    { killEntity((Entity) entityxx.get(_i)); }
  }

  public void killEntity(Entity entityxx)
  { if (entityxx == null) { return; }
   entitys.remove(entityxx);
    Vector _2removedownerOperation = new Vector();
    Vector _1removedownerProperty = new Vector();
    Vector _2qrangeownerOperation = new Vector();
    _2qrangeownerOperation.addAll(entityxx.getownedOperation());
    for (int _i = 0; _i < _2qrangeownerOperation.size(); _i++)
    { Operation operationx = (Operation) _2qrangeownerOperation.get(_i);
      if (operationx != null && entityxx.equals(operationx.getowner()))
      { _2removedownerOperation.add(operationx);
        operationx.setowner(null);
      }
    }

    entityxx.setownedOperation(new Vector());
    Vector _1qrangecontextBasicExpression = new Vector();
    _1qrangecontextBasicExpression.addAll(basicexpressions);
    for (int _i = 0; _i < _1qrangecontextBasicExpression.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) _1qrangecontextBasicExpression.get(_i);
      if (basicexpressionx != null && basicexpressionx.getcontext().contains(entityxx))
      { removecontext(basicexpressionx,entityxx); }
    }
    Vector _1qrangeownerProperty = new Vector();
    _1qrangeownerProperty.addAll(entityxx.getownedAttribute());
    for (int _i = 0; _i < _1qrangeownerProperty.size(); _i++)
    { Property propertyx = (Property) _1qrangeownerProperty.get(_i);
      if (propertyx != null && entityxx.equals(propertyx.getowner()))
      { _1removedownerProperty.add(propertyx);
        propertyx.setowner(null);
      }
    }
    for (int _i = 0; _i < _2removedownerOperation.size(); _i++)
    { killOperation((Operation) _2removedownerOperation.get(_i)); }
    for (int _i = 0; _i < _1removedownerProperty.size(); _i++)
    { killProperty((Property) _1removedownerProperty.get(_i)); }
  killClassifier(entityxx);
  }



  public void killAllCollectionType(List collectiontypexx)
  { for (int _i = 0; _i < collectiontypexx.size(); _i++)
    { killCollectionType((CollectionType) collectiontypexx.get(_i)); }
  }

  public void killCollectionType(CollectionType collectiontypexx)
  { if (collectiontypexx == null) { return; }
   collectiontypes.remove(collectiontypexx);
  killDataType(collectiontypexx);
  }



  public void killAllExpression(List expressionxx)
  { for (int _i = 0; _i < expressionxx.size(); _i++)
    { killExpression((Expression) expressionxx.get(_i)); }
  }

  public void killExpression(Expression expressionxx)
  { if (expressionxx == null) { return; }
   expressions.remove(expressionxx);
    Vector _1removedleftBinaryExpression = new Vector();
    Vector _1removedrightBinaryExpression = new Vector();
    Vector _1removedargumentUnaryExpression = new Vector();
    Vector _1removedinitialValueProperty = new Vector();
    Vector _1removedcallExpOperationCallStatement = new Vector();
    Vector _1removedcallExpImplicitCallStatement = new Vector();
    Vector _1removedtestLoopStatement = new Vector();
    Vector _1removedleftAssignStatement = new Vector();
    Vector _1removedrightAssignStatement = new Vector();
    Vector _1removedtestConditionalStatement = new Vector();
    Vector _1removedloopRangeBoundedLoopStatement = new Vector();
    Vector _1removedloopVarBoundedLoopStatement = new Vector();
    Vector _1qrangeelementsCollectionExpression = new Vector();
    _1qrangeelementsCollectionExpression.addAll(collectionexpressions);
    for (int _i = 0; _i < _1qrangeelementsCollectionExpression.size(); _i++)
    { CollectionExpression collectionexpressionx = (CollectionExpression) _1qrangeelementsCollectionExpression.get(_i);
      if (collectionexpressionx != null && collectionexpressionx.getelements().contains(expressionxx))
      { removeelements(collectionexpressionx,expressionxx); }
    }
    Vector _1qrangeleftBinaryExpression = new Vector();
    _1qrangeleftBinaryExpression.addAll(binaryexpressions);
    for (int _i = 0; _i < _1qrangeleftBinaryExpression.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) _1qrangeleftBinaryExpression.get(_i);
      if (binaryexpressionx != null && expressionxx.equals(binaryexpressionx.getleft()))
      { _1removedleftBinaryExpression.add(binaryexpressionx);
        binaryexpressionx.setleft(null);
      }
    }
    Vector _1qrangerightBinaryExpression = new Vector();
    _1qrangerightBinaryExpression.addAll(binaryexpressions);
    for (int _i = 0; _i < _1qrangerightBinaryExpression.size(); _i++)
    { BinaryExpression binaryexpressionx = (BinaryExpression) _1qrangerightBinaryExpression.get(_i);
      if (binaryexpressionx != null && expressionxx.equals(binaryexpressionx.getright()))
      { _1removedrightBinaryExpression.add(binaryexpressionx);
        binaryexpressionx.setright(null);
      }
    }
    Vector _1qrangeparametersBasicExpression = new Vector();
    _1qrangeparametersBasicExpression.addAll(basicexpressions);
    for (int _i = 0; _i < _1qrangeparametersBasicExpression.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) _1qrangeparametersBasicExpression.get(_i);
      if (basicexpressionx != null && basicexpressionx.getparameters().contains(expressionxx))
      { removeparameters(basicexpressionx,expressionxx); }
    }
    Vector _1qrangeargumentUnaryExpression = new Vector();
    _1qrangeargumentUnaryExpression.addAll(unaryexpressions);
    for (int _i = 0; _i < _1qrangeargumentUnaryExpression.size(); _i++)
    { UnaryExpression unaryexpressionx = (UnaryExpression) _1qrangeargumentUnaryExpression.get(_i);
      if (unaryexpressionx != null && expressionxx.equals(unaryexpressionx.getargument()))
      { _1removedargumentUnaryExpression.add(unaryexpressionx);
        unaryexpressionx.setargument(null);
      }
    }
    Vector _1qrangeinitialValueProperty = new Vector();
    _1qrangeinitialValueProperty.addAll(propertys);
    for (int _i = 0; _i < _1qrangeinitialValueProperty.size(); _i++)
    { Property propertyx = (Property) _1qrangeinitialValueProperty.get(_i);
      if (propertyx != null && expressionxx.equals(propertyx.getinitialValue()))
      { _1removedinitialValueProperty.add(propertyx);
        propertyx.setinitialValue(null);
      }
    }
    Vector _1qrangereturnValueReturnStatement = new Vector();
    _1qrangereturnValueReturnStatement.addAll(returnstatements);
    for (int _i = 0; _i < _1qrangereturnValueReturnStatement.size(); _i++)
    { ReturnStatement returnstatementx = (ReturnStatement) _1qrangereturnValueReturnStatement.get(_i);
      if (returnstatementx != null && returnstatementx.getreturnValue().contains(expressionxx))
      { removereturnValue(returnstatementx,expressionxx); }
    }
    Vector _1qrangecallExpOperationCallStatement = new Vector();
    _1qrangecallExpOperationCallStatement.addAll(operationcallstatements);
    for (int _i = 0; _i < _1qrangecallExpOperationCallStatement.size(); _i++)
    { OperationCallStatement operationcallstatementx = (OperationCallStatement) _1qrangecallExpOperationCallStatement.get(_i);
      if (operationcallstatementx != null && expressionxx.equals(operationcallstatementx.getcallExp()))
      { _1removedcallExpOperationCallStatement.add(operationcallstatementx);
        operationcallstatementx.setcallExp(null);
      }
    }
    Vector _1qrangecallExpImplicitCallStatement = new Vector();
    _1qrangecallExpImplicitCallStatement.addAll(implicitcallstatements);
    for (int _i = 0; _i < _1qrangecallExpImplicitCallStatement.size(); _i++)
    { ImplicitCallStatement implicitcallstatementx = (ImplicitCallStatement) _1qrangecallExpImplicitCallStatement.get(_i);
      if (implicitcallstatementx != null && expressionxx.equals(implicitcallstatementx.getcallExp()))
      { _1removedcallExpImplicitCallStatement.add(implicitcallstatementx);
        implicitcallstatementx.setcallExp(null);
      }
    }
    Vector _1qrangetestLoopStatement = new Vector();
    _1qrangetestLoopStatement.addAll(loopstatements);
    for (int _i = 0; _i < _1qrangetestLoopStatement.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) _1qrangetestLoopStatement.get(_i);
      if (loopstatementx != null && expressionxx.equals(loopstatementx.gettest()))
      { _1removedtestLoopStatement.add(loopstatementx);
        loopstatementx.settest(null);
      }
    }
    Vector _1qrangeleftAssignStatement = new Vector();
    _1qrangeleftAssignStatement.addAll(assignstatements);
    for (int _i = 0; _i < _1qrangeleftAssignStatement.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) _1qrangeleftAssignStatement.get(_i);
      if (assignstatementx != null && expressionxx.equals(assignstatementx.getleft()))
      { _1removedleftAssignStatement.add(assignstatementx);
        assignstatementx.setleft(null);
      }
    }
    Vector _1qrangerightAssignStatement = new Vector();
    _1qrangerightAssignStatement.addAll(assignstatements);
    for (int _i = 0; _i < _1qrangerightAssignStatement.size(); _i++)
    { AssignStatement assignstatementx = (AssignStatement) _1qrangerightAssignStatement.get(_i);
      if (assignstatementx != null && expressionxx.equals(assignstatementx.getright()))
      { _1removedrightAssignStatement.add(assignstatementx);
        assignstatementx.setright(null);
      }
    }
    Vector _1qrangetestConditionalStatement = new Vector();
    _1qrangetestConditionalStatement.addAll(conditionalstatements);
    for (int _i = 0; _i < _1qrangetestConditionalStatement.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) _1qrangetestConditionalStatement.get(_i);
      if (conditionalstatementx != null && expressionxx.equals(conditionalstatementx.gettest()))
      { _1removedtestConditionalStatement.add(conditionalstatementx);
        conditionalstatementx.settest(null);
      }
    }
    Vector _1qrangeloopRangeBoundedLoopStatement = new Vector();
    _1qrangeloopRangeBoundedLoopStatement.addAll(boundedloopstatements);
    for (int _i = 0; _i < _1qrangeloopRangeBoundedLoopStatement.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) _1qrangeloopRangeBoundedLoopStatement.get(_i);
      if (boundedloopstatementx != null && expressionxx.equals(boundedloopstatementx.getloopRange()))
      { _1removedloopRangeBoundedLoopStatement.add(boundedloopstatementx);
        boundedloopstatementx.setloopRange(null);
      }
    }
    Vector _1qrangeloopVarBoundedLoopStatement = new Vector();
    _1qrangeloopVarBoundedLoopStatement.addAll(boundedloopstatements);
    for (int _i = 0; _i < _1qrangeloopVarBoundedLoopStatement.size(); _i++)
    { BoundedLoopStatement boundedloopstatementx = (BoundedLoopStatement) _1qrangeloopVarBoundedLoopStatement.get(_i);
      if (boundedloopstatementx != null && expressionxx.equals(boundedloopstatementx.getloopVar()))
      { _1removedloopVarBoundedLoopStatement.add(boundedloopstatementx);
        boundedloopstatementx.setloopVar(null);
      }
    }
    expressionexpIdindex.remove(expressionxx.getexpId());
    for (int _i = 0; _i < _1removedleftBinaryExpression.size(); _i++)
    { killBinaryExpression((BinaryExpression) _1removedleftBinaryExpression.get(_i)); }
    for (int _i = 0; _i < _1removedrightBinaryExpression.size(); _i++)
    { killBinaryExpression((BinaryExpression) _1removedrightBinaryExpression.get(_i)); }
    for (int _i = 0; _i < _1removedargumentUnaryExpression.size(); _i++)
    { killUnaryExpression((UnaryExpression) _1removedargumentUnaryExpression.get(_i)); }
    for (int _i = 0; _i < _1removedinitialValueProperty.size(); _i++)
    { killProperty((Property) _1removedinitialValueProperty.get(_i)); }
    for (int _i = 0; _i < _1removedcallExpOperationCallStatement.size(); _i++)
    { killOperationCallStatement((OperationCallStatement) _1removedcallExpOperationCallStatement.get(_i)); }
    for (int _i = 0; _i < _1removedcallExpImplicitCallStatement.size(); _i++)
    { killImplicitCallStatement((ImplicitCallStatement) _1removedcallExpImplicitCallStatement.get(_i)); }
    for (int _i = 0; _i < _1removedtestLoopStatement.size(); _i++)
    { killAbstractLoopStatement((LoopStatement) _1removedtestLoopStatement.get(_i)); }
    for (int _i = 0; _i < _1removedleftAssignStatement.size(); _i++)
    { killAssignStatement((AssignStatement) _1removedleftAssignStatement.get(_i)); }
    for (int _i = 0; _i < _1removedrightAssignStatement.size(); _i++)
    { killAssignStatement((AssignStatement) _1removedrightAssignStatement.get(_i)); }
    for (int _i = 0; _i < _1removedtestConditionalStatement.size(); _i++)
    { killConditionalStatement((ConditionalStatement) _1removedtestConditionalStatement.get(_i)); }
    for (int _i = 0; _i < _1removedloopRangeBoundedLoopStatement.size(); _i++)
    { killBoundedLoopStatement((BoundedLoopStatement) _1removedloopRangeBoundedLoopStatement.get(_i)); }
    for (int _i = 0; _i < _1removedloopVarBoundedLoopStatement.size(); _i++)
    { killBoundedLoopStatement((BoundedLoopStatement) _1removedloopVarBoundedLoopStatement.get(_i)); }
  }

  public void killAbstractExpression(Expression expressionxx)
  {
    if (expressionxx instanceof UnaryExpression)
    { killUnaryExpression((UnaryExpression) expressionxx); }
    if (expressionxx instanceof BasicExpression)
    { killBasicExpression((BasicExpression) expressionxx); }
    if (expressionxx instanceof BinaryExpression)
    { killBinaryExpression((BinaryExpression) expressionxx); }
    if (expressionxx instanceof CollectionExpression)
    { killCollectionExpression((CollectionExpression) expressionxx); }
  }

  public void killAbstractExpression(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { Expression _e = (Expression) _l.get(_i);
      killAbstractExpression(_e);
    }
  }



  public void killAllBinaryExpression(List binaryexpressionxx)
  { for (int _i = 0; _i < binaryexpressionxx.size(); _i++)
    { killBinaryExpression((BinaryExpression) binaryexpressionxx.get(_i)); }
  }

  public void killBinaryExpression(BinaryExpression binaryexpressionxx)
  { if (binaryexpressionxx == null) { return; }
   binaryexpressions.remove(binaryexpressionxx);
  killExpression(binaryexpressionxx);
  }



  public void killAllUnaryExpression(List unaryexpressionxx)
  { for (int _i = 0; _i < unaryexpressionxx.size(); _i++)
    { killUnaryExpression((UnaryExpression) unaryexpressionxx.get(_i)); }
  }

  public void killUnaryExpression(UnaryExpression unaryexpressionxx)
  { if (unaryexpressionxx == null) { return; }
   unaryexpressions.remove(unaryexpressionxx);
  killExpression(unaryexpressionxx);
  }



  public void killAllCollectionExpression(List collectionexpressionxx)
  { for (int _i = 0; _i < collectionexpressionxx.size(); _i++)
    { killCollectionExpression((CollectionExpression) collectionexpressionxx.get(_i)); }
  }

  public void killCollectionExpression(CollectionExpression collectionexpressionxx)
  { if (collectionexpressionxx == null) { return; }
   collectionexpressions.remove(collectionexpressionxx);
  killExpression(collectionexpressionxx);
  }



  public void killAllBasicExpression(List basicexpressionxx)
  { for (int _i = 0; _i < basicexpressionxx.size(); _i++)
    { killBasicExpression((BasicExpression) basicexpressionxx.get(_i)); }
  }

  public void killBasicExpression(BasicExpression basicexpressionxx)
  { if (basicexpressionxx == null) { return; }
   basicexpressions.remove(basicexpressionxx);
    Vector _1qrangearrayIndexBasicExpression = new Vector();
    _1qrangearrayIndexBasicExpression.addAll(basicexpressions);
    for (int _i = 0; _i < _1qrangearrayIndexBasicExpression.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) _1qrangearrayIndexBasicExpression.get(_i);
      if (basicexpressionx != null && basicexpressionx.getarrayIndex().contains(basicexpressionxx))
      { removearrayIndex(basicexpressionx,basicexpressionxx); }
    }
    Vector _1qrangeobjectRefBasicExpression = new Vector();
    _1qrangeobjectRefBasicExpression.addAll(basicexpressions);
    for (int _i = 0; _i < _1qrangeobjectRefBasicExpression.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) _1qrangeobjectRefBasicExpression.get(_i);
      if (basicexpressionx != null && basicexpressionx.getobjectRef().contains(basicexpressionxx))
      { removeobjectRef(basicexpressionx,basicexpressionxx); }
    }
  killExpression(basicexpressionxx);
  }



  public void killAllProperty(List propertyxx)
  { for (int _i = 0; _i < propertyxx.size(); _i++)
    { killProperty((Property) propertyxx.get(_i)); }
  }

  public void killProperty(Property propertyxx)
  { if (propertyxx == null) { return; }
   propertys.remove(propertyxx);
    Vector _1qrangereferredPropertyBasicExpression = new Vector();
    _1qrangereferredPropertyBasicExpression.addAll(basicexpressions);
    for (int _i = 0; _i < _1qrangereferredPropertyBasicExpression.size(); _i++)
    { BasicExpression basicexpressionx = (BasicExpression) _1qrangereferredPropertyBasicExpression.get(_i);
      if (basicexpressionx != null && basicexpressionx.getreferredProperty().contains(propertyxx))
      { removereferredProperty(basicexpressionx,propertyxx); }
    }
    Vector _2qrangeownedAttributeEntity = new Vector();
    _2qrangeownedAttributeEntity.add(propertyxx.getowner());
    for (int _i = 0; _i < _2qrangeownedAttributeEntity.size(); _i++)
    { Entity entityx = (Entity) _2qrangeownedAttributeEntity.get(_i);
      if (entityx != null && entityx.getownedAttribute().contains(propertyxx))
      { removeownedAttribute(entityx,propertyxx); }
    }
    Vector _1qrangeparametersUseCase = new Vector();
    _1qrangeparametersUseCase.addAll(usecases);
    for (int _i = 0; _i < _1qrangeparametersUseCase.size(); _i++)
    { UseCase usecasex = (UseCase) _1qrangeparametersUseCase.get(_i);
      if (usecasex != null && usecasex.getparameters().contains(propertyxx))
      { removeparameters(usecasex,propertyxx); }
    }
  }



  public void killAllExp2C(List exp2cxx)
  { for (int _i = 0; _i < exp2cxx.size(); _i++)
    { killExp2C((Exp2C) exp2cxx.get(_i)); }
  }

  public void killExp2C(Exp2C exp2cxx)
  { if (exp2cxx == null) { return; }
   exp2cs.remove(exp2cxx);
  }



  public void killAllCPrimitiveType(List cprimitivetypexx)
  { for (int _i = 0; _i < cprimitivetypexx.size(); _i++)
    { killCPrimitiveType((CPrimitiveType) cprimitivetypexx.get(_i)); }
  }

  public void killCPrimitiveType(CPrimitiveType cprimitivetypexx)
  { if (cprimitivetypexx == null) { return; }
   cprimitivetypes.remove(cprimitivetypexx);
  killCType(cprimitivetypexx);
  }



  public void killAllCArrayType(List carraytypexx)
  { for (int _i = 0; _i < carraytypexx.size(); _i++)
    { killCArrayType((CArrayType) carraytypexx.get(_i)); }
  }

  public void killCArrayType(CArrayType carraytypexx)
  { if (carraytypexx == null) { return; }
   carraytypes.remove(carraytypexx);
  killCType(carraytypexx);
  }



  public void killAllCPointerType(List cpointertypexx)
  { for (int _i = 0; _i < cpointertypexx.size(); _i++)
    { killCPointerType((CPointerType) cpointertypexx.get(_i)); }
  }

  public void killCPointerType(CPointerType cpointertypexx)
  { if (cpointertypexx == null) { return; }
   cpointertypes.remove(cpointertypexx);
  killCType(cpointertypexx);
  }



  public void killAllCStruct(List cstructxx)
  { for (int _i = 0; _i < cstructxx.size(); _i++)
    { killCStruct((CStruct) cstructxx.get(_i)); }
  }

  public void killCStruct(CStruct cstructxx)
  { if (cstructxx == null) { return; }
   cstructs.remove(cstructxx);
    Vector _1qrangestructsCProgram = new Vector();
    _1qrangestructsCProgram.addAll(cprograms);
    for (int _i = 0; _i < _1qrangestructsCProgram.size(); _i++)
    { CProgram cprogramx = (CProgram) _1qrangestructsCProgram.get(_i);
      if (cprogramx != null && cprogramx.getstructs().contains(cstructxx))
      { removestructs(cprogramx,cstructxx); }
    }
    cstructnameindex.remove(cstructxx.getname());
  killCType(cstructxx);
  }



  public void killAllCMember(List cmemberxx)
  { for (int _i = 0; _i < cmemberxx.size(); _i++)
    { killCMember((CMember) cmemberxx.get(_i)); }
  }

  public void killCMember(CMember cmemberxx)
  { if (cmemberxx == null) { return; }
   cmembers.remove(cmemberxx);
    Vector _1qrangemembersCStruct = new Vector();
    _1qrangemembersCStruct.addAll(cstructs);
    for (int _i = 0; _i < _1qrangemembersCStruct.size(); _i++)
    { CStruct cstructx = (CStruct) _1qrangemembersCStruct.get(_i);
      if (cstructx != null && cstructx.getmembers().contains(cmemberxx))
      { removemembers(cstructx,cmemberxx); }
    }
    Vector _1qrangeallMembersCStruct = new Vector();
    _1qrangeallMembersCStruct.addAll(cstructs);
    for (int _i = 0; _i < _1qrangeallMembersCStruct.size(); _i++)
    { CStruct cstructx = (CStruct) _1qrangeallMembersCStruct.get(_i);
      if (cstructx != null && cstructx.getallMembers().contains(cmemberxx))
      { removeallMembers(cstructx,cmemberxx); }
    }
  }



  public void killAllCVariable(List cvariablexx)
  { for (int _i = 0; _i < cvariablexx.size(); _i++)
    { killCVariable((CVariable) cvariablexx.get(_i)); }
  }

  public void killCVariable(CVariable cvariablexx)
  { if (cvariablexx == null) { return; }
   cvariables.remove(cvariablexx);
    Vector _1qrangevariablesCProgram = new Vector();
    _1qrangevariablesCProgram.addAll(cprograms);
    for (int _i = 0; _i < _1qrangevariablesCProgram.size(); _i++)
    { CProgram cprogramx = (CProgram) _1qrangevariablesCProgram.get(_i);
      if (cprogramx != null && cprogramx.getvariables().contains(cvariablexx))
      { removevariables(cprogramx,cvariablexx); }
    }
    Vector _1qrangeparametersCOperation = new Vector();
    _1qrangeparametersCOperation.addAll(coperations);
    for (int _i = 0; _i < _1qrangeparametersCOperation.size(); _i++)
    { COperation coperationx = (COperation) _1qrangeparametersCOperation.get(_i);
      if (coperationx != null && coperationx.getparameters().contains(cvariablexx))
      { removeparameters(coperationx,cvariablexx); }
    }
  }



  public void killAllCProgram(List cprogramxx)
  { for (int _i = 0; _i < cprogramxx.size(); _i++)
    { killCProgram((CProgram) cprogramxx.get(_i)); }
  }

  public void killCProgram(CProgram cprogramxx)
  { if (cprogramxx == null) { return; }
   cprograms.remove(cprogramxx);
  }



  public void killAllCFunctionPointerType(List cfunctionpointertypexx)
  { for (int _i = 0; _i < cfunctionpointertypexx.size(); _i++)
    { killCFunctionPointerType((CFunctionPointerType) cfunctionpointertypexx.get(_i)); }
  }

  public void killCFunctionPointerType(CFunctionPointerType cfunctionpointertypexx)
  { if (cfunctionpointertypexx == null) { return; }
   cfunctionpointertypes.remove(cfunctionpointertypexx);
  killCType(cfunctionpointertypexx);
  }



  public void killAllCOperation(List coperationxx)
  { for (int _i = 0; _i < coperationxx.size(); _i++)
    { killCOperation((COperation) coperationxx.get(_i)); }
  }

  public void killCOperation(COperation coperationxx)
  { if (coperationxx == null) { return; }
   coperations.remove(coperationxx);
    Vector _1qrangeoperationsCProgram = new Vector();
    _1qrangeoperationsCProgram.addAll(cprograms);
    for (int _i = 0; _i < _1qrangeoperationsCProgram.size(); _i++)
    { CProgram cprogramx = (CProgram) _1qrangeoperationsCProgram.get(_i);
      if (cprogramx != null && cprogramx.getoperations().contains(coperationxx))
      { removeoperations(cprogramx,coperationxx); }
    }
    coperationopIdindex.remove(coperationxx.getopId());
  }



  public void killAllStatement(List statementxx)
  { for (int _i = 0; _i < statementxx.size(); _i++)
    { killStatement((Statement) statementxx.get(_i)); }
  }

  public void killStatement(Statement statementxx)
  { if (statementxx == null) { return; }
   statements.remove(statementxx);
    Vector _1removedactivityBehaviouralFeature = new Vector();
    Vector _1removedclassifierBehaviourUseCase = new Vector();
    Vector _1removedifPartConditionalStatement = new Vector();
    Vector _1removedbodyLoopStatement = new Vector();
    Vector _1qrangeactivityBehaviouralFeature = new Vector();
    _1qrangeactivityBehaviouralFeature.addAll(behaviouralfeatures);
    for (int _i = 0; _i < _1qrangeactivityBehaviouralFeature.size(); _i++)
    { BehaviouralFeature behaviouralfeaturex = (BehaviouralFeature) _1qrangeactivityBehaviouralFeature.get(_i);
      if (behaviouralfeaturex != null && statementxx.equals(behaviouralfeaturex.getactivity()))
      { _1removedactivityBehaviouralFeature.add(behaviouralfeaturex);
        behaviouralfeaturex.setactivity(null);
      }
    }
    Vector _1qrangeclassifierBehaviourUseCase = new Vector();
    _1qrangeclassifierBehaviourUseCase.addAll(usecases);
    for (int _i = 0; _i < _1qrangeclassifierBehaviourUseCase.size(); _i++)
    { UseCase usecasex = (UseCase) _1qrangeclassifierBehaviourUseCase.get(_i);
      if (usecasex != null && statementxx.equals(usecasex.getclassifierBehaviour()))
      { _1removedclassifierBehaviourUseCase.add(usecasex);
        usecasex.setclassifierBehaviour(null);
      }
    }
    Vector _1qrangeifPartConditionalStatement = new Vector();
    _1qrangeifPartConditionalStatement.addAll(conditionalstatements);
    for (int _i = 0; _i < _1qrangeifPartConditionalStatement.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) _1qrangeifPartConditionalStatement.get(_i);
      if (conditionalstatementx != null && statementxx.equals(conditionalstatementx.getifPart()))
      { _1removedifPartConditionalStatement.add(conditionalstatementx);
        conditionalstatementx.setifPart(null);
      }
    }
    Vector _1qrangeelsePartConditionalStatement = new Vector();
    _1qrangeelsePartConditionalStatement.addAll(conditionalstatements);
    for (int _i = 0; _i < _1qrangeelsePartConditionalStatement.size(); _i++)
    { ConditionalStatement conditionalstatementx = (ConditionalStatement) _1qrangeelsePartConditionalStatement.get(_i);
      if (conditionalstatementx != null && conditionalstatementx.getelsePart().contains(statementxx))
      { removeelsePart(conditionalstatementx,statementxx); }
    }
    Vector _1qrangestatementsSequenceStatement = new Vector();
    _1qrangestatementsSequenceStatement.addAll(sequencestatements);
    for (int _i = 0; _i < _1qrangestatementsSequenceStatement.size(); _i++)
    { SequenceStatement sequencestatementx = (SequenceStatement) _1qrangestatementsSequenceStatement.get(_i);
      if (sequencestatementx != null && sequencestatementx.getstatements().contains(statementxx))
      { removestatements(sequencestatementx,statementxx); }
    }
    Vector _1qrangebodyLoopStatement = new Vector();
    _1qrangebodyLoopStatement.addAll(loopstatements);
    for (int _i = 0; _i < _1qrangebodyLoopStatement.size(); _i++)
    { LoopStatement loopstatementx = (LoopStatement) _1qrangebodyLoopStatement.get(_i);
      if (loopstatementx != null && statementxx.equals(loopstatementx.getbody()))
      { _1removedbodyLoopStatement.add(loopstatementx);
        loopstatementx.setbody(null);
      }
    }
    statementstatIdindex.remove(statementxx.getstatId());
    for (int _i = 0; _i < _1removedactivityBehaviouralFeature.size(); _i++)
    { killAbstractBehaviouralFeature((BehaviouralFeature) _1removedactivityBehaviouralFeature.get(_i)); }
    for (int _i = 0; _i < _1removedclassifierBehaviourUseCase.size(); _i++)
    { killUseCase((UseCase) _1removedclassifierBehaviourUseCase.get(_i)); }
    for (int _i = 0; _i < _1removedifPartConditionalStatement.size(); _i++)
    { killConditionalStatement((ConditionalStatement) _1removedifPartConditionalStatement.get(_i)); }
    for (int _i = 0; _i < _1removedbodyLoopStatement.size(); _i++)
    { killAbstractLoopStatement((LoopStatement) _1removedbodyLoopStatement.get(_i)); }
  }

  public void killAbstractStatement(Statement statementxx)
  {
    if (statementxx instanceof ReturnStatement)
    { killReturnStatement((ReturnStatement) statementxx); }
    if (statementxx instanceof BreakStatement)
    { killBreakStatement((BreakStatement) statementxx); }
    if (statementxx instanceof OperationCallStatement)
    { killOperationCallStatement((OperationCallStatement) statementxx); }
    if (statementxx instanceof ImplicitCallStatement)
    { killImplicitCallStatement((ImplicitCallStatement) statementxx); }
    if (statementxx instanceof SequenceStatement)
    { killSequenceStatement((SequenceStatement) statementxx); }
    if (statementxx instanceof ConditionalStatement)
    { killConditionalStatement((ConditionalStatement) statementxx); }
    if (statementxx instanceof AssignStatement)
    { killAssignStatement((AssignStatement) statementxx); }
    if (statementxx instanceof CreationStatement)
    { killCreationStatement((CreationStatement) statementxx); }
    if (statementxx instanceof BoundedLoopStatement)
    { killBoundedLoopStatement((BoundedLoopStatement) statementxx); }
    if (statementxx instanceof UnboundedLoopStatement)
    { killUnboundedLoopStatement((UnboundedLoopStatement) statementxx); }
  }

  public void killAbstractStatement(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { Statement _e = (Statement) _l.get(_i);
      killAbstractStatement(_e);
    }
  }



  public void killAllReturnStatement(List returnstatementxx)
  { for (int _i = 0; _i < returnstatementxx.size(); _i++)
    { killReturnStatement((ReturnStatement) returnstatementxx.get(_i)); }
  }

  public void killReturnStatement(ReturnStatement returnstatementxx)
  { if (returnstatementxx == null) { return; }
   returnstatements.remove(returnstatementxx);
  killStatement(returnstatementxx);
  }



  public void killAllBehaviouralFeature(List behaviouralfeaturexx)
  { for (int _i = 0; _i < behaviouralfeaturexx.size(); _i++)
    { killBehaviouralFeature((BehaviouralFeature) behaviouralfeaturexx.get(_i)); }
  }

  public void killBehaviouralFeature(BehaviouralFeature behaviouralfeaturexx)
  { if (behaviouralfeaturexx == null) { return; }
   behaviouralfeatures.remove(behaviouralfeaturexx);
  }

  public void killAbstractBehaviouralFeature(BehaviouralFeature behaviouralfeaturexx)
  {
    if (behaviouralfeaturexx instanceof Operation)
    { killOperation((Operation) behaviouralfeaturexx); }
  }

  public void killAbstractBehaviouralFeature(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { BehaviouralFeature _e = (BehaviouralFeature) _l.get(_i);
      killAbstractBehaviouralFeature(_e);
    }
  }



  public void killAllOperation(List operationxx)
  { for (int _i = 0; _i < operationxx.size(); _i++)
    { killOperation((Operation) operationxx.get(_i)); }
  }

  public void killOperation(Operation operationxx)
  { if (operationxx == null) { return; }
   operations.remove(operationxx);
    Vector _1qrangeownedOperationEntity = new Vector();
    _1qrangeownedOperationEntity.add(operationxx.getowner());
    for (int _i = 0; _i < _1qrangeownedOperationEntity.size(); _i++)
    { Entity entityx = (Entity) _1qrangeownedOperationEntity.get(_i);
      if (entityx != null && entityx.getownedOperation().contains(operationxx))
      { removeownedOperation(entityx,operationxx); }
    }
  killBehaviouralFeature(operationxx);
  }



  public void killAllUseCase(List usecasexx)
  { for (int _i = 0; _i < usecasexx.size(); _i++)
    { killUseCase((UseCase) usecasexx.get(_i)); }
  }

  public void killUseCase(UseCase usecasexx)
  { if (usecasexx == null) { return; }
   usecases.remove(usecasexx);
  }



  public void killAllBreakStatement(List breakstatementxx)
  { for (int _i = 0; _i < breakstatementxx.size(); _i++)
    { killBreakStatement((BreakStatement) breakstatementxx.get(_i)); }
  }

  public void killBreakStatement(BreakStatement breakstatementxx)
  { if (breakstatementxx == null) { return; }
   breakstatements.remove(breakstatementxx);
  killStatement(breakstatementxx);
  }



  public void killAllOperationCallStatement(List operationcallstatementxx)
  { for (int _i = 0; _i < operationcallstatementxx.size(); _i++)
    { killOperationCallStatement((OperationCallStatement) operationcallstatementxx.get(_i)); }
  }

  public void killOperationCallStatement(OperationCallStatement operationcallstatementxx)
  { if (operationcallstatementxx == null) { return; }
   operationcallstatements.remove(operationcallstatementxx);
  killStatement(operationcallstatementxx);
  }



  public void killAllImplicitCallStatement(List implicitcallstatementxx)
  { for (int _i = 0; _i < implicitcallstatementxx.size(); _i++)
    { killImplicitCallStatement((ImplicitCallStatement) implicitcallstatementxx.get(_i)); }
  }

  public void killImplicitCallStatement(ImplicitCallStatement implicitcallstatementxx)
  { if (implicitcallstatementxx == null) { return; }
   implicitcallstatements.remove(implicitcallstatementxx);
  killStatement(implicitcallstatementxx);
  }



  public void killAllLoopStatement(List loopstatementxx)
  { for (int _i = 0; _i < loopstatementxx.size(); _i++)
    { killLoopStatement((LoopStatement) loopstatementxx.get(_i)); }
  }

  public void killLoopStatement(LoopStatement loopstatementxx)
  { if (loopstatementxx == null) { return; }
   loopstatements.remove(loopstatementxx);
  killStatement(loopstatementxx);
  }

  public void killAbstractLoopStatement(LoopStatement loopstatementxx)
  {
    if (loopstatementxx instanceof BoundedLoopStatement)
    { killBoundedLoopStatement((BoundedLoopStatement) loopstatementxx); }
    if (loopstatementxx instanceof UnboundedLoopStatement)
    { killUnboundedLoopStatement((UnboundedLoopStatement) loopstatementxx); }
  }

  public void killAbstractLoopStatement(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { LoopStatement _e = (LoopStatement) _l.get(_i);
      killAbstractLoopStatement(_e);
    }
  }



  public void killAllBoundedLoopStatement(List boundedloopstatementxx)
  { for (int _i = 0; _i < boundedloopstatementxx.size(); _i++)
    { killBoundedLoopStatement((BoundedLoopStatement) boundedloopstatementxx.get(_i)); }
  }

  public void killBoundedLoopStatement(BoundedLoopStatement boundedloopstatementxx)
  { if (boundedloopstatementxx == null) { return; }
   boundedloopstatements.remove(boundedloopstatementxx);
  killLoopStatement(boundedloopstatementxx);
  }



  public void killAllUnboundedLoopStatement(List unboundedloopstatementxx)
  { for (int _i = 0; _i < unboundedloopstatementxx.size(); _i++)
    { killUnboundedLoopStatement((UnboundedLoopStatement) unboundedloopstatementxx.get(_i)); }
  }

  public void killUnboundedLoopStatement(UnboundedLoopStatement unboundedloopstatementxx)
  { if (unboundedloopstatementxx == null) { return; }
   unboundedloopstatements.remove(unboundedloopstatementxx);
  killLoopStatement(unboundedloopstatementxx);
  }



  public void killAllAssignStatement(List assignstatementxx)
  { for (int _i = 0; _i < assignstatementxx.size(); _i++)
    { killAssignStatement((AssignStatement) assignstatementxx.get(_i)); }
  }

  public void killAssignStatement(AssignStatement assignstatementxx)
  { if (assignstatementxx == null) { return; }
   assignstatements.remove(assignstatementxx);
  killStatement(assignstatementxx);
  }



  public void killAllSequenceStatement(List sequencestatementxx)
  { for (int _i = 0; _i < sequencestatementxx.size(); _i++)
    { killSequenceStatement((SequenceStatement) sequencestatementxx.get(_i)); }
  }

  public void killSequenceStatement(SequenceStatement sequencestatementxx)
  { if (sequencestatementxx == null) { return; }
   sequencestatements.remove(sequencestatementxx);
  killStatement(sequencestatementxx);
  }



  public void killAllConditionalStatement(List conditionalstatementxx)
  { for (int _i = 0; _i < conditionalstatementxx.size(); _i++)
    { killConditionalStatement((ConditionalStatement) conditionalstatementxx.get(_i)); }
  }

  public void killConditionalStatement(ConditionalStatement conditionalstatementxx)
  { if (conditionalstatementxx == null) { return; }
   conditionalstatements.remove(conditionalstatementxx);
  killStatement(conditionalstatementxx);
  }



  public void killAllCreationStatement(List creationstatementxx)
  { for (int _i = 0; _i < creationstatementxx.size(); _i++)
    { killCreationStatement((CreationStatement) creationstatementxx.get(_i)); }
  }

  public void killCreationStatement(CreationStatement creationstatementxx)
  { if (creationstatementxx == null) { return; }
   creationstatements.remove(creationstatementxx);
  killStatement(creationstatementxx);
  }



  public void killAllCStatement(List cstatementxx)
  { for (int _i = 0; _i < cstatementxx.size(); _i++)
    { killCStatement((CStatement) cstatementxx.get(_i)); }
  }

  public void killCStatement(CStatement cstatementxx)
  { if (cstatementxx == null) { return; }
   cstatements.remove(cstatementxx);
    Vector _1removedcodeCOperation = new Vector();
    Vector _1removedifPartIfStatement = new Vector();
    Vector _1removedbodyCLoopStatement = new Vector();
    Vector _1qrangecodeCOperation = new Vector();
    _1qrangecodeCOperation.addAll(coperations);
    for (int _i = 0; _i < _1qrangecodeCOperation.size(); _i++)
    { COperation coperationx = (COperation) _1qrangecodeCOperation.get(_i);
      if (coperationx != null && cstatementxx.equals(coperationx.getcode()))
      { _1removedcodeCOperation.add(coperationx);
        coperationx.setcode(null);
      }
    }
    Vector _1qrangeifPartIfStatement = new Vector();
    _1qrangeifPartIfStatement.addAll(ifstatements);
    for (int _i = 0; _i < _1qrangeifPartIfStatement.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) _1qrangeifPartIfStatement.get(_i);
      if (ifstatementx != null && cstatementxx.equals(ifstatementx.getifPart()))
      { _1removedifPartIfStatement.add(ifstatementx);
        ifstatementx.setifPart(null);
      }
    }
    Vector _1qrangeelsePartIfStatement = new Vector();
    _1qrangeelsePartIfStatement.addAll(ifstatements);
    for (int _i = 0; _i < _1qrangeelsePartIfStatement.size(); _i++)
    { IfStatement ifstatementx = (IfStatement) _1qrangeelsePartIfStatement.get(_i);
      if (ifstatementx != null && ifstatementx.getelsePart().contains(cstatementxx))
      { removeelsePart(ifstatementx,cstatementxx); }
    }
    Vector _1qrangestatementsCSequenceStatement = new Vector();
    _1qrangestatementsCSequenceStatement.addAll(csequencestatements);
    for (int _i = 0; _i < _1qrangestatementsCSequenceStatement.size(); _i++)
    { CSequenceStatement csequencestatementx = (CSequenceStatement) _1qrangestatementsCSequenceStatement.get(_i);
      if (csequencestatementx != null && csequencestatementx.getstatements().contains(cstatementxx))
      { removestatements(csequencestatementx,cstatementxx); }
    }
    Vector _1qrangebodyCLoopStatement = new Vector();
    _1qrangebodyCLoopStatement.addAll(cloopstatements);
    for (int _i = 0; _i < _1qrangebodyCLoopStatement.size(); _i++)
    { CLoopStatement cloopstatementx = (CLoopStatement) _1qrangebodyCLoopStatement.get(_i);
      if (cloopstatementx != null && cstatementxx.equals(cloopstatementx.getbody()))
      { _1removedbodyCLoopStatement.add(cloopstatementx);
        cloopstatementx.setbody(null);
      }
    }
    cstatementcstatIdindex.remove(cstatementxx.getcstatId());
    for (int _i = 0; _i < _1removedcodeCOperation.size(); _i++)
    { killCOperation((COperation) _1removedcodeCOperation.get(_i)); }
    for (int _i = 0; _i < _1removedifPartIfStatement.size(); _i++)
    { killIfStatement((IfStatement) _1removedifPartIfStatement.get(_i)); }
    for (int _i = 0; _i < _1removedbodyCLoopStatement.size(); _i++)
    { killAbstractCLoopStatement((CLoopStatement) _1removedbodyCLoopStatement.get(_i)); }
  }

  public void killAbstractCStatement(CStatement cstatementxx)
  {
    if (cstatementxx instanceof CReturnStatement)
    { killCReturnStatement((CReturnStatement) cstatementxx); }
    if (cstatementxx instanceof CBreakStatement)
    { killCBreakStatement((CBreakStatement) cstatementxx); }
    if (cstatementxx instanceof OpCallStatement)
    { killOpCallStatement((OpCallStatement) cstatementxx); }
    if (cstatementxx instanceof CSequenceStatement)
    { killCSequenceStatement((CSequenceStatement) cstatementxx); }
    if (cstatementxx instanceof IfStatement)
    { killIfStatement((IfStatement) cstatementxx); }
    if (cstatementxx instanceof CAssignment)
    { killCAssignment((CAssignment) cstatementxx); }
    if (cstatementxx instanceof DeclarationStatement)
    { killDeclarationStatement((DeclarationStatement) cstatementxx); }
    if (cstatementxx instanceof ForLoop)
    { killForLoop((ForLoop) cstatementxx); }
    if (cstatementxx instanceof WhileLoop)
    { killWhileLoop((WhileLoop) cstatementxx); }
  }

  public void killAbstractCStatement(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { CStatement _e = (CStatement) _l.get(_i);
      killAbstractCStatement(_e);
    }
  }



  public void killAllCReturnStatement(List creturnstatementxx)
  { for (int _i = 0; _i < creturnstatementxx.size(); _i++)
    { killCReturnStatement((CReturnStatement) creturnstatementxx.get(_i)); }
  }

  public void killCReturnStatement(CReturnStatement creturnstatementxx)
  { if (creturnstatementxx == null) { return; }
   creturnstatements.remove(creturnstatementxx);
  killCStatement(creturnstatementxx);
  }



  public void killAllCBreakStatement(List cbreakstatementxx)
  { for (int _i = 0; _i < cbreakstatementxx.size(); _i++)
    { killCBreakStatement((CBreakStatement) cbreakstatementxx.get(_i)); }
  }

  public void killCBreakStatement(CBreakStatement cbreakstatementxx)
  { if (cbreakstatementxx == null) { return; }
   cbreakstatements.remove(cbreakstatementxx);
  killCStatement(cbreakstatementxx);
  }



  public void killAllOpCallStatement(List opcallstatementxx)
  { for (int _i = 0; _i < opcallstatementxx.size(); _i++)
    { killOpCallStatement((OpCallStatement) opcallstatementxx.get(_i)); }
  }

  public void killOpCallStatement(OpCallStatement opcallstatementxx)
  { if (opcallstatementxx == null) { return; }
   opcallstatements.remove(opcallstatementxx);
  killCStatement(opcallstatementxx);
  }



  public void killAllCLoopStatement(List cloopstatementxx)
  { for (int _i = 0; _i < cloopstatementxx.size(); _i++)
    { killCLoopStatement((CLoopStatement) cloopstatementxx.get(_i)); }
  }

  public void killCLoopStatement(CLoopStatement cloopstatementxx)
  { if (cloopstatementxx == null) { return; }
   cloopstatements.remove(cloopstatementxx);
  killCStatement(cloopstatementxx);
  }

  public void killAbstractCLoopStatement(CLoopStatement cloopstatementxx)
  {
    if (cloopstatementxx instanceof ForLoop)
    { killForLoop((ForLoop) cloopstatementxx); }
    if (cloopstatementxx instanceof WhileLoop)
    { killWhileLoop((WhileLoop) cloopstatementxx); }
  }

  public void killAbstractCLoopStatement(List _l)
  { for (int _i = 0; _i < _l.size(); _i++)
    { CLoopStatement _e = (CLoopStatement) _l.get(_i);
      killAbstractCLoopStatement(_e);
    }
  }



  public void killAllForLoop(List forloopxx)
  { for (int _i = 0; _i < forloopxx.size(); _i++)
    { killForLoop((ForLoop) forloopxx.get(_i)); }
  }

  public void killForLoop(ForLoop forloopxx)
  { if (forloopxx == null) { return; }
   forloops.remove(forloopxx);
  killCLoopStatement(forloopxx);
  }



  public void killAllWhileLoop(List whileloopxx)
  { for (int _i = 0; _i < whileloopxx.size(); _i++)
    { killWhileLoop((WhileLoop) whileloopxx.get(_i)); }
  }

  public void killWhileLoop(WhileLoop whileloopxx)
  { if (whileloopxx == null) { return; }
   whileloops.remove(whileloopxx);
  killCLoopStatement(whileloopxx);
  }



  public void killAllCAssignment(List cassignmentxx)
  { for (int _i = 0; _i < cassignmentxx.size(); _i++)
    { killCAssignment((CAssignment) cassignmentxx.get(_i)); }
  }

  public void killCAssignment(CAssignment cassignmentxx)
  { if (cassignmentxx == null) { return; }
   cassignments.remove(cassignmentxx);
  killCStatement(cassignmentxx);
  }



  public void killAllCSequenceStatement(List csequencestatementxx)
  { for (int _i = 0; _i < csequencestatementxx.size(); _i++)
    { killCSequenceStatement((CSequenceStatement) csequencestatementxx.get(_i)); }
  }

  public void killCSequenceStatement(CSequenceStatement csequencestatementxx)
  { if (csequencestatementxx == null) { return; }
   csequencestatements.remove(csequencestatementxx);
    Vector _1removedincrementForLoop = new Vector();
    Vector _1qrangeincrementForLoop = new Vector();
    _1qrangeincrementForLoop.addAll(forloops);
    for (int _i = 0; _i < _1qrangeincrementForLoop.size(); _i++)
    { ForLoop forloopx = (ForLoop) _1qrangeincrementForLoop.get(_i);
      if (forloopx != null && csequencestatementxx.equals(forloopx.getincrement()))
      { _1removedincrementForLoop.add(forloopx);
        forloopx.setincrement(null);
      }
    }
    for (int _i = 0; _i < _1removedincrementForLoop.size(); _i++)
    { killForLoop((ForLoop) _1removedincrementForLoop.get(_i)); }
  killCStatement(csequencestatementxx);
  }



  public void killAllIfStatement(List ifstatementxx)
  { for (int _i = 0; _i < ifstatementxx.size(); _i++)
    { killIfStatement((IfStatement) ifstatementxx.get(_i)); }
  }

  public void killIfStatement(IfStatement ifstatementxx)
  { if (ifstatementxx == null) { return; }
   ifstatements.remove(ifstatementxx);
  killCStatement(ifstatementxx);
  }



  public void killAllDeclarationStatement(List declarationstatementxx)
  { for (int _i = 0; _i < declarationstatementxx.size(); _i++)
    { killDeclarationStatement((DeclarationStatement) declarationstatementxx.get(_i)); }
  }

  public void killDeclarationStatement(DeclarationStatement declarationstatementxx)
  { if (declarationstatementxx == null) { return; }
   declarationstatements.remove(declarationstatementxx);
  killCStatement(declarationstatementxx);
  }



  public void killAllPrintcode(List printcodexx)
  { for (int _i = 0; _i < printcodexx.size(); _i++)
    { killPrintcode((Printcode) printcodexx.get(_i)); }
  }

  public void killPrintcode(Printcode printcodexx)
  { if (printcodexx == null) { return; }
   printcodes.remove(printcodexx);
  }




  
  
  public void exp2C() 
  { 

    List _range56 = new Vector();
  _range56.addAll(Controller.inst().operations);
  for (int _i55 = 0; _i55 < _range56.size(); _i55++)
  { Operation loopvar$0 = (Operation) _range56.get(_i55);
       Controller.inst().exp2c1(loopvar$0);
  }
    List _range58 = new Vector();
  _range58.addAll(Controller.inst().usecases);
  for (int _i57 = 0; _i57 < _range58.size(); _i57++)
  { UseCase loopvar$1 = (UseCase) _range58.get(_i57);
       Controller.inst().exp2c2(loopvar$1);
  }
    List _range60 = new Vector();
  _range60.addAll(Controller.inst().coperations);
  for (int _i59 = 0; _i59 < _range60.size(); _i59++)
  { COperation loopvar$2 = (COperation) _range60.get(_i59);
       Controller.inst().exp2c3(loopvar$2);
  }
    List _range62 = new Vector();
  _range62.addAll(Controller.inst().coperations);
  for (int _i61 = 0; _i61 < _range62.size(); _i61++)
  { COperation loopvar$3 = (COperation) _range62.get(_i61);
       Controller.inst().exp2c4(loopvar$3);
  }
    List _range64 = new Vector();
  _range64.addAll(Controller.inst().coperations);
  for (int _i63 = 0; _i63 < _range64.size(); _i63++)
  { COperation loopvar$4 = (COperation) _range64.get(_i63);
       Controller.inst().exp2c5(loopvar$4);
  }
    List _range66 = new Vector();
  _range66.addAll(Controller.inst().cprograms);
  for (int _i65 = 0; _i65 < _range66.size(); _i65++)
  { CProgram loopvar$5 = (CProgram) _range66.get(_i65);
       Controller.inst().exp2c6(loopvar$5);
  }

  }



  
  public void printcode() 
  { 

    List _range68 = new Vector();
  _range68.addAll(Controller.inst().cprograms);
  for (int _i67 = 0; _i67 < _range68.size(); _i67++)
  { CProgram loopvar$6 = (CProgram) _range68.get(_i67);
       Controller.inst().printcode1(loopvar$6);
  }
    List _range70 = new Vector();
  _range70.addAll(Controller.inst().cstructs);
  for (int _i69 = 0; _i69 < _range70.size(); _i69++)
  { CStruct loopvar$7 = (CStruct) _range70.get(_i69);
       Controller.inst().printcode2(loopvar$7);
  }
    List _range72 = new Vector();
  _range72.addAll(Controller.inst().cstructs);
  for (int _i71 = 0; _i71 < _range72.size(); _i71++)
  { CStruct loopvar$8 = (CStruct) _range72.get(_i71);
       Controller.inst().printcode3(loopvar$8);
  }
    List _range74 = new Vector();
  _range74.addAll(Controller.inst().cstructs);
  for (int _i73 = 0; _i73 < _range74.size(); _i73++)
  { CStruct loopvar$9 = (CStruct) _range74.get(_i73);
       Controller.inst().printcode4(loopvar$9);
  }
    List _range76 = new Vector();
  _range76.addAll(Controller.inst().cstructs);
  for (int _i75 = 0; _i75 < _range76.size(); _i75++)
  { CStruct loopvar$10 = (CStruct) _range76.get(_i75);
       Controller.inst().printcode5outer(loopvar$10);
  }
    List _range78 = new Vector();
  _range78.addAll(Controller.inst().cstructs);
  for (int _i77 = 0; _i77 < _range78.size(); _i77++)
  { CStruct loopvar$11 = (CStruct) _range78.get(_i77);
       Controller.inst().printcode6outer(loopvar$11);
  }
    List _range80 = new Vector();
  _range80.addAll(Controller.inst().cstructs);
  for (int _i79 = 0; _i79 < _range80.size(); _i79++)
  { CStruct loopvar$12 = (CStruct) _range80.get(_i79);
       Controller.inst().printcode7outer(loopvar$12);
  }
    List _range82 = new Vector();
  _range82.addAll(Controller.inst().cstructs);
  for (int _i81 = 0; _i81 < _range82.size(); _i81++)
  { CStruct loopvar$13 = (CStruct) _range82.get(_i81);
       Controller.inst().printcode8outer(loopvar$13);
  }
    List _range84 = new Vector();
  _range84.addAll(Controller.inst().cstructs);
  for (int _i83 = 0; _i83 < _range84.size(); _i83++)
  { CStruct loopvar$14 = (CStruct) _range84.get(_i83);
       Controller.inst().printcode9outer(loopvar$14);
  }
    List _range86 = new Vector();
  _range86.addAll(Controller.inst().cstructs);
  for (int _i85 = 0; _i85 < _range86.size(); _i85++)
  { CStruct loopvar$15 = (CStruct) _range86.get(_i85);
       Controller.inst().printcode10outer(loopvar$15);
  }
    List _range88 = new Vector();
  _range88.addAll(Controller.inst().cstructs);
  for (int _i87 = 0; _i87 < _range88.size(); _i87++)
  { CStruct loopvar$16 = (CStruct) _range88.get(_i87);
       Controller.inst().printcode11outer(loopvar$16);
  }
    List _range90 = new Vector();
  _range90.addAll(Controller.inst().cstructs);
  for (int _i89 = 0; _i89 < _range90.size(); _i89++)
  { CStruct loopvar$17 = (CStruct) _range90.get(_i89);
       Controller.inst().printcode12(loopvar$17);
  }
    List _range92 = new Vector();
  _range92.addAll(Controller.inst().cstructs);
  for (int _i91 = 0; _i91 < _range92.size(); _i91++)
  { CStruct loopvar$18 = (CStruct) _range92.get(_i91);
       Controller.inst().printcode13outer(loopvar$18);
  }
    List _range94 = new Vector();
  _range94.addAll(Controller.inst().cstructs);
  for (int _i93 = 0; _i93 < _range94.size(); _i93++)
  { CStruct loopvar$19 = (CStruct) _range94.get(_i93);
       Controller.inst().printcode14(loopvar$19);
  }
    List _range96 = new Vector();
  _range96.addAll(Controller.inst().cstructs);
  for (int _i95 = 0; _i95 < _range96.size(); _i95++)
  { CStruct loopvar$20 = (CStruct) _range96.get(_i95);
       Controller.inst().printcode15(loopvar$20);
  }
    List _range98 = new Vector();
  _range98.addAll(Controller.inst().cstructs);
  for (int _i97 = 0; _i97 < _range98.size(); _i97++)
  { CStruct loopvar$21 = (CStruct) _range98.get(_i97);
       Controller.inst().printcode16(loopvar$21);
  }
    List _range100 = new Vector();
  _range100.addAll(Controller.inst().cstructs);
  for (int _i99 = 0; _i99 < _range100.size(); _i99++)
  { CStruct loopvar$22 = (CStruct) _range100.get(_i99);
       Controller.inst().printcode17(loopvar$22);
  }
    List _range102 = new Vector();
  _range102.addAll(Controller.inst().cstructs);
  for (int _i101 = 0; _i101 < _range102.size(); _i101++)
  { CStruct loopvar$23 = (CStruct) _range102.get(_i101);
       Controller.inst().printcode18(loopvar$23);
  }
    List _range104 = new Vector();
  _range104.addAll(Controller.inst().cstructs);
  for (int _i103 = 0; _i103 < _range104.size(); _i103++)
  { CStruct loopvar$24 = (CStruct) _range104.get(_i103);
       Controller.inst().printcode19(loopvar$24);
  }
    List _range106 = new Vector();
  _range106.addAll(Controller.inst().cstructs);
  for (int _i105 = 0; _i105 < _range106.size(); _i105++)
  { CStruct loopvar$25 = (CStruct) _range106.get(_i105);
       Controller.inst().printcode20(loopvar$25);
  }
    List _range108 = new Vector();
  _range108.addAll(Controller.inst().cstructs);
  for (int _i107 = 0; _i107 < _range108.size(); _i107++)
  { CStruct loopvar$26 = (CStruct) _range108.get(_i107);
       Controller.inst().printcode21(loopvar$26);
  }
    List _range110 = new Vector();
  _range110.addAll(Controller.inst().cstructs);
  for (int _i109 = 0; _i109 < _range110.size(); _i109++)
  { CStruct loopvar$27 = (CStruct) _range110.get(_i109);
       Controller.inst().printcode22(loopvar$27);
  }
    List _range112 = new Vector();
  _range112.addAll(Controller.inst().cstructs);
  for (int _i111 = 0; _i111 < _range112.size(); _i111++)
  { CStruct loopvar$28 = (CStruct) _range112.get(_i111);
       Controller.inst().printcode23(loopvar$28);
  }
    List _range114 = new Vector();
  _range114.addAll(Controller.inst().cstructs);
  for (int _i113 = 0; _i113 < _range114.size(); _i113++)
  { CStruct loopvar$29 = (CStruct) _range114.get(_i113);
       Controller.inst().printcode24(loopvar$29);
  }
    List _range116 = new Vector();
  _range116.addAll(Controller.inst().cstructs);
  for (int _i115 = 0; _i115 < _range116.size(); _i115++)
  { CStruct loopvar$30 = (CStruct) _range116.get(_i115);
       Controller.inst().printcode25(loopvar$30);
  }
    List _range118 = new Vector();
  _range118.addAll(Controller.inst().cstructs);
  for (int _i117 = 0; _i117 < _range118.size(); _i117++)
  { CStruct loopvar$31 = (CStruct) _range118.get(_i117);
       Controller.inst().printcode26(loopvar$31);
  }
    List _range120 = new Vector();
  _range120.addAll(Controller.inst().cstructs);
  for (int _i119 = 0; _i119 < _range120.size(); _i119++)
  { CStruct loopvar$32 = (CStruct) _range120.get(_i119);
       Controller.inst().printcode27(loopvar$32);
  }
    List _range122 = new Vector();
  _range122.addAll(Controller.inst().cstructs);
  for (int _i121 = 0; _i121 < _range122.size(); _i121++)
  { CStruct loopvar$33 = (CStruct) _range122.get(_i121);
       Controller.inst().printcode28(loopvar$33);
  }
    List _range124 = new Vector();
  _range124.addAll(Controller.inst().cstructs);
  for (int _i123 = 0; _i123 < _range124.size(); _i123++)
  { CStruct loopvar$34 = (CStruct) _range124.get(_i123);
       Controller.inst().printcode29(loopvar$34);
  }
    List _range126 = new Vector();
  _range126.addAll(Controller.inst().cstructs);
  for (int _i125 = 0; _i125 < _range126.size(); _i125++)
  { CStruct loopvar$35 = (CStruct) _range126.get(_i125);
       Controller.inst().printcode30(loopvar$35);
  }
    List _range128 = new Vector();
  _range128.addAll(Controller.inst().cstructs);
  for (int _i127 = 0; _i127 < _range128.size(); _i127++)
  { CStruct loopvar$36 = (CStruct) _range128.get(_i127);
       Controller.inst().printcode31(loopvar$36);
  }
    List _range130 = new Vector();
  _range130.addAll(Controller.inst().cstructs);
  for (int _i129 = 0; _i129 < _range130.size(); _i129++)
  { CStruct loopvar$37 = (CStruct) _range130.get(_i129);
       Controller.inst().printcode32(loopvar$37);
  }
    List _range132 = new Vector();
  _range132.addAll(Controller.inst().cstructs);
  for (int _i131 = 0; _i131 < _range132.size(); _i131++)
  { CStruct loopvar$38 = (CStruct) _range132.get(_i131);
       Controller.inst().printcode33(loopvar$38);
  }

  }

  public static void main(String[] args)
  { Controller c = Controller.inst();
    c.loadModel("cmodel.txt");  
    c.checkCompleteness(); 
 
    // Date d1 = new Date(); 
    // long t1 = d1.getTime(); 
 
    c.printcode(); 
    c.exp2C(); 

    /* Date d2 = new Date(); 
    long t2 = d2.getTime();
    System.out.println(t2 - t1); */ 
	
	System.out.println("/* Delete operations for empty structs. Currently, sequences & sets of "); 
	System.out.println("   basic values (numerics, booleans) are not supported. Maps must have ");
	System.out.println("   String domain type.                                               */"); 
	
 
  }  

 
}



