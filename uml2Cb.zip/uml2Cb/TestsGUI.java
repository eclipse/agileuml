package uml2Cb;


import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.io.*;
import java.util.StringTokenizer;

public class TestsGUI extends JFrame implements ActionListener
{ JPanel panel = new JPanel();
  JPanel tPanel = new JPanel();
  JPanel cPanel = new JPanel();
  Controller cont = Controller.inst();
    JButton loadModelButton = new JButton("loadModel");
    JButton saveModelButton = new JButton("saveModel");
    JButton loadXmiButton = new JButton("loadXmi");
    JButton loadCSVButton = new JButton("loadCSVs");
    JButton saveCSVButton = new JButton("saveCSVs");
    JButton exp2CButton = new JButton("exp2C");
    JButton printcodeButton = new JButton("printcode");

 public TestsGUI()
  { super("Select use case to test");
    panel.setLayout(new BorderLayout());
    panel.add(tPanel, BorderLayout.NORTH);
    panel.add(cPanel, BorderLayout.CENTER);
    setContentPane(panel);
    addWindowListener(new WindowAdapter() 
    { public void windowClosing(WindowEvent e)
      { System.exit(0); } });
    tPanel.add(loadModelButton);
    loadModelButton.addActionListener(this);
    tPanel.add(saveModelButton);
    saveModelButton.addActionListener(this);
    tPanel.add(loadXmiButton);
    loadXmiButton.addActionListener(this);
    tPanel.add(loadCSVButton);
    loadCSVButton.addActionListener(this);
    tPanel.add(saveCSVButton);
    saveCSVButton.addActionListener(this);
    cPanel.add(exp2CButton);
    exp2CButton.addActionListener(this);
    cPanel.add(printcodeButton);
    printcodeButton.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e)
  { if (e == null) { return; }
    String cmd = e.getActionCommand();
    if ("loadModel".equals(cmd))
    { Controller.loadModel("in.txt");
      cont.checkCompleteness();
      System.err.println("Model loaded");
      return; } 
    if ("saveModel".equals(cmd))
    { cont.saveModel("out.txt");  
      cont.saveXSI("xsi.txt"); 
      return; } 
    if ("loadXmi".equals(cmd))
    { cont.loadXSI();  
      cont.checkCompleteness();
      System.err.println("Model loaded");
      return; } 
    if ("loadCSVs".equals(cmd))
    { Controller.loadCSVModel();
      System.err.println("Model loaded");
      return; } 
    if ("saveCSVs".equals(cmd))
    { cont.saveCSVModel();  
      return; } 
    int[] intTestValues = {0, -1, 1, 2147483647, -2147483648};
    long[] longTestValues = {0, -1, 1, 9223372036854775807L, -9223372036854775808L};
    double[] doubleTestValues = {0, -1, 1, 1.7976931348623157E308, 4.9E-324};
    boolean[] booleanTestValues = {false, true};
    String[] stringTestValues = {"", " abc_XZ ", "#�$* &~@'"};
    if ("exp2C".equals(cmd))
    {       System.out.println();
      System.out.print(">>> Test: " + "");
      try {  cont.exp2C();
      }
      catch(Exception _e) { System.out.println(" !! Exception occurred: test failed !! "); }

      System.out.println();
      System.out.println();

      return;
    } 
    if ("printcode".equals(cmd))
    {       System.out.println();
      System.out.print(">>> Test: " + "");
      try {  cont.printcode();
      }
      catch(Exception _e) { System.out.println(" !! Exception occurred: test failed !! "); }

      System.out.println();
      System.out.println();

      return;
    } 
  }

  public static void main(String[] args)
  { TestsGUI gui = new TestsGUI();
    gui.setSize(550,400);
    gui.setVisible(true);
  }
 }
