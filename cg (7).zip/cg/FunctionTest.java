
import java.util.*;
import java.util.Map;
import java.util.HashMap;


 
public class FunctionTest { static ArrayList<FunctionTest> FunctionTest_allInstances = new ArrayList<FunctionTest>();

  Evaluation<Double,Double> g = null;

  FunctionTest() { FunctionTest_allInstances.add(this); }

  static FunctionTest createFunctionTest() { FunctionTest result = new FunctionTest();
    return result; }


  public double findRoot(Evaluation<Double,Double> f)
  { g = f; 
    double result = 0;
    result = f.evaluate(0.5);
    return result;
  }


  public double testCall()
  {
    double result = 0;
    result = findRoot((x) -> { return (x * x + x + 1); });
    return result;
  }

 public static void main(String[] args) 
 { FunctionTest ft = new FunctionTest(); 
   System.out.println(ft.testCall()); 
   System.out.println(ft.g.evaluate(1.0)); 
 }

 
}



