This is an example app development for a share analysis system, which connects to yahoo finance and extracts a series of prices (in this case, GBP to US$ rates) from a given date. 

Specify dates in the format 2019-06-19, etc. 

For iOS you will need to run 

pod init 

in your Xcode directory, and copy the contents of the supplied podfile into the created podfile, then run 

pod install 

to get the Charts package. 

