This example shows the specification (app5mm.txt) and the implementation of a simple Bond analysis app using an on-device database. 

For iOS you will need to set up the database with a pathname appropriate for your settup. 

