
/* C header for OclIterator library component */
/* Requires ocl.h                             */ 


struct OclIterator {
  void** elements; 
  int position;
  int size;  
};

struct OclIterator* newOclIterator_Sequence(void* col[])
{ struct OclIterator* iter = (struct OclIterator*) malloc(sizeof(struct OclIterator)); 
  iter->elements = col; 
  iter->size = length(col);
  iter->position = 0; 
  return iter; 
}

struct OclIterator* newOclIterator_Set(void* col[])
{ struct OclIterator* iter = (struct OclIterator*) malloc(sizeof(struct OclIterator)); 
  iter->elements = treesort(col, compareTo_OclAny); 
  iter->size = length(col);
  iter->position = 0; 
  return iter; 
}

struct OclIterator* newOclIterator_String(char* s)
{ struct OclIterator* iter = (struct OclIterator*) malloc(sizeof(struct OclIterator)); 
  iter->elements = split(s, " \n\t"); 
  iter->size = length(iter->elements);
  iter->position = 0; 
  return iter; 
}

struct OclIterator* newOclIterator_String_String(char* s, char* seps)
{ struct OclIterator* iter = (struct OclIterator*) malloc(sizeof(struct OclIterator)); 
  iter->elements = split(s, seps); 
  iter->size = length(iter->elements);
  iter->position = 0; 
  return iter; 
}


unsigned char hasNext_OclIterator(struct OclIterator* self)
{ if (self->position >= 0 && self->position < self->size)
  { return TRUE; }
  return FALSE; 
} 

unsigned char hasPrevious_OclIterator(struct OclIterator* self)
{ if (self->position > 1 && self->position <= self->size)
  { return TRUE; }
  return FALSE; 
} 

int nextIndex_OclIterator(struct OclIterator* self)
{ return self->position + 1; } 

int previousIndex_OclIterator(struct OclIterator* self)
{ return self->position - 1; } 

void moveForward_OclIterator(struct OclIterator* self)
{ if (self->position <= self->size)
  { self->position = self->position + 1; }
}

void moveBackward_OclIterator(struct OclIterator* self)
{ if (self->position >= 1)
  { self->position = self->position - 1; }
}

void moveTo_OclIterator(struct OclIterator* self, int i)
{ if (0 <= i && i <= self->size + 1)
  { self->position = i; }
}

void* getCurrent_OclIterator(struct OclIterator* self)
{ if (self->position >= 1 && self->position <= self->size)
  { return (self->elements)[self->position - 1]; }
  return NULL; 
}

void set_OclIterator(struct OclIterator* self, void* x)
{ if (self->position >= 1 && self->position <= self->size)
  { (self->elements)[self->position - 1] = x; }
}

void remove_OclIterator(struct OclIterator* self)
{ /* overwrite elements[position-1] by elements[position], etc */ 

  if (self->position < 1 || self->position > self->size)
  { return; }

  void** col = self->elements; 
  int n = self->size;
  int i = self->position-1; 
  for ( ; i < n-1; i++)
  { col[i] = col[i+1]; }
  col[i] = NULL;
  self->size = n - 1;
}

void insert_OclIterator(struct OclIterator* self, void* x)
{ /* store x in elements[position-1] and shuffle following elements along 1
     step. No reallocation needed if self->size < ALLOCATIONSIZE */ 

  if (self->position < 1 || self->position > self->size + 1)
  { return; }

  if (self->size + 1 >= ALLOCATIONSIZE) 
  { return; }

  void** col = self->elements; 
  int n = self->size;
  int i = n-1; 
  for ( ; i >= self->position - 1; i--)
  { col[i+1] = col[i]; }
  col[n+1] = NULL;
  col[self->position - 1] = x; 
  self->size = n + 1;
}

void* next_OclIterator(struct OclIterator* self)
{ if (self->position < self->size)
  { self->position = self->position + 1;
    return (self->elements)[self->position - 1]; 
  }
  return NULL; 
}

void* previous_OclIterator(struct OclIterator* self)
{ if (self->position > 1)
  { self->position = self->position - 1;
    return (self->elements)[self->position - 1]; 
  }
  return NULL; 
}

void* at_OclIterator(struct OclIterator* self, int i)
{ return (self->elements)[i-1]; }

int length_OclIterator(struct OclIterator* self)
{ return length(self->elements); } 


