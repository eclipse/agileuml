// cppUnitTests.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
// Controller.cc
#include <stdio.h>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <regex>
#include <thread>
#include <functional>
#include <cstdlib>
#include <condition_variable>
#include <sys/stat.h>
#include <direct.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <winhttp.h>
// #include <windows.h>


#pragma warning(disable : 4996)
#pragma comment(lib, "Ws2_32.lib")
#pragma comment(lib, "winhttp.lib")

#include "Controller.h"

using namespace std;




Controller* Controller::inst = new Controller();


map<string, OclType*>* OclType::ocltypenameindex = new map<string, OclType*>();



double MathLibrary::asinh(double x)
{
    double result = 0.0;
    result = log((x + sqrt((x * x + 1))));
    return result;
}


int MathLibrary::modInverse(int n, int p)
{
    int result = 0;
    if (0 >= n || n >= p) { return result; }

    { vector<int>* inverses = select_0(UmlRsdsLib<int>::integerSubrange(1, p - 1), n, p);
    if (inverses->size() > 0) { result = UmlRsdsLib<int>::min(inverses); }
    else { result = 0; }
    }
    return result;
}


double MathLibrary::asinh_mutant_0(double x)
{
    double result = 0.0;
    result = log((x + sqrt((x * x - 1))));
    return result;
}


double MathLibrary::asinh_mutant_1(double x)
{
    double result = 0.0;
    result = log((x + sqrt((x * x * 1))));
    return result;
}


double MathLibrary::asinh_mutant_2(double x)
{
    double result = 0.0;
    result = log((x - sqrt((x * x + 1))));
    return result;
}


double MathLibrary::asinh_mutant_3(double x)
{
    double result = 0.0;
    result = log((x * sqrt((x * x + 1))));
    return result;
}


int MathLibrary::modInverse_mutant_0(int n, int p)
{
    int result = 0;
    if (0 >= n || n >= p) { return result; }

    { vector<int>* inverses = select_1(UmlRsdsLib<int>::integerSubrange(1, p - 1), n, p);
    if (inverses->size() > 0) { result = UmlRsdsLib<int>::min(inverses); }
    else { result = 0; }
    }
    return result;
}


int MathLibrary::modInverse_mutant_1(int n, int p)
{
    int result = 0;
    if (0 >= n || n >= p) { return result; }

    { vector<int>* inverses = reject_2(UmlRsdsLib<int>::integerSubrange(1, p - 1), n, p);
    if (inverses->size() > 0) { result = UmlRsdsLib<int>::min(inverses); }
    else { result = 0; }
    }
    return result;
}


int MathLibrary::modInverse_mutant_2(int n, int p)
{
    int result = 0;
    if (0 >= n || n >= p) { return result; }

    { vector<int>* inverses = select_0(UmlRsdsLib<int>::integerSubrange(1, p - 1), n, p);
    if (inverses->size() > 0) { result = 0; }
    else { result = UmlRsdsLib<int>::min(inverses); }
    }
    return result;
}


void Controller::loadModel()
{
    ifstream infle("in.txt");
    if (infle.fail()) { cout << "No input file!" << endl; return; }
    string* str = new string("");
    vector<string>* res = new vector<string>();
    while (!infle.eof())
    {
        std::getline(infle, *str);
        vector<string>* words = UmlRsdsLib<string>::tokenise(res, *str);
        if (words->size() == 3 && (*words)[1] == ":")  // a : A
        {
            addObjectToClass((*words)[0], (*words)[2]);
        }
        else if (words->size() == 4 && (*words)[1] == ":") // a : b.role
        {
            addObjectToRole((*words)[2], (*words)[0], (*words)[3]);
        }
        else if (words->size() >= 4 && (*words)[2] == "=")  // a.f = val
        {
            int eqind = str->find("=");
            if (eqind < 0) { continue; }
            int f1ind = str->find_first_of("\"");
            int f2ind = str->find_last_of("\"");
            string value;
            if (f1ind != string::npos && f2ind != string::npos)
            {
                value = str->substr(f1ind, f2ind - f1ind + 1);
            }
            else if (words->size() == 4)
            {
                value = (*words)[3];
            }
            else if (words->size() == 5)
            {
                value = (*words)[3] + "." + (*words)[4];
            }
            setObjectFeatureValue((*words)[0], (*words)[1], value);
        }
        res->clear();
    }
}

void Controller::addObjectToClass(string a, string c)
{
    if (c == "MathLibrary")
    {
        MathLibrary* mathlibraryx = new MathLibrary();
        objectmap[a] = mathlibraryx;
        classmap[a] = c;
        addMathLibrary(mathlibraryx);
        return;
    }
}

void Controller::addObjectToRole(string a, string b, string role)
{ }

void Controller::setObjectFeatureValue(string a, string f, string val)
{ }


void Controller::saveModel(string f)
{
    ofstream outfile(f.c_str());
    for (int _i = 0; _i < mathlibrary_s->size(); _i++)
    {
        MathLibrary* mathlibraryx_ = (*mathlibrary_s)[_i];
        outfile << "mathlibraryx_" << (_i + 1) << " : MathLibrary" << endl;
    }


}


int MathLib::ix = 1001;

int MathLib::iy = 781;

int MathLib::iz = 913;

vector<string>* MathLib::hexdigit = UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequenceString(UmlRsdsLib<string>::addSequence((new vector<string>()), "0"), "1"), "2"), "3"), "4"), "5"), "6"), "7"), "8"), "9"), "A"), "B"), "C"), "D"), "E"), "F");


double MathLib::pi()
{
    double result = 0.0;
    result = 3.14159265;
    return result;
}


double MathLib::e()
{
    double result = 0.0;
    result = exp(1);
    return result;
}


void MathLib::setSeeds(int x, int y, int z)
{
    MathLib::setix(x);
    MathLib::setiy(y);
    MathLib::setiz(z);
}

double MathLib::nrandom()
{
    double result;
    MathLib::setix((MathLib::getix() * 171) % 30269);
    MathLib::setiy((MathLib::getiy() * 172) % 30307);
    MathLib::setiz((MathLib::getiz() * 170) % 30323);
    return ((MathLib::getix() / 30269.0) + (MathLib::getiy() / 30307.0) + (MathLib::getiz() / 30323.0));
}


double MathLib::random()
{
    double result = 0.0;
    double r = MathLib::nrandom();
    result = (r - ((int)floor(r)));
    return result;
}


long MathLib::combinatorial(int n, int m)
{
    long result = 0;
    if (n < m || m < 0) { return result; }
    if (n - m < m)
    {
        result = UmlRsdsLib<int>::prd(UmlRsdsLib<int>::integerSubrange(m + 1, n)) / UmlRsdsLib<int>::prd(UmlRsdsLib<int>::integerSubrange(1, n - m));
    }
    else if (n - m >= m)
    {
        result = UmlRsdsLib<int>::prd(UmlRsdsLib<int>::integerSubrange(n - m + 1, n)) / UmlRsdsLib<int>::prd(UmlRsdsLib<int>::integerSubrange(1, m));
    }
    return result;
}

long MathLib::factorial(int x)
{
    long result = 0;
    if (x < 2)
    {
        result = 1;
    }
    else if (x >= 2)
    {
        result = UmlRsdsLib<int>::prd(UmlRsdsLib<int>::integerSubrange(2, x));
    }
    return result;
}

double MathLib::asinh(double x)
{
    double result = 0.0;
    result = log((x + sqrt((x * x + 1))));
    return result;
}

double MathLib::acosh(double x)
{
    double result = 0.0;
    if (x < 1) { return result; }
    result = log((x + sqrt((x * x - 1))));
    return result;
}

double MathLib::atanh(double x)
{
    double result = 0.0;
    if (x == 1) { return result; }
    result = 0.5 * log(((1 + x) / (1 - x)));
    return result;
}

string MathLib::decimal2bits(long x)
{
    string result = "";
    if (x == 0) { result = ""; }
    else { result = MathLib::decimal2bits(x / 2).append(string("").append(std::to_string((x % 2)))); }
    return result;
}


string MathLib::decimal2binary(long x)
{
    string result = "";
    if (x < 0) { result = string("-").append(MathLib::decimal2bits(-x)); }
    else {
        if (x == 0) { result = "0"; }
        else { result = MathLib::decimal2bits(x); }
    }
    return result;
}


string MathLib::decimal2oct(long x)
{
    string result = "";
    if (x == 0) { result = ""; }
    else { result = MathLib::decimal2oct(x / 8).append(string("").append(std::to_string((x % 8)))); }
    return result;
}


string MathLib::decimal2octal(long x)
{
    string result = "";
    if (x < 0) { result = string("-").append(MathLib::decimal2oct(-x)); }
    else {
        if (x == 0) { result = "0"; }
        else { result = MathLib::decimal2oct(x); }
    }
    return result;
}


string MathLib::decimal2hx(long x)
{
    string result = "";
    if (x == 0) { result = ""; }
    else { result = MathLib::decimal2hx(x / 16).append((string("").append(((string)MathLib::gethexdigit()->at(((int)(x % 16)) + 1 - 1))))); }
    return result;
}


string MathLib::decimal2hex(long x)
{
    string result = "";
    if (x < 0) { result = string("-").append(MathLib::decimal2hx(-x)); }
    else {
        if (x == 0) { result = "0"; }
        else { result = MathLib::decimal2hx(x); }
    }
    return result;
}

int MathLib::bitwiseAnd(int x, int y)
{
    return x & y;
}

int MathLib::bitwiseOr(int x, int y)
{
    return x | y;
}

int MathLib::bitwiseXor(int x, int y)
{
    return x ^ y;
}

int MathLib::bitwiseNot(int x)
{
    return ~x;
}

long MathLib::bitwiseAnd(long x, long y)
{
    return x & y;
}

long MathLib::bitwiseOr(long x, long y)
{
    return x | y;
}

long MathLib::bitwiseXor(long x, long y)
{
    return x ^ y;
}

long MathLib::bitwiseNot(long x)
{
    return ~x;
}


vector<bool>* MathLib::toBitSequence(long x)
{
    vector<bool>* result;
    long x1;
    x1 = x;
    vector<bool>* res;
    res = (new vector<bool>());
    while (x1 > 0)
    {
        if (x1 % 2 == 0)
        {
            res = UmlRsdsLib<bool>::concatenate(UmlRsdsLib<bool>::makeSequence(false), res);
        }
        else
        {
            res = UmlRsdsLib<bool>::concatenate(UmlRsdsLib<bool>::makeSequence(true), res);
        }
        x1 = x1 / 2;
    }
    return res;
}

long MathLib::modInverse(long n, long p)
{
    long x = (n % p);
    for (int i = 1; i < p; i++)
    {
        if (((i * x) % p) == 1)
        {
            return i;
        }
    }
    return 0;
}

long MathLib::modPow(long n, long m, long p)
{
    long res = 1;
    long x = (n % p);
    for (int i = 1; i <= m; i++)
    {
        res = ((res * x) % p);
    }
    return res;
}

double MathLib::bisectionDiscrete(double r, double rl, double ru,
                                  vector<double>* values)
{
    double result = 0;
    result = 0;
    if ((r <= -1 || rl <= -1 || ru <= -1))
    {
        return result;
    }

    double v = 0;
    v = MathLib::netPresentValueDiscrete(r, values);
    if (ru - rl < 0.001)
    {
        return r;
    }
    if (v > 0)
    {
        return MathLib::bisectionDiscrete((ru + r) / 2, r, ru, values);
    }
    else if (v < 0)
    {
        return MathLib::bisectionDiscrete((r + rl) / 2, rl, r, values);
    }
    return r;
}


template< class K, class T>
T OrderedMap<K, T>::getByIndex(int i)
{
    T result = NULL;
    if (i > 0 && i <= elements->size())
    {
        result = ((T)(items)->at(((*elements)[i - 1])));
    }
    return result;
}


template< class K, class T>
T OrderedMap<K, T>::getByKey(K k)
{
    T result = NULL;
    result = ((T)(items)->at(k));
    return result;
}


template< class K, class T>
void OrderedMap<K, T>::add(K k, T t)
{
    OrderedMap* orderedmapx = this;
    elements = UmlRsdsLib<K>::concatenate(orderedmapx->getelements(), UmlRsdsLib<K>::makeSequence(k));
    items[k] = t;

}


template< class K, class T>
void OrderedMap<K, T>::remove(int i)
{
    OrderedMap* orderedmapx = this;
    K k = ((*elements)[i - 1]);

    elements = UmlRsdsLib<K>::removeAt(orderedmapx->getelements(), i);
    items = UmlRsdsOcl<K, T, T>::antirestrict(orderedmapx->getitems(), UmlRsdsLib<K>::addSet((new set<K>()), k));
}

string StringLib::format(string f, vector<void*>* sq)
{
    int n = sq->size();
    int flength = f.length();
    if (n == 0 || flength == 0)
    {
        return f;
    }

    const char* format = f.c_str();
    void* ap;
    char* p = (char*)format;
    int i = 0;

    char* sval;
    int ival;
    unsigned int uval;
    double dval;

    ostringstream buff;
    ap = sq->at(0);

    for (; *p != '\0'; p++)
    {
        if (*p != '%')
        {
            buff << *p;
            continue;
        }

        char* tmp = (char*)calloc(flength + 1, sizeof(char));
        tmp[0] = '%';
        int k = 1;
        p++;

        while (*p != 'i' && *p != 'd' && *p != 'g' && *p != 'e' &&
            *p != 'o' && *p != 'x' && *p != 'X' && *p != 'E' &&
            *p != 'G' && *p != 's' && *p != '%' &&
            *p != 'u' && *p != 'c' && *p != 'f' && *p != 'p')
        {
            tmp[k] = *p;
            k++;
            p++;
        }  /* Now p points to flag after % */

        tmp[k] = *p;
        tmp[k + 1] = '\0';

        if (i >= n)
        {
            continue;
        }

        switch (*p)
        {
        case 'i':
            ival = *((int*)sq->at(i));
            i++;
            { char* ibuff0 = (char*)calloc(int(log10(abs(ival) + 1)) + 2, sizeof(char));
            sprintf(ibuff0, tmp, ival);
            buff << ibuff0;
            }
            break;
        case 'o':
        case 'x':
        case 'X':
        case 'u':
            uval = *((unsigned int*)sq->at(i));
            i++;
            { char* ubuff = (char*)calloc(int(log10(uval + 1)) + 2, sizeof(char));
            sprintf(ubuff, tmp, uval);
            buff << ubuff;
            }
            break;
        case 'c':
        case 'd':
            ival = *((int*)sq->at(i));

            i++;
            { char* ibuff1 = (char*)calloc(int(log10(abs(ival) + 1)) + 2, sizeof(char));
            sprintf(ibuff1, tmp, ival);
            buff << ibuff1;
            }
            break;
        case 'f':
        case 'e':
        case 'E':
        case 'g':
        case 'G':
            dval = *((double*)sq->at(i));
            i++;
            { char* dbuff = (char*)calloc(int(log10(fabs(dval) + 1)) + 2, sizeof(char));
            sprintf(dbuff, tmp, dval);
            buff << dbuff;
            }
            break;
        case 's':
            sval = ((char*)sq->at(i));

            i++;
            { // int sn = strlen(sval) + 1;
              // char sbuff[sn];
              // sprintf(sbuff, tmp, sval);
                buff << sval;
            }
            break;
        case 'p':
            i++;
            { char* pbuff = (char*)calloc(9, sizeof(char));
            sprintf(pbuff, tmp, sq->at(i));
            buff << pbuff;
            }
            break;
        default:
            buff << *p;
            break;
        }
    }
    string res = buff.str();

    return res;
}



void SustainabilityTest::op()
{
   SustainabilityTest* sustainabilitytestx = this;
   int addcount = 40000;

   int checkcount = 0;

   std::chrono::time_point<std::chrono::high_resolution_clock> t1 = std::chrono::high_resolution_clock::now();

   while (addcount > 0)
   {
      elems->push_back(addcount);
      addcount = addcount - 1;
   }

   std::chrono::time_point<std::chrono::high_resolution_clock> t2 = std::chrono::high_resolution_clock::now();
   cout << (t2 - t1) / 1ms << " for " << elems->size() << endl;

   // std::chrono::time_point<std::chrono::high_resolution_clock> t1 = std::chrono::high_resolution_clock::now();

   while (checkcount > 0)
   {
     bool b = UmlRsdsLib<int>::isIn(checkcount, elems);

     checkcount = checkcount - 1;
   }

   // std::chrono::time_point<std::chrono::high_resolution_clock> t2 = std::chrono::high_resolution_clock::now();
   // cout << (t2 - t1) / 1ms << " for " << elems->size() << endl;

}



int main(int argc, char* argv[])
{ // OclFile::newOclFile("System.in");
  // OclFile::newOclFile("System.out");
  // OclFile::newOclFile("System.err");

    OclType* intType = OclType::createOclType("int");
    intType->setname(typeid(1).name());
    OclType* longType = OclType::createOclType("long");
    longType->setname(typeid(0L).name());
    OclType* doubleType = OclType::createOclType("double");
    doubleType->setname(typeid(1.0).name());
    OclType* booleanType = OclType::createOclType("boolean");
    booleanType->setname(typeid(true).name());
    OclType* stringType = OclType::createOclType("String");
    stringType->setname(typeid(string("")).name());
    OclType* sequenceType = OclType::createOclType("Sequence");
    sequenceType->setname(typeid(vector<void*>()).name());
    OclType* setType = OclType::createOclType("Set");
    setType->setname(typeid(set<void*>()).name());
    OclType* voidType = OclType::createOclType("void");
    voidType->setname("void");
    OclType* oclanyType = OclType::createOclType("OclAny");
    oclanyType->setname("void *");
    OclType* oclfileType = OclType::createOclType("OclFile");
    oclfileType->setname("class OclFile *");

    OclType* mathlibraryType = OclType::createOclType("MathLibrary");
    mathlibraryType->setname("class MathLibrary *");
    OclOperation* asinh_MathLibraryOperation = new OclOperation();
    asinh_MathLibraryOperation->setname("asinh");
    mathlibraryType->addoperations(asinh_MathLibraryOperation);
    OclOperation* modInverse_MathLibraryOperation = new OclOperation();
    modInverse_MathLibraryOperation->setname("modInverse");
    mathlibraryType->addoperations(modInverse_MathLibraryOperation);
    OclOperation* asinh_mutant_0_MathLibraryOperation = new OclOperation();
    asinh_mutant_0_MathLibraryOperation->setname("asinh_mutant_0");
    mathlibraryType->addoperations(asinh_mutant_0_MathLibraryOperation);
    OclOperation* asinh_mutant_1_MathLibraryOperation = new OclOperation();
    asinh_mutant_1_MathLibraryOperation->setname("asinh_mutant_1");
    mathlibraryType->addoperations(asinh_mutant_1_MathLibraryOperation);
    OclOperation* asinh_mutant_2_MathLibraryOperation = new OclOperation();
    asinh_mutant_2_MathLibraryOperation->setname("asinh_mutant_2");
    mathlibraryType->addoperations(asinh_mutant_2_MathLibraryOperation);
    OclOperation* asinh_mutant_3_MathLibraryOperation = new OclOperation();
    asinh_mutant_3_MathLibraryOperation->setname("asinh_mutant_3");
    mathlibraryType->addoperations(asinh_mutant_3_MathLibraryOperation);
    OclOperation* modInverse_mutant_0_MathLibraryOperation = new OclOperation();
    modInverse_mutant_0_MathLibraryOperation->setname("modInverse_mutant_0");
    mathlibraryType->addoperations(modInverse_mutant_0_MathLibraryOperation);
    OclOperation* modInverse_mutant_1_MathLibraryOperation = new OclOperation();
    modInverse_mutant_1_MathLibraryOperation->setname("modInverse_mutant_1");
    mathlibraryType->addoperations(modInverse_mutant_1_MathLibraryOperation);
    OclOperation* modInverse_mutant_2_MathLibraryOperation = new OclOperation();
    modInverse_mutant_2_MathLibraryOperation->setname("modInverse_mutant_2");
    mathlibraryType->addoperations(modInverse_mutant_2_MathLibraryOperation);

    /* MathLibrary* mm = new MathLibrary(); 
    int _counts[100]; 
    int _totals[100]; 
    MutationTest::asinh_mutation_tests(mm, _counts, _totals); */ 

    /* 
    int _cnts[10] = { 0 };
    _cnts[5]++; 

    cout << _cnts[5] << endl; 


    TestsGUI* tt = new TestsGUI(); 
    tt->runTests(); 
    vector<double>* vv = new vector<double>(); 
    vv->push_back(-100); 
    vv->push_back(2.0); 
    vv->push_back(102.0); 

    cout << MathLib::discountDiscrete(100, 0.1, 5) << endl; 
    cout << MathLib::netPresentValueDiscrete(0.01, vv) << endl; 
    cout << MathLib::irrDiscrete(vv) << endl; */ 

    /* OclDate* dd = OclDate::newOclDate_String("2022/01/30 09:30:45"); 
    cout << dd->toString() << endl; 
    OclDate* nn = OclDate::newOclDate(); 
    cout << nn << endl; 
    
    cout << nn->toString() << endl;
    if (dd < nn)
    {
        cout << dd << " is smaller than " << nn << endl;
    }  

    cout << MathLib::truncateN(12.345, 2) << endl; 
    cout << MathLib::roundN(12.345, 2) << endl;

    cout << MathLib::lcm(12, 18) << endl; 
    cout << MathLib::isIntegerOverflow(345, 2) << endl;

    cout << MathLib::isIntegerOverflow(45, 2) << endl;
    
    vector<double>* vv = new vector<double>(); 
    vv->push_back(1); vv->push_back(3); vv->push_back(5); vv->push_back(10);

    cout << MathLib::mean(vv) << endl; 
    cout << MathLib::median(vv) << endl;
    cout << MathLib::variance(vv) << endl;
    cout << MathLib::standardDeviation(vv) << endl;

    cout << MathLib::bisectionAsc(0, -2, 2, [=](double x) -> double { return (2 - (x * x));  }, 0.001) << endl; 

    vector<vector<double>*>* m1 = new vector<vector<double>*>(); 
    vector<double>* row1 = new vector<double>(); 
    row1->push_back(1); row1->push_back(3);
    vector<double>* row2 = new vector<double>();
    row2->push_back(7); row2->push_back(5);
    m1->push_back(row1); m1->push_back(row2); 
    // [[1, 3], [7, 5]]
    // m2 = [[6, 8], [4, 2]]
    vector<vector<double>*>* m2 = new vector<vector<double>*>();
    vector<double>* row3 = new vector<double>();
    row3->push_back(6); row3->push_back(8);
    vector<double>* row4 = new vector<double>();
    row4->push_back(4); row4->push_back(2);
    m2->push_back(row3); m2->push_back(row4);
    vector<vector<double>*>* rr = MathLib::matrixMultiplication(m1, m2); 
    cout << rr->at(0)->at(0) << " " << rr->at(0)->at(1) << endl;
    cout << rr->at(1)->at(0) << " " << rr->at(1)->at(1) << endl;

    cout << StringLib::leftTrim("  a long string  ") << "|" << endl;
    cout << StringLib::rightTrim("  a long string  ") << "|" << endl;
    cout << StringLib::padLeftWithInto(" a long ", "*", 12) << "|" << endl;
    cout << StringLib::leftAlignInto(" a long ", 12) << "|" << endl;
    cout << StringLib::rightAlignInto(" a long ", 12) << "|" << endl; */ 


    /* std::set<string>* ssr = new std::set<string>(); 
    ssr->insert("aa"); ssr->insert("dd"); ssr->insert("bb"); 

    cout << UmlRsdsLib<string>::collectionToString(ssr) << endl; 

    cout << UmlRsdsLib<string>::excludingSubrange("a long string", 3, 6) << endl; */

    SustainabilityTest* tt = new SustainabilityTest(); 

    // long long t1 = UmlRsdsLib<long>::getTime(); 
    // std::chrono::time_point<std::chrono::high_resolution_clock> t1 = std::chrono::high_resolution_clock::now();
    tt->op(); 

    // long long t2 = UmlRsdsLib<long>::getTime();

    // std::chrono::time_point<std::chrono::high_resolution_clock> t2 = std::chrono::high_resolution_clock::now();
    // cout << (t2 - t1)/1ms << " for " << tt->getelems()->size() << endl;


    return 0;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
