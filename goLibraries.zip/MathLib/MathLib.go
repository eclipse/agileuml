package MathLib

import "math"

var ix int = 1001
var iy int = 781
var iz int = 913
var hexdigit = []string{"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"}

func SetSeeds(x int, y int, z int) { 
  ix = x
  iy = y
  iz = z
} 

func GetIx() int { 
  return ix
}

func Pi() float64 { 
  return 3.14159265
}

func E() float64 { 
  return math.Exp(1)
}

func nrandom() float64 {
  ix = ( ix * 171 ) % 30269 
  iy = ( iy * 172 ) % 30307 
  iz = ( iz * 170 ) % 30323 
  return float64(ix) / 30269.0 + float64(iy) / 30307.0 + float64(iz) / 30323.0
}

func Random() float64 {
  r := nrandom() 
  return r - math.Floor(r)
} 








