#include <stdio.h>
#include <windows.h>
#include <direct.h> 
#include <sys/stat.h>
#include <shlwapi.h>

/* C header for OclFile library */


struct OclFile {
  char* name; 
  FILE* actualFile; 
  int port; 
  long position; 
};

struct OclFile* newOclFile(char* nme)
{ struct OclFile* res = (struct OclFile*) malloc(sizeof(struct OclFile)); 
  res->name = nme;
  res->port = 0; 
  res->actualFile = NULL;
  res->position = 0L;   
  return res; 
}

struct OclFile* newOclFile_Read(struct OclFile* self)
{ if (strcmp("System.in",self->name) == 0)
  { self->actualFile = stdin; } 
  else 
  { self->actualFile = fopen(self->name, "r"); } 
  return self; 
} 

struct OclFile* newOclFile_Write(struct OclFile* self)
{ if (strcmp("System.out",self->name) == 0)
  { self->actualFile = stdout; } 
  else if (strcmp("System.err",self->name) == 0)
  { self->actualFile = stderr; }
  else 
  { self->actualFile = fopen(self->name, "w+"); } 
  return self; 
} 

struct OclFile* newOclFile_ReadB(struct OclFile* self)
{ if (strcmp("System.in",self->name) == 0)
  { self->actualFile = stdin; } 
  else 
  { self->actualFile = fopen(self->name, "rb"); } 
  return self; 
} 

struct OclFile* newOclFile_WriteB(struct OclFile* self)
{ if (strcmp("System.out",self->name) == 0)
  { self->actualFile = stdout; } 
  else if (strcmp("System.err",self->name) == 0)
  { self->actualFile = stderr; }
  else 
  { self->actualFile = fopen(self->name, "wb+"); } 
  return self; 
} 

struct OclFile* newOclFile_Remote(char* nme, int port)
{ struct OclFile* res = newOclFile(nme); 
  res->port = port; 
  return res; 
} 

void openRead_OclFile(struct OclFile* self)
{ if (strcmp("System.in",self->name) == 0)
  { self->actualFile = stdin; } 
  else 
  { self->actualFile = fopen(self->name, "r"); } 
} 

void openWrite_OclFile(struct OclFile* self)
{ if (strcmp("System.out",self->name) == 0)
  { self->actualFile = stdout; } 
  else if (strcmp("System.err",self->name) == 0)
  { self->actualFile = stderr; }
  else 
  { self->actualFile = fopen(self->name, "w+"); } 
} 

void openReadB_OclFile(struct OclFile* self)
{ if (strcmp("System.in",self->name) == 0)
  { self->actualFile = stdin; } 
  else 
  { self->actualFile = fopen(self->name, "rb"); } 
} 

void openWriteB(struct OclFile* self)
{ if (strcmp("System.out",self->name) == 0)
  { self->actualFile = stdout; } 
  else if (strcmp("System.err",self->name) == 0)
  { self->actualFile = stderr; }
  else 
  { self->actualFile = fopen(self->name, "wb+"); }  
} 

long length_OclFile(struct OclFile* self)
{ struct stat stbuf; 
  stat(self->name, &stbuf); 
  return (long) stbuf.st_size; 
}  


void closeFile_OclFile(struct OclFile* self)
{ fclose(self->actualFile); } 

char* read_OclFile(struct OclFile* self)
{ if (self->actualFile == NULL) 
  { return NULL; }
  int ch = fgetc(self->actualFile); 
  if (ch == EOF)
  { return NULL; } 
  return byte2char(ch); 
} 

struct OclFile* getInputStream_OclFile(struct OclFile* self)
{ if (self->actualFile != NULL)
  { return self; }
  return NULL; 
}

struct OclFile* getOutputStream_OclFile(struct OclFile* self)
{ if (self->actualFile != NULL)
  { return self; }
  return NULL; 
}

unsigned char canRead_OclFile(struct OclFile* self)
{ if (self->actualFile == NULL)
  { return FALSE; }
  struct stat stbuf; 
  stat(self->name, &stbuf);
  if ((stbuf.st_mode & S_IREAD) == S_IREAD)
  { return TRUE; }
  return FALSE; 
} 

unsigned char canWrite_OclFile(struct OclFile* self)
{ if (self->actualFile == NULL)
  { return FALSE; }
  struct stat stbuf; 
  stat(self->name, &stbuf); 
   
  if ((stbuf.st_mode & S_IWRITE) == S_IWRITE)
  { return TRUE; }
  return FALSE; 
}

void write_OclFile(struct OclFile* self, char* s)
{ fprintf(self->actualFile, "%s", s); } 

void print_OclFile(struct OclFile* self, char* s)
{ if (strcmp("System.out",self->name) == 0)
  { printf("%s",s); } 
  else if (strcmp("System.err",self->name) == 0)
  { fprintf(stderr, "%s", s); } 
  else 
  { write_OclFile(self,s); } 
} 

char* readLine_OclFile(struct OclFile* self)
{ char* result = (char*) calloc(1024, sizeof(char));
  char* res = fgets(result, 1024, self->actualFile); 
  return res; 
} 

char* readAll_OclFile(struct OclFile* self)
{ if (self->actualFile == NULL) 
  { return NULL; }
  long sze = length_OclFile(self);
  char* result = (char*) calloc(sze+1, sizeof(char)); 
  int i = 0; 
  for ( ; i < sze; i++) 
  { int ch = fgetc(self->actualFile); 
    if (ch == EOF)
    { result[i] = '\0';
      return result; 
    } 
    result[i] = ch; 
  }
  result[i] = '\0';
  return result; 
}

void writeln_OclFile(struct OclFile* self, char* s)
{ fputs(s, self->actualFile);
  fputs("\n", self->actualFile);
}

void println_OclFile(struct OclFile* self, char* s)
{ if (strcmp("System.out",self->name) == 0)
  { printf("%s\n",s); } 
  else if (strcmp("System.err",self->name) == 0)
  { fprintf(stderr, "%s\n", s); } 
  else 
  { writeln_OclFile(self,s); } 
} 

void printf_OclFile(struct OclFile* self, char* f, void* sq[])
{ /* use va_list, vfprintf */ }

char* getName_OclFile(struct OclFile* self)
{ return self->name; } 

char* getInetAddress_OclFile(struct OclFile* self)
{ return self->name; } 

char* getLocalAddress_OclFile(struct OclFile* self)
{ return self->name; } 

void setPort_OclFile(struct OclFile* self, int portNumber)
{ self->port = portNumber; }

int getPort_OclFile(struct OclFile* self)
{ return self->port; }  

int getLocalPort_OclFile(struct OclFile* self)
{ return self->port; }  

int compareTo_OclFile(struct OclFile* self, struct OclFile* f)
{ return strcmp(self->name, f->name); }

char** list_OclFile(struct OclFile* self)
{ char** res = newStringList(); 

  unsigned char currentdir[MAX_PATH]; 
  getcwd(currentdir, sizeof(currentdir)-1); 
  char* completePath = concatenateStrings(currentdir, "\\*.*"); 
  WIN32_FIND_DATA data; 
  HANDLE h; 

  h = FindFirstFile(completePath, &data); 

  if (h != INVALID_HANDLE_VALUE) 
  { res = appendString(res, data.cFileName); 
    while (FindNextFile(h,&data))
    { res = appendString(res, data.cFileName); }
    FindClose(h); 
  }  
  return res; 
}  

struct OclFile** listFiles_OclFile(struct OclFile* self)
{ char** names = list_OclFile(self); 
  int flen = length((void**) names); 
  struct OclFile** res = (struct OclFile**) calloc(flen+1, sizeof(struct OclFile*)); 
  int i = 0; 
  for ( ; i < flen; i++) 
  { char* nme = names[i]; 
    struct OclFile* fle = newOclFile(nme); 
    res[i] = fle; 
  }
  res[i] = NULL; 
  return res; 
}
 
unsigned char delete_OclFile(struct OclFile* self)
{ int flg = remove(self->name); 
  if (flg > 0)
  { return FALSE; } 
  self->actualFile = NULL; 
  return TRUE; 
} 

void flush_OclFile(struct OclFile* self)
{ fflush(self->actualFile); }

void mark_OclFile(struct OclFile* self)
{ self->position = ftell(self->actualFile); } 

void reset_OclFile(struct OclFile* self)
{ fseek(self->actualFile, self->position, SEEK_SET); } 

void skipBytes_OclFile(struct OclFile* self, int n) 
{ int i = 0;  
  for ( ; i < n; i++) 
  { int ch = fgetc(self->actualFile);
    if (ch == EOF)
    { return; } 
  } 
} 

unsigned char mkdir_OclFile(struct OclFile* self)
{ int res = mkdir(self->name); 
  if (res == 0)
  { return TRUE; } 
  return FALSE; 
}

unsigned char isDirectory_OclFile(struct OclFile* self)
{ struct stat stbuf; 
  stat(self->name, &stbuf); 
  if (S_ISDIR(stbuf.st_mode) == 0)
  { return FALSE; }
  return TRUE; 
} 

unsigned char isFile_OclFile(struct OclFile* self)
{ struct stat stbuf; 
  stat(self->name, &stbuf); 
  if (S_ISREG(stbuf.st_mode) == 0)
  { return FALSE; }
  return TRUE; 
} 

unsigned char exists_OclFile(struct OclFile* self)
{ return isDirectory_OclFile(self) ||
         isFile_OclFile(self); 
} 

unsigned char isHidden_OclFile(struct OclFile* self)
{ if (strlen(self->name) == 0)
  { return FALSE; } 
  if (strcmp(".", subString(self->name,1,1)) == 0)
  { return TRUE; } 
  return FALSE; 
}

unsigned char isAbsolute_OclFile(struct OclFile* self)
{ if (self == NULL) 
  { return FALSE; }
  if (self->name == NULL)
  { return FALSE; } 
  if (strlen(self->name) == 0)
  { return FALSE; } 
  if ((self->name)[0] == '\\')
  { return TRUE; } 
  if (strlen(self->name) > 1 &&
      (self->name)[1] == ':')
  { return TRUE; } 
  return FALSE; 
} 

char* getPath_OclFile(struct OclFile* self)
{ return self->name; }

char* getAbsolutePath_OclFile(struct OclFile* self)
{ if (isAbsolute_OclFile(self))
  { return self->name; } 

  unsigned char currentdir[MAX_PATH]; 
  getcwd(currentdir, sizeof(currentdir)-1); 
  char* completePath = concatenateStrings(currentdir, "\\"); 
  char* res = concatenateStrings(completePath, self->name); 
  return res; 
}

long long lastModified_OclFile(struct OclFile* self)
{ struct stat stbuf; 
  stat(self->name, &stbuf); 
  return stbuf.st_mtime; 
}  
