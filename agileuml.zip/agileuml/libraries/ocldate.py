from time import *

class OclDate: 
  def __init__(self,t = int(time())): 
    self.time = t

  def getTime(self) : 
    return self.time

  def setTime(self,t) : 
    self.time = t

  def dateAfter(self,other) : 
    return self.time > other.time

  def dateBefore(self,other) : 
    return self.time < other.time

  def getSystemTime() : 
    return int(time())

  def newOclDate(t = int(time())) : 
    d = OclDate(t)
    return d


# print(OclDate.getSystemTime())
# sleep(0.5)
# print(OclDate.getSystemTime())








