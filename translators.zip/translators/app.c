#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <regexp.h>
#include <errno.h>


#define TRUE 1
#define FALSE 0

#include "ocl.h"

#include "mathlib.h"

#include "ocltype.h"

#include "oclfile.h"
#include "ocldate.h"
#include "oclprocess.h"
#include "oclrandom.h"

#include "app.h"

struct DTest** dtest_instances = NULL;
int dtest_size = 0;

struct DTest** newDTestList()
{ return (struct DTest**) calloc(ALLOCATIONSIZE, sizeof(struct DTest*)); }

struct DTest** appendDTest(struct DTest* col[], struct DTest* ex)
   { struct DTest** result;
     int len = length((void**) col);
     if (len % ALLOCATIONSIZE == 0)
     { result = (struct DTest**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct DTest*));
       int i = 0;
       for ( ; i < len; i++) { result[i] = col[i]; }
     }
    else { result = col; }
    result[len] = ex;
    result[len+1] = NULL;
    return result;
  }

struct DTest* createDTest()
{ struct DTest* result = (struct DTest*) malloc(sizeof(struct DTest));
  dtest_instances = appendDTest(dtest_instances, result);
  dtest_size++;
  return result;
}

struct DTest** insertDTest(struct DTest* col[], struct DTest* self)
  { if (isIn((void*) self, (void**) col))
    { return col; }
    return appendDTest(col,self);
  }

  struct DTest** subrangeDTest(struct DTest** col, int i, int j)
  { int len = length((void**) col);
    if (i > j || j > len) { return NULL; }
    struct DTest** result = (struct DTest**) calloc(j - i + 2, sizeof(struct DTest*));
     int k = i-1;
     int l = 0;
     for ( ; k < j; k++, l++)
     { result[l] = col[k]; }
    result[l] = NULL;
    return result;
  }

  struct DTest** reverseDTest(struct DTest** col)
  { int n = length((void**) col);
    struct DTest** result = (struct DTest**) calloc(n+1, sizeof(struct DTest*));
    int i = 0;
    int x = n-1;
    for ( ; i < n; i++, x--)
    { result[i] = col[x]; }
    result[n] = NULL;
    return result;
  }

struct DTest** removeDTest(struct DTest* col[], struct DTest* ex)
{ int len = length((void**) col);
  struct DTest** result = (struct DTest**) calloc(len+1, sizeof(struct DTest*));
  int j = 0;
  int i = 0;
  for ( ; i < len; i++)
  { struct DTest* eobj = col[i];
    if (eobj == NULL)
    { result[j] = NULL;
      return result; 
    }
    if (eobj == ex) { }
    else
    { result[j] = eobj; j++; }
  }
  result[j] = NULL;
  return result;
}

struct DTest** removeAllDTest(struct DTest* col1[], struct DTest* col2[])
{ int n = length((void**) col1);
  struct DTest** result = (struct DTest**) calloc(n+1, sizeof(struct DTest*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { struct DTest* ex = col1[i];
    if (isIn((void*) ex, (void**) col2)) {}
    else 
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

struct DTest** frontDTest(struct DTest* col[])
{ int n = length((void**) col);
  return subrangeDTest(col, 1, n-1);
}

struct DTest** tailDTest(struct DTest* col[])
{ int n = length((void**) col);
  return subrangeDTest(col, 2, n);
}

void op_DTest(struct DTest* self)
{  char** dd = NULL;
  dd = newStringList();
  dd = appendString(dd, "aa");
  dd = prependString(dd, "bb");
  dd = prependString(dd, "cc");
  int i = 0;
  i = 0;
  while (i < length((void**) dd))
  {   displayString(last((void**) dd));
  dd = frontString(dd);
  i = (i + 1);
  }
}

void initialise_DTest(struct DTest* self)
{}

struct DTest* newDTest(void)
{  struct DTest* result = NULL;
  struct DTest* res = NULL;
  res = createDTest();
  initialise_DTest(res);
  return res;
}

void killDTest(struct DTest* dtest_x)
{  dtest_instances = removeDTest(dtest_instances, dtest_x);
  free(dtest_x);
}

int main(int _argc, char* _argv[])
{ return 0; }

