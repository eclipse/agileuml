import ocl
import math
import re
import copy

from oclfile import *
from ocltype import *
from ocldate import *
from oclprocess import *
from mathlib import *
from ocliterator import *
from enum import Enum

def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)

def displaySequence(x):
  print(x)

def displaySet(x):
  print(x)

def displayMap(x):
  print(x)


class FromJavaScript : 
  fromjavascript_instances = []
  fromjavascript_index = dict({})

  def __init__(self):
    self.p = None
    FromJavaScript.fromjavascript_instances.append(self)



  def newFromJavaScript() :
    result = None
    result = createFromJavaScript()
    result.p = None
    result.initialise()
    return result

  def initialise(self) :
    self.p = Person.newPerson("Jim", 33)

  def killFromJavaScript(fromjavascript_x) :
    fromjavascript_instances = ocl.excludingSet(fromjavascript_instances, fromjavascript_x)
    free(fromjavascript_x)

class Person : 
  person_instances = []
  person_index = dict({})

  def __init__(self):
    self.name = None
    self.age = None
    self.retirementAge = 0
    Person.person_instances.append(self)



  def newPerson(nme,ag) :
    result = None
    _res_ = None
    _res_ = createPerson()
    _res_.name = nme
    _res_.age = ag
    _res_.retirementAge = 70
    return _res_

  def killPerson(person_x) :
    person_instances = ocl.excludingSet(person_instances, person_x)
    free(person_x)

def createFromJavaScript():
  fromjavascript = FromJavaScript()
  return fromjavascript

def allInstances_FromJavaScript():
  return FromJavaScript.fromjavascript_instances


fromjavascript_OclType = createByPKOclType("FromJavaScript")
fromjavascript_OclType.instance = createFromJavaScript()
fromjavascript_OclType.actualMetatype = type(fromjavascript_OclType.instance)


def createPerson():
  person = Person()
  return person

def allInstances_Person():
  return Person.person_instances


person_OclType = createByPKOclType("Person")
person_OclType.instance = createPerson()
person_OclType.actualMetatype = type(person_OclType.instance)


