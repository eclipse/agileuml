#include "app.c"


int main(int _argc, char* _argv[])
{ struct OclType* intType = createOclType("int");
  struct OclType* stringType = createOclType("String");
  struct OclType* longType = createOclType("long");
  struct OclType* booleanType = createOclType("boolean");
  struct OclType* doubleType = createOclType("double");
  struct OclType* sequenceType = createOclType("Sequence");
  struct OclType* setType = createOclType("Set");
  struct OclType* functionType = createOclType("Function");
  struct OclType* mapType = createOclType("Map");
  struct OclType* voidType = createOclType("void");

  struct OclType* dtestType = createOclType("DTest");
  dtestType.creator = createDTest;
  struct OclOperation* dtest_op = createOclOperation();
  dtest_op->name = "op";
  dtest_op->type = getOclTypeByPK("void");
  addOclType_operations(dtestType, dtest_op);
  struct OclOperation* dtest_newDTest = createOclOperation();
  dtest_newDTest->name = "newDTest";
  dtest_newDTest->type = getOclTypeByPK("DTest");
  addOclType_operations(dtestType, dtest_newDTest);
  struct OclOperation* dtest_initialise = createOclOperation();
  dtest_initialise->name = "initialise";
  dtest_initialise->type = getOclTypeByPK("void");
  addOclType_operations(dtestType, dtest_initialise);

  createOclFile_Write("System.out");
  createOclFile_Write("System.err");
  createOclFile_Read("System.in");


  char** res = getFileLines("app.itf");
  int ncommands = length(res);
  int i = 0;
  printf("Available use cases are:\n");
  for ( ; i < ncommands; i++)
  { printf(res[i]); }
  printf("Enter the use case to execute as\n");
  printf("name arguments (separated by spaces)\n");
  printf("\n");
  char* cmd = (char*) malloc(1024*sizeof(char));
  char* rd = gets(cmd);
  while (strcmp(cmd,"-") != 0)
  { int j = 0;
    for ( ; j < ncommands; j++)
    { char** ctok = tokenise(res[j], isspace);
      char* uc = ctok[0];
      if (startsWith(cmd,uc))
      { char* format = buildFormat(ctok);
        int err = 0;
      }
    }
    printf("Next command, or - to end: \n");
    rd = gets(cmd);
  }
}
