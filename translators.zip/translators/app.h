struct DTest {
  char* id; 
};

struct DTest** appendDTest(struct DTest* col[], struct DTest* ex);

struct DTest* createDTest(void);

struct DTest** insertDTest(struct DTest* col[], struct DTest* self);

  struct DTest** subrangeDTest(struct DTest** col, int i, int j);
  struct DTest** reverseDTest(struct DTest* col[]);
struct DTest** removeDTest(struct DTest* col[], struct DTest* ex);
struct DTest** removeAllDTest(struct DTest* _col1[], struct DTest* _col2[]);

struct DTest** frontDTest(struct DTest* _col[]);

struct DTest** tailDTest(struct DTest* _col[]);

void op_DTest(struct DTest* self);

void initialise_DTest(struct DTest* self);

struct DTest* newDTest(void);

void killDTest(struct DTest* dtest_x);

/* Header code written to app.h                          */
/* Please note that empty structs are not valid in C,    */
/* Add a field to any such structs.       */
