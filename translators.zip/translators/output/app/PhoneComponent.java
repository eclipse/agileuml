package com.example.app;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.content.Context;
import android.telephony.TelephonyManager;

import static android.telephony.TelephonyManager.CALL_STATE_IDLE;
import static android.telephony.TelephonyManager.CALL_STATE_RINGING;

public class PhoneComponent
{ Context myContext = null;
  static PhoneComponent instance = null;

  public static PhoneComponent getInstance(Context context) 
  { if (instance == null) 
    { instance = new PhoneComponent(context); }
    return instance;
  }

   private PhoneComponent(Context context)
   { myContext = context; }

    public boolean hasPhoneFeature()
    { PackageManager man = myContext.getPackageManager();
      if (man.hasSystemFeature(PackageManager.FEATURE_TELEPHONY))
      { return true; }
      return false;
    }

    public String getCallState()
    { TelephonyManager tman = null;
      int cstate = tman.getCallState();
      if (cstate == CALL_STATE_IDLE)
      { return "IDLE"; }
      else if (cstate == CALL_STATE_RINGING)
      { return "RINGING"; }
      else { return "OFFHOOK"; }
    }


    public void makeCall(String number)
    { Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number));
      myContext.startActivity(callIntent);
    }
}
