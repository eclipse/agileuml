package com.example.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import java.util.ArrayList;
import android.graphics.Canvas;
import android.content.Context;

import com.example.app.R;

public class GraphFragment extends Fragment
{ private View root;
  private Context myContext;

  public static GraphFragment newInstance(Context context)
  { GraphFragment fragment = new GraphFragment();
    fragment.myContext = context;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.graph_fragment, container, false);
    GraphComponent graph = GraphComponent.getInstance();
    ImageView graphview = (ImageView) root.findViewById(R.id.graphdisplay);
    graphview.invalidate();
    graphview.refreshDrawableState();
    graphview.setImageDrawable(graph);
    FloatingActionButton fab = findViewById(R.id.fab);

    fab.setOnClickListener(new View.OnClickListener() {
      @Override
            public void onClick(View view) {
                GraphComponent gc = GraphComponent.getInstance();
                ImageView v = findViewById(R.id.graphdisplay);
                v.invalidate();
                v.refreshDrawableState();
                v.setImageDrawable(gc);
                gc.redraw();
             }
        });
    return root;
  }

  public void onAttach(Context c)
  { super.onAttach(c);
    GraphComponent graph = GraphComponent.getInstance();
    graph.redraw();
  }

  public void onResume()
  { super.onResume();
    GraphComponent graph = GraphComponent.getInstance();
    ImageView graphview = (ImageView) root.findViewById(R.id.graphdisplay);
    graphview.invalidate();
    graphview.refreshDrawableState();
    graphview.setImageDrawable(graph);
    graphview.refreshDrawableState();
    graph.redraw();
  }
}
