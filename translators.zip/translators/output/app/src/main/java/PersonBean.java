package com.example.app;

import java.util.Vector;

import android.content.Context;

public class PersonBean
{ Dbi dbi;
  private String name = "";
  private String age = "";
  private int iage = 0;
  private Vector errors = new Vector();

  public PersonBean(Context _c) { dbi = new Dbi(_c); }

  public void setname(String namex)
  { name = namex; }

  public void setage(String agex)
  { age = agex; }

  public void resetData()
  { name = "";
    age = "";
    }

  public String errors() { return errors.toString(); }

}

