package com.example.app10;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;

public class MediaComponent implements OnPreparedListener
{
    private MediaPlayer mplay;
    private static MediaComponent instance = null;

    private MediaComponent()
    { mplay = new MediaPlayer(); }

    public static MediaComponent getInstance()
    { if (instance == null)
      { instance = new MediaComponent(); }
      return instance;
    }

    public void playAudioAsync(String source)
    { mplay.setAudioStreamType(AudioManager.STREAM_MUSIC);
      try
      { mplay.setDataSource(source); }
      catch (Exception _e) { return; }
      mplay.setOnPreparedListener(this);
      mplay.prepareAsync();
    }

    public void onPrepared(MediaPlayer mp)
    { mp.start(); }

    public void stopPlay()
    { mplay.stop(); }

    public void finalize()
    { mplay.release(); }
}

