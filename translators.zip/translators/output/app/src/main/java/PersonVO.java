package com.example.myApp;

import java.util.List;
import java.util.ArrayList;

public class PersonVO
{ 
  private String name;
  private int age;

  public PersonVO() {}

  public PersonVO(String namex,int agex)
  {    name = namex;
   age = agex;
  }

  public String toString()
  { return ("name= " + name + "," + "age= " + age); }

  public static List<String> toStringList(List<PersonVO> list)
  { List<String> _res = new ArrayList<String>();
    for (int i = 0; i < list.size(); i++)
    { PersonVO _x = (PersonVO) list.get(i);
      _res.add(_x.toString()); 
    }
    return _res;
  }

  public String getname()
  { return name; }

  public int getage()
  { return age; }

  public void setname(String _x)
  { name = _x; }

  public void setage(int _x)
  { age = _x; }

}


