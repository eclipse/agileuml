package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class createPatientFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  PatientBean patientbean;
  EditText codeTextField;
  String codeData = "";
  EditText nameTextField;
  String nameData = "";
  EditText ageTextField;
  String ageData = "";
  Button okButton;
  Button cancelButton;


 public createPatientFragment() {}

  public static createPatientFragment newInstance(Context c)
  { createPatientFragment fragment = new createPatientFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.createpatient_layout, container, false);
    Bundle data = getArguments();
    codeTextField = (EditText) root.findViewById(R.id.createPatientcodeField);
    nameTextField = (EditText) root.findViewById(R.id.createPatientnameField);
    ageTextField = (EditText) root.findViewById(R.id.createPatientageField);
    patientbean = new PatientBean(myContext);
    okButton = root.findViewById(R.id.createPatientOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.createPatientCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.createPatientOK)
    { createPatientOK(_v); }
    else if (_v.getId() == R.id.createPatientCancel)
    { createPatientCancel(_v); }
  }

  public void createPatientOK(View _v) 
  { 
    codeData = codeTextField.getText() + "";
    patientbean.setcode(codeData);
    nameData = nameTextField.getText() + "";
    patientbean.setname(nameData);
    ageData = ageTextField.getText() + "";
    patientbean.setage(ageData);
    if (patientbean.iscreatePatienterror())
    { Log.w(getClass().getName(), patientbean.errors());
      Toast.makeText(myContext, "Errors: " + patientbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { patientbean.createPatient(); }
  }


  public void createPatientCancel(View _v)
  { patientbean.resetData();
    codeTextField.setText("");
    nameTextField.setText("");
    ageTextField.setText("");
  }
}
