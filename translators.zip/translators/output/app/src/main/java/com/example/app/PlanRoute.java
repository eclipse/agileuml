package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class PlanRoute { static ArrayList<PlanRoute> PlanRoute_allInstances = new ArrayList<PlanRoute>();

  PlanRoute() { PlanRoute_allInstances.add(this); }

  static PlanRoute createPlanRoute() { PlanRoute result = new PlanRoute();
    return result; }


  public double planRoute(ArrayList<String> lats, ArrayList<String> lngs)
  {
    double result = 0;
    return result;
  }

}

