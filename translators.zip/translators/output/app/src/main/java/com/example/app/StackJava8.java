package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class StackJava8 { static ArrayList<StackJava8> StackJava8_allInstances = new ArrayList<StackJava8>();

  StackJava8() { StackJava8_allInstances.add(this); }

  static StackJava8 createStackJava8() { StackJava8 result = new StackJava8();
    return result; }

  String stackjava8Id = ""; /* primary */
  static Map<String,StackJava8> StackJava8_index = new HashMap<String,StackJava8>();

  static StackJava8 createByPKStackJava8(String stackjava8Idx)
  { StackJava8 result = StackJava8.StackJava8_index.get(stackjava8Idx);
    if (result != null) { return result; }
    result = new StackJava8();
    StackJava8.StackJava8_index.put(stackjava8Idx,result);
    result.stackjava8Id = stackjava8Idx;
    return result; }

  static void killStackJava8(String stackjava8Idx)
  { StackJava8 rem = StackJava8_index.get(stackjava8Idx);
    if (rem == null) { return; }
    ArrayList<StackJava8> remd = new ArrayList<StackJava8>();
    remd.add(rem);
    StackJava8_index.remove(stackjava8Idx);
    StackJava8_allInstances.removeAll(remd);
  }


  public boolean stackop()
  {
    boolean result = false;
    ArrayList st = new ArrayList();
    st = (new ArrayList());
    st = Ocl.append(st,"aa");
    st = Ocl.append(st,"bb");
    st = Ocl.append(st,"cc");
    String pp = "";
    pp = ((String) (Ocl.min(st)));
    int x = 0;
    x = ((st.contains("bb")) ? st.size() - (st.indexOf("bb") + 1) + 1 : -1);
    pp = ((String) (Ocl.last(st)));
    st = Ocl.front(st);
    return (st.size() == 0);
  }

}

