package com.example.app14.ui.main;

import java.util.Vector;

import android.content.Context;

public class RestaurantBean
{ ModelFacade model;
  private String name = "";
  private String website = "";
  private Vector errors = new Vector();

  public RestaurantBean(Context _c)
  { model = ModelFacade.getInstance(_c); }

  public void setname(String namex)
  { name = namex; }

  public void setwebsite(String websitex)
  { website = websitex; }

  public void resetData()
  { name = "";
    website = "";
    }

  public boolean iscreateRestauranterror()
  { errors.clear(); 
    return errors.size() > 0; }

  public String errors() { return errors.toString(); }

  public void createRestaurant()
  { model.createRestaurant(new RestaurantVO(name, website));
    resetData(); }

}

