package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.ImageView;
import android.widget.TextView;


public class loginFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  loginBean loginbean;

  EditText loginemailTextField;
  String loginemailData = "";
  EditText loginpasswordTextField;
  String loginpasswordData = "";
  Button loginOkButton;
  Button logincancelButton;


 public loginFragment() {}

  public static loginFragment newInstance(Context c)
  { loginFragment fragment = new loginFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.login_layout, container, false);
    Bundle data = getArguments();
    loginemailTextField = (EditText) root.findViewById(R.id.loginemailField);
    loginpasswordTextField = (EditText) root.findViewById(R.id.loginpasswordField);
    loginbean = new loginBean(myContext);
    loginOkButton = root.findViewById(R.id.loginOK);
    loginOkButton.setOnClickListener(this);
    logincancelButton = root.findViewById(R.id.loginCancel);
    logincancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.loginOK)
    { loginOK(_v); }
    else if (_v.getId() == R.id.loginCancel)
    { loginCancel(_v); }
  }

  public void loginOK(View _v) 
  { 
    loginemailData = loginemailTextField.getText() + "";
    loginbean.setemail(loginemailData);
    loginpasswordData = loginpasswordTextField.getText() + "";
    loginbean.setpassword(loginpasswordData);
    if (loginbean.isloginerror())
    { Log.w(getClass().getName(), loginbean.errors());
      Toast.makeText(myContext, "Errors: " + loginbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { loginbean.login(); }
  }


  public void loginCancel(View _v)
  { loginbean.resetData();
    loginemailTextField.setText("");
    loginpasswordTextField.setText("");
  }
}
