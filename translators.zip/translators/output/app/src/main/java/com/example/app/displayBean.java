package com.example.app14.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class displayBean
{ ModelFacade model = null;

  private String name = "";
  private List errors = new ArrayList();

  public displayBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setname(String namex)
  { name = namex; }

  public void resetData()
  { name = "";
    }

  public boolean isdisplayerror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public WebDisplay display()
  { return model.display(name); }

}

