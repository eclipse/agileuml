package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Main { static ArrayList<Main> Main_allInstances = new ArrayList<Main>();

  Main() { Main_allInstances.add(this); }

  static Main createMain() { Main result = new Main();
    return result; }

  String mainId = ""; /* primary */
  static Map<String,Main> Main_index = new HashMap<String,Main>();

  static Main createByPKMain(String mainIdx)
  { Main result = Main.Main_index.get(mainIdx);
    if (result != null) { return result; }
    result = new Main();
    Main.Main_index.put(mainIdx,result);
    result.mainId = mainIdx;
    return result; }

  static void killMain(String mainIdx)
  { Main rem = Main_index.get(mainIdx);
    if (rem == null) { return; }
    ArrayList<Main> remd = new ArrayList<Main>();
    remd.add(rem);
    Main_index.remove(mainIdx);
    Main_allInstances.removeAll(remd);
  }


  public static void main(ArrayList<String> args)
  {
    RunTest r1 = null;
    r1 = RunTest.newRunTest("1");
    RunTest r2 = null;
    r2 = RunTest.newRunTest("2");
    OclProcess t1 = null;
    t1 = OclProcess.newOclProcess(r1, "Thread-1635765125381");
    OclProcess t2 = null;
    t2 = OclProcess.newOclProcess(r2, "Thread-1635765125382");
    t1.start();
    t2.start();
  }


  public static Main newMain()
  {
    Main result = null;
    result = Main.createMain();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

