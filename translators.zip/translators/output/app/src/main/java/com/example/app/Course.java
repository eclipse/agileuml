package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Course
{ init() { }

  var code : String = "" /* principal key */

  static var Course_index : Dictionary<String,Course> = [String:Course]()

  static func getByPKCourse(index : String) -> Course?
  { return Course_index[index] }

}

