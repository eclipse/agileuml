package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Sup { static ArrayList<Sup> Sup_allInstances = new ArrayList<Sup>();

  Sup() { Sup_allInstances.add(this); }

  static Sup createSup() { Sup result = new Sup();
    return result; }

  String name = "";
  String supId = ""; /* primary */
  static Map<String,Sup> Sup_index = new HashMap<String,Sup>();

  static Sup createByPKSup(String supIdx)
  { Sup result = Sup.Sup_index.get(supIdx);
    if (result != null) { return result; }
    result = new Sup();
    Sup.Sup_index.put(supIdx,result);
    result.supId = supIdx;
    return result; }

  static void killSup(String supIdx)
  { Sup rem = Sup_index.get(supIdx);
    if (rem == null) { return; }
    ArrayList<Sup> remd = new ArrayList<Sup>();
    remd.add(rem);
    Sup_index.remove(supIdx);
    Sup_allInstances.removeAll(remd);
  }


  public static Sup newSup()
  {
    Sup result = null;
    result = Sup.createSup();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

