package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class CorrelationCalculator { static ArrayList<CorrelationCalculator> CorrelationCalculator_allInstances = new ArrayList<CorrelationCalculator>();

  CorrelationCalculator() { CorrelationCalculator_allInstances.add(this); }

  static CorrelationCalculator createCorrelationCalculator() { CorrelationCalculator result = new CorrelationCalculator();
    return result; }

  double meanx = 0.0;
  double meany = 0.0;
  double sumprods = 0.0;
  double sumdiffxsq = 0.0;
  double sumdiffysq = 0.0;
  double correlation = 0.0;
  ArrayList<DataPoint> datapoints = (new ArrayList());
  String correlationcalculatorId = ""; /* primary */
  static Map<String,CorrelationCalculator> CorrelationCalculator_index = new HashMap<String,CorrelationCalculator>();

  static CorrelationCalculator createByPKCorrelationCalculator(String correlationcalculatorIdx)
  { CorrelationCalculator result = CorrelationCalculator.CorrelationCalculator_index.get(correlationcalculatorIdx);
    if (result != null) { return result; }
    result = new CorrelationCalculator();
    CorrelationCalculator.CorrelationCalculator_index.put(correlationcalculatorIdx,result);
    result.correlationcalculatorId = correlationcalculatorIdx;
    return result; }

  static void killCorrelationCalculator(String correlationcalculatorIdx)
  { CorrelationCalculator rem = CorrelationCalculator_index.get(correlationcalculatorIdx);
    if (rem == null) { return; }
    ArrayList<CorrelationCalculator> remd = new ArrayList<CorrelationCalculator>();
    remd.add(rem);
    CorrelationCalculator_index.remove(correlationcalculatorIdx);
    CorrelationCalculator_allInstances.removeAll(remd);
  }


  public void calc()
  {
    meanx = Ocl.sumdouble(Ocl.collectSequence(datapoints, (var1) -> { return var1.x; })) / datapoints.size();
    meany = Ocl.sumdouble(Ocl.collectSequence(datapoints, (var2) -> { return var2.y; })) / datapoints.size();
    for (DataPoint d : datapoints)
    {
      d.prodxy = (d.x - meanx) * (d.y - meany);
    d.diffxsq = (d.x - meanx) * (d.x - meanx);
    d.diffysq = (d.y - meany) * (d.y - meany);
    }
    sumprods = Ocl.sumdouble(Ocl.collectSequence(datapoints, (var6) -> { return var6.prodxy; }));
    sumdiffxsq = Ocl.sumdouble(Ocl.collectSequence(datapoints, (var7) -> { return var7.diffxsq; }));
    sumdiffysq = Ocl.sumdouble(Ocl.collectSequence(datapoints, (var8) -> { return var8.diffysq; }));
    if ((sumdiffxsq > 0 && sumdiffysq > 0))
    {
      correlation = sumprods / Math.sqrt((sumdiffxsq * sumdiffysq));
    }
    else {
      {}
    }
  }


  public static CorrelationCalculator newCorrelationCalculator()
  {
    CorrelationCalculator result = null;
    result = CorrelationCalculator.createCorrelationCalculator();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

