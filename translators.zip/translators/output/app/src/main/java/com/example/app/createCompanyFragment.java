package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class createCompanyFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  CompanyBean companybean;
  EditText idTextField;
  String idData = "";
  EditText companyIdTextField;
  String companyIdData = "";
  Button okButton;
  Button cancelButton;


 public createCompanyFragment() {}

  public static createCompanyFragment newInstance(Context c)
  { createCompanyFragment fragment = new createCompanyFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.createcompany_layout, container, false);
    Bundle data = getArguments();
    idTextField = (EditText) root.findViewById(R.id.createCompanyidField);
    companyIdTextField = (EditText) root.findViewById(R.id.createCompanycompanyIdField);
    companybean = new CompanyBean(myContext);
    okButton = root.findViewById(R.id.createCompanyOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.createCompanyCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.createCompanyOK)
    { createCompanyOK(_v); }
    else if (_v.getId() == R.id.createCompanyCancel)
    { createCompanyCancel(_v); }
  }

  public void createCompanyOK(View _v) 
  { 
    idData = idTextField.getText() + "";
    companybean.setid(idData);
    companyIdData = companyIdTextField.getText() + "";
    companybean.setcompanyId(companyIdData);
    if (companybean.iscreateCompanyerror())
    { Log.w(getClass().getName(), companybean.errors());
      Toast.makeText(myContext, "Errors: " + companybean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { companybean.createCompany(); }
  }


  public void createCompanyCancel(View _v)
  { companybean.resetData();
    idTextField.setText("");
    companyIdTextField.setText("");
  }
}
