package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class NewCompany { static ArrayList<NewCompany> NewCompany_allInstances = new ArrayList<NewCompany>();

  NewCompany() { NewCompany_allInstances.add(this); }

  static NewCompany createNewCompany() { NewCompany result = new NewCompany();
    return result; }


  public void newCompany(String iden)
  {
  }

}

