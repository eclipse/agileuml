package com.example.app.ui.main;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.app.R;
import com.example.app.ui.main.listStudentFragment.OnListFragmentInteractionListener;
import java.util.List;

public class StudentRecyclerViewAdapter extends RecyclerView.Adapter<StudentRecyclerViewAdapter.ViewHolder>
{ private final List<StudentVO> mValues;
  private final OnListFragmentInteractionListener mListener;

  public StudentRecyclerViewAdapter(List<StudentVO> items, OnListFragmentInteractionListener listener)
  { mValues = items;
    mListener = listener;
  }

  @Override
  public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
  { View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_student, parent, false);
    return new ViewHolder(view);
  }
  
  @Override
  public void onBindViewHolder(final ViewHolder holder, int position)
  { holder.mItem = mValues.get(position);
  holder.listStudentidView.setText(" " +  mValues.get(position).id + " ");
  holder.listStudentnameView.setText(" " +  mValues.get(position).name + " ");
  holder.listStudentageView.setText(" " +  mValues.get(position).age + " ");
 
  holder.mView.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        if (null != mListener)
        { mListener.onListFragmentInteraction(holder.mItem); }
   }
     });
   }
  
  @Override
  public int getItemCount()
  { return mValues.size(); }
   
  public class ViewHolder extends RecyclerView.ViewHolder 
  { public final View mView;
    public final TextView listStudentidView;
    public final TextView listStudentnameView;
    public final TextView listStudentageView;
    public StudentVO mItem;

    public ViewHolder(View view)
    { super(view);
       mView = view;
     listStudentidView = (TextView) view.findViewById(R.id.listStudentidView);
     listStudentnameView = (TextView) view.findViewById(R.id.listStudentnameView);
     listStudentageView = (TextView) view.findViewById(R.id.listStudentageView);
    }

     @Override
     public String toString() 
     { return super.toString() + " " + mItem; }
      
  }
}
