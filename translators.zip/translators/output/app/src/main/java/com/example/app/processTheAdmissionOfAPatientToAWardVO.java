package com.example.app.ui.main;

public class processTheAdmissionOfAPatientToAWardVO
{ 
 private Nurse nursex;

  public processTheAdmissionOfAPatientToAWardVO() {}

  public processTheAdmissionOfAPatientToAWardVO(Nurse nursexx)
  {    nursex = nursexx;
  }

  public Nurse getnursex()
  { return nursex; }

  public void setnursex(Nurse _x)
  { nursex = _x; }

}


