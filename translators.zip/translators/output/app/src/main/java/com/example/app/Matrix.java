package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Matrix { static ArrayList<Matrix> Matrix_allInstances = new ArrayList<Matrix>();

  Matrix() { Matrix_allInstances.add(this); }

  static Matrix createMatrix() { Matrix result = new Matrix();
    return result; }

   String matrixId = ""; /* primary */
  static Map< String,Matrix> Matrix_index = new HashMap< String,Matrix>();

  static Matrix createByPKMatrix( String matrixIdx)
  { Matrix result = Matrix.Matrix_index.get(matrixIdx);
    if (result != null) { return result; }
    result = new Matrix();
    Matrix.Matrix_index.put(matrixIdx,result);
    result.matrixId = matrixIdx;
    return result; }

  static void killMatrix( String matrixIdx)
  { Matrix rem = Matrix_index.get(matrixIdx);
    if (rem == null) { return; }
    ArrayList<Matrix> remd = new ArrayList<Matrix>();
    remd.add(rem);
    Matrix_index.remove(matrixIdx);
    Matrix_allInstances.removeAll(remd);
  }


  public static  double determinant2(ArrayList<ArrayList<Double>> m)
  {
     double result = 0.0;
     double a1 = 0.0;
    a1 = (( double) ((ArrayList<Double>) (m).get(1 - 1)).get(1 - 1));
     double a2 = 0.0;
    a2 = (( double) ((ArrayList<Double>) (m).get(1 - 1)).get(2 - 1));
     double b1 = 0.0;
    b1 = (( double) ((ArrayList<Double>) (m).get(2 - 1)).get(1 - 1));
     double b2 = 0.0;
    b2 = (( double) ((ArrayList<Double>) (m).get(2 - 1)).get(2 - 1));
    result = a1 * b2 - a2 * b1;
    return result;
  }


  public static  double detaux( double x1,  double y1,  double x2,  double y2)
  {
     double result = 0.0;
    result = x1 * y1 - x2 * y2;
    return result;
  }


  public static  double determinant3(ArrayList<ArrayList<Double>> m)
  {
     double result = 0.0;
    result = ((( double) ((ArrayList<Double>) (m).get(1 - 1)).get(1 - 1))) * Matrix.detaux((( double) ((ArrayList<Double>) (m).get(2 - 1)).get(2 - 1)), (( double) ((ArrayList<Double>) (m).get(3 - 1)).get(3 - 1)), (( double) ((ArrayList<Double>) (m).get(2 - 1)).get(3 - 1)), (( double) ((ArrayList<Double>) (m).get(3 - 1)).get(2 - 1))) - ((( double) ((ArrayList<Double>) (m).get(1 - 1)).get(2 - 1))) * Matrix.detaux((( double) ((ArrayList<Double>) (m).get(2 - 1)).get(1 - 1)), (( double) ((ArrayList<Double>) (m).get(3 - 1)).get(3 - 1)), (( double) ((ArrayList<Double>) (m).get(3 - 1)).get(1 - 1)), (( double) ((ArrayList<Double>) (m).get(2 - 1)).get(3 - 1))) + ((( double) ((ArrayList<Double>) (m).get(1 - 1)).get(3 - 1))) * Matrix.detaux((( double) ((ArrayList<Double>) (m).get(2 - 1)).get(1 - 1)), (( double) ((ArrayList<Double>) (m).get(3 - 1)).get(2 - 1)), (( double) ((ArrayList<Double>) (m).get(2 - 1)).get(2 - 1)), (( double) ((ArrayList<Double>) (m).get(3 - 1)).get(1 - 1)));
    return result;
  }


  public static  double lineqn3solution1(ArrayList<ArrayList<Double>> m,  double d,  double d1,  double d2,  double d3)
  {
     double result = 0.0;
    ArrayList<ArrayList<Double>> m1 = new ArrayList<ArrayList<Double>>();
    m1 = Ocl.initialiseSequence(Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(1 - 1)).get(2 - 1)),(( double) ((ArrayList<Double>) (m).get(1 - 1)).get(3 - 1)),d1),Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(2 - 1)).get(2 - 1)),(( double) ((ArrayList<Double>) (m).get(2 - 1)).get(3 - 1)),d2),Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(3 - 1)).get(2 - 1)),(( double) ((ArrayList<Double>) (m).get(3 - 1)).get(3 - 1)),d3));
    result = -Matrix.determinant3(m1) / d;
    return result;
  }


  public static  double lineqn3solution2(ArrayList<ArrayList<Double>> m,  double d,  double d1,  double d2,  double d3)
  {
     double result = 0.0;
    ArrayList<ArrayList<Double>> m1 = new ArrayList<ArrayList<Double>>();
    m1 = Ocl.initialiseSequence(Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(1 - 1)).get(1 - 1)),(( double) ((ArrayList<Double>) (m).get(1 - 1)).get(3 - 1)),d1),Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(2 - 1)).get(1 - 1)),(( double) ((ArrayList<Double>) (m).get(2 - 1)).get(3 - 1)),d2),Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(3 - 1)).get(1 - 1)),(( double) ((ArrayList<Double>) (m).get(3 - 1)).get(3 - 1)),d3));
    result = Matrix.determinant3(m1) / d;
    return result;
  }


  public static  double lineqn3solution3(ArrayList<ArrayList<Double>> m,  double d,  double d1,  double d2,  double d3)
  {
     double result = 0.0;
    ArrayList<ArrayList<Double>> m1 = new ArrayList<ArrayList<Double>>();
    m1 = Ocl.initialiseSequence(Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(1 - 1)).get(1 - 1)),(( double) ((ArrayList<Double>) (m).get(1 - 1)).get(2 - 1)),d1),Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(2 - 1)).get(1 - 1)),(( double) ((ArrayList<Double>) (m).get(2 - 1)).get(2 - 1)),d2),Ocl.initialiseSequence((( double) ((ArrayList<Double>) (m).get(3 - 1)).get(1 - 1)),(( double) ((ArrayList<Double>) (m).get(3 - 1)).get(2 - 1)),d3));
    result = -Matrix.determinant3(m1) / d;
    return result;
  }


  public static  double max(ArrayList<ArrayList<Double>> m)
  {
     double result = 0.0;
    result = Ocl.max(Ocl.collectSequence(m,(s)->{return Ocl.max(s);}));
    return result;
  }


  public static  double min(ArrayList<ArrayList<Double>> m)
  {
     double result = 0.0;
    result = Ocl.min(_l);
    return result;
  }


  public static ArrayList<ArrayList<Double>> matrixAdd(ArrayList<ArrayList<Double>> s,  double v)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Ocl.collectSequence(s,(sq)->{return Sequences.sequenceAdd(sq, v);});
    return result;
  }


  public static ArrayList<ArrayList<Double>> mmAdd(ArrayList<ArrayList<Double>> m1, ArrayList<ArrayList<Double>> m2)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Integer.subrange(1,m1.size)->collect( i | Sequences.ssAdd(m1[i],m2[i]) );
    return result;
  }


  public static ArrayList<ArrayList<Double>> matrixMult(ArrayList<ArrayList<Double>> s,  double v)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Ocl.collectSequence(s,(sq)->{return Sequences.sequenceMult(sq, v);});
    return result;
  }


  public static ArrayList<ArrayList<Double>> mmMult(ArrayList<ArrayList<Double>> m1, ArrayList<ArrayList<Double>> m2)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Integer.subrange(1,m1.size)->collect( i | Sequences.ssMult(m1[i],m2[i]) );
    return result;
  }


  public static ArrayList<Double> rowMult(ArrayList<Double> s, ArrayList<ArrayList<Double>> m)
  {
    ArrayList<Double> result = new ArrayList<Double>();
    result = Integer.subrange(1,s.size)->collect( i | Integer.Sum(1,m.size,k,s[k] * ( m[k]->at(i) )) );
    return result;
  }


  public static ArrayList<ArrayList<Double>> matrixProd(ArrayList<ArrayList<Double>> m1, ArrayList<ArrayList<Double>> m2)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Ocl.collectSequence(m1,(row)->{return Matrix.rowMult(row, m2);});
    return result;
  }


  public static ArrayList<ArrayList<Boolean>> mmEq(ArrayList<ArrayList<Double>> m1, ArrayList<ArrayList<Double>> m2)
  {
    ArrayList<ArrayList<Boolean>> result = new ArrayList<ArrayList<Boolean>>();
    result = Integer.subrange(1,m1.size)->collect( i | Sequences.ssEq(m1[i],m2[i]) );
    return result;
  }


  public static ArrayList<ArrayList<Boolean>> mmLeq(ArrayList<ArrayList<Double>> m1, ArrayList<ArrayList<Double>> m2)
  {
    ArrayList<ArrayList<Boolean>> result = new ArrayList<ArrayList<Boolean>>();
    result = Integer.subrange(1,m1.size)->collect( i | Sequences.ssLeq(m1[i],m2[i]) );
    return result;
  }


  public static ArrayList<ArrayList<Boolean>> mmLess(ArrayList<ArrayList<Double>> m1, ArrayList<ArrayList<Double>> m2)
  {
    ArrayList<ArrayList<Boolean>> result = new ArrayList<ArrayList<Boolean>>();
    result = Integer.subrange(1,m1.size)->collect( i | Sequences.ssLess(m1[i],m2[i]) );
    return result;
  }


  public static ArrayList<ArrayList<Double>> subRows(ArrayList<ArrayList<Double>> m, ArrayList<Integer> s)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Ocl.collectSequence(Ocl.selectSequence(s,(i)->{return 1 <= i && i <= m.size();}),(j)->{return ((ArrayList<Double>) (m).get(j - 1));});
    return result;
  }


  public static ArrayList<ArrayList<Double>> subColumns(ArrayList<ArrayList<Double>> m, ArrayList<Integer> s)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Ocl.collectSequence(m,(r)->{return Sequences.subItems(r, s);});
    return result;
  }


  public static ArrayList<ArrayList<Double>> subMatrix(ArrayList<ArrayList<Double>> m, ArrayList<Integer> rows, ArrayList<Integer> cols)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Matrix.subColumns(Matrix.subRows(m, rows), cols);
    return result;
  }


  public static ArrayList<ArrayList<Double>> setMatrix(ArrayList<ArrayList<Double>> m, ArrayList<Double> vals)
  {
    ArrayList<ArrayList<Double>> result = new ArrayList<ArrayList<Double>>();
    result = Integer.subrange(1,m.size)->collect( i | vals.subrange(1 + ( i - 1 ) * m[1].size,i * m[1].size) );
    return result;
  }


  public static  String toStringDouble(ArrayList<ArrayList<Double>> s)
  {
     String result = "";
    result = "Sequence{ " + Ocl.sum String(Ocl.collectSequence(s,(x)->{return Sequences.toStringDouble(x) + " ";})) + "}";
    return result;
  }


  public static  String toStringInt(ArrayList<ArrayList<Integer>> s)
  {
     String result = "";
    result = "Sequence{ " + Ocl.sum String(Ocl.collectSequence(s,(x)->{return Sequences.toStringInt(x) + " ";})) + "}";
    return result;
  }


  public static  String toStringBoolean(ArrayList<ArrayList<Boolean>> s)
  {
     String result = "";
    result = "Sequence{ " + Ocl.sum String(Ocl.collectSequence(s,(x)->{return Sequences.toStringBoolean(x) + " ";})) + "}";
    return result;
  }

}

