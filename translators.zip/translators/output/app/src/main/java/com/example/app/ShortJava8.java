package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ShortJava8 { static ArrayList<ShortJava8> ShortJava8_allInstances = new ArrayList<ShortJava8>();

  ShortJava8() { ShortJava8_allInstances.add(this); }

  static ShortJava8 createShortJava8() { ShortJava8 result = new ShortJava8();
    return result; }

  String shortjava8Id = ""; /* primary */
  static Map<String,ShortJava8> ShortJava8_index = new HashMap<String,ShortJava8>();

  static ShortJava8 createByPKShortJava8(String shortjava8Idx)
  { ShortJava8 result = ShortJava8.ShortJava8_index.get(shortjava8Idx);
    if (result != null) { return result; }
    result = new ShortJava8();
    ShortJava8.ShortJava8_index.put(shortjava8Idx,result);
    result.shortjava8Id = shortjava8Idx;
    return result; }

  static void killShortJava8(String shortjava8Idx)
  { ShortJava8 rem = ShortJava8_index.get(shortjava8Idx);
    if (rem == null) { return; }
    ArrayList<ShortJava8> remd = new ArrayList<ShortJava8>();
    remd.add(rem);
    ShortJava8_index.remove(shortjava8Idx);
    ShortJava8_allInstances.removeAll(remd);
  }


  public int shortop()
  {
    int result = 0;
    int st = 0;
    st = Integer.decode(("0xFF" + "")).intValue();
    int x = 0;
    x = 32767;
    x = Integer.decode("077").intValue();
    double ff = 0.0;
    ff = Double.parseDouble((st + ""));
    return ((st < (Integer.decode((99 + "")).intValue())) ? -1 : ((st > (Integer.decode((99 + "")).intValue())) ? 1 : 0 ));
  }

}

