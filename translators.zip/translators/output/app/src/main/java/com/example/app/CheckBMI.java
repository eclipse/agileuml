package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class CheckBMI { static HashSet<CheckBMI> CheckBMI_allInstances = new HashSet<CheckBMI>();

  CheckBMI() { CheckBMI_allInstances.add(this); }

  static CheckBMI createCheckBMI() { CheckBMI result = new CheckBMI();
    return result; }

  static double bmi = 0;

  public String checkBMI(double weight, double height)
  {
    String result = "";
    return result;
  }

}

