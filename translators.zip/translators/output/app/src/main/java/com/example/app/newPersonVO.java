package com.example.app.ui.main;

public class newPersonVO
{ 
 private String nme;

  public newPersonVO() {}

  public newPersonVO(String nmex)
  {    nme = nmex;
  }

  public String getnme()
  { return nme; }

  public void setnme(String _x)
  { nme = _x; }

}


