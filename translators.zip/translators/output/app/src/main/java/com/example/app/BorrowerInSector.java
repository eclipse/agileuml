package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class BorrowerInSector { static ArrayList<BorrowerInSector> BorrowerInSector_allInstances = new ArrayList<BorrowerInSector>();

  BorrowerInSector() { BorrowerInSector_allInstances.add(this); }

  static BorrowerInSector createBorrowerInSector() { BorrowerInSector result = new BorrowerInSector();
    return result; }

  double omega = 0.0;
  double theta = 0.0;
  Borrower borrower = null;
  String borrowerinsectorId = ""; /* primary */
  static Map<String,BorrowerInSector> BorrowerInSector_index = new HashMap<String,BorrowerInSector>();

  static BorrowerInSector createByPKBorrowerInSector(String borrowerinsectorIdx)
  { BorrowerInSector result = BorrowerInSector.BorrowerInSector_index.get(borrowerinsectorIdx);
    if (result != null) { return result; }
    result = new BorrowerInSector();
    BorrowerInSector.BorrowerInSector_index.put(borrowerinsectorIdx,result);
    result.borrowerinsectorId = borrowerinsectorIdx;
    return result; }

  static void killBorrowerInSector(String borrowerinsectorIdx)
  { BorrowerInSector rem = BorrowerInSector_index.get(borrowerinsectorIdx);
    if (rem == null) { return; }
    ArrayList<BorrowerInSector> remd = new ArrayList<BorrowerInSector>();
    remd.add(rem);
    BorrowerInSector_index.remove(borrowerinsectorIdx);
    BorrowerInSector_allInstances.removeAll(remd);
  }


  public void initialise(Borrower borrower)
  {
    this.omega = 0.0;
    this.theta = 0.0;
    this.borrower = borrower;
  }


  public static BorrowerInSector newBorrowerInSector(Borrower borrower)
  {
    BorrowerInSector result = null;
    result = BorrowerInSector.createBorrowerInSector();
    result.initialise(borrower);
    return result;
  }


  public void initialise()
  {
    {}
  }


  public static BorrowerInSector newBorrowerInSector()
  {
    BorrowerInSector result = null;
    result = BorrowerInSector.createBorrowerInSector();
    result.initialise();
    return result;
  }

}

