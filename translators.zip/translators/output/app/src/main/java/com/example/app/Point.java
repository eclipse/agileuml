package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class Point { static ArrayList<Point> Point_allInstances = new ArrayList<Point>();

  Point() { Point_allInstances.add(this); }

  static Point createPoint() { Point result = new Point();
    return result; }

  int x = 0;
  int y = 0;
  String pointId = ""; /* primary */
  static Map<String,Point> Point_index = new HashMap<String,Point>();

  static Point createByPKPoint(String pointIdx)
  { Point result = Point.Point_index.get(pointIdx);
    if (result != null) { return result; }
    result = new Point();
    Point.Point_index.put(pointIdx,result);
    result.pointId = pointIdx;
    return result; }

  static void killPoint(String pointIdx)
  { Point rem = Point_index.get(pointIdx);
    if (rem == null) { return; }
    ArrayList<Point> remd = new ArrayList<Point>();
    remd.add(rem);
    Point_index.remove(pointIdx);
    Point_allInstances.removeAll(remd);
  }


  public static Point newPoint(int x, int y)
  {
    Point result = null;
    result = createPoint();
    result.x = x;
    result.y = y;
    return result;
  }

}

