package com.example.app4;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class CalorieCount { protected long now = 0;
    protected long now_pre = 0;
    static ArrayList<CalorieCount> CalorieCount_allInstances = new ArrayList<CalorieCount>();

  CalorieCount() { CalorieCount_allInstances.add(this); }

  static CalorieCount createCalorieCount() { CalorieCount result = new CalorieCount();
    return result; }


  private int act_calorieCount = 0;
  private int fin_calorieCount = 0;

  public double calorieCount(Gender gender, Exercise exercise, double time)
  {
    now = Ocl.getTime();
    now_pre = now;
    act_calorieCount++;
    double result = 0;
    return result;
    fin_calorieCount++;
  }

}

