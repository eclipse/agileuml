package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class Sector { static ArrayList<Sector> Sector_allInstances = new ArrayList<Sector>();

  Sector() { Sector_allInstances.add(this); }

  static Sector createSector() { Sector result = new Sector();
    return result; }

  String name = "";
  int n = 0;
  double p = 0.0;
  double q = 0.0;
  int L = 0;
  double mu = 0.0;
  ArrayList borrowers = (new ArrayList());
  String sectorId = ""; /* primary */
  static Map<String,Sector> Sector_index = new HashMap<String,Sector>();

  static Sector createByPKSector(String sectorIdx)
  { Sector result = Sector.Sector_index.get(sectorIdx);
    if (result != null) { return result; }
    result = new Sector();
    Sector.Sector_index.put(sectorIdx,result);
    result.sectorId = sectorIdx;
    return result; }

  static void killSector(String sectorIdx)
  { Sector rem = Sector_index.get(sectorIdx);
    if (rem == null) { return; }
    ArrayList<Sector> remd = new ArrayList<Sector>();
    remd.add(rem);
    Sector_index.remove(sectorIdx);
    Sector_allInstances.removeAll(remd);
  }


  public void initialise()
  {
    this.name = "";
    this.n = 0;
    this.p = 0.0;
    this.q = 0.0;
    this.L = 0;
    this.mu = 0.0;
  }


  public static Sector newSector()
  {
    Sector result = null;
    result = Sector.createSector();
    result.initialise();
    return result;
  }


  public double nocontagion(int m)
  {
    double result = 0.0;
    result = 0.0;
    double othersNotfailedProb = 0.0;
    othersNotfailedProb = Math.pow((1 - p),n - m);
    double mFailedProb = 0.0;
    mFailedProb = Math.pow(p,m);
    double noinfections = 0.0;
    noinfections = Math.pow((1 - q),m * (n - m));
    result = othersNotfailedProb * mFailedProb * noinfections;
    return result;
  }


  public double contagion(int i, int m)
  {
    double result = 0.0;
    result = 0;
    double othersNotfailedProb = 0.0;
    othersNotfailedProb = Math.pow((1 - p),n - i);
    double iFailedProb = 0.0;
    iFailedProb = Math.pow(p,i);
    double notInfectedProb = 0.0;
    notInfectedProb = Math.pow((1 - q),i * (n - m));
    double infectionProb = 0.0;
    infectionProb = Math.pow((1 - Math.pow((1 - q),i)),m - i);
    result = othersNotfailedProb * iFailedProb * notInfectedProb * infectionProb * StatFunc.comb(m, i);
    return result;
  }


  public double borrowerLoss(int i)
  {
    double result = 0.0;
    result = 0;
    BorrowerInSector bs = null;
    bs = ((BorrowerInSector) (((Object) borrowers.get((i - 1) + 1 - 1))));
    result = bs.omega * bs.borrower.L;
    return result;
  }

}

