package com.example.app.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class testBean
{ ModelFacade model = null;

  private List errors = new ArrayList();

  public testBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void resetData()
  { }

  public boolean istesterror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void test()
  { model.test(); }

}

