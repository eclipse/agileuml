package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ForJava8 { static ArrayList<ForJava8> ForJava8_allInstances = new ArrayList<ForJava8>();

  ForJava8() { ForJava8_allInstances.add(this); }

  static ForJava8 createForJava8() { ForJava8 result = new ForJava8();
    return result; }

  String forjava8Id = ""; /* primary */
  static Map<String,ForJava8> ForJava8_index = new HashMap<String,ForJava8>();

  static ForJava8 createByPKForJava8(String forjava8Idx)
  { ForJava8 result = ForJava8.ForJava8_index.get(forjava8Idx);
    if (result != null) { return result; }
    result = new ForJava8();
    ForJava8.ForJava8_index.put(forjava8Idx,result);
    result.forjava8Id = forjava8Idx;
    return result; }

  static void killForJava8(String forjava8Idx)
  { ForJava8 rem = ForJava8_index.get(forjava8Idx);
    if (rem == null) { return; }
    ArrayList<ForJava8> remd = new ArrayList<ForJava8>();
    remd.add(rem);
    ForJava8_index.remove(forjava8Idx);
    ForJava8_allInstances.removeAll(remd);
  }


  public int forop()
  {
    int result = 0;
    ArrayList<Integer> arr = new ArrayList<Integer>();
    arr = Ocl.initialiseSequence(1,2,3,5,7,11,13,17,19);
    int total = 0;
    total = 0;
    int i = 0;
    i = 0;
    while (i < arr.size())
    {
      total = total + ((int) (arr).get(i + 1 - 1));
    i = i + 1;
    }
    return total;
  }

}

