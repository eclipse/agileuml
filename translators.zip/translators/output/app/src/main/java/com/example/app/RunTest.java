package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class RunTest implements Runnable
{ static ArrayList<RunTest> RunTest_allInstances = new ArrayList<RunTest>();

  RunTest() { RunTest_allInstances.add(this); }

  static RunTest createRunTest() { RunTest result = new RunTest();
    return result; }

  String inst = "";
  String runtestId = ""; /* primary */
  static Map<String,RunTest> RunTest_index = new HashMap<String,RunTest>();

  static RunTest createByPKRunTest(String runtestIdx)
  { RunTest result = RunTest.RunTest_index.get(runtestIdx);
    if (result != null) { return result; }
    result = new RunTest();
    RunTest.RunTest_index.put(runtestIdx,result);
    result.runtestId = runtestIdx;
    return result; }

  static void killRunTest(String runtestIdx)
  { RunTest rem = RunTest_index.get(runtestIdx);
    if (rem == null) { return; }
    ArrayList<RunTest> remd = new ArrayList<RunTest>();
    remd.add(rem);
    RunTest_index.remove(runtestIdx);
    RunTest_allInstances.removeAll(remd);
  }


  public void initialise(String nme)
  {
    inst = nme;
  }


  public static RunTest newRunTest(String nme)
  {
    RunTest result = null;
    result = RunTest.createRunTest();
    result.initialise(nme);
    return result;
  }


  public void run()
  {
    int i = 0;
    i = 0;
    while (i < 20)
    {
      Ocl.displayString((">> step " + i + " of " + inst));
    i = (i + 1);
    }
  }

}

