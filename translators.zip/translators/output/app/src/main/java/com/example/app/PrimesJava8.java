package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class PrimesJava8 { static ArrayList<PrimesJava8> PrimesJava8_allInstances = new ArrayList<PrimesJava8>();

  PrimesJava8() { PrimesJava8_allInstances.add(this); }

  static PrimesJava8 createPrimesJava8() { PrimesJava8 result = new PrimesJava8();
    return result; }

  String primesjava8Id = ""; /* primary */
  static Map<String,PrimesJava8> PrimesJava8_index = new HashMap<String,PrimesJava8>();

  static PrimesJava8 createByPKPrimesJava8(String primesjava8Idx)
  { PrimesJava8 result = PrimesJava8.PrimesJava8_index.get(primesjava8Idx);
    if (result != null) { return result; }
    result = new PrimesJava8();
    PrimesJava8.PrimesJava8_index.put(primesjava8Idx,result);
    result.primesjava8Id = primesjava8Idx;
    return result; }

  static void killPrimesJava8(String primesjava8Idx)
  { PrimesJava8 rem = PrimesJava8_index.get(primesjava8Idx);
    if (rem == null) { return; }
    ArrayList<PrimesJava8> remd = new ArrayList<PrimesJava8>();
    remd.add(rem);
    PrimesJava8_index.remove(primesjava8Idx);
    PrimesJava8_allInstances.removeAll(remd);
  }


  public boolean primes()
  {
    boolean result = false;
    ArrayList<Boolean> primes = new ArrayList<Boolean>();
    primes = Ocl.collectSequence(Ocl.integerSubrange(1,100),(var0)->{return false;});
    primes = Ocl.collectSequence(primes,(var1)->{return true;});
    int i = 0;
    i = 2;
    while (i < 11)
    {
      int p = 0;
    p = 2;
    while (p * i < 100)
    {
      primes.set(p * i + 1 - 1,false);
    p = p + 1;
    }
    i = i + 1;
    }
    try {     return ((boolean) (primes).get(91 + 1 - 1));
    }
      catch (IllegalAccessException ex) {     return false;
      }

  }

}

