package com.example.app.ui.main;

public enum ComorbidityTYPE { present, absent, unknown }


