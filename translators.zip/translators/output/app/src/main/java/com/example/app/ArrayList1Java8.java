package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ArrayList1Java8 { static ArrayList<ArrayList1Java8> ArrayList1Java8_allInstances = new ArrayList<ArrayList1Java8>();

  ArrayList1Java8() { ArrayList1Java8_allInstances.add(this); }

  static ArrayList1Java8 createArrayList1Java8() { ArrayList1Java8 result = new ArrayList1Java8();
    return result; }

  String arraylist1java8Id = ""; /* primary */
  static Map<String,ArrayList1Java8> ArrayList1Java8_index = new HashMap<String,ArrayList1Java8>();

  static ArrayList1Java8 createByPKArrayList1Java8(String arraylist1java8Idx)
  { ArrayList1Java8 result = ArrayList1Java8.ArrayList1Java8_index.get(arraylist1java8Idx);
    if (result != null) { return result; }
    result = new ArrayList1Java8();
    ArrayList1Java8.ArrayList1Java8_index.put(arraylist1java8Idx,result);
    result.arraylist1java8Id = arraylist1java8Idx;
    return result; }

  static void killArrayList1Java8(String arraylist1java8Idx)
  { ArrayList1Java8 rem = ArrayList1Java8_index.get(arraylist1java8Idx);
    if (rem == null) { return; }
    ArrayList<ArrayList1Java8> remd = new ArrayList<ArrayList1Java8>();
    remd.add(rem);
    ArrayList1Java8_index.remove(arraylist1java8Idx);
    ArrayList1Java8_allInstances.removeAll(remd);
  }


  public boolean arr1op()
  {
    boolean result = false;
    ArrayList sq = new ArrayList();
    sq = (new ArrayList());
    sq = (new ArrayList());
    sq = Ocl.includingSequence(sq,"aa");
    sq = Ocl.includingSequence(sq,"bb");
    sq = Ocl.insertAt(sq,0 + 1,"cc");
    ArrayList sq1 = new ArrayList();
    sq1 = ((ArrayList) (Ocl.copySequence(sq)));
    sq = Ocl.union(Ocl.union(Ocl.subrange(sq,1,2),sq1),Ocl.subrange(sq,2 + 1));
    String ss = "";
    ss = ((String) (((Object) sq.get(5 + 1 - 1))));
    return sq.contains("bb");
  }

}

