package com.example.app.ui.main;

public class nextgenerationVO
{ 

  public nextgenerationVO() {}

}


