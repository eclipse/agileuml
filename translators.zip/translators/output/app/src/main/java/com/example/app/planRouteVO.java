package com.example.app;

public class planRouteVO
{ 
 private ArrayList<String> lats;
 private ArrayList<String> lngs;

  public planRouteVO() {}

  public planRouteVO(ArrayList<String> latsx,ArrayList<String> lngsx)
  {    lats = latsx;
   lngs = lngsx;
  }

  public ArrayList<String> getlats()
  { return lats; }

  public ArrayList<String> getlngs()
  { return lngs; }

  public void setlats(ArrayList<String> _x)
  { lats = _x; }

  public void setlngs(ArrayList<String> _x)
  { lngs = _x; }

}


