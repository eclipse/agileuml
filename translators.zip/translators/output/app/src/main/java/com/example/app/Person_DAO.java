package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.StringTokenizer;
import java.util.Date; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.*;

public class Person_DAO
{ public static String getURL(String command, ArrayList<String> pars, ArrayList<String> values)
  { String res = "base url for the data source";
    if (command != null)
    { res = res + command; }
    if (pars.size() == 0)
    { return res; }
    res = res + "?";
    for (int i = 0; i < pars.size(); i++)
    { String par = pars.get(i); 
      String val = values.get(i); 
      res = res + par + "=" + val;
      if (i < pars.size() - 1)
      { res = res + "&"; }
    }
    return res;
  }

  public static boolean isCached(String id)
  { Person _x = Person.Person_index.get(id);
    if (_x == null) { return false; }
    return true;
  }



  public static Person getCachedInstance(String id)
  { return Person.Person_index.get(id); }



  public static Person parseCSV(String _line)
  { if (_line == null) { return null; }
    ArrayList<String> _line1vals = Ocl.tokeniseCSV(_line);
    Person personx;
    personx = Person.Person_index.get((String) _line1vals.get(0));
    if (personx == null)
    { personx = Person.createByPKPerson((String) _line1vals.get(0)); }
    personx.name = (String) _line1vals.get(0);
    personx.age = Integer.parseInt((String) _line1vals.get(1));
    personx.id = (String) _line1vals.get(2);
    return personx;
  }



  public static Person parseJSON(JSONObject obj)
  { if (obj == null) { return null; }

    try {
      String id = obj.getString("id");
      Person _personx = Person.Person_index.get(id);
      if (_personx == null) { _personx = Person.createByPKPerson(id); }
      
      _personx.name = obj.getString("name");
      _personx.age = obj.getInt("age");
      _personx.id = obj.getString("id");
      return _personx;
    } catch (Exception _e) { return null; }
  }



  public static ArrayList<Person> makeFromCSV(String lines)
  { ArrayList<Person> result = new ArrayList<Person>();

    if (lines == null)
    { return result; }

    ArrayList<String> rows = Ocl.parseCSVtable(lines);

    for (int i = 1; i < rows.size(); i++)
    { String row = rows.get(i);
      if (row == null || row.trim().length() == 0)
      { }
      else
      { Person _x = parseCSV(row);
        if (_x != null)
        { result.add(_x); }
      }
    }
    return result;
  }



  public static ArrayList<Person> parseJSONArray(JSONArray jarray)
  { if (jarray == null) { return null; }
    ArrayList<Person> res = new ArrayList<Person>();

    int len = jarray.length();
    for (int i = 0; i < len; i++)
    { try { JSONObject _x = jarray.getJSONObject(i);
        if (_x != null)
        { Person _y = parseJSON(_x); 
          if (_y != null) { res.add(_y); }
        }
      }
      catch (Exception _e) { }
    }
    return res;
  }



  public static JSONObject writeJSON(Person _x)
  { JSONObject result = new JSONObject();
    try {
       result.put("name", _x.name);
       result.put("age", _x.age);
       result.put("id", _x.id);
      } catch (Exception _e) { return null; }
    return result;
  }



  public static Person parseRaw(Object obj)
  { if (obj == null) { return null; }

    try {
      Map<String,Object> _map = (Map<String,Object>) obj;
      String id = (String) _map.get("id");
      Person _personx = Person.Person_index.get(id);
      if (_personx == null) { _personx = Person.createByPKPerson(id); }
      
      _personx.name = (String) _map.get("name");
      _personx.age = (int) ((Long) _map.get("age")).longValue();
      _personx.id = (String) _map.get("id");
      return _personx;
    } catch (Exception _e) { return null; }
  }



  public static JSONArray writeJSONArray(ArrayList<Person> es)
  { JSONArray result = new JSONArray();
    for (int _i = 0; _i < es.size(); _i++)
    { Person _ex = es.get(_i);
      JSONObject _jx = writeJSON(_ex);
      if (_jx == null) { } 
      else 
      { try { result.put(_jx); }
        catch (Exception _ee) { }
      }
    }
    return result;
  }


}
