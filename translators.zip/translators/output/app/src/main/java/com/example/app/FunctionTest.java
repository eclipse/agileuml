package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class FunctionTest { static ArrayList<FunctionTest> FunctionTest_allInstances = new ArrayList<FunctionTest>();

  FunctionTest() { FunctionTest_allInstances.add(this); }

  static FunctionTest createFunctionTest() { FunctionTest result = new FunctionTest();
    return result; }

  String functiontestId = ""; /* primary */
  static Map<String,FunctionTest> FunctionTest_index = new HashMap<String,FunctionTest>();

  static FunctionTest createByPKFunctionTest(String functiontestIdx)
  { FunctionTest result = FunctionTest.FunctionTest_index.get(functiontestIdx);
    if (result != null) { return result; }
    result = new FunctionTest();
    FunctionTest.FunctionTest_index.put(functiontestIdx,result);
    result.functiontestId = functiontestIdx;
    return result; }

  static void killFunctionTest(String functiontestIdx)
  { FunctionTest rem = FunctionTest_index.get(functiontestIdx);
    if (rem == null) { return; }
    ArrayList<FunctionTest> remd = new ArrayList<FunctionTest>();
    remd.add(rem);
    FunctionTest_index.remove(functiontestIdx);
    FunctionTest_allInstances.removeAll(remd);
  }


  public double findRoot(Evaluation<Double,Double> f)
  {
    double result = 0.0;
    result = f.evaluate(0.5);
    return result;
  }


  public double testCall()
  {
    double result = 0.0;
    result = findRoot((x) -> { return (x * x + x + 1); });
    return result;
  }

}

