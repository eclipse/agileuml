package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Strings4Java8 { static ArrayList<Strings4Java8> Strings4Java8_allInstances = new ArrayList<Strings4Java8>();

  Strings4Java8() { Strings4Java8_allInstances.add(this); }

  static Strings4Java8 createStrings4Java8() { Strings4Java8 result = new Strings4Java8();
    return result; }

  String strings4java8Id = ""; /* primary */
  static Map<String,Strings4Java8> Strings4Java8_index = new HashMap<String,Strings4Java8>();

  static Strings4Java8 createByPKStrings4Java8(String strings4java8Idx)
  { Strings4Java8 result = Strings4Java8.Strings4Java8_index.get(strings4java8Idx);
    if (result != null) { return result; }
    result = new Strings4Java8();
    Strings4Java8.Strings4Java8_index.put(strings4java8Idx,result);
    result.strings4java8Id = strings4java8Idx;
    return result; }

  static void killStrings4Java8(String strings4java8Idx)
  { Strings4Java8 rem = Strings4Java8_index.get(strings4java8Idx);
    if (rem == null) { return; }
    ArrayList<Strings4Java8> remd = new ArrayList<Strings4Java8>();
    remd.add(rem);
    Strings4Java8_index.remove(strings4java8Idx);
    Strings4Java8_allInstances.removeAll(remd);
  }


  public String strings4op()
  {
    String result = "";
    String ss = "";
    ss = "a long string";
    ArrayList<String> chrs = new ArrayList<String>();
    chrs = Ocl.characters(ss);
    String s1 = "";
    s1 = ss.toUpperCase();
    String cs = "";
    cs = Ocl.subrange(ss,5 + 1,7);
    s1 = s1.toLowerCase();
    return ss.trim();
  }

}

