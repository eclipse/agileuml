package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class StringLib { static ArrayList<StringLib> StringLib_allInstances = new ArrayList<StringLib>();

  StringLib() { StringLib_allInstances.add(this); }

  static StringLib createStringLib() { StringLib result = new StringLib();
    return result; }

  String stringlibId = ""; /* primary */
  static Map<String,StringLib> StringLib_index = new HashMap<String,StringLib>();

  static StringLib createByPKStringLib(String stringlibIdx)
  { StringLib result = StringLib.StringLib_index.get(stringlibIdx);
    if (result != null) { return result; }
    result = new StringLib();
    StringLib.StringLib_index.put(stringlibIdx,result);
    result.stringlibId = stringlibIdx;
    return result; }

  static void killStringLib(String stringlibIdx)
  { StringLib rem = StringLib_index.get(stringlibIdx);
    if (rem == null) { return; }
    ArrayList<StringLib> remd = new ArrayList<StringLib>();
    remd.add(rem);
    StringLib_index.remove(stringlibIdx);
    StringLib_allInstances.removeAll(remd);
  }


  public static String before(String str, String delim)
  {
    String result = "";
    int i = 0;
    i = (str.indexOf(delim) + 1);
    if (i > 0)
    {
      result = Ocl.subrange(str,1,i - 1);
    }
    else {
      if (i <= 0)
    {
      result = str;
    }
    else {
      }
    }
    return result;
  }


  public static String after(String str, String delim)
  {
    String result = "";
    int i = 0;
    i = (str.indexOf(delim) + 1);
    if (i > 0)
    {
      result = Ocl.subrange(str,i + delim.length(),str.length());
    }
    else {
      if (i <= 0)
    {
      result = str;
    }
    else {
      }
    }
    return result;
  }


  public static boolean equalsIgnoreCase(String s1, String s2)
  {
    boolean result = false;
    if (s1.toLowerCase().equals(s2.toLowerCase()))
    {
      result = true;
    }
    else {
      }
    return result;
  }


  public static int lastIndexOf(String s, String d)
  {
    int result = 0;
    int i = 0;
    i = (Ocl.reverse(s).indexOf(Ocl.reverse(d)) + 1);
    if (i <= 0)
    {
      result = 0;
    }
    else {
      if (i > 0)
    {
      result = s.length() - i - d.length() + 2;
    }
    else {
      }
    }
    return result;
  }


  public static ArrayList<String> split(String str, String delim)
  {
    ArrayList<String> result = new ArrayList<String>();
    result = Ocl.copySequence((new ArrayList()));
    int i = 0;
    i = (str.indexOf(delim) + 1);
    while (i > 0)
    {
      String x = "";
    x = Ocl.subrange(str,1,i - 1);
    if (x.length() > 0)
    {
      result = Ocl.copySequence(Ocl.includingSequence(result,x));
    }
    else {
      {}
    }
    str = Ocl.subrange(str,i + delim.length(),str.length());
    i = (str.indexOf(delim) + 1);
    }
    if (str.length() > 0)
    {
      result = Ocl.copySequence(Ocl.includingSequence(result,str));
    }
    else {
      {}
    }
    return result;
  }


  public static String replace(String str, String delim, String s2)
  {
    String result = "";
    result = "";
    int i = 0;
    i = (str.indexOf(delim) + 1);
    while (i > 0)
    {
      result = result + Ocl.subrange(str,1,i - 1) + s2;
    str = Ocl.subrange(str,i + delim.length(),str.length());
    i = (str.indexOf(delim) + 1);
    }
    result = result + str;
    return result;
  }


  public static String trim(String str)
  {
    String result = "";
    result = "";
    int i = 0;
    i = 1;
    while ((i < str.length() && (str.charAt(i - 1) + "").equals(" ")))
    {
      i = i + 1;
    }
    int j = 0;
    j = str.length();
    while (j >= 1 && (str.charAt(j - 1) + "").equals(" "))
    {
      j = j - 1;
    }
    if (j < i)
    {
      result = "";
    }
    else {
      result = Ocl.subrange(str,i,j);
    }
    return result;
  }

}

