package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Math { static ArrayList<Math> Math_allInstances = new ArrayList<Math>();

  Math() { Math_allInstances.add(this); }

  static Math createMath() { Math result = new Math();
    return result; }

   String mathId = ""; /* primary */
  static Map< String,Math> Math_index = new HashMap< String,Math>();

  static Math createByPKMath( String mathIdx)
  { Math result = Math.Math_index.get(mathIdx);
    if (result != null) { return result; }
    result = new Math();
    Math.Math_index.put(mathIdx,result);
    result.mathId = mathIdx;
    return result; }

  static void killMath( String mathIdx)
  { Math rem = Math_index.get(mathIdx);
    if (rem == null) { return; }
    ArrayList<Math> remd = new ArrayList<Math>();
    remd.add(rem);
    Math_index.remove(mathIdx);
    Math_allInstances.removeAll(remd);
  }


  public static  double random()
  {
     double result = 0.0;
    result = 0.5;
    return result;
  }

}

