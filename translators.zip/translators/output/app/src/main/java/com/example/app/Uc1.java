package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Uc1 { static ArrayList<Uc1> Uc1_allInstances = new ArrayList<Uc1>();

  Uc1() { Uc1_allInstances.add(this); }

  static Uc1 createUc1() { Uc1 result = new Uc1();
    return result; }


  public void uc1()
  {
  }

}

