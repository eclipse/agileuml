package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class Borrower { static ArrayList<Borrower> Borrower_allInstances = new ArrayList<Borrower>();

  Borrower() { Borrower_allInstances.add(this); }

  static Borrower createBorrower() { Borrower result = new Borrower();
    return result; }

  String name = "";
  int L = 0;
  double p = 0.0;
  String borrowerId = ""; /* primary */
  static Map<String,Borrower> Borrower_index = new HashMap<String,Borrower>();

  static Borrower createByPKBorrower(String borrowerIdx)
  { Borrower result = Borrower.Borrower_index.get(borrowerIdx);
    if (result != null) { return result; }
    result = new Borrower();
    Borrower.Borrower_index.put(borrowerIdx,result);
    result.borrowerId = borrowerIdx;
    return result; }

  static void killBorrower(String borrowerIdx)
  { Borrower rem = Borrower_index.get(borrowerIdx);
    if (rem == null) { return; }
    ArrayList<Borrower> remd = new ArrayList<Borrower>();
    remd.add(rem);
    Borrower_index.remove(borrowerIdx);
    Borrower_allInstances.removeAll(remd);
  }


  public void initialise()
  {
    this.name = "";
    this.L = 0;
    this.p = 0.0;
  }


  public static Borrower newBorrower()
  {
    Borrower result = null;
    result = Borrower.createBorrower();
    result.initialise();
    return result;
  }

}

