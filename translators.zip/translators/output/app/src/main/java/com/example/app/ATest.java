package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ATest { static ArrayList<ATest> ATest_allInstances = new ArrayList<ATest>();

  ATest() { ATest_allInstances.add(this); }

  static ATest createATest() { ATest result = new ATest();
    return result; }

  String atestId = ""; /* primary */
  static Map<String,ATest> ATest_index = new HashMap<String,ATest>();

  static ATest createByPKATest(String atestIdx)
  { ATest result = ATest.ATest_index.get(atestIdx);
    if (result != null) { return result; }
    result = new ATest();
    ATest.ATest_index.put(atestIdx,result);
    result.atestId = atestIdx;
    return result; }

  static void killATest(String atestIdx)
  { ATest rem = ATest_index.get(atestIdx);
    if (rem == null) { return; }
    ArrayList<ATest> remd = new ArrayList<ATest>();
    remd.add(rem);
    ATest_index.remove(atestIdx);
    ATest_allInstances.removeAll(remd);
  }


  public String getName()
  {
    String result = "";
    return result;
  }


  public static ATest newATest()
  {
    ATest result = null;
    result = ATest.createATest();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

