package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Tests { static ArrayList<Tests> Tests_allInstances = new ArrayList<Tests>();

  Tests() { Tests_allInstances.add(this); }

  static Tests createTests() { Tests result = new Tests();
    return result; }


  public void tests()
  {
  }

}

