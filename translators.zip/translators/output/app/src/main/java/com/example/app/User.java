package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class User extends Person { static ArrayList<User> User_allInstances = new ArrayList<User>();

  User() { super();
    User_allInstances.add(this); }

  static User createUser() { User result = new User();
    return result; }

  String userId = "";

  public void initialise(String nme, String uId)
  {
    super.initialise(nme);
    userId = uId;
  }


  public static User newUser(String nme, String uId)
  {
    User result = null;
    result = User.createUser();
    result.initialise(nme, uId);
    return result;
  }

}

