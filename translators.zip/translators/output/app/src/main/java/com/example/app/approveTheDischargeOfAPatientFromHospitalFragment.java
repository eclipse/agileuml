package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.ImageView;
import android.widget.TextView;


public class approveTheDischargeOfAPatientFromHospitalFragment extends Fragment implements OnClickListener, AdapterView.OnItemSelectedListener
{ View root;
  Context myContext;
  approveTheDischargeOfAPatientFromHospitalBean approvethedischargeofapatientfromhospitalbean;

  Spinner approveTheDischargeOfAPatientFromHospitaldoctorxSpinner;
  List<String> approveTheDischargeOfAPatientFromHospitaldoctorxListItems = new ArrayList<String>();
  String approveTheDischargeOfAPatientFromHospitaldoctorxData = "";
  Spinner approveTheDischargeOfAPatientFromHospitalpatientxSpinner;
  List<String> approveTheDischargeOfAPatientFromHospitalpatientxListItems = new ArrayList<String>();
  String approveTheDischargeOfAPatientFromHospitalpatientxData = "";
  Button approveTheDischargeOfAPatientFromHospitalOkButton;
  Button approveTheDischargeOfAPatientFromHospitalcancelButton;


 public approveTheDischargeOfAPatientFromHospitalFragment() {}

  public static approveTheDischargeOfAPatientFromHospitalFragment newInstance(Context c)
  { approveTheDischargeOfAPatientFromHospitalFragment fragment = new approveTheDischargeOfAPatientFromHospitalFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.approvethedischargeofapatientfromhospital_layout, container, false);
    Bundle data = getArguments();
    approveTheDischargeOfAPatientFromHospitaldoctorxSpinner = (Spinner) root.findViewById(R.id.approveTheDischargeOfAPatientFromHospitaldoctorxSpinner);
    approveTheDischargeOfAPatientFromHospitaldoctorxListItems = ModelFacade.getInstance(myContext).allDoctorids();
    ArrayAdapter<String> approveTheDischargeOfAPatientFromHospitaldoctorxAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,approveTheDischargeOfAPatientFromHospitaldoctorxListItems);
    approveTheDischargeOfAPatientFromHospitaldoctorxAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    approveTheDischargeOfAPatientFromHospitaldoctorxSpinner.setAdapter(approveTheDischargeOfAPatientFromHospitaldoctorxAdapter);
    approveTheDischargeOfAPatientFromHospitaldoctorxSpinner.setOnItemSelectedListener(this);

    approveTheDischargeOfAPatientFromHospitalpatientxSpinner = (Spinner) root.findViewById(R.id.approveTheDischargeOfAPatientFromHospitalpatientxSpinner);
    approveTheDischargeOfAPatientFromHospitalpatientxListItems = ModelFacade.getInstance(myContext).allPatientids();
    ArrayAdapter<String> approveTheDischargeOfAPatientFromHospitalpatientxAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,approveTheDischargeOfAPatientFromHospitalpatientxListItems);
    approveTheDischargeOfAPatientFromHospitalpatientxAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    approveTheDischargeOfAPatientFromHospitalpatientxSpinner.setAdapter(approveTheDischargeOfAPatientFromHospitalpatientxAdapter);
    approveTheDischargeOfAPatientFromHospitalpatientxSpinner.setOnItemSelectedListener(this);

    approvethedischargeofapatientfromhospitalbean = new approveTheDischargeOfAPatientFromHospitalBean(myContext);
    approveTheDischargeOfAPatientFromHospitalOkButton = root.findViewById(R.id.approveTheDischargeOfAPatientFromHospitalOK);
    approveTheDischargeOfAPatientFromHospitalOkButton.setOnClickListener(this);
    approveTheDischargeOfAPatientFromHospitalcancelButton = root.findViewById(R.id.approveTheDischargeOfAPatientFromHospitalCancel);
    approveTheDischargeOfAPatientFromHospitalcancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.approveTheDischargeOfAPatientFromHospitalOK)
    { approveTheDischargeOfAPatientFromHospitalOK(_v); }
    else if (_v.getId() == R.id.approveTheDischargeOfAPatientFromHospitalCancel)
    { approveTheDischargeOfAPatientFromHospitalCancel(_v); }
  }

  public void approveTheDischargeOfAPatientFromHospitalOK(View _v) 
  { 
    approvethedischargeofapatientfromhospitalbean.setdoctorx(approveTheDischargeOfAPatientFromHospitaldoctorxData);
    approvethedischargeofapatientfromhospitalbean.setpatientx(approveTheDischargeOfAPatientFromHospitalpatientxData);
    if (approvethedischargeofapatientfromhospitalbean.isapproveTheDischargeOfAPatientFromHospitalerror())
    { Log.w(getClass().getName(), approvethedischargeofapatientfromhospitalbean.errors());
      Toast.makeText(myContext, "Errors: " + approvethedischargeofapatientfromhospitalbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { approvethedischargeofapatientfromhospitalbean.approveTheDischargeOfAPatientFromHospital(); }
  }


  public void approveTheDischargeOfAPatientFromHospitalCancel(View _v)
  { approvethedischargeofapatientfromhospitalbean.resetData();
  }
  public void onItemSelected(AdapterView<?> _parent, View _v, int _position, long _id)
  {     if (_parent == approveTheDischargeOfAPatientFromHospitaldoctorxSpinner)
    { approveTheDischargeOfAPatientFromHospitaldoctorxData = approveTheDischargeOfAPatientFromHospitaldoctorxListItems.get(_position); }
    if (_parent == approveTheDischargeOfAPatientFromHospitalpatientxSpinner)
    { approveTheDischargeOfAPatientFromHospitalpatientxData = approveTheDischargeOfAPatientFromHospitalpatientxListItems.get(_position); }
 }

  public void onNothingSelected(AdapterView<?> _parent)
  {     approveTheDischargeOfAPatientFromHospitaldoctorxData = "";
    approveTheDischargeOfAPatientFromHospitalpatientxData = "";
 }

}
