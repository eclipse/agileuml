package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class CC { static ArrayList<CC> CC_allInstances = new ArrayList<CC>();

  CC() { CC_allInstances.add(this); }

  static CC createCC() { CC result = new CC();
    return result; }

  String ccId = ""; /* primary */
  static Map<String,CC> CC_index = new HashMap<String,CC>();

  static CC createByPKCC(String ccIdx)
  { CC result = CC.CC_index.get(ccIdx);
    if (result != null) { return result; }
    result = new CC();
    CC.CC_index.put(ccIdx,result);
    result.ccId = ccIdx;
    return result; }

  static void killCC(String ccIdx)
  { CC rem = CC_index.get(ccIdx);
    if (rem == null) { return; }
    ArrayList<CC> remd = new ArrayList<CC>();
    remd.add(rem);
    CC_index.remove(ccIdx);
    CC_allInstances.removeAll(remd);
  }


  public int op()
  {
    int result = 0;
    int[] x = new int[1];
    x = (new int[10]);
    x[0] = 5;
    int[] y = new int[1];
    y = x;
    y[0] = 3;
    return x[0];
  }

}

