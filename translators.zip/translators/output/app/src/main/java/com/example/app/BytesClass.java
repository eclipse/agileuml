package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class BytesClass { static ArrayList<BytesClass> BytesClass_allInstances = new ArrayList<BytesClass>();

  BytesClass() { BytesClass_allInstances.add(this); }

  static BytesClass createBytesClass() { BytesClass result = new BytesClass();
    return result; }

  String bytesclassId = ""; /* primary */
  static Map<String,BytesClass> BytesClass_index = new HashMap<String,BytesClass>();

  static BytesClass createByPKBytesClass(String bytesclassIdx)
  { BytesClass result = BytesClass.BytesClass_index.get(bytesclassIdx);
    if (result != null) { return result; }
    result = new BytesClass();
    BytesClass.BytesClass_index.put(bytesclassIdx,result);
    result.bytesclassId = bytesclassIdx;
    return result; }

  static void killBytesClass(String bytesclassIdx)
  { BytesClass rem = BytesClass_index.get(bytesclassIdx);
    if (rem == null) { return; }
    ArrayList<BytesClass> remd = new ArrayList<BytesClass>();
    remd.add(rem);
    BytesClass_index.remove(bytesclassIdx);
    BytesClass_allInstances.removeAll(remd);
  }


  public int bytesop()
  {
    int result = 0;
    int b = 0;
    b = Integer.decode((97 + "")).intValue();
    b = Integer.decode(("0xF" + "")).intValue();
    int x = 0;
    x = Integer.decode((b + "")).intValue();
    x = Integer.decode("077").intValue();
    x = Integer.decode("055").intValue();
    return ((b < (Integer.decode(("0" + "")).intValue())) ? -1 : ((b > (Integer.decode(("0" + "")).intValue())) ? 1 : 0 ));
  }

}

