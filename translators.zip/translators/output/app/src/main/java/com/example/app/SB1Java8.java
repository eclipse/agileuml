package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class SB1Java8 { static ArrayList<SB1Java8> SB1Java8_allInstances = new ArrayList<SB1Java8>();

  SB1Java8() { SB1Java8_allInstances.add(this); }

  static SB1Java8 createSB1Java8() { SB1Java8 result = new SB1Java8();
    return result; }

  String sb1java8Id = ""; /* primary */
  static Map<String,SB1Java8> SB1Java8_index = new HashMap<String,SB1Java8>();

  static SB1Java8 createByPKSB1Java8(String sb1java8Idx)
  { SB1Java8 result = SB1Java8.SB1Java8_index.get(sb1java8Idx);
    if (result != null) { return result; }
    result = new SB1Java8();
    SB1Java8.SB1Java8_index.put(sb1java8Idx,result);
    result.sb1java8Id = sb1java8Idx;
    return result; }

  static void killSB1Java8(String sb1java8Idx)
  { SB1Java8 rem = SB1Java8_index.get(sb1java8Idx);
    if (rem == null) { return; }
    ArrayList<SB1Java8> remd = new ArrayList<SB1Java8>();
    remd.add(rem);
    SB1Java8_index.remove(sb1java8Idx);
    SB1Java8_allInstances.removeAll(remd);
  }


  public int sb1op()
  {
    int result = 0;
    String b = "";
    b = "";
    b = ("" + "a long string");
    b = "";
    b = (b + ("" + 0.5));
    b = (b + ("" + "c"));
    b = (b + ("" + "text"));
    ArrayList<String> cc = new ArrayList<String>();
    cc = Ocl.initialiseSequence("a","b","c");
    b = (b + Ocl.sumString(cc));
    String x = "";
    x = (b.charAt(0 + 1 - 1) + "");
    b = Ocl.subrange(b,1,0) + b->subrange(5 + 1);
    b = Ocl.removeAt(b,0 + 1);
    return (((Ocl.subrange(b,10 + 1,b.length()).indexOf("a" + "") + 1) > 0) ? ((Ocl.subrange(b,10 + 1,b.length()).indexOf("a" + "") + 1) + 10 - 1) : -1);
  }

}

