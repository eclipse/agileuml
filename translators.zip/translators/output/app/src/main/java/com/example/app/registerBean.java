package com.example.app.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class registerBean
{ ModelFacade model = null;

  private String email = "";
  private String password = "";
  private List errors = new ArrayList();

  public registerBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setemail(String emailx)
  { email = emailx; }

  public void setpassword(String passwordx)
  { password = passwordx; }

  public void resetData()
  { email = "";
    password = "";
    }

  public boolean isregistererror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void register()
  { model.register(email,password); }

}

