package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class BigDecimalJava8 { static ArrayList<BigDecimalJava8> BigDecimalJava8_allInstances = new ArrayList<BigDecimalJava8>();

  BigDecimalJava8() { BigDecimalJava8_allInstances.add(this); }

  static BigDecimalJava8 createBigDecimalJava8() { BigDecimalJava8 result = new BigDecimalJava8();
    return result; }

  String bigdecimaljava8Id = ""; /* primary */
  static Map<String,BigDecimalJava8> BigDecimalJava8_index = new HashMap<String,BigDecimalJava8>();

  static BigDecimalJava8 createByPKBigDecimalJava8(String bigdecimaljava8Idx)
  { BigDecimalJava8 result = BigDecimalJava8.BigDecimalJava8_index.get(bigdecimaljava8Idx);
    if (result != null) { return result; }
    result = new BigDecimalJava8();
    BigDecimalJava8.BigDecimalJava8_index.put(bigdecimaljava8Idx,result);
    result.bigdecimaljava8Id = bigdecimaljava8Idx;
    return result; }

  static void killBigDecimalJava8(String bigdecimaljava8Idx)
  { BigDecimalJava8 rem = BigDecimalJava8_index.get(bigdecimaljava8Idx);
    if (rem == null) { return; }
    ArrayList<BigDecimalJava8> remd = new ArrayList<BigDecimalJava8>();
    remd.add(rem);
    BigDecimalJava8_index.remove(bigdecimaljava8Idx);
    BigDecimalJava8_allInstances.removeAll(remd);
  }


  public long bdop()
  {
    long result = 0;
    double dd = 0.0;
    dd = Double.parseDouble((999999.99 + ""));
    dd = Double.parseDouble(("99999999999.99" + ""));
    double da = 0.0;
    da = Math.abs(dd);
    dd = dd + da;
    double dv = 0.0;
    dv = Double.parseDouble((dd + ""));
    dd = Ocl.min(Ocl.initialiseSet(dd,da));
    dd = -da;
    return ((long) dd);
  }

}

