package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class TestSequenceIndexOps { static ArrayList<TestSequenceIndexOps> TestSequenceIndexOps_allInstances = new ArrayList<TestSequenceIndexOps>();

  TestSequenceIndexOps() { TestSequenceIndexOps_allInstances.add(this); }

  static TestSequenceIndexOps createTestSequenceIndexOps() { TestSequenceIndexOps result = new TestSequenceIndexOps();
    return result; }

  String testsequenceindexopsId = ""; /* primary */
  static Map<String,TestSequenceIndexOps> TestSequenceIndexOps_index = new HashMap<String,TestSequenceIndexOps>();

  static TestSequenceIndexOps createByPKTestSequenceIndexOps(String testsequenceindexopsIdx)
  { TestSequenceIndexOps result = TestSequenceIndexOps.TestSequenceIndexOps_index.get(testsequenceindexopsIdx);
    if (result != null) { return result; }
    result = new TestSequenceIndexOps();
    TestSequenceIndexOps.TestSequenceIndexOps_index.put(testsequenceindexopsIdx,result);
    result.testsequenceindexopsId = testsequenceindexopsIdx;
    return result; }

  static void killTestSequenceIndexOps(String testsequenceindexopsIdx)
  { TestSequenceIndexOps rem = TestSequenceIndexOps_index.get(testsequenceindexopsIdx);
    if (rem == null) { return; }
    ArrayList<TestSequenceIndexOps> remd = new ArrayList<TestSequenceIndexOps>();
    remd.add(rem);
    TestSequenceIndexOps_index.remove(testsequenceindexopsIdx);
    TestSequenceIndexOps_allInstances.removeAll(remd);
  }


  public static ArrayList<String> op1(ArrayList<String> s, String t)
  {
    ArrayList<String> result = new ArrayList<String>();
    displayint(((s.indexOf(t) + 1)));
    displayint(((s.lastIndexOf(t) + 1)));
    result = Ocl.copySequence(Ocl.subrange(s,1,3));
    return result;
  }


  public static void op2(ArrayList<String> s1, ArrayList<String> s2)
  {
    displayint(((Collections.indexOfSubList(s1,s2) + 1)));
    displayint(((Collections.lastIndexOfSubList(s1,s2) + 1)));
  }

}

