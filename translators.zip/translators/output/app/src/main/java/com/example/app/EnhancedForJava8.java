package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class EnhancedForJava8 { static ArrayList<EnhancedForJava8> EnhancedForJava8_allInstances = new ArrayList<EnhancedForJava8>();

  EnhancedForJava8() { EnhancedForJava8_allInstances.add(this); }

  static EnhancedForJava8 createEnhancedForJava8() { EnhancedForJava8 result = new EnhancedForJava8();
    return result; }

  String enhancedforjava8Id = ""; /* primary */
  static Map<String,EnhancedForJava8> EnhancedForJava8_index = new HashMap<String,EnhancedForJava8>();

  static EnhancedForJava8 createByPKEnhancedForJava8(String enhancedforjava8Idx)
  { EnhancedForJava8 result = EnhancedForJava8.EnhancedForJava8_index.get(enhancedforjava8Idx);
    if (result != null) { return result; }
    result = new EnhancedForJava8();
    EnhancedForJava8.EnhancedForJava8_index.put(enhancedforjava8Idx,result);
    result.enhancedforjava8Id = enhancedforjava8Idx;
    return result; }

  static void killEnhancedForJava8(String enhancedforjava8Idx)
  { EnhancedForJava8 rem = EnhancedForJava8_index.get(enhancedforjava8Idx);
    if (rem == null) { return; }
    ArrayList<EnhancedForJava8> remd = new ArrayList<EnhancedForJava8>();
    remd.add(rem);
    EnhancedForJava8_index.remove(enhancedforjava8Idx);
    EnhancedForJava8_allInstances.removeAll(remd);
  }


  public int efop()
  {
    int result = 0;
    ArrayList<Integer> arr = new ArrayList<Integer>();
    arr = Ocl.initialiseSequence(87,68,94,100,83,78,85,91,76,87);
    int total = 0;
    total = 0;
    for (int num : arr)
    {
      total = total + num;
    }
    return total;
  }

}

