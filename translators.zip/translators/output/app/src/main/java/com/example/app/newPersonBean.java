package com.example.app.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class newPersonBean
{ ModelFacade model = null;

  private String nme = "";
  private List errors = new ArrayList();

  public newPersonBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setnme(String nmex)
  { nme = nmex; }

  public void resetData()
  { nme = "";
    }

  public boolean isnewPersonerror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void newPerson()
  { model.newPerson(nme); }

}

