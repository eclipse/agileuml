package com.example.app5.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app5.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class findYieldFragment extends Fragment implements OnClickListener, AdapterView.OnItemSelectedListener
{ View root;
  Context myContext;
  findYieldBean findyieldbean;
  findDurationBean finddurationbean;

  Spinner findYieldbondSpinner;
  List<String> findYieldbondListItems = new ArrayList<String>();
  String findYieldbondData = "";
  TextView findYieldResult;
  Button findYieldOkButton;
  Button findYieldcancelButton;
  Button findDurationOkButton;
  Spinner findDurationbondSpinner;
  List<String> findDurationbondListItems = new ArrayList<String>();
  String findDurationbondData = "";
  TextView findDurationResult;


 public findYieldFragment() {}

  public static findYieldFragment newInstance(Context c)
  { findYieldFragment fragment = new findYieldFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.findyield_layout, container, false);
    Bundle data = getArguments();
    findYieldbondSpinner = (Spinner) root.findViewById(R.id.findYieldbondSpinner);
    findYieldbondListItems = ModelFacade.getInstance(myContext).allBondids();
    ArrayAdapter<String> findYieldbondAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,findYieldbondListItems);
    findYieldbondAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    findYieldbondSpinner.setAdapter(findYieldbondAdapter);
    findYieldbondSpinner.setOnItemSelectedListener(this);

    findYieldResult = (TextView) root.findViewById(R.id.findYieldResult);
    findyieldbean = new findYieldBean(myContext);
    findDurationbondSpinner = (Spinner) root.findViewById(R.id.findDurationbondSpinner);
    findDurationbondListItems = ModelFacade.getInstance(myContext).allBondids();
    ArrayAdapter<String> findDurationbondAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,findDurationbondListItems);
    findDurationbondAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    findDurationbondSpinner.setAdapter(findDurationbondAdapter);
    findDurationbondSpinner.setOnItemSelectedListener(this);

    findDurationResult = (TextView) root.findViewById(R.id.findDurationResult);
    finddurationbean = new findDurationBean(myContext);
    findYieldOkButton = root.findViewById(R.id.findYieldOK);
    findYieldOkButton.setOnClickListener(this);
    findYieldcancelButton = root.findViewById(R.id.findYieldCancel);
    findYieldcancelButton.setOnClickListener(this);
    findDurationOkButton = root.findViewById(R.id.findDurationOK);
    findDurationOkButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.findYieldOK)
    { findYieldOK(_v); }
    else if (_v.getId() == R.id.findYieldCancel)
    { findYieldCancel(_v); }
    else if (_v.getId() == R.id.findDurationOK)
    { findDurationOK(_v); }
  }

  public void findYieldOK(View _v) 
  { 
    findyieldbean.setbond(findYieldbondData);
    if (findyieldbean.isfindYielderror())
    { Log.w(getClass().getName(), findyieldbean.errors());
      Toast.makeText(myContext, "Errors: " + findyieldbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { findYieldResult.setText(findyieldbean.findYield() + ""); }
  }


  public void findYieldCancel(View _v)
  { findyieldbean.resetData();
    findYieldResult.setText("");
  }
  public void findDurationOK(View _v) 
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    finddurationbean.setbond(findDurationbondData);
    if (finddurationbean.isfindDurationerror())
    { Log.w(getClass().getName(), finddurationbean.errors()); 
      Toast.makeText(myContext, "Errors: " + finddurationbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { findDurationResult.setText(finddurationbean.findDuration() + ""); }
  }


  public void onItemSelected(AdapterView<?> _parent, View _v, int _position, long _id)
  {     if (_parent == findYieldbondSpinner)
    { findYieldbondData = findYieldbondListItems.get(_position); }
    if (_parent == findDurationbondSpinner)
    { findDurationbondData = findDurationbondListItems.get(_position); }
 }

  public void onNothingSelected(AdapterView<?> _parent)
  {     findYieldbondData = "";
    findDurationbondData = "";
 }

}
