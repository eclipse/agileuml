package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class BigIntegerJava8 { static ArrayList<BigIntegerJava8> BigIntegerJava8_allInstances = new ArrayList<BigIntegerJava8>();

  BigIntegerJava8() { BigIntegerJava8_allInstances.add(this); }

  static BigIntegerJava8 createBigIntegerJava8() { BigIntegerJava8 result = new BigIntegerJava8();
    return result; }

  String bigintegerjava8Id = ""; /* primary */
  static Map<String,BigIntegerJava8> BigIntegerJava8_index = new HashMap<String,BigIntegerJava8>();

  static BigIntegerJava8 createByPKBigIntegerJava8(String bigintegerjava8Idx)
  { BigIntegerJava8 result = BigIntegerJava8.BigIntegerJava8_index.get(bigintegerjava8Idx);
    if (result != null) { return result; }
    result = new BigIntegerJava8();
    BigIntegerJava8.BigIntegerJava8_index.put(bigintegerjava8Idx,result);
    result.bigintegerjava8Id = bigintegerjava8Idx;
    return result; }

  static void killBigIntegerJava8(String bigintegerjava8Idx)
  { BigIntegerJava8 rem = BigIntegerJava8_index.get(bigintegerjava8Idx);
    if (rem == null) { return; }
    ArrayList<BigIntegerJava8> remd = new ArrayList<BigIntegerJava8>();
    remd.add(rem);
    BigIntegerJava8_index.remove(bigintegerjava8Idx);
    BigIntegerJava8_allInstances.removeAll(remd);
  }


  public void bigintop()
  {
    long bb = 0;
    bb = Long.decode("10000000").longValue();
    long bx = 0;
    bx = Long.decode((99999999 + "")).longValue();
    long x = 0;
    x = bb + bx;
    x = (bb / 1);
    double d = 0.0;
    d = Double.parseDouble((bb + ""));
    x = Ocl.gcd(bb,bx);
    x = Math.pow(bb,5);
    x = (bb - bx);
  }

}

