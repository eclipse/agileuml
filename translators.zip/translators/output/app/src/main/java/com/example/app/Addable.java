package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

abstract class Addable { static ArrayList<Addable> Addable_allInstances = new ArrayList<Addable>();
  Addable() { Addable_allInstances.add(this); }

  String addableId = ""; /* primary */
  static Map<String,Addable> Addable_index = new HashMap<String,Addable>();

  static Addable createByPKAddable(String addableIdx)
  { Addable result = Addable.Addable_index.get(addableIdx);
    if (result != null) { return result; }
    result = new Addable();
    Addable.Addable_index.put(addableIdx,result);
    result.addableId = addableIdx;
    return result; }

  static void killAddable(String addableIdx)
  { Addable rem = Addable_index.get(addableIdx);
    if (rem == null) { return; }
    ArrayList<Addable> remd = new ArrayList<Addable>();
    remd.add(rem);
    Addable_index.remove(addableIdx);
    Addable_allInstances.removeAll(remd);
  }


  public Addable<T> add(T x)
  {
    Addable<T> result = null;
  }

}

