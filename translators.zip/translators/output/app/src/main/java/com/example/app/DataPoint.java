package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class DataPoint { static ArrayList<DataPoint> DataPoint_allInstances = new ArrayList<DataPoint>();

  DataPoint() { DataPoint_allInstances.add(this); }

  static DataPoint createDataPoint() { DataPoint result = new DataPoint();
    return result; }

  double x = 0.0;
  double y = 0.0;
  double prodxy = 0.0;
  double diffxsq = 0.0;
  double diffysq = 0.0;
  String datapointId = ""; /* primary */
  static Map<String,DataPoint> DataPoint_index = new HashMap<String,DataPoint>();

  static DataPoint createByPKDataPoint(String datapointIdx)
  { DataPoint result = DataPoint.DataPoint_index.get(datapointIdx);
    if (result != null) { return result; }
    result = new DataPoint();
    DataPoint.DataPoint_index.put(datapointIdx,result);
    result.datapointId = datapointIdx;
    return result; }

  static void killDataPoint(String datapointIdx)
  { DataPoint rem = DataPoint_index.get(datapointIdx);
    if (rem == null) { return; }
    ArrayList<DataPoint> remd = new ArrayList<DataPoint>();
    remd.add(rem);
    DataPoint_index.remove(datapointIdx);
    DataPoint_allInstances.removeAll(remd);
  }


  public static DataPoint newDataPoint()
  {
    DataPoint result = null;
    result = DataPoint.createDataPoint();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

