package com.example.app;

public class calcVO
{ 

  public calcVO() {}

}


