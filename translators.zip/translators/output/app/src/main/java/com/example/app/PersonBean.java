package com.example.app.ui.main;

import java.util.Vector;

import android.content.Context;

public class PersonBean
{ ModelFacade model;
  private String name = "";
  private String age = "";
  private int iage = 0;
  private String id = "";
  private Vector errors = new Vector();

  public PersonBean(Context _c)
  { model = ModelFacade.getInstance(_c); }

  public void setname(String namex)
  { name = namex; }

  public void setage(String agex)
  { age = agex; }

  public void setid(String idx)
  { id = idx; }

  public void resetData()
  { name = "";
    age = "";
    id = "";
    }

  public boolean iscreatePersonerror()
  { errors.clear(); 
    try { iage = Integer.parseInt(age); }
    catch (Exception e)
    { errors.add("age is not an integer"); }
    return errors.size() > 0; }

  public boolean islistPersonerror()
  { errors.clear(); 
    return errors.size() > 0; }

  public String errors() { return errors.toString(); }

  public void createPerson()
  { model.createPerson(new PersonVO(name, iage, id));
    resetData(); }

}

