package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Outpatient extends Patient { static ArrayList<Outpatient> Outpatient_allInstances = new ArrayList<Outpatient>();

  Outpatient() { super();
    Outpatient_allInstances.add(this); }

  static Outpatient createOutpatient() { Outpatient result = new Outpatient();
    return result; }

}

