package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class NewPerson { static ArrayList<NewPerson> NewPerson_allInstances = new ArrayList<NewPerson>();

  NewPerson() { NewPerson_allInstances.add(this); }

  static NewPerson createNewPerson() { NewPerson result = new NewPerson();
    return result; }


  public void newPerson(String nme)
  {
  }

}

