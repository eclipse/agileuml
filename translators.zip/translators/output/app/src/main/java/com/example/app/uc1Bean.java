package com.example.app;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class uc1Bean
{ ModelFacade model = null;

  private List errors = new ArrayList();

  public uc1Bean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void resetData()
  { }

  public boolean isuc1error()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void uc1()
  { model.uc1(); }

}

