package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.ImageView;
import android.widget.TextView;


public class logoutFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  logoutBean logoutbean;

  Button logoutOkButton;
  Button logoutcancelButton;


 public logoutFragment() {}

  public static logoutFragment newInstance(Context c)
  { logoutFragment fragment = new logoutFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.logout_layout, container, false);
    Bundle data = getArguments();
    logoutbean = new logoutBean(myContext);
    logoutOkButton = root.findViewById(R.id.logoutOK);
    logoutOkButton.setOnClickListener(this);
    logoutcancelButton = root.findViewById(R.id.logoutCancel);
    logoutcancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.logoutOK)
    { logoutOK(_v); }
    else if (_v.getId() == R.id.logoutCancel)
    { logoutCancel(_v); }
  }

  public void logoutOK(View _v) 
  { 
    if (logoutbean.islogouterror())
    { Log.w(getClass().getName(), logoutbean.errors());
      Toast.makeText(myContext, "Errors: " + logoutbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { logoutbean.logout(); }
  }


  public void logoutCancel(View _v)
  { logoutbean.resetData();
  }
}
