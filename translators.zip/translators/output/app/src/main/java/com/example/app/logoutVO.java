package com.example.app.ui.main;

public class logoutVO
{ 

  public logoutVO() {}

}


