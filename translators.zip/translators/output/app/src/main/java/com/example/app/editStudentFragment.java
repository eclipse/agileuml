package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class editStudentFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  ModelFacade model;
  StudentBean studentbean;
  EditText forenameTextField;
  String forenameData = "";
  EditText surnameTextField;
  String surnameData = "";
  EditText birthdateTextField;
  String birthdateData = "";
  EditText codeTextField;
  String codeData = "";
  Button okButton;
  Button cancelButton;


 public editStudentFragment() {}

  public static editStudentFragment newInstance(Context c)
  { editStudentFragment fragment = new editStudentFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.editstudent_layout, container, false);
    Bundle data = getArguments();
    model = ModelFacade.getInstance(myContext);
    StudentVO selectedItem = model.getSelectedStudent();
    forenameTextField = (EditText) root.findViewById(R.id.editStudentforenameField);
    if (selected != null)
    { forenameTextField.setText(selected.forename + ""); }
    surnameTextField = (EditText) root.findViewById(R.id.editStudentsurnameField);
    if (selected != null)
    { surnameTextField.setText(selected.surname + ""); }
    birthdateTextField = (EditText) root.findViewById(R.id.editStudentbirthdateField);
    if (selected != null)
    { birthdateTextField.setText(selected.birthdate + ""); }
    codeTextField = (EditText) root.findViewById(R.id.editStudentcodeField);
    if (selected != null)
    { codeTextField.setText(selected.code + ""); }
    studentbean = new StudentBean(myContext);
    okButton = root.findViewById(R.id.editStudentOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.editStudentCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.editStudentOK)
    { editStudentOK(_v); }
    else if (_v.getId() == R.id.editStudentCancel)
    { editStudentCancel(_v); }
  }

  public void editStudentOK(View _v) 
  { 
    forenameData = forenameTextField.getText() + "";
    studentbean.setforename(forenameData);
    surnameData = surnameTextField.getText() + "";
    studentbean.setsurname(surnameData);
    birthdateData = birthdateTextField.getText() + "";
    studentbean.setbirthdate(birthdateData);
    codeData = codeTextField.getText() + "";
    studentbean.setcode(codeData);
    if (studentbean.iseditStudenterror())
    { Log.w(getClass().getName(), studentbean.errors());
      Toast.makeText(myContext, "Errors: " + studentbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { studentbean.editStudent(); }
  }


  public void editStudentCancel(View _v)
  { studentbean.resetData();
    forenameTextField.setText("");
    surnameTextField.setText("");
    birthdateTextField.setText("");
    codeTextField.setText("");
  }
}
