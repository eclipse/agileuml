package com.example.app.ui.main;

import java.util.List;
import java.util.ArrayList;

public class PersonVO
{ 
  String name;
  int age;
  String id;

  public PersonVO() {}

  public PersonVO(String namex,int agex,String idx)
  {    name = namex;
   age = agex;
   id = idx;
  }

  public PersonVO(Person _x)
  {
   name = _x.name;
   age = _x.age;
   id = _x.id;
  }

  public String toString()
  { return ("name= " + name + "," + "age= " + age + "," + "id= " + id); }

  public static List<String> toStringList(List<PersonVO> list)
  { List<String> _res = new ArrayList<String>();
    for (int i = 0; i < list.size(); i++)
    { PersonVO _x = (PersonVO) list.get(i);
      _res.add(_x.toString()); 
    }
    return _res;
  }

  public String getname()
  { return name; }

  public int getage()
  { return age; }

  public String getid()
  { return id; }

  public void setname(String _x)
  { name = _x; }

  public void setage(int _x)
  { age = _x; }

  public void setid(String _x)
  { id = _x; }

}


