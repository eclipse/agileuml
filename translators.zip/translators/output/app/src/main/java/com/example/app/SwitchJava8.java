package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class SwitchJava8 { static ArrayList<SwitchJava8> SwitchJava8_allInstances = new ArrayList<SwitchJava8>();

  SwitchJava8() { SwitchJava8_allInstances.add(this); }

  static SwitchJava8 createSwitchJava8() { SwitchJava8 result = new SwitchJava8();
    return result; }

  String switchjava8Id = ""; /* primary */
  static Map<String,SwitchJava8> SwitchJava8_index = new HashMap<String,SwitchJava8>();

  static SwitchJava8 createByPKSwitchJava8(String switchjava8Idx)
  { SwitchJava8 result = SwitchJava8.SwitchJava8_index.get(switchjava8Idx);
    if (result != null) { return result; }
    result = new SwitchJava8();
    SwitchJava8.SwitchJava8_index.put(switchjava8Idx,result);
    result.switchjava8Id = switchjava8Idx;
    return result; }

  static void killSwitchJava8(String switchjava8Idx)
  { SwitchJava8 rem = SwitchJava8_index.get(switchjava8Idx);
    if (rem == null) { return; }
    ArrayList<SwitchJava8> remd = new ArrayList<SwitchJava8>();
    remd.add(rem);
    SwitchJava8_index.remove(switchjava8Idx);
    SwitchJava8_allInstances.removeAll(remd);
  }


  public int switchop()
  {
    int result = 0;
    ArrayList<Integer> values = new ArrayList<Integer>();
    values = Ocl.initialiseSequence(99,95,78,72,76,72,70,66,61,60,55,50,48,40,36,30,22,10);
    int evens = 0;
    evens = 0;
    int odds = 0;
    odds = 0;
    int leap = 0;
    leap = 0;
    int total = 0;
    total = 0;
    int i = 0;
    i = 0;
    while (i < values.size())
    {
      for (int _i : Ocl.integerSubrange(1,1))
    {
      if (((((int) (values).get(i + 1 - 1)) % 4) == 0))
    {
      leap = leap + 1;
    evens = evens + 1;
    total = total + 1;
    break;
    }
    else {
      {}
    }
    if (((((int) (values).get(i + 1 - 1)) % 4) == 2))
    {
      evens = evens + 1;
    total = total + 1;
    break;
    }
    else {
      {}
    }
    odds = odds + 1;
    total = total + 1;
    }
    i = i + 1;
    }
    return total;
  }

}

