package com.example.app;

public class uc1VO
{ 

  public uc1VO() {}

}


