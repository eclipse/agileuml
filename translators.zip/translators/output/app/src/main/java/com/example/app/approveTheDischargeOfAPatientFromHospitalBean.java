package com.example.app.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class approveTheDischargeOfAPatientFromHospitalBean
{ ModelFacade model = null;

  private String doctorx = "";
  private Doctor instance_doctorx = null;
  private String patientx = "";
  private Patient instance_patientx = null;
  private List errors = new ArrayList();

  public approveTheDischargeOfAPatientFromHospitalBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setdoctorx(String doctorxx)
  { doctorx = doctorxx; }

  public void setpatientx(String patientxx)
  { patientx = patientxx; }

  public void resetData()
  { doctorx = "";
    patientx = "";
    }

  public boolean isapproveTheDischargeOfAPatientFromHospitalerror()
  { errors.clear(); 
    instance_doctorx = model.getDoctorByPK(doctorx);
    if (instance_doctorx == null)
    { errors.add("doctorx must be a valid Doctor id"); }
    instance_patientx = model.getPatientByPK(patientx);
    if (instance_patientx == null)
    { errors.add("patientx must be a valid Patient id"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void approveTheDischargeOfAPatientFromHospital()
  { model.approveTheDischargeOfAPatientFromHospital(instance_doctorx,instance_patientx); }

}

