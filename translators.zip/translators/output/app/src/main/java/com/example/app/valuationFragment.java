package com.example.app5.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app5.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class valuationFragment extends Fragment implements OnClickListener, AdapterView.OnItemSelectedListener
{ View root;
  Context myContext;
  valuationBean valuationbean;

  Spinner bondSpinner;
  List<String> bondListItems = new ArrayList<String>();
  String bondData = "";
  TextView valuationResult;
  Button okButton;
  Button cancelButton;


 public valuationFragment() {}

  public static valuationFragment newInstance(Context c)
  { valuationFragment fragment = new valuationFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.valuation_layout, container, false);
    Bundle data = getArguments();
    bondSpinner = (Spinner) root.findViewById(R.id.valuationbondSpinner);
    bondListItems = ModelFacade.getInstance(myContext).allBondids();
    ArrayAdapter<String> bondAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,bondListItems);
    bondAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    bondSpinner.setAdapter(bondAdapter);
    bondSpinner.setOnItemSelectedListener(this);

    valuationResult = (TextView) root.findViewById(R.id.valuationResult);
    valuationbean = new valuationBean(myContext);
    okButton = root.findViewById(R.id.valuationOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.valuationCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.valuationOK)
    { valuationOK(_v); }
    else if (_v.getId() == R.id.valuationCancel)
    { valuationCancel(_v); }
  }

  public void valuationOK(View _v) 
  { 
    valuationbean.setbond(bondData);
    if (valuationbean.isvaluationerror())
    { Log.w(getClass().getName(), valuationbean.errors());
      Toast.makeText(myContext, "Errors: " + valuationbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { valuationResult.setText(valuationbean.valuation() + ""); }
  }


  public void valuationCancel(View _v)
  { valuationbean.resetData();
    valuationResult.setText("");
  }
  public void onItemSelected(AdapterView<?> _parent, View _v, int _position, long _id)
  {     if (_parent == bondSpinner)
    { bondData = bondListItems.get(_position); }
 }

  public void onNothingSelected(AdapterView<?> _parent)
  {     bondData = "";
 }

}
