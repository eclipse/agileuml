package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class editPersonFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  ModelFacade model;
  PersonBean personbean;
  EditText nameTextField;
  String nameData = "";
  EditText addressTextField;
  String addressData = "";
  EditText personIdTextField;
  String personIdData = "";
  Button okButton;
  Button cancelButton;


 public editPersonFragment() {}

  public static editPersonFragment newInstance(Context c)
  { editPersonFragment fragment = new editPersonFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.editperson_layout, container, false);
    Bundle data = getArguments();
    model = ModelFacade.getInstance(myContext);
    PersonVO selectedItem = model.getSelectedPerson();
    nameTextField = (EditText) root.findViewById(R.id.editPersonnameField);
    if (selected != null)
    { nameTextField.setText(selected.name + ""); }
    addressTextField = (EditText) root.findViewById(R.id.editPersonaddressField);
    if (selected != null)
    { addressTextField.setText(selected.address + ""); }
    personIdTextField = (EditText) root.findViewById(R.id.editPersonpersonIdField);
    if (selected != null)
    { personIdTextField.setText(selected.personId + ""); }
    personbean = new PersonBean(myContext);
    okButton = root.findViewById(R.id.editPersonOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.editPersonCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.editPersonOK)
    { editPersonOK(_v); }
    else if (_v.getId() == R.id.editPersonCancel)
    { editPersonCancel(_v); }
  }

  public void editPersonOK(View _v) 
  { 
    nameData = nameTextField.getText() + "";
    personbean.setname(nameData);
    addressData = addressTextField.getText() + "";
    personbean.setaddress(addressData);
    personIdData = personIdTextField.getText() + "";
    personbean.setpersonId(personIdData);
    if (personbean.iseditPersonerror())
    { Log.w(getClass().getName(), personbean.errors());
      Toast.makeText(myContext, "Errors: " + personbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { personbean.editPerson(); }
  }


  public void editPersonCancel(View _v)
  { personbean.resetData();
    nameTextField.setText("");
    addressTextField.setText("");
    personIdTextField.setText("");
  }
}
