package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ArrayList2Java8 { static ArrayList<ArrayList2Java8> ArrayList2Java8_allInstances = new ArrayList<ArrayList2Java8>();

  ArrayList2Java8() { ArrayList2Java8_allInstances.add(this); }

  static ArrayList2Java8 createArrayList2Java8() { ArrayList2Java8 result = new ArrayList2Java8();
    return result; }

  String arraylist2java8Id = ""; /* primary */
  static Map<String,ArrayList2Java8> ArrayList2Java8_index = new HashMap<String,ArrayList2Java8>();

  static ArrayList2Java8 createByPKArrayList2Java8(String arraylist2java8Idx)
  { ArrayList2Java8 result = ArrayList2Java8.ArrayList2Java8_index.get(arraylist2java8Idx);
    if (result != null) { return result; }
    result = new ArrayList2Java8();
    ArrayList2Java8.ArrayList2Java8_index.put(arraylist2java8Idx,result);
    result.arraylist2java8Id = arraylist2java8Idx;
    return result; }

  static void killArrayList2Java8(String arraylist2java8Idx)
  { ArrayList2Java8 rem = ArrayList2Java8_index.get(arraylist2java8Idx);
    if (rem == null) { return; }
    ArrayList<ArrayList2Java8> remd = new ArrayList<ArrayList2Java8>();
    remd.add(rem);
    ArrayList2Java8_index.remove(arraylist2java8Idx);
    ArrayList2Java8_allInstances.removeAll(remd);
  }


  public boolean arr2op()
  {
    boolean result = false;
    HashSet st = new HashSet();
    st = (new HashSet());
    st = Ocl.includingSet(st,"aa");
    st = Ocl.includingSet(st,"bb");
    ArrayList sq = new ArrayList();
    sq = Ocl.union((new ArrayList()),st);
    sq = Ocl.union(sq,st);
    int i = 0;
    i = ((sq.lastIndexOf("bb") + 1) - 1);
    String s = "";
    s = ((String) (((Object) sq.get(i + 1 - 1))));
    sq = Ocl.removeAt(sq,i + 1);
    sq.set(0 + 1 - 1,"xx");
    i = sq.size();
    return (sq.size() == 0);
  }

}

