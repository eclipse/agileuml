package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.ImageView;
import android.widget.TextView;


public class registerFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  registerBean registerbean;
  loginBean loginbean;

  EditText registeremailTextField;
  String registeremailData = "";
  EditText registerpasswordTextField;
  String registerpasswordData = "";
  Button registerOkButton;
  Button registercancelButton;
  Button loginOkButton;
  EditText loginemailTextField;
  String loginemailData = "";
  EditText loginpasswordTextField;
  String loginpasswordData = "";


 public registerFragment() {}

  public static registerFragment newInstance(Context c)
  { registerFragment fragment = new registerFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.register_layout, container, false);
    Bundle data = getArguments();
    registeremailTextField = (EditText) root.findViewById(R.id.registeremailField);
    registerpasswordTextField = (EditText) root.findViewById(R.id.registerpasswordField);
    registerbean = new registerBean(myContext);
    loginemailTextField = (EditText) root.findViewById(R.id.loginemailField);
    loginpasswordTextField = (EditText) root.findViewById(R.id.loginpasswordField);
    loginbean = new loginBean(myContext);
    registerOkButton = root.findViewById(R.id.registerOK);
    registerOkButton.setOnClickListener(this);
    registercancelButton = root.findViewById(R.id.registerCancel);
    registercancelButton.setOnClickListener(this);
    loginOkButton = root.findViewById(R.id.loginOK);
    loginOkButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.registerOK)
    { registerOK(_v); }
    else if (_v.getId() == R.id.registerCancel)
    { registerCancel(_v); }
    else if (_v.getId() == R.id.loginOK)
    { loginOK(_v); }
  }

  public void registerOK(View _v) 
  { 
    registeremailData = registeremailTextField.getText() + "";
    registerbean.setemail(registeremailData);
    registerpasswordData = registerpasswordTextField.getText() + "";
    registerbean.setpassword(registerpasswordData);
    if (registerbean.isregistererror())
    { Log.w(getClass().getName(), registerbean.errors());
      Toast.makeText(myContext, "Errors: " + registerbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { registerbean.register(); }
  }


  public void registerCancel(View _v)
  { registerbean.resetData();
    registeremailTextField.setText("");
    registerpasswordTextField.setText("");
  }
  public void loginOK(View _v) 
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    loginemailData = loginemailTextField.getText() + "";
    loginbean.setemail(loginemailData);
    loginpasswordData = loginpasswordTextField.getText() + "";
    loginbean.setpassword(loginpasswordData);
    if (loginbean.isloginerror())
    { Log.w(getClass().getName(), loginbean.errors()); 
      Toast.makeText(myContext, "Errors: " + loginbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { loginbean.login(); }
  }


}
