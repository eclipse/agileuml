package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Module { static ArrayList<Module> Module_allInstances = new ArrayList<Module>();

  Module() { Module_allInstances.add(this); }

  static Module createModule() { Module result = new Module();
    return result; }

  ArrayList students = (new ArrayList());
  String moduleId = ""; /* primary */
  static Map<String,Module> Module_index = new HashMap<String,Module>();

  static Module createByPKModule(String moduleIdx)
  { Module result = Module.Module_index.get(moduleIdx);
    if (result != null) { return result; }
    result = new Module();
    Module.Module_index.put(moduleIdx,result);
    result.moduleId = moduleIdx;
    return result; }

  static void killModule(String moduleIdx)
  { Module rem = Module_index.get(moduleIdx);
    if (rem == null) { return; }
    ArrayList<Module> remd = new ArrayList<Module>();
    remd.add(rem);
    Module_index.remove(moduleIdx);
    Module_allInstances.removeAll(remd);
  }


  public void addStudent(String x)
  {
    Student sx = null;
    sx = Student.newStudent(x);
    students = Ocl.includingSequence(students,sx);
  }


  public static Module newModule()
  {
    Module result = null;
    result = Module.createModule();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

