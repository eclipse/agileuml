package com.example.app.ui.main;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.app.R;
import com.example.app.ui.main.listPersonFragment.OnListFragmentInteractionListener;
import java.util.List;

public class PersonRecyclerViewAdapter extends RecyclerView.Adapter<PersonRecyclerViewAdapter.ViewHolder>
{ private final List<PersonVO> mValues;
  private final OnListFragmentInteractionListener mListener;

  public PersonRecyclerViewAdapter(List<PersonVO> items, OnListFragmentInteractionListener listener)
  { mValues = items;
    mListener = listener;
  }

  @Override
  public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
  { View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_person, parent, false);
    return new ViewHolder(view);
  }
  
  @Override
  public void onBindViewHolder(final ViewHolder holder, int position)
  { holder.mItem = mValues.get(position);
  holder.listPersonnameView.setText(" " +  mValues.get(position).name + " ");
  holder.listPersonageView.setText(" " +  mValues.get(position).age + " ");
  holder.listPersonidView.setText(" " +  mValues.get(position).id + " ");
 
  holder.mView.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        if (null != mListener)
        { mListener.onListFragmentInteraction(holder.mItem); }
   }
     });
   }
  
  @Override
  public int getItemCount()
  { return mValues.size(); }
   
  public class ViewHolder extends RecyclerView.ViewHolder 
  { public final View mView;
    public final TextView listPersonnameView;
    public final TextView listPersonageView;
    public final TextView listPersonidView;
    public PersonVO mItem;

    public ViewHolder(View view)
    { super(view);
       mView = view;
     listPersonnameView = (TextView) view.findViewById(R.id.listPersonnameView);
     listPersonageView = (TextView) view.findViewById(R.id.listPersonageView);
     listPersonidView = (TextView) view.findViewById(R.id.listPersonidView);
    }

     @Override
     public String toString() 
     { return super.toString() + " " + mItem; }
      
  }
}
