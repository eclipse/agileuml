package com.example.app.ui.main.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.ui.main.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class createStudentFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  StudentBean studentbean;
  EditText codeTextField;
  String codeData = "";
  EditText forenameTextField;
  String forenameData = "";
  EditText surnameTextField;
  String surnameData = "";
  EditText birthdateTextField;
  String birthdateData = "";
  Button okButton;
  Button cancelButton;


 public createStudentFragment() {}

  public static createStudentFragment newInstance(Context c)
  { createStudentFragment fragment = new createStudentFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.createstudent_layout, container, false);
    Bundle data = getArguments();
    codeTextField = (EditText) root.findViewById(R.id.createcodeField);
    forenameTextField = (EditText) root.findViewById(R.id.createforenameField);
    surnameTextField = (EditText) root.findViewById(R.id.createsurnameField);
    birthdateTextField = (EditText) root.findViewById(R.id.createbirthdateField);
    studentbean = new StudentBean(myContext);
    okButton = root.findViewById(R.id.createOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.createCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.createOK)
    { createOK(_v); }
    else if (_v.getId() == R.id.createCancel)
    { createCancel(_v); }
  }

  public void createOK(View _v) 
  { 
    codeData = codeTextField.getText() + "";
    studentbean.setcode(codeData);
    forenameData = forenameTextField.getText() + "";
    studentbean.setforename(forenameData);
    surnameData = surnameTextField.getText() + "";
    studentbean.setsurname(surnameData);
    birthdateData = birthdateTextField.getText() + "";
    studentbean.setbirthdate(birthdateData);
    if (studentbean.iscreateerror())
    { Log.w(getClass().getName(), studentbean.errors());
      Toast.makeText(myContext, "Errors: " + studentbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { studentbean.create(); }
  }


  public void createCancel(View _v)
  { studentbean.resetData();
    codeTextField.setText("");
    forenameTextField.setText("");
    surnameTextField.setText("");
    birthdateTextField.setText("");
  }
}
