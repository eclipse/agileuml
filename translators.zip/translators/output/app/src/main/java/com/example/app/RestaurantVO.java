package com.example.app14.ui.main;

import java.util.List;
import java.util.ArrayList;

public class RestaurantVO
{ 
  String name;
  String website;

  public RestaurantVO() {}

  public RestaurantVO(String namex,String websitex)
  {    name = namex;
   website = websitex;
  }

  public RestaurantVO(Restaurant _x)
  {
   name = _x.name;
   website = _x.website;
  }

  public String toString()
  { return ("name= " + name + "," + "website= " + website); }

  public static List<String> toStringList(List<RestaurantVO> list)
  { List<String> _res = new ArrayList<String>();
    for (int i = 0; i < list.size(); i++)
    { RestaurantVO _x = (RestaurantVO) list.get(i);
      _res.add(_x.toString()); 
    }
    return _res;
  }

  public String getname()
  { return name; }

  public String getwebsite()
  { return website; }

  public void setname(String _x)
  { name = _x; }

  public void setwebsite(String _x)
  { website = _x; }

}


