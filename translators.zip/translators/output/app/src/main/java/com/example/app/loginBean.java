package com.example.app.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class loginBean
{ ModelFacade model = null;

  private String email = "";
  private String password = "";
  private List errors = new ArrayList();

  public loginBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setemail(String emailx)
  { email = emailx; }

  public void setpassword(String passwordx)
  { password = passwordx; }

  public void resetData()
  { email = "";
    password = "";
    }

  public boolean isloginerror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void login()
  { model.login(email,password); }

}

