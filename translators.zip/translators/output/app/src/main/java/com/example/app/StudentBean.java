package com.example.app.ui.main;

import java.util.Vector;

import android.content.Context;

public class StudentBean
{ ModelFacade model;
  private String code = "";
  private Vector errors = new Vector();

  public StudentBean(Context _c)
  { model = ModelFacade.getInstance(_c); }

  public void setcode(String codex)
  { code = codex; }

  public void resetData()
  { code = "";
    }

  public String errors() { return errors.toString(); }

}

