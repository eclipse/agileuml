package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class LongJava8 { static ArrayList<LongJava8> LongJava8_allInstances = new ArrayList<LongJava8>();

  LongJava8() { LongJava8_allInstances.add(this); }

  static LongJava8 createLongJava8() { LongJava8 result = new LongJava8();
    return result; }

  String longjava8Id = ""; /* primary */
  static Map<String,LongJava8> LongJava8_index = new HashMap<String,LongJava8>();

  static LongJava8 createByPKLongJava8(String longjava8Idx)
  { LongJava8 result = LongJava8.LongJava8_index.get(longjava8Idx);
    if (result != null) { return result; }
    result = new LongJava8();
    LongJava8.LongJava8_index.put(longjava8Idx,result);
    result.longjava8Id = longjava8Idx;
    return result; }

  static void killLongJava8(String longjava8Idx)
  { LongJava8 rem = LongJava8_index.get(longjava8Idx);
    if (rem == null) { return; }
    ArrayList<LongJava8> remd = new ArrayList<LongJava8>();
    remd.add(rem);
    LongJava8_index.remove(longjava8Idx);
    LongJava8_allInstances.removeAll(remd);
  }


  public String oplong()
  {
    String result = "";
    long lx = 0;
    lx = Long.decode(("0xFFFFFF" + "")).longValue();
    lx = Long.decode((4000000 + "")).longValue();
    lx = Long.decode("07777").longValue();
    int b = 0;
    b = Integer.decode((lx + "")).intValue();
    double f = 0.0;
    f = Double.parseDouble((lx + ""));
    long lv = 0;
    lv = -9223372036854775808;
    return MathLib.decimal2binary(lv);
  }

}

