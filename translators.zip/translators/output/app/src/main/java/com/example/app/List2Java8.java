package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class List2Java8 { static ArrayList<List2Java8> List2Java8_allInstances = new ArrayList<List2Java8>();

  List2Java8() { List2Java8_allInstances.add(this); }

  static List2Java8 createList2Java8() { List2Java8 result = new List2Java8();
    return result; }

  String list2java8Id = ""; /* primary */
  static Map<String,List2Java8> List2Java8_index = new HashMap<String,List2Java8>();

  static List2Java8 createByPKList2Java8(String list2java8Idx)
  { List2Java8 result = List2Java8.List2Java8_index.get(list2java8Idx);
    if (result != null) { return result; }
    result = new List2Java8();
    List2Java8.List2Java8_index.put(list2java8Idx,result);
    result.list2java8Id = list2java8Idx;
    return result; }

  static void killList2Java8(String list2java8Idx)
  { List2Java8 rem = List2Java8_index.get(list2java8Idx);
    if (rem == null) { return; }
    ArrayList<List2Java8> remd = new ArrayList<List2Java8>();
    remd.add(rem);
    List2Java8_index.remove(list2java8Idx);
    List2Java8_allInstances.removeAll(remd);
  }


  public String list2op()
  {
    String result = "";
    ArrayList lt = new ArrayList();
    lt = (new ArrayList());
    lt = Ocl.append(lt,"cc");
    lt = Ocl.prepend(lt,"bb");
    lt = Ocl.prepend(lt,"aa");
    String ss = "";
    ss = Ocl.last(lt);
    int i = 0;
    i = ((lt.indexOf("bb") + 1) - 1);
    ss = ((String) (Ocl.first(lt)));
    lt = Ocl.tail(lt);
    lt.set(0 + 1 - 1,"xx");
    return (lt + "");
  }

}

