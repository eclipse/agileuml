package com.example.app;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;

import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity
{ calcBean calcbean;



  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.activity_main);
    calcbean = new calcBean(this);
  }




  public void calcOK(View _v) 
  { InputMethodManager _imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (calcbean.iscalcerror())
    { Log.w(getClass().getName(), calcbean.errors());
      Toast.makeText(this, "Errors: " + calcbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { calcbean.calc(); }
  }



  public void calcCancel(View _v)
  { calcbean.resetData();
  }
}
