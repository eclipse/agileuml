package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class AuxCalc { static HashSet<AuxCalc> AuxCalc_allInstances = new HashSet<AuxCalc>();

  AuxCalc() { AuxCalc_allInstances.add(this); }

  static AuxCalc createAuxCalc() { AuxCalc result = new AuxCalc();
    return result; }


  public double auxCalc(double age, double weight)
  {
    double result = 0;
    return result;
  }

}

