package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;

class Word { static ArrayList<Word> Word_allInstances = new ArrayList<Word>();

  Word() { Word_allInstances.add(this); }

  static Word createWord() { Word result = new Word();
    return result; }

  String text = "";
  String pos = "";
  String wordId = ""; /* primary */
  static Map<String,Word> Word_index = new HashMap<String,Word>();

  static Word createByPKWord(String wordIdx)
  { Word result = Word.Word_index.get(wordIdx);
    if (result != null) { return result; }
    result = new Word();
    Word.Word_index.put(wordIdx,result);
    result.wordId = wordIdx;
    return result; }

  static void killWord(String wordIdx)
  { Word rem = Word_index.get(wordIdx);
    if (rem == null) { return; }
    ArrayList<Word> remd = new ArrayList<Word>();
    remd.add(rem);
    Word_index.remove(wordIdx);
    Word_allInstances.removeAll(remd);
  }


  public String streamOp3()
  {
    String result = "";
    ArrayList<Word> words = new ArrayList<Word>();
    words = (new ArrayList());
    Word w1 = null;
    w1 = Word.newWord();
    w1.text = "aa";
    Word w2 = null;
    w2 = Word.newWord();
    w2.text = "bb";
    Word w3 = null;
    w3 = Word.newWord();
    w3.text = "cc";
    Word w4 = null;
    w4 = Word.newWord();
    w4.text = "aa";
    w4.pos = "VB";
    words = Ocl.includingSequence(words,w1);
    words = Ocl.includingSequence(words,w2);
    words = Ocl.includingSequence(words,w3);
    words = Ocl.includingSequence(words,w4);
    ArrayList<String> strm = new ArrayList<String>();
    strm = Ocl.asOrderedSet((Ocl.collectSequence(words,(_var)->{return _var.text;})));
    long x = 0;
    x = strm.size();
    Ocl.displaylong(x);
    boolean total = false;
    total = Ocl.forAll(words, (_var)->{ return _var.pos.equals("NN"); });
    return total + "";
  }


  public static Word newWord()
  {
    Word result = null;
    result = Word.createWord();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

