package com.example.app;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class auxCalcBean
{ ModelFacade model = null;

  private String age = "";
  private double dage = 0;
  private String weight = "";
  private double dweight = 0;
  private List errors = new ArrayList();

  public auxCalcBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setage(String agex)
  { age = agex; }

  public void setweight(String weightx)
  { weight = weightx; }

  public void resetData()
  { age = "";
    weight = "";
    }

  public boolean isauxCalcerror()
  { errors.clear(); 
    try { dage = Double.parseDouble(age); }
    catch (Exception e)
    { errors.add("age is not a double"); }
    try { dweight = Double.parseDouble(weight); }
    catch (Exception e)
    { errors.add("weight is not a double"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public double auxCalc()
  { return model.auxCalc(dage,dweight); }

}

