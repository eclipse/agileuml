package com.example.app.ui.main;

public class newCompanyVO
{ 
 private String iden;

  public newCompanyVO() {}

  public newCompanyVO(String idenx)
  {    iden = idenx;
  }

  public String getiden()
  { return iden; }

  public void setiden(String _x)
  { iden = _x; }

}


