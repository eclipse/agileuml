package com.example.app7;

public class graphVO
{ 

  public graphVO() {}

}


