package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class A implements IA { static ArrayList<A> A_allInstances = new ArrayList<A>();

  A() { A_allInstances.add(this); }

  static A createA() { A result = new A();
    return result; }

  String aId = ""; /* primary */
  static Map<String,A> A_index = new HashMap<String,A>();

  static A createByPKA(String aIdx)
  { A result = A.A_index.get(aIdx);
    if (result != null) { return result; }
    result = new A();
    A.A_index.put(aIdx,result);
    result.aId = aIdx;
    return result; }

  static void killA(String aIdx)
  { A rem = A_index.get(aIdx);
    if (rem == null) { return; }
    ArrayList<A> remd = new ArrayList<A>();
    remd.add(rem);
    A_index.remove(aIdx);
    A_allInstances.removeAll(remd);
  }


  public void opA()
  {
    Ocl.displayString("opA");
  }


  public static A newA()
  {
    A result = null;
    result = A.createA();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

