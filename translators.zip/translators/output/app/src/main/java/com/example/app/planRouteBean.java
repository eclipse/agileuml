package com.example.app;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class planRouteBean
{ ModelFacade model = null;

  private String lats = "";
  private ArrayList<String> slats = new ArrayList<String>();
  private String lngs = "";
  private ArrayList<String> slngs = new ArrayList<String>();
  private List errors = new ArrayList();

  public planRouteBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setlats(String latsx)
  { lats = latsx; }

  public void setlngs(String lngsx)
  { lngs = lngsx; }

  public void resetData()
  { lats = "";
    lngs = "";
    }

  public boolean isplanRouteerror()
  { errors.clear(); 
    String[] split_lats = lats.split(" ");
    for (int _i = 0; _i < split_lats.length; _i++)
    { slats.add(split_lats[_i]); }
    if (slats.size() == 0)
    { errors.add("lats must have one or more values"); }
    String[] split_lngs = lngs.split(" ");
    for (int _i = 0; _i < split_lngs.length; _i++)
    { slngs.add(split_lngs[_i]); }
    if (slngs.size() == 0)
    { errors.add("lngs must have one or more values"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public double planRoute()
  { return model.planRoute(slats,slngs); }

}

