package com.example.app.ui.main;

import java.util.List;
import java.util.ArrayList;

public class CompanyVO
{ 
  String code;

  public CompanyVO() {}

  public CompanyVO(String codex)
  {    code = codex;
  }

  public CompanyVO(Company _x)
  {
   code = _x.code;
  }

  public String toString()
  { return ("code= " + code); }

  public static List<String> toStringList(List<CompanyVO> list)
  { List<String> _res = new ArrayList<String>();
    for (int i = 0; i < list.size(); i++)
    { CompanyVO _x = (CompanyVO) list.get(i);
      _res.add(_x.toString()); 
    }
    return _res;
  }

  public String getcode()
  { return code; }

  public void setcode(String _x)
  { code = _x; }

}


