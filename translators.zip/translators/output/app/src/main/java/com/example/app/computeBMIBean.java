package com.example.app4;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class computeBMIBean
{ ModelFacade model = null;

  private String height = "";
  private double dheight = 0;
  private String weight = "";
  private double dweight = 0;
  private List errors = new ArrayList();

  public computeBMIBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setheight(String heightx)
  { height = heightx; }

  public void setweight(String weightx)
  { weight = weightx; }

  public void resetData()
  { height = "";
    weight = "";
    }

  public boolean iscomputeBMIerror()
  { errors.clear(); 
    try { dheight = Double.parseDouble(height); }
    catch (Exception e)
    { errors.add("height is not a double"); }
    try { dweight = Double.parseDouble(weight); }
    catch (Exception e)
    { errors.add("weight is not a double"); }
    if (dheight > 0 && dheight <= 3) { }
    else { errors.add("Precondition: dheight > 0 && dheight <= 3 failed"); }
    if (dweight > 0 && dweight <= 300) { }
    else { errors.add("Precondition: dweight > 0 && dweight <= 300 failed"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public double computeBMI()
  { return model.computeBMI(dheight,dweight); }

}

