package com.example.app;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;


public class loginActivity extends AppCompatActivity
{ loginBean loginbean;

  EditText emailTextField;
  String emailData = "";
  EditText passwordTextField;
  String passwordData = "";
  TextView loginResult;


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.login_layout);
    emailTextField = (EditText) findViewById(R.id.loginemailField);
    passwordTextField = (EditText) findViewById(R.id.loginpasswordField);
    loginResult = (TextView) findViewById(R.id.loginResult);
    loginbean = new loginBean(this);
  }




  public void loginOK(View _v) 
  { InputMethodManager _imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    emailData = emailTextField.getText() + "";
    loginbean.setemail(emailData);
    passwordData = passwordTextField.getText() + "";
    loginbean.setpassword(passwordData);
    if (loginbean.isloginerror())
    { Log.w(getClass().getName(), loginbean.errors());
      Toast.makeText(this, "Errors: " + loginbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { loginResult.setText(loginbean.login() + ""); }
  }


  public void loginCancel(View _v)
  { loginbean.resetData();
    emailTextField.setText("");
    passwordTextField.setText("");
    loginResult.setText("");
  }
}
