package com.example.app.ui.main;

import java.util.List;
import java.util.ArrayList;

public class StudentVO
{ 
  String code;

  public StudentVO() {}

  public StudentVO(String codex)
  {    code = codex;
  }

  public StudentVO(Student _x)
  {
   code = _x.code;
  }

  public String toString()
  { return ("code= " + code); }

  public static List<String> toStringList(List<StudentVO> list)
  { List<String> _res = new ArrayList<String>();
    for (int i = 0; i < list.size(); i++)
    { StudentVO _x = (StudentVO) list.get(i);
      _res.add(_x.toString()); 
    }
    return _res;
  }

  public String getcode()
  { return code; }

  public void setcode(String _x)
  { code = _x; }

}


