package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class CClass { static ArrayList<CClass> CClass_allInstances = new ArrayList<CClass>();

  CClass() { CClass_allInstances.add(this); }

  static CClass createCClass() { CClass result = new CClass();
    return result; }

  String cclassId = ""; /* primary */
  static Map<String,CClass> CClass_index = new HashMap<String,CClass>();

  static CClass createByPKCClass(String cclassIdx)
  { CClass result = CClass.CClass_index.get(cclassIdx);
    if (result != null) { return result; }
    result = new CClass();
    CClass.CClass_index.put(cclassIdx,result);
    result.cclassId = cclassIdx;
    return result; }

  static void killCClass(String cclassIdx)
  { CClass rem = CClass_index.get(cclassIdx);
    if (rem == null) { return; }
    ArrayList<CClass> remd = new ArrayList<CClass>();
    remd.add(rem);
    CClass_index.remove(cclassIdx);
    CClass_allInstances.removeAll(remd);
  }


  public boolean charsop()
  {
    boolean result = false;
    String cc = "";
    cc = ("$" + "");
    String mc = "";
    mc = "\u0000";
    String xc = "";
    xc = "\uFFFF";
    Class t = 0.getClass();
    t = "".getClass();
    boolean b = false;
    b = Ocl.isMatch(("9" + ""),"[0-9]");
    b = Ocl.isMatch(("$" + ""),"[a-zA-Z]");
    b = ("c".toLowerCase().equals("c"));
    String h = "";
    h = ("P" + "").toLowerCase();
    xc = (cc + "");
    return Ocl.isMatch(("$" + ""),"[0-9a-zA-Z_$]");
  }

}

