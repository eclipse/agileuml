package com.example.app.ui.main;

import android.content.Context;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModelFacade
{ 
  FileAccessor fileSystem;
  Context myContext;
  static ModelFacade instance = null; 

  public static ModelFacade getInstance(Context context)
  { if (instance == null) 
    { instance = new ModelFacade(context);
      ModelFacade.initialiseOclTypes();
    }
    return instance;
  }



/* This metatype code requires OclType.java, OclAttribute.java, OclOperation.java */

  public static void initialiseOclTypes()
  { 
    OclType point_OclType = OclType.createByPKOclType("Point");
    point_OclType.setMetatype(Point.class);

    OclType fromc_OclType = OclType.createByPKOclType("FromC");
    fromc_OclType.setMetatype(FromC.class);

  }

  private ModelFacade(Context context)
  { myContext = context; 
    fileSystem = new FileAccessor(context); 
  }

}
