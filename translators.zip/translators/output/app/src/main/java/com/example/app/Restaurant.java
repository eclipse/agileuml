package com.example.app14.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Restaurant { static ArrayList<Restaurant> Restaurant_allInstances = new ArrayList<Restaurant>();

  Restaurant() { Restaurant_allInstances.add(this); }

  static Restaurant createRestaurant() { Restaurant result = new Restaurant();
    return result; }

  String name = ""; /* primary */
  static Map<String,Restaurant> Restaurant_index = new HashMap<String,Restaurant>();

  static Restaurant createByPKRestaurant(String namex) { Restaurant result = new Restaurant();
    Restaurant.Restaurant_index.put(namex,result);
    result.name = namex;
    return result; }

  String website = "";
}

