package com.example.app5.ui.main;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.app5.R;
import com.example.app5.ui.main.listBondFragment.OnListFragmentInteractionListener;
import java.util.List;

public class BondRecyclerViewAdapter extends RecyclerView.Adapter<BondRecyclerViewAdapter.ViewHolder>
{ private final List<BondVO> mValues;
  private final OnListFragmentInteractionListener mListener;

  public BondRecyclerViewAdapter(List<BondVO> items, OnListFragmentInteractionListener listener)
  { mValues = items;
    mListener = listener;
  }

  @Override
  public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
  { View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_bond, parent, false);
    return new ViewHolder(view);
  }
  
  @Override
  public void onBindViewHolder(final ViewHolder holder, int position)
  { holder.mItem = mValues.get(position);
  holder.listBondnameView.setText(" " +  mValues.get(position).name + " ");
  holder.listBondtermView.setText(" " +  mValues.get(position).term + " ");
  holder.listBondcouponView.setText(" " +  mValues.get(position).coupon + " ");
  holder.listBondpriceView.setText(" " +  mValues.get(position).price + " ");
  holder.listBondfrequencyView.setText(" " +  mValues.get(position).frequency + " ");
  holder.listBondyieldView.setText(" " +  mValues.get(position).yield + " ");
  holder.listBonddurationView.setText(" " +  mValues.get(position).duration + " ");
 
  holder.mView.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
        if (null != mListener)
        { mListener.onListFragmentInteraction(holder.mItem); }
   }
     });
   }
  
  @Override
  public int getItemCount()
  { return mValues.size(); }
   
  public class ViewHolder extends RecyclerView.ViewHolder 
  { public final View mView;
    public final TextView listBondnameView;
    public final TextView listBondtermView;
    public final TextView listBondcouponView;
    public final TextView listBondpriceView;
    public final TextView listBondfrequencyView;
    public final TextView listBondyieldView;
    public final TextView listBonddurationView;
    public BondVO mItem;

    public ViewHolder(View view)
    { super(view);
       mView = view;
     listBondnameView = (TextView) view.findViewById(R.id.listBondnameView);
     listBondtermView = (TextView) view.findViewById(R.id.listBondtermView);
     listBondcouponView = (TextView) view.findViewById(R.id.listBondcouponView);
     listBondpriceView = (TextView) view.findViewById(R.id.listBondpriceView);
     listBondfrequencyView = (TextView) view.findViewById(R.id.listBondfrequencyView);
     listBondyieldView = (TextView) view.findViewById(R.id.listBondyieldView);
     listBonddurationView = (TextView) view.findViewById(R.id.listBonddurationView);
    }

     @Override
     public String toString() 
     { return super.toString() + " " + mItem; }
      
  }
}
