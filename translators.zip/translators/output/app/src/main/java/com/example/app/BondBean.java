package com.example.app5.ui.main;

import java.util.Vector;

import android.content.Context;

public class BondBean
{ ModelFacade model;
  private String name = "";
  private String term = "";
  private double dterm = 0;
  private String coupon = "";
  private double dcoupon = 0;
  private String price = "";
  private double dprice = 0;
  private String frequency = "";
  private int ifrequency = 0;
  private String yield = "";
  private double dyield = 0;
  private String duration = "";
  private double dduration = 0;
  private Vector errors = new Vector();

  public BondBean(Context _c)
  { model = ModelFacade.getInstance(_c); }

  public void setname(String namex)
  { name = namex; }

  public void setterm(String termx)
  { term = termx; }

  public void setcoupon(String couponx)
  { coupon = couponx; }

  public void setprice(String pricex)
  { price = pricex; }

  public void setfrequency(String frequencyx)
  { frequency = frequencyx; }

  public void setyield(String yieldx)
  { yield = yieldx; }

  public void setduration(String durationx)
  { duration = durationx; }

  public void resetData()
  { name = "";
    term = "";
    coupon = "";
    price = "";
    frequency = "";
    yield = "";
    duration = "";
    }

  public boolean iscreateBonderror()
  { errors.clear(); 
    try { dterm = Double.parseDouble(term); }
    catch (Exception e)
    { errors.add("term is not a double"); }
    try { dcoupon = Double.parseDouble(coupon); }
    catch (Exception e)
    { errors.add("coupon is not a double"); }
    try { dprice = Double.parseDouble(price); }
    catch (Exception e)
    { errors.add("price is not a double"); }
    try { ifrequency = Integer.parseInt(frequency); }
    catch (Exception e)
    { errors.add("frequency is not an integer"); }
    try { dyield = Double.parseDouble(yield); }
    catch (Exception e)
    { errors.add("yield is not a double"); }
    try { dduration = Double.parseDouble(duration); }
    catch (Exception e)
    { errors.add("duration is not a double"); }
    if (dterm > 0) { }
    else { errors.add("Constraint: dterm > 0 failed"); }
    if (dcoupon >= 0) { }
    else { errors.add("Constraint: dcoupon >= 0 failed"); }
    return errors.size() > 0; }

  public boolean islistBonderror()
  { errors.clear(); 
    return errors.size() > 0; }

  public boolean isdeleteBonderror()
  { errors.clear(); 
    return errors.size() > 0; }

  public String errors() { return errors.toString(); }

  public void createBond()
  { model.createBond(new BondVO(name, dterm, dcoupon, dprice, ifrequency, dyield, dduration));
    resetData(); }

  public void deleteBond()
  { model.deleteBond(name);
    resetData(); }

}

