package com.example.app5.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Valuation { static HashSet<Valuation> Valuation_allInstances = new HashSet<Valuation>();

  Valuation() { Valuation_allInstances.add(this); }

  static Valuation createValuation() { Valuation result = new Valuation();
    return result; }


  public String valuation(Bond bond)
  {
    String result = "";
    return result;
  }

}

