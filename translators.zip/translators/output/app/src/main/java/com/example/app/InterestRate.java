package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class InterestRate { static ArrayList<InterestRate> InterestRate_allInstances = new ArrayList<InterestRate>();

  InterestRate() { InterestRate_allInstances.add(this); }

  static InterestRate createInterestRate() { InterestRate result = new InterestRate();
    return result; }

  double maturity = 0.0;
  double rate = 0.0;
  String interestrateId = ""; /* primary */
  static Map<String,InterestRate> InterestRate_index = new HashMap<String,InterestRate>();

  static InterestRate createByPKInterestRate(String interestrateIdx)
  { InterestRate result = InterestRate.InterestRate_index.get(interestrateIdx);
    if (result != null) { return result; }
    result = new InterestRate();
    InterestRate.InterestRate_index.put(interestrateIdx,result);
    result.interestrateId = interestrateIdx;
    return result; }

  static void killInterestRate(String interestrateIdx)
  { InterestRate rem = InterestRate_index.get(interestrateIdx);
    if (rem == null) { return; }
    ArrayList<InterestRate> remd = new ArrayList<InterestRate>();
    remd.add(rem);
    InterestRate_index.remove(interestrateIdx);
    InterestRate_allInstances.removeAll(remd);
  }


  public static double nelsonseigal(double t, double v1, double v2, double v3, double lambda1)
  {
    double result = 0.0;
    result = 0.0;
    double tscaled = 0.0;
    tscaled = 0.0;
    tscaled = t / lambda1;
    double exptscaled = 0.0;
    exptscaled = 0.0;
    exptscaled = Math.exp((-tscaled));
    double expratio = 0.0;
    expratio = 0.0;
    expratio = (1 - exptscaled) / tscaled;
    result = v1 + v2 * expratio + v3 * (expratio - exptscaled);
    return result;
  }


  public static double nelsonseigalsvensson(double t, double v1, double v2, double v3, double v4, double lambda1, double lambda2)
  {
    double result = 0.0;
    result = 0.0;
    double tscaled1 = 0.0;
    tscaled1 = 0.0;
    tscaled1 = t / lambda1;
    double tscaled2 = 0.0;
    tscaled2 = 0.0;
    tscaled2 = t / lambda2;
    double exptscaled1 = 0.0;
    exptscaled1 = 0.0;
    exptscaled1 = Math.exp((-tscaled1));
    double exptscaled2 = 0.0;
    exptscaled2 = 0.0;
    exptscaled2 = Math.exp((-tscaled2));
    double expratio1 = 0.0;
    expratio1 = 0.0;
    expratio1 = (1 - exptscaled1) / tscaled1;
    double expratio2 = 0.0;
    expratio2 = 0.0;
    expratio2 = (1 - exptscaled2) / tscaled2;
    result = v1 + v2 * expratio1 + v3 * (expratio1 - exptscaled1) + v4 * (expratio2 - exptscaled2);
    return result;
  }


  public static double ns(double t, double v1, double v2, double v3, double lambda1)
  {
    double result = 0.0;
    result = 0.0;
    if ((t == 0))
    {
      result = v1 + v2;
    }
    else {
      if ((t > 0))
    {
      result = InterestRate.nelsonseigal(t, v1, v2, v3, lambda1);
    }
    else {
      {}
    }
    }
    return result;
  }


  public static double nss(double t, double v1, double v2, double v3, double v4, double lambda1, double lambda2)
  {
    double result = 0.0;
    result = 0.0;
    if ((t == 0))
    {
      result = v1 + v2;
    }
    else {
      if ((t > 0))
    {
      result = InterestRate.nelsonseigalsvensson(t, v1, v2, v3, v4, lambda1, lambda2);
    }
    else {
      {}
    }
    }
    return result;
  }


  public static InterestRate newInterestRate()
  {
    InterestRate result = null;
    result = InterestRate.createInterestRate();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

