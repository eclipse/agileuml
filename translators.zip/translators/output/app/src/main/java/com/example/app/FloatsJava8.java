package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class FloatsJava8 { static ArrayList<FloatsJava8> FloatsJava8_allInstances = new ArrayList<FloatsJava8>();

  FloatsJava8() { FloatsJava8_allInstances.add(this); }

  static FloatsJava8 createFloatsJava8() { FloatsJava8 result = new FloatsJava8();
    return result; }

  String floatsjava8Id = ""; /* primary */
  static Map<String,FloatsJava8> FloatsJava8_index = new HashMap<String,FloatsJava8>();

  static FloatsJava8 createByPKFloatsJava8(String floatsjava8Idx)
  { FloatsJava8 result = FloatsJava8.FloatsJava8_index.get(floatsjava8Idx);
    if (result != null) { return result; }
    result = new FloatsJava8();
    FloatsJava8.FloatsJava8_index.put(floatsjava8Idx,result);
    result.floatsjava8Id = floatsjava8Idx;
    return result; }

  static void killFloatsJava8(String floatsjava8Idx)
  { FloatsJava8 rem = FloatsJava8_index.get(floatsjava8Idx);
    if (rem == null) { return; }
    ArrayList<FloatsJava8> remd = new ArrayList<FloatsJava8>();
    remd.add(rem);
    FloatsJava8_index.remove(floatsjava8Idx);
    FloatsJava8_allInstances.removeAll(remd);
  }


  public boolean fop()
  {
    boolean result = false;
    double f = 0.0;
    f = Double.parseDouble((1.0E-4 + ""));
    f = Double.parseDouble(("0.0001" + ""));
    double x = 0.0;
    x = (Math.pow(2,-149));
    x = Double.POSITIVE_INFINITY;
    long p = 0;
    p = Long.decode((x + "")).longValue();
    return ((x == Double.POSITIVE_INFINITY) || (x == Double.NEGATIVE_INFINITY));
  }

}

