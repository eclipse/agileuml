package com.example.app.ui.main;

public enum Gender { male, female, other }


