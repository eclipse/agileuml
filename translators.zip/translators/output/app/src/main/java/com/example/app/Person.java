package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class Person { static ArrayList<Person> Person_allInstances = new ArrayList<Person>();

  Person() { Person_allInstances.add(this); }

  static Person createPerson() { Person result = new Person();
    return result; }

  String name = "";
  int age = 0;
  String id = ""; /* primary */
  static Map<String,Person> Person_index = new HashMap<String,Person>();

  static Person createByPKPerson(String idx)
  { Person result = Person.Person_index.get(idx);
    if (result != null) { return result; }
    result = new Person();
    Person.Person_index.put(idx,result);
    result.id = idx;
    return result; }

  static void killPerson(String idx)
  { Person rem = Person_index.get(idx);
    if (rem == null) { return; }
    ArrayList<Person> remd = new ArrayList<Person>();
    remd.add(rem);
    Person_index.remove(idx);
    Person_allInstances.removeAll(remd);
  }

}

