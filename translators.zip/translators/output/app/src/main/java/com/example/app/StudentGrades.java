package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class StudentGrades { static ArrayList<StudentGrades> StudentGrades_allInstances = new ArrayList<StudentGrades>();

  StudentGrades() { StudentGrades_allInstances.add(this); }

  static StudentGrades createStudentGrades() { StudentGrades result = new StudentGrades();
    return result; }

  int agrades = 0;
  int bgrades = 0;
  int cgrades = 0;
  int dgrades = 0;
  int fails = 0;
  String studentgradesId = ""; /* primary */
  static Map<String,StudentGrades> StudentGrades_index = new HashMap<String,StudentGrades>();

  static StudentGrades createByPKStudentGrades(String studentgradesIdx)
  { StudentGrades result = StudentGrades.StudentGrades_index.get(studentgradesIdx);
    if (result != null) { return result; }
    result = new StudentGrades();
    StudentGrades.StudentGrades_index.put(studentgradesIdx,result);
    result.studentgradesId = studentgradesIdx;
    return result; }

  static void killStudentGrades(String studentgradesIdx)
  { StudentGrades rem = StudentGrades_index.get(studentgradesIdx);
    if (rem == null) { return; }
    ArrayList<StudentGrades> remd = new ArrayList<StudentGrades>();
    remd.add(rem);
    StudentGrades_index.remove(studentgradesIdx);
    StudentGrades_allInstances.removeAll(remd);
  }


  public void initialise()
  {
    {}
  }


  public static StudentGrades newStudentGrades()
  {
    StudentGrades result = null;
    result = StudentGrades.createStudentGrades();
    result.initialise();
    return result;
  }


  public void countGrades()
  {
    ArrayList<Integer> grades = new ArrayList<Integer>();
    grades = Ocl.initialiseSequence(99,95,88,82,76,72,70,66,61,60,55,50,48,40,36,30,22,10);
    int i = 0;
    i = 0;
    while (i < grades.size())
    {
      for (int _i : Ocl.integerSubrange(1,1))
    {
      if (((((int) (grades).get(i + 1 - 1)) / 10) == 10) || ((((int) (grades).get(i + 1 - 1)) / 10) == 9) || ((((int) (grades).get(i + 1 - 1)) / 10) == 8) || ((((int) (grades).get(i + 1 - 1)) / 10) == 7))
    {
      agrades = agrades + 1;
    break;
    }
    else {
      {}
    }
    if (((((int) (grades).get(i + 1 - 1)) / 10) == 6))
    {
      bgrades = bgrades + 1;
    break;
    }
    else {
      {}
    }
    if (((((int) (grades).get(i + 1 - 1)) / 10) == 5))
    {
      cgrades = cgrades + 1;
    break;
    }
    else {
      {}
    }
    if (((((int) (grades).get(i + 1 - 1)) / 10) == 4))
    {
      dgrades = dgrades + 1;
    break;
    }
    else {
      {}
    }
    fails = fails + 1;
    }
    i = (i + 1);
    }
  }

}

