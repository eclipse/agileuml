package com.example.app.ui.main;

public class loginVO
{ 
 private String email;
 private String password;

  public loginVO() {}

  public loginVO(String emailx,String passwordx)
  {    email = emailx;
   password = passwordx;
  }

  public String getemail()
  { return email; }

  public String getpassword()
  { return password; }

  public void setemail(String _x)
  { email = _x; }

  public void setpassword(String _x)
  { password = _x; }

}


