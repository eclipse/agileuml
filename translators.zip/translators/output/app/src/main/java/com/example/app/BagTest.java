package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class BagTest { static ArrayList<BagTest> BagTest_allInstances = new ArrayList<BagTest>();

  BagTest() { BagTest_allInstances.add(this); }

  static BagTest createBagTest() { BagTest result = new BagTest();
    return result; }

  String bagtestId = ""; /* primary */
  static Map<String,BagTest> BagTest_index = new HashMap<String,BagTest>();

  static BagTest createByPKBagTest(String bagtestIdx)
  { BagTest result = BagTest.BagTest_index.get(bagtestIdx);
    if (result != null) { return result; }
    result = new BagTest();
    BagTest.BagTest_index.put(bagtestIdx,result);
    result.bagtestId = bagtestIdx;
    return result; }

  static void killBagTest(String bagtestIdx)
  { BagTest rem = BagTest_index.get(bagtestIdx);
    if (rem == null) { return; }
    ArrayList<BagTest> remd = new ArrayList<BagTest>();
    remd.add(rem);
    BagTest_index.remove(bagtestIdx);
    BagTest_allInstances.removeAll(remd);
  }


  public void bagop()
  {
    ArrayList<Integer> x = new ArrayList<Integer>();
    x = Ocl.initialiseSequence(1,2,3,4,2,5,1);
    ArrayList<Integer> y = new ArrayList<Integer>();
    y = Ocl.asBag(x);
    y = Ocl.asOrderedSet(x);
  }

}

