package com.example.app5.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app5.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class deleteBondFragment extends Fragment implements OnClickListener, AdapterView.OnItemSelectedListener
{ View root;
  Context myContext;
  ModelFacade model;
  BondBean bondbean;
  Spinner deletebondSpinner;
  List<String> allBondids = new ArrayList<String>();
  EditText nameTextField;
  String nameData = "";
  Button okButton;
  Button cancelButton;


 public deleteBondFragment() {}

  public static deleteBondFragment newInstance(Context c)
  { deleteBondFragment fragment = new deleteBondFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.deletebond_layout, container, false);
    Bundle data = getArguments();
    return root;
  }

  @Override
  public void onResume()
  { super.onResume();
    model = ModelFacade.getInstance(myContext);
    BondVO selectedItem = model.getSelectedBond();
    allBondids = model.allBondids();
    nameTextField = (EditText) root.findViewById(R.id.deleteBondnameField);
    deletebondSpinner = (Spinner) root.findViewById(R.id.deleteBondSpinner);
    ArrayAdapter<String> deletebondAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,allBondids);
    deletebondAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    deletebondSpinner.setAdapter(deletebondAdapter);
    deletebondSpinner.setOnItemSelectedListener(this);
    if (selectedItem != null)
    { nameTextField.setText(selectedItem.name + ""); }
    bondbean = new BondBean(myContext);
    okButton = root.findViewById(R.id.deleteBondOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.deleteBondCancel);
    cancelButton.setOnClickListener(this);
  }



  public void onItemSelected(AdapterView<?> _parent, View _v, int _position, long _id)
  {  if (_parent == deletebondSpinner)
     { nameTextField.setText(allBondids.get(_position)); }
  }

  public void onNothingSelected(AdapterView<?> _parent) { }

  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.deleteBondOK)
    { deleteBondOK(_v); }
    else if (_v.getId() == R.id.deleteBondCancel)
    { deleteBondCancel(_v); }
  }

  public void deleteBondOK(View _v) 
  { 
    nameData = nameTextField.getText() + "";
    bondbean.setname(nameData);
    if (bondbean.isdeleteBonderror())
    { Log.w(getClass().getName(), bondbean.errors());
      Toast.makeText(myContext, "Errors: " + bondbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { bondbean.deleteBond(); }
  }


  public void deleteBondCancel(View _v)
  { bondbean.resetData();
    nameTextField.setText("");
  }
}
