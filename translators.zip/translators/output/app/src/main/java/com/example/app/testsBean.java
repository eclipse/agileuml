package com.example.app;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class testsBean
{ ModelFacade model = null;

  private List errors = new ArrayList();

  public testsBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void resetData()
  { }

  public boolean istestserror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void tests()
  { model.tests(); }

}

