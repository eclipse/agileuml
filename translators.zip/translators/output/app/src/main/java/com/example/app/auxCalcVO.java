package com.example.app;

public class auxCalcVO
{ 
 private double age;
 private double weight;

  public auxCalcVO() {}

  public auxCalcVO(double agex,double weightx)
  {    age = agex;
   weight = weightx;
  }

  public double getage()
  { return age; }

  public double getweight()
  { return weight; }

  public void setage(double _x)
  { age = _x; }

  public void setweight(double _x)
  { weight = _x; }

}


