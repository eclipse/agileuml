package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class CDO { static ArrayList<CDO> CDO_allInstances = new ArrayList<CDO>();

  CDO() { CDO_allInstances.add(this); }

  static CDO createCDO() { CDO result = new CDO();
    return result; }

  double ps0 = 0.0;
  ArrayList sectors = (new ArrayList());
  String cdoId = ""; /* primary */
  static Map<String,CDO> CDO_index = new HashMap<String,CDO>();

  static CDO createByPKCDO(String cdoIdx)
  { CDO result = CDO.CDO_index.get(cdoIdx);
    if (result != null) { return result; }
    result = new CDO();
    CDO.CDO_index.put(cdoIdx,result);
    result.cdoId = cdoIdx;
    return result; }

  static void killCDO(String cdoIdx)
  { CDO rem = CDO_index.get(cdoIdx);
    if (rem == null) { return; }
    ArrayList<CDO> remd = new ArrayList<CDO>();
    remd.add(rem);
    CDO_index.remove(cdoIdx);
    CDO_allInstances.removeAll(remd);
  }


  public void initialise()
  {
    this.ps0 = 0;
  }


  public static CDO newCDO()
  {
    CDO result = null;
    result = CDO.createCDO();
    result.initialise();
    return result;
  }


  public double PCond(int k, int m)
  {
    double result = 0.0;
    result = 0;
    if ((m >= 1))
    {
      Sector sk = null;
    sk = ((Sector) (((Object) sectors.get((k - 1) + 1 - 1))));
    result = 1.0 / (1 - Math.pow((1 - sk.p),sk.n));
    }
    else {
      if ((m < 1))
    {
      result = 0;
    }
    else {
      {}
    }
    }
    return result;
  }

}

