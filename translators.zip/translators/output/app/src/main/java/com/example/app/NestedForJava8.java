package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class NestedForJava8 { static ArrayList<NestedForJava8> NestedForJava8_allInstances = new ArrayList<NestedForJava8>();

  NestedForJava8() { NestedForJava8_allInstances.add(this); }

  static NestedForJava8 createNestedForJava8() { NestedForJava8 result = new NestedForJava8();
    return result; }

  String nestedforjava8Id = ""; /* primary */
  static Map<String,NestedForJava8> NestedForJava8_index = new HashMap<String,NestedForJava8>();

  static NestedForJava8 createByPKNestedForJava8(String nestedforjava8Idx)
  { NestedForJava8 result = NestedForJava8.NestedForJava8_index.get(nestedforjava8Idx);
    if (result != null) { return result; }
    result = new NestedForJava8();
    NestedForJava8.NestedForJava8_index.put(nestedforjava8Idx,result);
    result.nestedforjava8Id = nestedforjava8Idx;
    return result; }

  static void killNestedForJava8(String nestedforjava8Idx)
  { NestedForJava8 rem = NestedForJava8_index.get(nestedforjava8Idx);
    if (rem == null) { return; }
    ArrayList<NestedForJava8> remd = new ArrayList<NestedForJava8>();
    remd.add(rem);
    NestedForJava8_index.remove(nestedforjava8Idx);
    NestedForJava8_allInstances.removeAll(remd);
  }


  public int nfop()
  {
    int result = 0;
    ArrayList<Integer> sums = new ArrayList<Integer>();
    sums = Ocl.collectSequence(Ocl.integerSubrange(1,10),(var0)->{return 0;});
    int i = 0;
    i = 0;
    while (i < 10)
    {
      int j = 0;
    j = 1;
    while (j <= i)
    {
      sums.set(i + 1 - 1,((int) (sums).get(i + 1 - 1)) + j);
    j = j + 1;
    }
    i = i + 1;
    }
    return ((int) (sums).get(9 + 1 - 1));
  }

}

