package com.example.app5.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app5.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class createBondFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  BondBean bondbean;
  EditText nameTextField;
  String nameData = "";
  EditText termTextField;
  String termData = "";
  EditText couponTextField;
  String couponData = "";
  EditText priceTextField;
  String priceData = "";
  EditText frequencyTextField;
  String frequencyData = "";
  EditText yieldTextField;
  String yieldData = "";
  EditText durationTextField;
  String durationData = "";
  Button okButton;
  Button cancelButton;


 public createBondFragment() {}

  public static createBondFragment newInstance(Context c)
  { createBondFragment fragment = new createBondFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.createbond_layout, container, false);
    Bundle data = getArguments();
    nameTextField = (EditText) root.findViewById(R.id.createBondnameField);
    termTextField = (EditText) root.findViewById(R.id.createBondtermField);
    couponTextField = (EditText) root.findViewById(R.id.createBondcouponField);
    priceTextField = (EditText) root.findViewById(R.id.createBondpriceField);
    frequencyTextField = (EditText) root.findViewById(R.id.createBondfrequencyField);
    yieldTextField = (EditText) root.findViewById(R.id.createBondyieldField);
    durationTextField = (EditText) root.findViewById(R.id.createBonddurationField);
    bondbean = new BondBean(myContext);
    okButton = root.findViewById(R.id.createBondOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.createBondCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.createBondOK)
    { createBondOK(_v); }
    else if (_v.getId() == R.id.createBondCancel)
    { createBondCancel(_v); }
  }

  public void createBondOK(View _v) 
  { 
    nameData = nameTextField.getText() + "";
    bondbean.setname(nameData);
    termData = termTextField.getText() + "";
    bondbean.setterm(termData);
    couponData = couponTextField.getText() + "";
    bondbean.setcoupon(couponData);
    priceData = priceTextField.getText() + "";
    bondbean.setprice(priceData);
    frequencyData = frequencyTextField.getText() + "";
    bondbean.setfrequency(frequencyData);
    yieldData = yieldTextField.getText() + "";
    bondbean.setyield(yieldData);
    durationData = durationTextField.getText() + "";
    bondbean.setduration(durationData);
    if (bondbean.iscreateBonderror())
    { Log.w(getClass().getName(), bondbean.errors());
      Toast.makeText(myContext, "Errors: " + bondbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { bondbean.createBond(); }
  }


  public void createBondCancel(View _v)
  { bondbean.resetData();
    nameTextField.setText("");
    termTextField.setText("");
    couponTextField.setText("");
    priceTextField.setText("");
    frequencyTextField.setText("");
    yieldTextField.setText("");
    durationTextField.setText("");
  }
}
