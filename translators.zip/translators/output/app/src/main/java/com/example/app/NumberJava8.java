package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class NumberJava8 { static ArrayList<NumberJava8> NumberJava8_allInstances = new ArrayList<NumberJava8>();

  NumberJava8() { NumberJava8_allInstances.add(this); }

  static NumberJava8 createNumberJava8() { NumberJava8 result = new NumberJava8();
    return result; }

  String numberjava8Id = ""; /* primary */
  static Map<String,NumberJava8> NumberJava8_index = new HashMap<String,NumberJava8>();

  static NumberJava8 createByPKNumberJava8(String numberjava8Idx)
  { NumberJava8 result = NumberJava8.NumberJava8_index.get(numberjava8Idx);
    if (result != null) { return result; }
    result = new NumberJava8();
    NumberJava8.NumberJava8_index.put(numberjava8Idx,result);
    result.numberjava8Id = numberjava8Idx;
    return result; }

  static void killNumberJava8(String numberjava8Idx)
  { NumberJava8 rem = NumberJava8_index.get(numberjava8Idx);
    if (rem == null) { return; }
    ArrayList<NumberJava8> remd = new ArrayList<NumberJava8>();
    remd.add(rem);
    NumberJava8_index.remove(numberjava8Idx);
    NumberJava8_allInstances.removeAll(remd);
  }


  public void opnum()
  {
    double nn = 0.0;
    nn = 0.0;
    int bb = 0;
    bb = Integer.decode((nn + "")).intValue();
    throw (new IllegalAccessException());
  }

}

