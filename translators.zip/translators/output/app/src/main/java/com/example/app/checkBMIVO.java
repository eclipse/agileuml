package com.example.app;

public class checkBMIVO
{ 
 private double weight;
 private double height;

  public checkBMIVO() {}

  public checkBMIVO(double weightx,double heightx)
  {    weight = weightx;
   height = heightx;
  }

  public double getweight()
  { return weight; }

  public double getheight()
  { return height; }

  public void setweight(double _x)
  { weight = _x; }

  public void setheight(double _x)
  { height = _x; }

}


