package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class SSD { static ArrayList<SSD> SSD_allInstances = new ArrayList<SSD>();

  SSD() { SSD_allInstances.add(this); }

  static SSD createSSD() { SSD result = new SSD();
    return result; }

   String ssdId = ""; /* primary */
  static Map< String,SSD> SSD_index = new HashMap< String,SSD>();

  static SSD createByPKSSD( String ssdIdx)
  { SSD result = SSD.SSD_index.get(ssdIdx);
    if (result != null) { return result; }
    result = new SSD();
    SSD.SSD_index.put(ssdIdx,result);
    result.ssdId = ssdIdx;
    return result; }

  static void killSSD( String ssdIdx)
  { SSD rem = SSD_index.get(ssdIdx);
    if (rem == null) { return; }
    ArrayList<SSD> remd = new ArrayList<SSD>();
    remd.add(rem);
    SSD_index.remove(ssdIdx);
    SSD_allInstances.removeAll(remd);
  }


  public  double sumSqDiffs(ArrayList<Double> v, ArrayList<Double> w)
  {
     double result = 0.0;
     double res = 0.0;
    res = 0.0;
     int i = 0;
    i = 0;
    while ((i < v.size() && i < w.size()))
    {
       double diff = 0.0;
    diff = (( double) (v).get(i + 1 - 1)) - (( double) (w).get(i + 1 - 1));
    res = res + diff * diff;
    i = i + 1;
    }
    return Math.sqrt(res);
  }

}

