package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class NClass { static ArrayList<NClass> NClass_allInstances = new ArrayList<NClass>();

  NClass() { NClass_allInstances.add(this); }

  static NClass createNClass() { NClass result = new NClass();
    return result; }

  String nclassId = ""; /* primary */
  static Map<String,NClass> NClass_index = new HashMap<String,NClass>();

  static NClass createByPKNClass(String nclassIdx)
  { NClass result = NClass.NClass_index.get(nclassIdx);
    if (result != null) { return result; }
    result = new NClass();
    NClass.NClass_index.put(nclassIdx,result);
    result.nclassId = nclassIdx;
    return result; }

  static void killNClass(String nclassIdx)
  { NClass rem = NClass_index.get(nclassIdx);
    if (rem == null) { return; }
    ArrayList<NClass> remd = new ArrayList<NClass>();
    remd.add(rem);
    NClass_index.remove(nclassIdx);
    NClass_allInstances.removeAll(remd);
  }


  public String op(Object obj, int x)
  {
    String result = "";
    String res = "";
    res = new OclType(obj.getClass()).getName() + x;
    return res;
  }


  public String op1(Object obj)
  {
    String result = "";
    return "" + obj;
  }


  public static NClass newNClass()
  {
    NClass result = null;
    result = NClass.createNClass();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

