package com.example.app14.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Display { static ArrayList<Display> Display_allInstances = new ArrayList<Display>();

  Display() { Display_allInstances.add(this); }

  static Display createDisplay() { Display result = new Display();
    return result; }


  public WebDisplay display(String name)
  {
    WebDisplay result = null;
    return result;
  }

}

