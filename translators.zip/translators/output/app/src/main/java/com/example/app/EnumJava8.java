package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class EnumJava8 { static ArrayList<EnumJava8> EnumJava8_allInstances = new ArrayList<EnumJava8>();

  EnumJava8() { EnumJava8_allInstances.add(this); }

  static EnumJava8 createEnumJava8() { EnumJava8 result = new EnumJava8();
    return result; }

  String enumjava8Id = ""; /* primary */
  static Map<String,EnumJava8> EnumJava8_index = new HashMap<String,EnumJava8>();

  static EnumJava8 createByPKEnumJava8(String enumjava8Idx)
  { EnumJava8 result = EnumJava8.EnumJava8_index.get(enumjava8Idx);
    if (result != null) { return result; }
    result = new EnumJava8();
    EnumJava8.EnumJava8_index.put(enumjava8Idx,result);
    result.enumjava8Id = enumjava8Idx;
    return result; }

  static void killEnumJava8(String enumjava8Idx)
  { EnumJava8 rem = EnumJava8_index.get(enumjava8Idx);
    if (rem == null) { return; }
    ArrayList<EnumJava8> remd = new ArrayList<EnumJava8>();
    remd.add(rem);
    EnumJava8_index.remove(enumjava8Idx);
    EnumJava8_allInstances.removeAll(remd);
  }


  public String enumop()
  {
    String result = "";
    HashMap<String,Object> ht = new HashMap<String,Object>();
    ht = (new HashMap());
    ht.put("1","aa");
    ht.put("2","bb");
    OclIterator en = null;
    en = OclIterator.newOclIterator_Set(ht.values());
    String result = "";
    result = "";
    while (en.hasNext())
    {
      result = result + en.next();
    }
    return result;
  }

}

