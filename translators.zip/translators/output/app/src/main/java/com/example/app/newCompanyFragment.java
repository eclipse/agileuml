package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;


public class newCompanyFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  newCompanyBean newcompanybean;

  EditText newCompanyidenTextField;
  String newCompanyidenData = "";
  Button newCompanyOkButton;
  Button newCompanycancelButton;


 public newCompanyFragment() {}

  public static newCompanyFragment newInstance(Context c)
  { newCompanyFragment fragment = new newCompanyFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.newcompany_layout, container, false);
    Bundle data = getArguments();
    newCompanyidenTextField = (EditText) root.findViewById(R.id.newCompanyidenField);
    newcompanybean = new newCompanyBean(myContext);
    newCompanyOkButton = root.findViewById(R.id.newCompanyOK);
    newCompanyOkButton.setOnClickListener(this);
    newCompanycancelButton = root.findViewById(R.id.newCompanyCancel);
    newCompanycancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.newCompanyOK)
    { newCompanyOK(_v); }
    else if (_v.getId() == R.id.newCompanyCancel)
    { newCompanyCancel(_v); }
  }

  public void newCompanyOK(View _v) 
  { 
    newCompanyidenData = newCompanyidenTextField.getText() + "";
    newcompanybean.setiden(newCompanyidenData);
    if (newcompanybean.isnewCompanyerror())
    { Log.w(getClass().getName(), newcompanybean.errors());
      Toast.makeText(myContext, "Errors: " + newcompanybean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { newcompanybean.newCompany(); }
  }


  public void newCompanyCancel(View _v)
  { newcompanybean.resetData();
    newCompanyidenTextField.setText("");
  }
}
