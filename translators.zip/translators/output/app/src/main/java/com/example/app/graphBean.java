package com.example.app7;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class graphBean
{ ModelFacade model = null;

  private List errors = new ArrayList();

  public graphBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void resetData()
  { }

  public boolean isgrapherror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void graph()
  { model.graph(); }

}

