package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class RouteLeg { static ArrayList<RouteLeg> RouteLeg_allInstances = new ArrayList<RouteLeg>();

  RouteLeg() { RouteLeg_allInstances.add(this); }

  static RouteLeg createRouteLeg() { RouteLeg result = new RouteLeg();
    return result; }

  String name = ""; /* primary */
  static Map<String,RouteLeg> RouteLeg_index = new HashMap<String,RouteLeg>();

  static RouteLeg createByPKRouteLeg(String namex) { RouteLeg result = new RouteLeg();
    RouteLeg.RouteLeg_index.put(namex,result);
    result.name = namex;
    return result; }

  double distance = 0;
  double rate = 0;
  MapLocation startsFrom = null;
  MapLocation endsAt = null;
}

