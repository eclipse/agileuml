package com.example.app;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;


public class registerActivity extends AppCompatActivity
{ registerBean registerbean;

  EditText emailTextField;
  String emailData = "";
  EditText passwordTextField;
  String passwordData = "";
  TextView registerResult;


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.register_layout);
    emailTextField = (EditText) findViewById(R.id.registeremailField);
    passwordTextField = (EditText) findViewById(R.id.registerpasswordField);
    registerResult = (TextView) findViewById(R.id.registerResult);
    registerbean = new registerBean(this);
  }




  public void registerOK(View _v) 
  { InputMethodManager _imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    emailData = emailTextField.getText() + "";
    registerbean.setemail(emailData);
    passwordData = passwordTextField.getText() + "";
    registerbean.setpassword(passwordData);
    if (registerbean.isregistererror())
    { Log.w(getClass().getName(), registerbean.errors());
      Toast.makeText(this, "Errors: " + registerbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { registerResult.setText(registerbean.register() + ""); }
  }


  public void registerCancel(View _v)
  { registerbean.resetData();
    emailTextField.setText("");
    passwordTextField.setText("");
    registerResult.setText("");
  }
}
