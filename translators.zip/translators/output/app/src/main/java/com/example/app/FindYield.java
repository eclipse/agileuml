package com.example.app5.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class FindYield { static HashSet<FindYield> FindYield_allInstances = new HashSet<FindYield>();

  FindYield() { FindYield_allInstances.add(this); }

  static FindYield createFindYield() { FindYield result = new FindYield();
    return result; }


  public String findYield(Bond bond)
  {
    String result = "";
    return result;
  }

}

