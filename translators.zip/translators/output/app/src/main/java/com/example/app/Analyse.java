package com.example.app16.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Analyse { static ArrayList<Analyse> Analyse_allInstances = new ArrayList<Analyse>();

  Analyse() { Analyse_allInstances.add(this); }

  static Analyse createAnalyse() { Analyse result = new Analyse();
    return result; }


  public GraphDisplay analyse()
  {
    GraphDisplay result = null;
    return result;
  }

}

