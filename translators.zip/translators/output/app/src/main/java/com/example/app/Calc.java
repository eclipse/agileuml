package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Calc { static ArrayList<Calc> Calc_allInstances = new ArrayList<Calc>();

  Calc() { Calc_allInstances.add(this); }

  static Calc createCalc() { Calc result = new Calc();
    return result; }


  public void calc()
  {
  }

}

