package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ProcessTheAdmissionOfAPatientToAWard { static ArrayList<ProcessTheAdmissionOfAPatientToAWard> ProcessTheAdmissionOfAPatientToAWard_allInstances = new ArrayList<ProcessTheAdmissionOfAPatientToAWard>();

  ProcessTheAdmissionOfAPatientToAWard() { ProcessTheAdmissionOfAPatientToAWard_allInstances.add(this); }

  static ProcessTheAdmissionOfAPatientToAWard createProcessTheAdmissionOfAPatientToAWard() { ProcessTheAdmissionOfAPatientToAWard result = new ProcessTheAdmissionOfAPatientToAWard();
    return result; }


  public void processTheAdmissionOfAPatientToAWard(Nurse nursex)
  {
  }

}

