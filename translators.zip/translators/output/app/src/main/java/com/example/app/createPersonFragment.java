package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class createPersonFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  PersonBean personbean;
  EditText nameTextField;
  String nameData = "";
  EditText ageTextField;
  String ageData = "";
  EditText idTextField;
  String idData = "";
  Button okButton;
  Button cancelButton;


 public createPersonFragment() {}

  public static createPersonFragment newInstance(Context c)
  { createPersonFragment fragment = new createPersonFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.createperson_layout, container, false);
    Bundle data = getArguments();
    nameTextField = (EditText) root.findViewById(R.id.createPersonnameField);
    ageTextField = (EditText) root.findViewById(R.id.createPersonageField);
    idTextField = (EditText) root.findViewById(R.id.createPersonidField);
    personbean = new PersonBean(myContext);
    okButton = root.findViewById(R.id.createPersonOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.createPersonCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.createPersonOK)
    { createPersonOK(_v); }
    else if (_v.getId() == R.id.createPersonCancel)
    { createPersonCancel(_v); }
  }

  public void createPersonOK(View _v) 
  { 
    nameData = nameTextField.getText() + "";
    personbean.setname(nameData);
    ageData = ageTextField.getText() + "";
    personbean.setage(ageData);
    idData = idTextField.getText() + "";
    personbean.setid(idData);
    if (personbean.iscreatePersonerror())
    { Log.w(getClass().getName(), personbean.errors());
      Toast.makeText(myContext, "Errors: " + personbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { personbean.createPerson(); }
  }


  public void createPersonCancel(View _v)
  { personbean.resetData();
    nameTextField.setText("");
    ageTextField.setText("");
    idTextField.setText("");
  }
}
