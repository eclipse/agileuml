package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class B implements IB { static ArrayList<B> B_allInstances = new ArrayList<B>();

  B() { B_allInstances.add(this); }

  static B createB() { B result = new B();
    return result; }

  String bId = ""; /* primary */
  static Map<String,B> B_index = new HashMap<String,B>();

  static B createByPKB(String bIdx)
  { B result = B.B_index.get(bIdx);
    if (result != null) { return result; }
    result = new B();
    B.B_index.put(bIdx,result);
    result.bId = bIdx;
    return result; }

  static void killB(String bIdx)
  { B rem = B_index.get(bIdx);
    if (rem == null) { return; }
    ArrayList<B> remd = new ArrayList<B>();
    remd.add(rem);
    B_index.remove(bIdx);
    B_allInstances.removeAll(remd);
  }


  public void opB()
  {
    Ocl.displayString("opB");
  }


  public static B newB()
  {
    B result = null;
    result = B.createB();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

