package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class D { static ArrayList<D> D_allInstances = new ArrayList<D>();

  D() { D_allInstances.add(this); }

  static D createD() { D result = new D();
    return result; }

  String dId = ""; /* primary */
  static Map<String,D> D_index = new HashMap<String,D>();

  static D createByPKD(String dIdx)
  { D result = D.D_index.get(dIdx);
    if (result != null) { return result; }
    result = new D();
    D.D_index.put(dIdx,result);
    result.dId = dIdx;
    return result; }

  static void killD(String dIdx)
  { D rem = D_index.get(dIdx);
    if (rem == null) { return; }
    ArrayList<D> remd = new ArrayList<D>();
    remd.add(rem);
    D_index.remove(dIdx);
    D_allInstances.removeAll(remd);
  }


  public void op(Object x)
  {
    if (((x instanceof IA)))
    {
      x.opA();
    }
    else {
      if (((x instanceof IB)))
    {
      x.opB();
    }
    else {
      {}
    }
    }
  }


  public static D newD()
  {
    D result = null;
    result = D.createD();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

