package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class MultipleSideEffectsJava8 { static ArrayList<MultipleSideEffectsJava8> MultipleSideEffectsJava8_allInstances = new ArrayList<MultipleSideEffectsJava8>();

  MultipleSideEffectsJava8() { MultipleSideEffectsJava8_allInstances.add(this); }

  static MultipleSideEffectsJava8 createMultipleSideEffectsJava8() { MultipleSideEffectsJava8 result = new MultipleSideEffectsJava8();
    return result; }

  String multiplesideeffectsjava8Id = ""; /* primary */
  static Map<String,MultipleSideEffectsJava8> MultipleSideEffectsJava8_index = new HashMap<String,MultipleSideEffectsJava8>();

  static MultipleSideEffectsJava8 createByPKMultipleSideEffectsJava8(String multiplesideeffectsjava8Idx)
  { MultipleSideEffectsJava8 result = MultipleSideEffectsJava8.MultipleSideEffectsJava8_index.get(multiplesideeffectsjava8Idx);
    if (result != null) { return result; }
    result = new MultipleSideEffectsJava8();
    MultipleSideEffectsJava8.MultipleSideEffectsJava8_index.put(multiplesideeffectsjava8Idx,result);
    result.multiplesideeffectsjava8Id = multiplesideeffectsjava8Idx;
    return result; }

  static void killMultipleSideEffectsJava8(String multiplesideeffectsjava8Idx)
  { MultipleSideEffectsJava8 rem = MultipleSideEffectsJava8_index.get(multiplesideeffectsjava8Idx);
    if (rem == null) { return; }
    ArrayList<MultipleSideEffectsJava8> remd = new ArrayList<MultipleSideEffectsJava8>();
    remd.add(rem);
    MultipleSideEffectsJava8_index.remove(multiplesideeffectsjava8Idx);
    MultipleSideEffectsJava8_allInstances.removeAll(remd);
  }


  public void mseop()
  {
    int x = 0;
    x = 1;
    int y = 0;
    y = 0;
    x = x + 1;
    y = x + x;
    x = x + 1;
  }

}

