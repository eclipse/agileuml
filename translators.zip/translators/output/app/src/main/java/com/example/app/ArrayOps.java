package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ArrayOps { static ArrayList<ArrayOps> ArrayOps_allInstances = new ArrayList<ArrayOps>();

  ArrayOps() { ArrayOps_allInstances.add(this); }

  static ArrayOps createArrayOps() { ArrayOps result = new ArrayOps();
    return result; }

  String arrayopsId = ""; /* primary */
  static Map<String,ArrayOps> ArrayOps_index = new HashMap<String,ArrayOps>();

  static ArrayOps createByPKArrayOps(String arrayopsIdx)
  { ArrayOps result = ArrayOps.ArrayOps_index.get(arrayopsIdx);
    if (result != null) { return result; }
    result = new ArrayOps();
    ArrayOps.ArrayOps_index.put(arrayopsIdx,result);
    result.arrayopsId = arrayopsIdx;
    return result; }

  static void killArrayOps(String arrayopsIdx)
  { ArrayOps rem = ArrayOps_index.get(arrayopsIdx);
    if (rem == null) { return; }
    ArrayList<ArrayOps> remd = new ArrayList<ArrayOps>();
    remd.add(rem);
    ArrayOps_index.remove(arrayopsIdx);
    ArrayOps_allInstances.removeAll(remd);
  }


  public static void swap(ArrayList<Integer> x, ArrayList<Integer> y)
  {
    int z = 0;
    z = ((int) (x).get(0 + 1 - 1));
    x.set(0 + 1 - 1,((int) (y).get(0 + 1 - 1)));
    y.set(0 + 1 - 1,z);
  }


  public static void main(ArrayList<String> args)
  {
    ArrayList<Integer> a = new ArrayList<Integer>();
    a = Ocl.initialiseSequence(1,2,3,4);
    ArrayList<Integer> b = new ArrayList<Integer>();
    b = Ocl.initialiseSequence(2,4,6,8);
    swap(a, b);
    Ocl.displayString(("" + ((int) (a).get(0 + 1 - 1)) + " " + ((int) (a).get(1 + 1 - 1)) + " " + ((int) (a).get(2 + 1 - 1)) + " " + ((int) (a).get(3 + 1 - 1))));
    Ocl.displayString(("" + ((int) (b).get(0 + 1 - 1)) + " " + ((int) (b).get(1 + 1 - 1)) + " " + ((int) (b).get(2 + 1 - 1)) + " " + ((int) (b).get(3 + 1 - 1))));
  }

}

