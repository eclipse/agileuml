package com.example.app.ui.main;


import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.HashSet;
import java.util.ArrayList;
import java.io.*;
import java.util.StringTokenizer;

public class TestsGUI extends JFrame implements ActionListener
{ JPanel panel = new JPanel();
  ModelFacade cont = ModelFacade.getInstance();
    JButton loadCSVButton = new JButton("Mutation Tests");

 public TestsGUI()
  { super("Select use case to test");
    setContentPane(panel);
    addWindowListener(new WindowAdapter() 
    { public void windowClosing(WindowEvent e)
      { System.exit(0); } });
    panel.add(loadCSVButton);
    loadCSVButton.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e)
  { if (e == null) { return; }
    String cmd = e.getActionCommand();
    if ("Mutation Tests".equals(cmd))
    { System.err.println("Mutation tests");
      int _point_instances = Controller.inst().point.size();
      int _fromc_instances = Controller.inst().fromc.size();
      return;
    } 
    int[] intTestValues = {0, -1, 1, 2147483647, -2147483648};
    long[] longTestValues = {0, -1, 1, 9223372036854775807L, -9223372036854775808L};
    double[] doubleTestValues = {0, -1, 1, 1.7976931348623157E308, 4.9E-324};
    boolean[] booleanTestValues = {false, true};
    String[] stringTestValues = {"", " abc_XZ ", "#�$* &~@'"};
  }

  public static void main(String[] args)
  { TestsGUI gui = new TestsGUI();
    gui.setSize(550,400);
    gui.setVisible(true);
  }
 }
