package com.example.app4;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ComputeBMI { protected long now = 0;
    protected long now_pre = 0;
    static ArrayList<ComputeBMI> ComputeBMI_allInstances = new ArrayList<ComputeBMI>();

  ComputeBMI() { ComputeBMI_allInstances.add(this); }

  static ComputeBMI createComputeBMI() { ComputeBMI result = new ComputeBMI();
    return result; }


  private int act_computeBMI = 0;
  private int fin_computeBMI = 0;

  public double computeBMI(double height, double weight)
  {
    now = Ocl.getTime();
    now_pre = now;
    act_computeBMI++;
    double result = 0;
    return result;
    fin_computeBMI++;
  }

}

