package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class DoWhileJava8 { static ArrayList<DoWhileJava8> DoWhileJava8_allInstances = new ArrayList<DoWhileJava8>();

  DoWhileJava8() { DoWhileJava8_allInstances.add(this); }

  static DoWhileJava8 createDoWhileJava8() { DoWhileJava8 result = new DoWhileJava8();
    return result; }

  String dowhilejava8Id = ""; /* primary */
  static Map<String,DoWhileJava8> DoWhileJava8_index = new HashMap<String,DoWhileJava8>();

  static DoWhileJava8 createByPKDoWhileJava8(String dowhilejava8Idx)
  { DoWhileJava8 result = DoWhileJava8.DoWhileJava8_index.get(dowhilejava8Idx);
    if (result != null) { return result; }
    result = new DoWhileJava8();
    DoWhileJava8.DoWhileJava8_index.put(dowhilejava8Idx,result);
    result.dowhilejava8Id = dowhilejava8Idx;
    return result; }

  static void killDoWhileJava8(String dowhilejava8Idx)
  { DoWhileJava8 rem = DoWhileJava8_index.get(dowhilejava8Idx);
    if (rem == null) { return; }
    ArrayList<DoWhileJava8> remd = new ArrayList<DoWhileJava8>();
    remd.add(rem);
    DoWhileJava8_index.remove(dowhilejava8Idx);
    DoWhileJava8_allInstances.removeAll(remd);
  }


  public int dowhile()
  {
    int result = 0;
    int counter = 0;
    counter = 1;
    Ocl.displayString(("Counter: " + counter));
    counter = counter + 1;
    while ((counter <= 10))
    {
      Ocl.displayString(("Counter: " + counter));
    counter = counter + 1;
    }
    return counter;
  }

}

