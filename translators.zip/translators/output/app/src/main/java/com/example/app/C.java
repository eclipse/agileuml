package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class C implements IA, IB { static ArrayList<C> C_allInstances = new ArrayList<C>();

  C() { C_allInstances.add(this); }

  static C createC() { C result = new C();
    return result; }

  String cId = ""; /* primary */
  static Map<String,C> C_index = new HashMap<String,C>();

  static C createByPKC(String cIdx)
  { C result = C.C_index.get(cIdx);
    if (result != null) { return result; }
    result = new C();
    C.C_index.put(cIdx,result);
    result.cId = cIdx;
    return result; }

  static void killC(String cIdx)
  { C rem = C_index.get(cIdx);
    if (rem == null) { return; }
    ArrayList<C> remd = new ArrayList<C>();
    remd.add(rem);
    C_index.remove(cIdx);
    C_allInstances.removeAll(remd);
  }


  public void opA()
  {
    Ocl.displayString("Operation A");
  }


  public void opB()
  {
    Ocl.displayString("Operation B");
  }


  public static C newC()
  {
    C result = null;
    result = C.createC();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

