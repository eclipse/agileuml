package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Test { static ArrayList<Test> Test_allInstances = new ArrayList<Test>();

  Test() { Test_allInstances.add(this); }

  static Test createTest() { Test result = new Test();
    return result; }

   String testId = ""; /* primary */
  static Map< String,Test> Test_index = new HashMap< String,Test>();

  static Test createByPKTest( String testIdx)
  { Test result = Test.Test_index.get(testIdx);
    if (result != null) { return result; }
    result = new Test();
    Test.Test_index.put(testIdx,result);
    result.testId = testIdx;
    return result; }

  static void killTest( String testIdx)
  { Test rem = Test_index.get(testIdx);
    if (rem == null) { return; }
    ArrayList<Test> remd = new ArrayList<Test>();
    remd.add(rem);
    Test_index.remove(testIdx);
    Test_allInstances.removeAll(remd);
  }


  public  void testop(ArrayList<String> ss)
  {
    displaySequence((Ocl.removeFirst(Ocl.initialiseSequence("aa","bb","aa","cc"),"aa")));
    displaySequence((Ocl.removeAt(Ocl.initialiseSequence("aa","bb","cc"),3)));
    displaySequence(Ocl.setAt(ss,2,"xx"));
  }

}

