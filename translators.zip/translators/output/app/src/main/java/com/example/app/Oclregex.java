package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Oclregex { static ArrayList<Oclregex> Oclregex_allInstances = new ArrayList<Oclregex>();\n\n  Oclregex() { Oclregex_allInstances.add(this); }\n\n  static Oclregex createOclregex() { Oclregex result = new Oclregex();\n    return result; }\n\n
  public void oclregex()
  {
  }

}\n
