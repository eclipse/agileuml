package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;

class FromJava { static ArrayList<FromJava> FromJava_allInstances = new ArrayList<FromJava>();

  FromJava() { FromJava_allInstances.add(this); }

  static FromJava createFromJava() { FromJava result = new FromJava();
    return result; }

  String fromjavaId = ""; /* primary */
  static Map<String,FromJava> FromJava_index = new HashMap<String,FromJava>();

  static FromJava createByPKFromJava(String fromjavaIdx)
  { FromJava result = FromJava.FromJava_index.get(fromjavaIdx);
    if (result != null) { return result; }
    result = new FromJava();
    FromJava.FromJava_index.put(fromjavaIdx,result);
    result.fromjavaId = fromjavaIdx;
    return result; }

  static void killFromJava(String fromjavaIdx)
  { FromJava rem = FromJava_index.get(fromjavaIdx);
    if (rem == null) { return; }
    ArrayList<FromJava> remd = new ArrayList<FromJava>();
    remd.add(rem);
    FromJava_index.remove(fromjavaIdx);
    FromJava_allInstances.removeAll(remd);
  }


  public int linkedListOp()
  {
    int result = 0;
    ArrayList lst = new ArrayList();
    lst = (new ArrayList());
    boolean b = false;
    b = true;
    lst = Ocl.includingSequence(lst,"aa");
    lst = Ocl.includingSequence(lst,"bb");
    lst = Ocl.includingSequence(lst,"cc");
    lst = Ocl.prepend(lst,"xx");
    lst = Ocl.append(lst,"yy");
    String str = "";
    str = ((String) (Ocl.first(lst)));
    str = ((String) (Ocl.last(lst)));
    Object obj = null;
    obj = Ocl.first(lst);
    lst = Ocl.tail(lst);
    obj = Ocl.last(lst);
    lst = Ocl.front(lst);
    return lst.size();
  }

}

