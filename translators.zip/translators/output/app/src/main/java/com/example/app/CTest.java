package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class CTest { static ArrayList<CTest> CTest_allInstances = new ArrayList<CTest>();

  CTest() { CTest_allInstances.add(this); }

  static CTest createCTest() { CTest result = new CTest();
    return result; }

  String ctestId = ""; /* primary */
  static Map<String,CTest> CTest_index = new HashMap<String,CTest>();

  static CTest createByPKCTest(String ctestIdx)
  { CTest result = CTest.CTest_index.get(ctestIdx);
    if (result != null) { return result; }
    result = new CTest();
    CTest.CTest_index.put(ctestIdx,result);
    result.ctestId = ctestIdx;
    return result; }

  static void killCTest(String ctestIdx)
  { CTest rem = CTest_index.get(ctestIdx);
    if (rem == null) { return; }
    ArrayList<CTest> remd = new ArrayList<CTest>();
    remd.add(rem);
    CTest_index.remove(ctestIdx);
    CTest_allInstances.removeAll(remd);
  }


  public long caltest()
  {
    long result = 0;
    OclDate c = null;
    c = OclDate.newOclDate();
    long res = 0;
    res = c.time;
    res = c.time;
    c.setTime(30000000);
    OclDate d = null;
    d = OclDate.newOclDate();
    boolean b = false;
    b = d.dateAfter(c);
    return d.time;
  }


  public static CTest newCTest()
  {
    CTest result = null;
    result = CTest.createCTest();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

