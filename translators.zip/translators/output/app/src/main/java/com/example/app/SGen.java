package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class SGen { static ArrayList<SGen> SGen_allInstances = new ArrayList<SGen>();

  SGen() { SGen_allInstances.add(this); }

  static SGen createSGen() { SGen result = new SGen();
    return result; }

  String sgenId = ""; /* primary */
  static Map<String,SGen> SGen_index = new HashMap<String,SGen>();

  static SGen createByPKSGen(String sgenIdx)
  { SGen result = SGen.SGen_index.get(sgenIdx);
    if (result != null) { return result; }
    result = new SGen();
    SGen.SGen_index.put(sgenIdx,result);
    result.sgenId = sgenIdx;
    return result; }

  static void killSGen(String sgenIdx)
  { SGen rem = SGen_index.get(sgenIdx);
    if (rem == null) { return; }
    ArrayList<SGen> remd = new ArrayList<SGen>();
    remd.add(rem);
    SGen_index.remove(sgenIdx);
    SGen_allInstances.removeAll(remd);
  }


  public <T> String op(T x)
  {
    String result = "";
    result = x + "";
    return result;
  }

}

