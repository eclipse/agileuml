package com.example.app5.ui.main;

import java.util.List;
import java.util.ArrayList;

public class BondVO
{ 
  String name;
  double term;
  double coupon;
  double price;
  int frequency;
  double yield;
  double duration;

  public BondVO() {}

  public BondVO(String namex,double termx,double couponx,double pricex,int frequencyx,double yieldx,double durationx)
  {    name = namex;
   term = termx;
   coupon = couponx;
   price = pricex;
   frequency = frequencyx;
   yield = yieldx;
   duration = durationx;
  }

  public BondVO(Bond _x)
  {
   name = _x.name;
   term = _x.term;
   coupon = _x.coupon;
   price = _x.price;
   frequency = _x.frequency;
   yield = _x.yield;
   duration = _x.duration;
  }

  public String toString()
  { return ("name= " + name + "," + "term= " + term + "," + "coupon= " + coupon + "," + "price= " + price + "," + "frequency= " + frequency + "," + "yield= " + yield + "," + "duration= " + duration); }

  public static List<String> toStringList(List<BondVO> list)
  { List<String> _res = new ArrayList<String>();
    for (int i = 0; i < list.size(); i++)
    { BondVO _x = (BondVO) list.get(i);
      _res.add(_x.toString()); 
    }
    return _res;
  }

  public String getname()
  { return name; }

  public double getterm()
  { return term; }

  public double getcoupon()
  { return coupon; }

  public double getprice()
  { return price; }

  public int getfrequency()
  { return frequency; }

  public double getyield()
  { return yield; }

  public double getduration()
  { return duration; }

  public void setname(String _x)
  { name = _x; }

  public void setterm(double _x)
  { term = _x; }

  public void setcoupon(double _x)
  { coupon = _x; }

  public void setprice(double _x)
  { price = _x; }

  public void setfrequency(int _x)
  { frequency = _x; }

  public void setyield(double _x)
  { yield = _x; }

  public void setduration(double _x)
  { duration = _x; }

}


