package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Sequences { static ArrayList<Sequences> Sequences_allInstances = new ArrayList<Sequences>();

  Sequences() { Sequences_allInstances.add(this); }

  static Sequences createSequences() { Sequences result = new Sequences();
    return result; }

   String sequencesId = ""; /* primary */
  static Map< String,Sequences> Sequences_index = new HashMap< String,Sequences>();

  static Sequences createByPKSequences( String sequencesIdx)
  { Sequences result = Sequences.Sequences_index.get(sequencesIdx);
    if (result != null) { return result; }
    result = new Sequences();
    Sequences.Sequences_index.put(sequencesIdx,result);
    result.sequencesId = sequencesIdx;
    return result; }

  static void killSequences( String sequencesIdx)
  { Sequences rem = Sequences_index.get(sequencesIdx);
    if (rem == null) { return; }
    ArrayList<Sequences> remd = new ArrayList<Sequences>();
    remd.add(rem);
    Sequences_index.remove(sequencesIdx);
    Sequences_allInstances.removeAll(remd);
  }


  public static ArrayList<Double> subItems(ArrayList<Double> s, ArrayList<Integer> inds)
  {
    ArrayList<Double> result = new ArrayList<Double>();
    result = Ocl.collectSequence(Ocl.selectSequence(inds,(i)->{return 1 <= i && i <= s.size();}),(j)->{return (( double) (s).get(j - 1));});
    return result;
  }


  public static ArrayList<Integer> sqFloor(ArrayList<Double> s)
  {
    ArrayList<Integer> result = new ArrayList<Integer>();
    result = Ocl.collectSequence(s,(x)->{return x.floor;});
    return result;
  }


  public static ArrayList<Integer> sqRound(ArrayList<Double> s)
  {
    ArrayList<Integer> result = new ArrayList<Integer>();
    result = Ocl.collectSequence(s,(x)->{return x.round;});
    return result;
  }


  public static ArrayList<Double> sqAbs(ArrayList<Double> s)
  {
    ArrayList<Double> result = new ArrayList<Double>();
    result = Ocl.collectSequence(s,(x)->{return x.abs;});
    return result;
  }


  public static ArrayList<Integer> sqCeil(ArrayList<Double> s)
  {
    ArrayList<Integer> result = new ArrayList<Integer>();
    result = Ocl.collectSequence(s,(x)->{return x.ceil;});
    return result;
  }


  public static ArrayList<Boolean> sequenceEq(ArrayList<Double> s,  double v)
  {
    ArrayList<Boolean> result = new ArrayList<Boolean>();
    result = Ocl.collectSequence(s,(e)->{return e == v;});
    return result;
  }


  public static ArrayList<Boolean> sequenceLeq(ArrayList<Double> s,  double v)
  {
    ArrayList<Boolean> result = new ArrayList<Boolean>();
    result = Ocl.collectSequence(s,(e)->{return e <= v;});
    return result;
  }


  public static ArrayList<Boolean> sequenceLess(ArrayList<Double> s,  double v)
  {
    ArrayList<Boolean> result = new ArrayList<Boolean>();
    result = Ocl.collectSequence(s,(e)->{return e < v;});
    return result;
  }


  public static ArrayList<Double> sequenceAdd(ArrayList<Double> s,  double v)
  {
    ArrayList<Double> result = new ArrayList<Double>();
    result = Ocl.collectSequence(s,(e)->{return e + v;});
    return result;
  }


  public static ArrayList<Double> ssAdd(ArrayList<Double> s1, ArrayList<Double> s2)
  {
    ArrayList<Double> result = new ArrayList<Double>();
    result = Integer.subrange(1,s1.size)->collect( i | s1[i] + s2[i] );
    return result;
  }


  public static ArrayList<Double> sequenceMult(ArrayList<Double> ss,  double v)
  {
    ArrayList<Double> result = new ArrayList<Double>();
    result = Ocl.collectSequence(ss,(e)->{return e * v;});
    return result;
  }


  public static ArrayList<Double> ssMult(ArrayList<Double> s1, ArrayList<Double> s2)
  {
    ArrayList<Double> result = new ArrayList<Double>();
    result = Integer.subrange(1,s1.size)->collect( i | s1[i] * s2[i] );
    return result;
  }


  public static ArrayList<Boolean> ssEq(ArrayList<Double> s1, ArrayList<Double> s2)
  {
    ArrayList<Boolean> result = new ArrayList<Boolean>();
    result = Integer.subrange(1,s1.size)->collect( i | s1[i] = s2[i] );
    return result;
  }


  public static ArrayList<Boolean> ssLeq(ArrayList<Double> s1, ArrayList<Double> s2)
  {
    ArrayList<Boolean> result = new ArrayList<Boolean>();
    result = Integer.subrange(1,s1.size)->collect( i | s1[i] <= s2[i] );
    return result;
  }


  public static ArrayList<Boolean> ssLess(ArrayList<Double> s1, ArrayList<Double> s2)
  {
    ArrayList<Boolean> result = new ArrayList<Boolean>();
    result = Integer.subrange(1,s1.size)->collect( i | s1[i] < s2[i] );
    return result;
  }


  public static  String toStringDouble(ArrayList<Double> s)
  {
     String result = "";
    result = "Sequence{ " + Ocl.sum String(Ocl.collectSequence(s,(x)->{return x + " ";})) + "}";
    return result;
  }


  public static  String toStringInt(ArrayList<Integer> s)
  {
     String result = "";
    result = "Sequence{ " + Ocl.sum String(Ocl.collectSequence(s,(x)->{return x + " ";})) + "}";
    return result;
  }


  public static  String toStringBoolean(ArrayList<Boolean> s)
  {
     String result = "";
    result = "Sequence{ " + Ocl.sum String(Ocl.collectSequence(s,(x)->{return x + " ";})) + "}";
    return result;
  }

}

