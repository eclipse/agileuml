package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Collections1Java8 { static ArrayList<Collections1Java8> Collections1Java8_allInstances = new ArrayList<Collections1Java8>();

  Collections1Java8() { Collections1Java8_allInstances.add(this); }

  static Collections1Java8 createCollections1Java8() { Collections1Java8 result = new Collections1Java8();
    return result; }

  String collections1java8Id = ""; /* primary */
  static Map<String,Collections1Java8> Collections1Java8_index = new HashMap<String,Collections1Java8>();

  static Collections1Java8 createByPKCollections1Java8(String collections1java8Idx)
  { Collections1Java8 result = Collections1Java8.Collections1Java8_index.get(collections1java8Idx);
    if (result != null) { return result; }
    result = new Collections1Java8();
    Collections1Java8.Collections1Java8_index.put(collections1java8Idx,result);
    result.collections1java8Id = collections1java8Idx;
    return result; }

  static void killCollections1Java8(String collections1java8Idx)
  { Collections1Java8 rem = Collections1Java8_index.get(collections1java8Idx);
    if (rem == null) { return; }
    ArrayList<Collections1Java8> remd = new ArrayList<Collections1Java8>();
    remd.add(rem);
    Collections1Java8_index.remove(collections1java8Idx);
    Collections1Java8_allInstances.removeAll(remd);
  }


  public String coll1op()
  {
    String result = "";
    ArrayList lst0 = new ArrayList();
    lst0 = (new ArrayList());
    lst0 = Ocl.collectSequence(Ocl.integerSubrange(1,5),(var0)->{return "aa";});
    int i = 0;
    i = ((lst0.indexOf("bb") + 1) - 1);
    ArrayList lst1 = new ArrayList();
    lst1 = Ocl.initialiseSequence("bb");
    lst0 = Ocl.union(lst0,lst1);
    i = ((Collections.lastIndexOfSubList(lst0,lst1) + 1) - 1);
    lst0 = Ocl.collectSequence(lst0,(x_1)->{return ((x_1.equals("aa")) ? "cc" : x_1);});
    lst0 = Ocl.reverse(lst0);
    return ((String) (Ocl.max(lst0)));
  }

}

