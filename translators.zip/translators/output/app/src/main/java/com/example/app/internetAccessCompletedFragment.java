package com.example.app7.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app7.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class internetAccessCompletedFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  internetAccessCompletedBean internetaccesscompletedbean;

  EditText internetAccessCompletedresponseTextField;
  String internetAccessCompletedresponseData = "";
  Button internetAccessCompletedOkButton;
  Button internetAccessCompletedcancelButton;


 public internetAccessCompletedFragment() {}

  public static internetAccessCompletedFragment newInstance(Context c)
  { internetAccessCompletedFragment fragment = new internetAccessCompletedFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.internetaccesscompleted_layout, container, false);
    Bundle data = getArguments();
    internetAccessCompletedresponseTextField = (EditText) root.findViewById(R.id.internetAccessCompletedresponseField);
    internetaccesscompletedbean = new internetAccessCompletedBean(myContext);
    internetAccessCompletedOkButton = root.findViewById(R.id.internetAccessCompletedOK);
    internetAccessCompletedOkButton.setOnClickListener(this);
    internetAccessCompletedcancelButton = root.findViewById(R.id.internetAccessCompletedCancel);
    internetAccessCompletedcancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.internetAccessCompletedOK)
    { internetAccessCompletedOK(_v); }
    else if (_v.getId() == R.id.internetAccessCompletedCancel)
    { internetAccessCompletedCancel(_v); }
  }

  public void internetAccessCompletedOK(View _v) 
  { 
    internetAccessCompletedresponseData = internetAccessCompletedresponseTextField.getText() + "";
    internetaccesscompletedbean.setresponse(internetAccessCompletedresponseData);
    if (internetaccesscompletedbean.isinternetAccessCompletederror())
    { Log.w(getClass().getName(), internetaccesscompletedbean.errors());
      Toast.makeText(myContext, "Errors: " + internetaccesscompletedbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { internetaccesscompletedbean.internetAccessCompleted(); }
  }


  public void internetAccessCompletedCancel(View _v)
  { internetaccesscompletedbean.resetData();
    internetAccessCompletedresponseTextField.setText("");
  }
}
