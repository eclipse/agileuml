package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class TreeMapJava8 { static ArrayList<TreeMapJava8> TreeMapJava8_allInstances = new ArrayList<TreeMapJava8>();

  TreeMapJava8() { TreeMapJava8_allInstances.add(this); }

  static TreeMapJava8 createTreeMapJava8() { TreeMapJava8 result = new TreeMapJava8();
    return result; }

  String treemapjava8Id = ""; /* primary */
  static Map<String,TreeMapJava8> TreeMapJava8_index = new HashMap<String,TreeMapJava8>();

  static TreeMapJava8 createByPKTreeMapJava8(String treemapjava8Idx)
  { TreeMapJava8 result = TreeMapJava8.TreeMapJava8_index.get(treemapjava8Idx);
    if (result != null) { return result; }
    result = new TreeMapJava8();
    TreeMapJava8.TreeMapJava8_index.put(treemapjava8Idx,result);
    result.treemapjava8Id = treemapjava8Idx;
    return result; }

  static void killTreeMapJava8(String treemapjava8Idx)
  { TreeMapJava8 rem = TreeMapJava8_index.get(treemapjava8Idx);
    if (rem == null) { return; }
    ArrayList<TreeMapJava8> remd = new ArrayList<TreeMapJava8>();
    remd.add(rem);
    TreeMapJava8_index.remove(treemapjava8Idx);
    TreeMapJava8_allInstances.removeAll(remd);
  }


  public int tmop()
  {
    int result = 0;
    HashMap<String,Object> tm = new HashMap<String,Object>();
    tm = (new HashMap());
    tm.put("1","aa");
    tm.put("3","cc");
    tm.put("2","bb");
    String fk = "";
    fk = ((String) (Ocl.min(Ocl.mapKeys(tm))));
    fk = ((String) (Ocl.max(Ocl.mapKeys(tm))));
    HashMap<String,Object> sm = new HashMap<String,Object>();
    sm = Ocl.restrictMap(tm,Ocl.selectSet(Ocl.mapKeys(tm),(_key)->{return (_key.compareTo("3") < 0);}));
    sm = Ocl.restrictMap(tm,Ocl.selectSet(Ocl.mapKeys(tm),(_key)->{return (_key.compareTo("1") >= 0) && (_key.compareTo("3") < 0);}));
    return sm.size();
  }

}

