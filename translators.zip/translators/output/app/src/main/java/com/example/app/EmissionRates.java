package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class EmissionRates { static ArrayList<EmissionRates> EmissionRates_allInstances = new ArrayList<EmissionRates>();

  EmissionRates() { EmissionRates_allInstances.add(this); }

  static EmissionRates createEmissionRates() { EmissionRates result = new EmissionRates();
    return result; }


  public static double getRateFor(String mode)
  {
    double result = 0;
    if (mode.equals("Car"))
    {
      result = 0.185;
    }
    else {
      if (mode.equals("Flight"))
    {
      result = 0.266;
    }
    else {
      if (mode.equals("Train"))
    {
      result = 0.046;
    }
    else {
      result = 0;
    }
    }
    }
    return result;
  }

}

