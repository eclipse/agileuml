package com.example.app;

public class oclregexVO
{ 

  public oclregexVO() {}

}


