package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class Stack implements Addable { static ArrayList<Stack> Stack_allInstances = new ArrayList<Stack>();

  Stack() { Stack_allInstances.add(this); }

  static Stack createStack() { Stack result = new Stack();
    return result; }

  ArrayList<T> elems = (new ArrayList());
  String stackId = ""; /* primary */
  static Map<String,Stack> Stack_index = new HashMap<String,Stack>();

  static Stack createByPKStack(String stackIdx)
  { Stack result = Stack.Stack_index.get(stackIdx);
    if (result != null) { return result; }
    result = new Stack();
    Stack.Stack_index.put(stackIdx,result);
    result.stackId = stackIdx;
    return result; }

  static void killStack(String stackIdx)
  { Stack rem = Stack_index.get(stackIdx);
    if (rem == null) { return; }
    ArrayList<Stack> remd = new ArrayList<Stack>();
    remd.add(rem);
    Stack_index.remove(stackIdx);
    Stack_allInstances.removeAll(remd);
  }


  public Stack<T> add(T x)
  {
    Stack<T> result = null;
    elems = Ocl.append(elems,x);
  }

}

