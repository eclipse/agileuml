package com.example.app14.ui.main;

public class displayVO
{ 
 private String name;

  public displayVO() {}

  public displayVO(String namex)
  {    name = namex;
  }

  public String getname()
  { return name; }

  public void setname(String _x)
  { name = _x; }

}


