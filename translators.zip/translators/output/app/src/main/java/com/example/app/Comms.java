package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Comms { static ArrayList<Comms> Comms_allInstances = new ArrayList<Comms>();

  Comms() { Comms_allInstances.add(this); }

  static Comms createComms() { Comms result = new Comms();
    return result; }

  String commsId = ""; /* primary */
  static Map<String,Comms> Comms_index = new HashMap<String,Comms>();

  static Comms createByPKComms(String commsIdx)
  { Comms result = Comms.Comms_index.get(commsIdx);
    if (result != null) { return result; }
    result = new Comms();
    Comms.Comms_index.put(commsIdx,result);
    result.commsId = commsIdx;
    return result; }

  static void killComms(String commsIdx)
  { Comms rem = Comms_index.get(commsIdx);
    if (rem == null) { return; }
    ArrayList<Comms> remd = new ArrayList<Comms>();
    remd.add(rem);
    Comms_index.remove(commsIdx);
    Comms_allInstances.removeAll(remd);
  }


  public void initialise()
  {
    {}
  }


  public static Comms newComms()
  {
    Comms result = null;
    result = Comms.createComms();
    result.initialise();
    return result;
  }


  public String toString()
  {
    String result = "";
    return "";
  }

}

