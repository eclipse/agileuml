package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class GeneticAlgorithm { static ArrayList<GeneticAlgorithm> GeneticAlgorithm_allInstances = new ArrayList<GeneticAlgorithm>();

  GeneticAlgorithm() { GeneticAlgorithm_allInstances.add(this); }

  static GeneticAlgorithm createGeneticAlgorithm() { GeneticAlgorithm result = new GeneticAlgorithm();
    return result; }

  static  double maxfitness = 0.0;
  static  double maxvalue = 0.0;
  static  double elitelb = 0.0;
  static  double combinelb = 0.0;
  static  double mutatelb = 0.0;
   String geneticalgorithmId = ""; /* primary */
  static Map< String,GeneticAlgorithm> GeneticAlgorithm_index = new HashMap< String,GeneticAlgorithm>();

  static GeneticAlgorithm createByPKGeneticAlgorithm( String geneticalgorithmIdx)
  { GeneticAlgorithm result = GeneticAlgorithm.GeneticAlgorithm_index.get(geneticalgorithmIdx);
    if (result != null) { return result; }
    result = new GeneticAlgorithm();
    GeneticAlgorithm.GeneticAlgorithm_index.put(geneticalgorithmIdx,result);
    result.geneticalgorithmId = geneticalgorithmIdx;
    return result; }

  static void killGeneticAlgorithm( String geneticalgorithmIdx)
  { GeneticAlgorithm rem = GeneticAlgorithm_index.get(geneticalgorithmIdx);
    if (rem == null) { return; }
    ArrayList<GeneticAlgorithm> remd = new ArrayList<GeneticAlgorithm>();
    remd.add(rem);
    GeneticAlgorithm_index.remove(geneticalgorithmIdx);
    GeneticAlgorithm_allInstances.removeAll(remd);
  }

  HashSet<GAIndividual> population = new HashSet<GAIndividual>();
  HashSet<GAIndividual> elite = new HashSet<GAIndividual>();
  HashSet<GAIndividual> recombined = new HashSet<GAIndividual>();
  HashSet<GAIndividual> mutated = new HashSet<GAIndividual>();

  public  boolean isUnfit( GAIndividual g)
  {
     boolean result = false;
    if ((( GATrait) (g.traits).get(1 - 1)).value <= 0)
    {
      result = true;
    }
    else {
      if ((( GATrait) (g.traits).get(4 - 1)).value <= 0)
    {
      }
    else {
      if ((( GATrait) (g.traits).get(1 - 1)).value + (( GATrait) (g.traits).get(2 - 1)).value <= 0)
    {
      result = true;
    }
    else {
      }
    }
    }
    return result;
  }

}

