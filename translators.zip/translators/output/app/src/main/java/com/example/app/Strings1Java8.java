package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Strings1Java8 { static ArrayList<Strings1Java8> Strings1Java8_allInstances = new ArrayList<Strings1Java8>();

  Strings1Java8() { Strings1Java8_allInstances.add(this); }

  static Strings1Java8 createStrings1Java8() { Strings1Java8 result = new Strings1Java8();
    return result; }

  String strings1java8Id = ""; /* primary */
  static Map<String,Strings1Java8> Strings1Java8_index = new HashMap<String,Strings1Java8>();

  static Strings1Java8 createByPKStrings1Java8(String strings1java8Idx)
  { Strings1Java8 result = Strings1Java8.Strings1Java8_index.get(strings1java8Idx);
    if (result != null) { return result; }
    result = new Strings1Java8();
    Strings1Java8.Strings1Java8_index.put(strings1java8Idx,result);
    result.strings1java8Id = strings1java8Idx;
    return result; }

  static void killStrings1Java8(String strings1java8Idx)
  { Strings1Java8 rem = Strings1Java8_index.get(strings1java8Idx);
    if (rem == null) { return; }
    ArrayList<Strings1Java8> remd = new ArrayList<Strings1Java8>();
    remd.add(rem);
    Strings1Java8_index.remove(strings1java8Idx);
    Strings1Java8_allInstances.removeAll(remd);
  }


  public int strings1op()
  {
    int result = 0;
    String s0 = "";
    s0 = "";
    ArrayList<Integer> bb = new ArrayList<Integer>();
    bb = Ocl.initialiseSequence(97,98,99);
    String s1 = "";
    s1 = Ocl.sumString(Ocl.collectSequence(bb,(_x)->{return Ocl.byte2char(_x);}));
    ArrayList<String> cc = new ArrayList<String>();
    cc = Ocl.initialiseSequence("x","y","z");
    s1 = Ocl.sumString(cc);
    String p = "";
    p = (s1.charAt(1 + 1 - 1) + "");
    return ((String) s0.toLowerCase()).compareTo(s1.toLowerCase());
  }

}

