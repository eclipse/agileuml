package com.example.app.ui.main;

public class assessTheConditionOfAPatientVO
{ 
 private Doctor doctorx;
 private Patient patientx;

  public assessTheConditionOfAPatientVO() {}

  public assessTheConditionOfAPatientVO(Doctor doctorxx,Patient patientxx)
  {    doctorx = doctorxx;
   patientx = patientxx;
  }

  public Doctor getdoctorx()
  { return doctorx; }

  public Patient getpatientx()
  { return patientx; }

  public void setdoctorx(Doctor _x)
  { doctorx = _x; }

  public void setpatientx(Patient _x)
  { patientx = _x; }

}


