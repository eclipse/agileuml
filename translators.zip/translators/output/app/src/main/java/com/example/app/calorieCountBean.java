package com.example.app4;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class calorieCountBean
{ ModelFacade model = null;

  private String gender = "";
  private Gender egender = Gender.male;
  private String exercise = "";
  private Exercise eexercise = Exercise.walking;
  private String time = "";
  private double dtime = 0;
  private List errors = new ArrayList();

  public calorieCountBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setgender(String genderx)
  { gender = genderx; }

  public void setexercise(String exercisex)
  { exercise = exercisex; }

  public void settime(String timex)
  { time = timex; }

  public void resetData()
  { gender = "";
    exercise = "";
    time = "";
    }

  public boolean iscalorieCounterror()
  { errors.clear(); 
    if (gender.equals("male"))
    { egender = Gender.male; } else
    if (gender.equals("female"))
    { egender = Gender.female; } else
    { errors.add("gender is not in type Gender"); }
    if (exercise.equals("walking"))
    { eexercise = Exercise.walking; } else
    if (exercise.equals("jogging"))
    { eexercise = Exercise.jogging; } else
    if (exercise.equals("running"))
    { eexercise = Exercise.running; } else
    if (exercise.equals("swimming"))
    { eexercise = Exercise.swimming; } else
    if (exercise.equals("weights"))
    { eexercise = Exercise.weights; } else
    { errors.add("exercise is not in type Exercise"); }
    try { dtime = Double.parseDouble(time); }
    catch (Exception e)
    { errors.add("time is not a double"); }
    if (dtime >= 0) { }
    else { errors.add("Precondition: dtime >= 0 failed"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public double calorieCount()
  { return model.calorieCount(egender,eexercise,dtime); }

}

