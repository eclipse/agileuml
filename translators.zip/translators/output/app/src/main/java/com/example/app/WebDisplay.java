package com.example.app14.ui.main;


public class WebDisplay
{ String url = "";

  public WebDisplay()
  { }

  public void loadURL(String url)
  { this.url = url; }

  public void reload()
  { }
}
