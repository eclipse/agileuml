package com.example.app5.ui.main;

public class findDurationVO
{ 
 private Bond bond;

  public findDurationVO() {}

  public findDurationVO(Bond bondx)
  {    bond = bondx;
  }

  public Bond getbond()
  { return bond; }

  public void setbond(Bond _x)
  { bond = _x; }

}


