package com.example.app7;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Graph { static ArrayList<Graph> Graph_allInstances = new ArrayList<Graph>();

  Graph() { Graph_allInstances.add(this); }

  static Graph createGraph() { Graph result = new Graph();
    return result; }


  public void graph()
  {
  }

}

