package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ApproveTheDischargeOfAPatientFromHospital { static ArrayList<ApproveTheDischargeOfAPatientFromHospital> ApproveTheDischargeOfAPatientFromHospital_allInstances = new ArrayList<ApproveTheDischargeOfAPatientFromHospital>();

  ApproveTheDischargeOfAPatientFromHospital() { ApproveTheDischargeOfAPatientFromHospital_allInstances.add(this); }

  static ApproveTheDischargeOfAPatientFromHospital createApproveTheDischargeOfAPatientFromHospital() { ApproveTheDischargeOfAPatientFromHospital result = new ApproveTheDischargeOfAPatientFromHospital();
    return result; }


  public void approveTheDischargeOfAPatientFromHospital(Doctor doctorx, Patient patientx)
  {
  }

}

