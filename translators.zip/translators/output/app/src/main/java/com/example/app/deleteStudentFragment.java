package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class deleteStudentFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  ModelFacade model;
  StudentBean studentbean;
  EditText codeTextField;
  String codeData = "";
  Button okButton;
  Button cancelButton;


 public deleteStudentFragment() {}

  public static deleteStudentFragment newInstance(Context c)
  { deleteStudentFragment fragment = new deleteStudentFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.deletestudent_layout, container, false);
    Bundle data = getArguments();
    model = ModelFacade.getInstance(myContext);
    StudentVO selectedItem = model.getSelectedStudent();
    codeTextField = (EditText) root.findViewById(R.id.deleteStudentcodeField);
    if (selected != null)
    { codeTextField.setText(selected.code + ""); }
    studentbean = new StudentBean(myContext);
    okButton = root.findViewById(R.id.deleteStudentOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.deleteStudentCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.deleteStudentOK)
    { deleteStudentOK(_v); }
    else if (_v.getId() == R.id.deleteStudentCancel)
    { deleteStudentCancel(_v); }
  }

  public void deleteStudentOK(View _v) 
  { 
    codeData = codeTextField.getText() + "";
    studentbean.setcode(codeData);
    if (studentbean.isdeleteStudenterror())
    { Log.w(getClass().getName(), studentbean.errors());
      Toast.makeText(myContext, "Errors: " + studentbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { studentbean.deleteStudent(); }
  }


  public void deleteStudentCancel(View _v)
  { studentbean.resetData();
    codeTextField.setText("");
  }
}
