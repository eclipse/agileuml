package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class WhileJava8 { static ArrayList<WhileJava8> WhileJava8_allInstances = new ArrayList<WhileJava8>();

  WhileJava8() { WhileJava8_allInstances.add(this); }

  static WhileJava8 createWhileJava8() { WhileJava8 result = new WhileJava8();
    return result; }

  String whilejava8Id = ""; /* primary */
  static Map<String,WhileJava8> WhileJava8_index = new HashMap<String,WhileJava8>();

  static WhileJava8 createByPKWhileJava8(String whilejava8Idx)
  { WhileJava8 result = WhileJava8.WhileJava8_index.get(whilejava8Idx);
    if (result != null) { return result; }
    result = new WhileJava8();
    WhileJava8.WhileJava8_index.put(whilejava8Idx,result);
    result.whilejava8Id = whilejava8Idx;
    return result; }

  static void killWhileJava8(String whilejava8Idx)
  { WhileJava8 rem = WhileJava8_index.get(whilejava8Idx);
    if (rem == null) { return; }
    ArrayList<WhileJava8> remd = new ArrayList<WhileJava8>();
    remd.add(rem);
    WhileJava8_index.remove(whilejava8Idx);
    WhileJava8_allInstances.removeAll(remd);
  }


  public int whileop()
  {
    int result = 0;
    double investment = 0.0;
    investment = 100.0;
    double rate = 0.0;
    rate = 0.05;
    int years = 0;
    years = 0;
    while ((investment * Math.pow(1.05,years) < 2 * investment))
    {
      years = years + 1;
    }
    return years;
  }

}

