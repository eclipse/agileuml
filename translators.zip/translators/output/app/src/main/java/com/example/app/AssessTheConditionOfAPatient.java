package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class AssessTheConditionOfAPatient { static ArrayList<AssessTheConditionOfAPatient> AssessTheConditionOfAPatient_allInstances = new ArrayList<AssessTheConditionOfAPatient>();

  AssessTheConditionOfAPatient() { AssessTheConditionOfAPatient_allInstances.add(this); }

  static AssessTheConditionOfAPatient createAssessTheConditionOfAPatient() { AssessTheConditionOfAPatient result = new AssessTheConditionOfAPatient();
    return result; }


  public void assessTheConditionOfAPatient(Doctor doctorx, Patient patientx)
  {
  }

}

