package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class SB2Java8 { static ArrayList<SB2Java8> SB2Java8_allInstances = new ArrayList<SB2Java8>();

  SB2Java8() { SB2Java8_allInstances.add(this); }

  static SB2Java8 createSB2Java8() { SB2Java8 result = new SB2Java8();
    return result; }

  String sb2java8Id = ""; /* primary */
  static Map<String,SB2Java8> SB2Java8_index = new HashMap<String,SB2Java8>();

  static SB2Java8 createByPKSB2Java8(String sb2java8Idx)
  { SB2Java8 result = SB2Java8.SB2Java8_index.get(sb2java8Idx);
    if (result != null) { return result; }
    result = new SB2Java8();
    SB2Java8.SB2Java8_index.put(sb2java8Idx,result);
    result.sb2java8Id = sb2java8Idx;
    return result; }

  static void killSB2Java8(String sb2java8Idx)
  { SB2Java8 rem = SB2Java8_index.get(sb2java8Idx);
    if (rem == null) { return; }
    ArrayList<SB2Java8> remd = new ArrayList<SB2Java8>();
    remd.add(rem);
    SB2Java8_index.remove(sb2java8Idx);
    SB2Java8_allInstances.removeAll(remd);
  }


  public String sb2op()
  {
    String result = "";
    String bf = "";
    bf = ("" + "a long string");
    String b1 = "";
    b1 = Ocl.insertAt(bf,5 + 1,"" + true);
    bf = Ocl.insertAt(bf,5 + 1,("" + true));
    bf = Ocl.insertAt(bf,5 + 1,("" + 100));
    bf = Ocl.reverse(bf);
    bf = Ocl.setAt(bf,0 + 1,"x");
    String cs = "";
    cs = Ocl.subrange(bf,0 + 1,4);
    return Ocl.subrange(bf,5 + 1,bf.length());
  }

}

