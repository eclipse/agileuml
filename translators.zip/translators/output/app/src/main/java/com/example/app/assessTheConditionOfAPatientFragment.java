package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.ImageView;
import android.widget.TextView;


public class assessTheConditionOfAPatientFragment extends Fragment implements OnClickListener, AdapterView.OnItemSelectedListener
{ View root;
  Context myContext;
  assessTheConditionOfAPatientBean assesstheconditionofapatientbean;

  Spinner assessTheConditionOfAPatientdoctorxSpinner;
  List<String> assessTheConditionOfAPatientdoctorxListItems = new ArrayList<String>();
  String assessTheConditionOfAPatientdoctorxData = "";
  Spinner assessTheConditionOfAPatientpatientxSpinner;
  List<String> assessTheConditionOfAPatientpatientxListItems = new ArrayList<String>();
  String assessTheConditionOfAPatientpatientxData = "";
  Button assessTheConditionOfAPatientOkButton;
  Button assessTheConditionOfAPatientcancelButton;


 public assessTheConditionOfAPatientFragment() {}

  public static assessTheConditionOfAPatientFragment newInstance(Context c)
  { assessTheConditionOfAPatientFragment fragment = new assessTheConditionOfAPatientFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.assesstheconditionofapatient_layout, container, false);
    Bundle data = getArguments();
    assessTheConditionOfAPatientdoctorxSpinner = (Spinner) root.findViewById(R.id.assessTheConditionOfAPatientdoctorxSpinner);
    assessTheConditionOfAPatientdoctorxListItems = ModelFacade.getInstance(myContext).allDoctorids();
    ArrayAdapter<String> assessTheConditionOfAPatientdoctorxAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,assessTheConditionOfAPatientdoctorxListItems);
    assessTheConditionOfAPatientdoctorxAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    assessTheConditionOfAPatientdoctorxSpinner.setAdapter(assessTheConditionOfAPatientdoctorxAdapter);
    assessTheConditionOfAPatientdoctorxSpinner.setOnItemSelectedListener(this);

    assessTheConditionOfAPatientpatientxSpinner = (Spinner) root.findViewById(R.id.assessTheConditionOfAPatientpatientxSpinner);
    assessTheConditionOfAPatientpatientxListItems = ModelFacade.getInstance(myContext).allPatientids();
    ArrayAdapter<String> assessTheConditionOfAPatientpatientxAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,assessTheConditionOfAPatientpatientxListItems);
    assessTheConditionOfAPatientpatientxAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    assessTheConditionOfAPatientpatientxSpinner.setAdapter(assessTheConditionOfAPatientpatientxAdapter);
    assessTheConditionOfAPatientpatientxSpinner.setOnItemSelectedListener(this);

    assesstheconditionofapatientbean = new assessTheConditionOfAPatientBean(myContext);
    assessTheConditionOfAPatientOkButton = root.findViewById(R.id.assessTheConditionOfAPatientOK);
    assessTheConditionOfAPatientOkButton.setOnClickListener(this);
    assessTheConditionOfAPatientcancelButton = root.findViewById(R.id.assessTheConditionOfAPatientCancel);
    assessTheConditionOfAPatientcancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.assessTheConditionOfAPatientOK)
    { assessTheConditionOfAPatientOK(_v); }
    else if (_v.getId() == R.id.assessTheConditionOfAPatientCancel)
    { assessTheConditionOfAPatientCancel(_v); }
  }

  public void assessTheConditionOfAPatientOK(View _v) 
  { 
    assesstheconditionofapatientbean.setdoctorx(assessTheConditionOfAPatientdoctorxData);
    assesstheconditionofapatientbean.setpatientx(assessTheConditionOfAPatientpatientxData);
    if (assesstheconditionofapatientbean.isassessTheConditionOfAPatienterror())
    { Log.w(getClass().getName(), assesstheconditionofapatientbean.errors());
      Toast.makeText(myContext, "Errors: " + assesstheconditionofapatientbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { assesstheconditionofapatientbean.assessTheConditionOfAPatient(); }
  }


  public void assessTheConditionOfAPatientCancel(View _v)
  { assesstheconditionofapatientbean.resetData();
  }
  public void onItemSelected(AdapterView<?> _parent, View _v, int _position, long _id)
  {     if (_parent == assessTheConditionOfAPatientdoctorxSpinner)
    { assessTheConditionOfAPatientdoctorxData = assessTheConditionOfAPatientdoctorxListItems.get(_position); }
    if (_parent == assessTheConditionOfAPatientpatientxSpinner)
    { assessTheConditionOfAPatientpatientxData = assessTheConditionOfAPatientpatientxListItems.get(_position); }
 }

  public void onNothingSelected(AdapterView<?> _parent)
  {     assessTheConditionOfAPatientdoctorxData = "";
    assessTheConditionOfAPatientpatientxData = "";
 }

}
