package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

abstract class Patient { static ArrayList<Patient> Patient_allInstances = new ArrayList<Patient>();
  Patient() { Patient_allInstances.add(this); }

  String name = "";
  double age = 0.0;
  String admissionDate = "";
  String stayDuration = "";
  String diabetesMeasure = "";
  String incontinenceMeasure = "";
  String dysphagiaMeasure = "";
  String visualfieldMeasure = "";
  double mortalityRisk = 0.0;
  String disabilityRisk = "";
  BarthelIndex record = new BarthelIndex();
}

