package com.example.app4;

public class calorieCountVO
{ 
 private Gender gender;
 private Exercise exercise;
 private double time;

  public calorieCountVO() {}

  public calorieCountVO(Gender genderx,Exercise exercisex,double timex)
  {    gender = genderx;
   exercise = exercisex;
   time = timex;
  }

  public Gender getgender()
  { return gender; }

  public Exercise getexercise()
  { return exercise; }

  public double gettime()
  { return time; }

  public void setgender(Gender _x)
  { gender = _x; }

  public void setexercise(Exercise _x)
  { exercise = _x; }

  public void settime(double _x)
  { time = _x; }

}


