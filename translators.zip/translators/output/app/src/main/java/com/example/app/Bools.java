package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Bools { static ArrayList<Bools> Bools_allInstances = new ArrayList<Bools>();

  Bools() { Bools_allInstances.add(this); }

  static Bools createBools() { Bools result = new Bools();
    return result; }

  String boolsId = ""; /* primary */
  static Map<String,Bools> Bools_index = new HashMap<String,Bools>();

  static Bools createByPKBools(String boolsIdx)
  { Bools result = Bools.Bools_index.get(boolsIdx);
    if (result != null) { return result; }
    result = new Bools();
    Bools.Bools_index.put(boolsIdx,result);
    result.boolsId = boolsIdx;
    return result; }

  static void killBools(String boolsIdx)
  { Bools rem = Bools_index.get(boolsIdx);
    if (rem == null) { return; }
    ArrayList<Bools> remd = new ArrayList<Bools>();
    remd.add(rem);
    Bools_index.remove(boolsIdx);
    Bools_allInstances.removeAll(remd);
  }


  public boolean boolop()
  {
    boolean result = false;
    AssertionError er = null;
    er = new AssertionError();
    er = AssertionException.newAssertionException("" + 0.0);
    er = AssertionException.newAssertionException("" + 10000000);
    boolean b = false;
    b = false;
    b = Boolean.parseBoolean(("true" + ""));
    b = Boolean.parseBoolean((true + ""));
    boolean x = false;
    x = Boolean.parseBoolean((b + ""));
    return x == false;
  }

}

