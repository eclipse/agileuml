package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ArraysJava8 { static ArrayList<ArraysJava8> ArraysJava8_allInstances = new ArrayList<ArraysJava8>();

  ArraysJava8() { ArraysJava8_allInstances.add(this); }

  static ArraysJava8 createArraysJava8() { ArraysJava8 result = new ArraysJava8();
    return result; }

  String arraysjava8Id = ""; /* primary */
  static Map<String,ArraysJava8> ArraysJava8_index = new HashMap<String,ArraysJava8>();

  static ArraysJava8 createByPKArraysJava8(String arraysjava8Idx)
  { ArraysJava8 result = ArraysJava8.ArraysJava8_index.get(arraysjava8Idx);
    if (result != null) { return result; }
    result = new ArraysJava8();
    ArraysJava8.ArraysJava8_index.put(arraysjava8Idx,result);
    result.arraysjava8Id = arraysjava8Idx;
    return result; }

  static void killArraysJava8(String arraysjava8Idx)
  { ArraysJava8 rem = ArraysJava8_index.get(arraysjava8Idx);
    if (rem == null) { return; }
    ArrayList<ArraysJava8> remd = new ArrayList<ArraysJava8>();
    remd.add(rem);
    ArraysJava8_index.remove(arraysjava8Idx);
    ArraysJava8_allInstances.removeAll(remd);
  }


  public boolean oparrays()
  {
    boolean result = false;
    ArrayList<String> strs = new ArrayList<String>();
    strs = Ocl.initialiseSequence("aa","bb","cc","dd","ee");
    ArrayList lst = new ArrayList();
    lst = strs;
    int i = 0;
    i = ((strs.indexOf("dd") + 1) - 1);
    ArrayList<Integer> barr = new ArrayList<Integer>();
    barr = Ocl.initialiseSequence(97,98,99,100);
    barr = Ocl.collectSequence(barr,(var0)->{return 102;});
    strs = Ocl.sort(strs);
    strs = Ocl.concatenate(Ocl.subrange(strs,1,0),Ocl.concatenate((Ocl.sort(Ocl.subrange(strs,0 + 1,3))),Ocl.subrange(strs,3 + 1,strs.size())));
    return (Ocl.collectSequence(Ocl.integerSubrange(1,5),(var1)->{return "";}).equals(strs));
  }

}

