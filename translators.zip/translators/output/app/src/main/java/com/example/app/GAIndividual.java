package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class GAIndividual { static ArrayList<GAIndividual> GAIndividual_allInstances = new ArrayList<GAIndividual>();

  GAIndividual() { GAIndividual_allInstances.add(this); }

  static GAIndividual createGAIndividual() { GAIndividual result = new GAIndividual();
    return result; }

   double fitnessval = 0.0;
   String gaindividualId = ""; /* primary */
  static Map< String,GAIndividual> GAIndividual_index = new HashMap< String,GAIndividual>();

  static GAIndividual createByPKGAIndividual( String gaindividualIdx)
  { GAIndividual result = GAIndividual.GAIndividual_index.get(gaindividualIdx);
    if (result != null) { return result; }
    result = new GAIndividual();
    GAIndividual.GAIndividual_index.put(gaindividualIdx,result);
    result.gaindividualId = gaindividualIdx;
    return result; }

  static void killGAIndividual( String gaindividualIdx)
  { GAIndividual rem = GAIndividual_index.get(gaindividualIdx);
    if (rem == null) { return; }
    ArrayList<GAIndividual> remd = new ArrayList<GAIndividual>();
    remd.add(rem);
    GAIndividual_index.remove(gaindividualIdx);
    GAIndividual_allInstances.removeAll(remd);
  }

  ArrayList<GATrait> traits = new ArrayList<GATrait>();

  public  double fitness()
  {
     double result = 0.0;
     double sumsquares = 0.0;
    sumsquares = Ocl.sum double(Ocl.collectSequence(InterestRate,(r)->{return ((r.rate - InterestRate.ns(r.maturity, (( GATrait) (traits).get(1 - 1)).value, (( GATrait) (traits).get(2 - 1)).value, (( GATrait) (traits).get(3 - 1)).value, (( GATrait) (traits).get(4 - 1)).value)))*((r.rate - InterestRate.ns(r.maturity, (( GATrait) (traits).get(1 - 1)).value, (( GATrait) (traits).get(2 - 1)).value, (( GATrait) (traits).get(3 - 1)).value, (( GATrait) (traits).get(4 - 1)).value)));}));
    result = 4.0 / (1 + Math.sqrt(sumsquares));
    return result;
  }


  public  GAIndividual combine( GAIndividual g)
  {
     GAIndividual result = null;
     int n = 0;
    n = traits.size();
     int m = 0;
    m = g.traits.size();
     int p = 0;
    p = ((int) Math.floor((Math.random() * n))) + 1;
     GAIndividual h = null;
    h = GAIndividual.createGAIndividual();
    h.traits = Ocl.concatenate(Ocl.subrange(traits,1,p),Ocl.subrange(g.traits,p + 1,m));
    result = h;
    return result;
  }


  public  GAIndividual mutate()
  {
     GAIndividual result = null;
     int n = 0;
    n = traits.size();
     int p = 0;
    p = ((int) Math.floor((Math.random() * n))) + 1;
     String itm = "";
    itm = (( GATrait) (traits).get(p - 1)).item;
     double val = 0.0;
    val = (( GATrait) (traits).get(p - 1)).value;
     GAIndividual h = null;
    h = GAIndividual.createGAIndividual();
    h.traits = Ocl.union(h.traits,traits);
     GATrait tr = null;
    tr = GATrait.createGATrait();
    tr.item = itm;
    tr.value = (Math.random() - 0.5) * 2 + val;
    h.traits.set(p - 1,tr);
    result = h;
    return result;
  }


  public  String toString()
  {
     String result = "";
    result = Ocl.sum String(Ocl.collectSequence(traits,(t)->{return t.item + " = " + t.value + " ";}));
    return result;
  }

}

