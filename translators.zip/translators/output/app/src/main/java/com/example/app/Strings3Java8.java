package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Strings3Java8 { static ArrayList<Strings3Java8> Strings3Java8_allInstances = new ArrayList<Strings3Java8>();

  Strings3Java8() { Strings3Java8_allInstances.add(this); }

  static Strings3Java8 createStrings3Java8() { Strings3Java8 result = new Strings3Java8();
    return result; }

  String strings3java8Id = ""; /* primary */
  static Map<String,Strings3Java8> Strings3Java8_index = new HashMap<String,Strings3Java8>();

  static Strings3Java8 createByPKStrings3Java8(String strings3java8Idx)
  { Strings3Java8 result = Strings3Java8.Strings3Java8_index.get(strings3java8Idx);
    if (result != null) { return result; }
    result = new Strings3Java8();
    Strings3Java8.Strings3Java8_index.put(strings3java8Idx,result);
    result.strings3java8Id = strings3java8Idx;
    return result; }

  static void killStrings3Java8(String strings3java8Idx)
  { Strings3Java8 rem = Strings3Java8_index.get(strings3java8Idx);
    if (rem == null) { return; }
    ArrayList<Strings3Java8> remd = new ArrayList<Strings3Java8>();
    remd.add(rem);
    Strings3Java8_index.remove(strings3java8Idx);
    Strings3Java8_allInstances.removeAll(remd);
  }


  public boolean strings3op()
  {
    boolean result = false;
    String str = "";
    str = "long test string";
    boolean b = false;
    b = Ocl.isMatch(str,"[a-z]+");
    String ss = "";
    ss = "test";
    b = (Ocl.subrange(str,5 + 1,5 + 4).equals(Ocl.subrange(ss,0 + 1,0 + 4)));
    String s2 = "";
    s2 = Ocl.replace(ss,"t","$");
    s2 = Ocl.replaceAll(str,"[a-z]+","*");
    ArrayList<String> sq = new ArrayList<String>();
    sq = Ocl.split(str," ");
    return str.startsWith("long");
  }

}

