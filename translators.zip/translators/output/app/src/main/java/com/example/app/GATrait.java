package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class GATrait { static ArrayList<GATrait> GATrait_allInstances = new ArrayList<GATrait>();

  GATrait() { GATrait_allInstances.add(this); }

  static GATrait createGATrait() { GATrait result = new GATrait();
    return result; }

   String item = "";
   double value = 0.0;
   String gatraitId = ""; /* primary */
  static Map< String,GATrait> GATrait_index = new HashMap< String,GATrait>();

  static GATrait createByPKGATrait( String gatraitIdx)
  { GATrait result = GATrait.GATrait_index.get(gatraitIdx);
    if (result != null) { return result; }
    result = new GATrait();
    GATrait.GATrait_index.put(gatraitIdx,result);
    result.gatraitId = gatraitIdx;
    return result; }

  static void killGATrait( String gatraitIdx)
  { GATrait rem = GATrait_index.get(gatraitIdx);
    if (rem == null) { return; }
    ArrayList<GATrait> remd = new ArrayList<GATrait>();
    remd.add(rem);
    GATrait_index.remove(gatraitIdx);
    GATrait_allInstances.removeAll(remd);
  }

}

