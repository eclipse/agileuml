package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Place { static ArrayList<Place> Place_allInstances = new ArrayList<Place>();

  Place() { Place_allInstances.add(this); }

  static Place createPlace() { Place result = new Place();
    return result; }

  double lat = 0;
  double lng = 0;
  String name = ""; /* primary */
  static Map<String,Place> Place_index = new HashMap<String,Place>();

  static Place createByPKPlace(String namex) { Place result = new Place();
    Place.Place_index.put(namex,result);
    result.name = namex;
    return result; }

}

