package com.example.app5.ui.main;

public class valuationVO
{ 
 private Bond bond;

  public valuationVO() {}

  public valuationVO(Bond bondx)
  {    bond = bondx;
  }

  public Bond getbond()
  { return bond; }

  public void setbond(Bond _x)
  { bond = _x; }

}


