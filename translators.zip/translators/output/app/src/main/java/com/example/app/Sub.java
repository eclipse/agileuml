package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Sub extends Sup implements IA { static ArrayList<Sub> Sub_allInstances = new ArrayList<Sub>();

  Sub() { super();
    Sub_allInstances.add(this); }

  static Sub createSub() { Sub result = new Sub();
    return result; }


  public long getTime()
  {
    long result = 0;
    return 0;
  }


  public static Sub newSub()
  {
    Sub result = null;
    result = Sub.createSub();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

