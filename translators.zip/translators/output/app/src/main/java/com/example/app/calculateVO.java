package com.example.app5.ui.main;

public class calculateVO
{ 
 private Bond bond;

  public calculateVO() {}

  public calculateVO(Bond bondx)
  {    bond = bondx;
  }

  public Bond getbond()
  { return bond; }

  public void setbond(Bond _x)
  { bond = _x; }

}


