package com.example.app;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class checkBMIBean
{ ModelFacade model = null;

  private String weight = "";
  private double dweight = 0;
  private String height = "";
  private double dheight = 0;
  private List errors = new ArrayList();

  public checkBMIBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setweight(String weightx)
  { weight = weightx; }

  public void setheight(String heightx)
  { height = heightx; }

  public void resetData()
  { weight = "";
    height = "";
    }

  public boolean ischeckBMIerror()
  { errors.clear(); 
    try { dweight = Double.parseDouble(weight); }
    catch (Exception e)
    { errors.add("weight is not a double"); }
    try { dheight = Double.parseDouble(height); }
    catch (Exception e)
    { errors.add("height is not a double"); }
    if (dheight > 0) { }
    else { errors.add("Precondition: dheight > 0 failed"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public String checkBMI()
  { return model.checkBMI(dweight,dheight); }

}

