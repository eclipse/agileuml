package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class StackLike { static ArrayList<StackLike> StackLike_allInstances = new ArrayList<StackLike>();

  StackLike() { StackLike_allInstances.add(this); }

  static StackLike createStackLike() { StackLike result = new StackLike();
    return result; }

  ArrayList<T> elems = (new ArrayList());
  String stacklikeId = ""; /* primary */
  static Map<String,StackLike> StackLike_index = new HashMap<String,StackLike>();

  static StackLike createByPKStackLike(String stacklikeIdx)
  { StackLike result = StackLike.StackLike_index.get(stacklikeIdx);
    if (result != null) { return result; }
    result = new StackLike();
    StackLike.StackLike_index.put(stacklikeIdx,result);
    result.stacklikeId = stacklikeIdx;
    return result; }

  static void killStackLike(String stacklikeIdx)
  { StackLike rem = StackLike_index.get(stacklikeIdx);
    if (rem == null) { return; }
    ArrayList<StackLike> remd = new ArrayList<StackLike>();
    remd.add(rem);
    StackLike_index.remove(stacklikeIdx);
    StackLike_allInstances.removeAll(remd);
  }


  public void initialise(int cap)
  {
    elems = (new ArrayList());
  }


  public static StackLike newStackLike(int cap)
  {
    StackLike result = null;
    result = StackLike.createStackLike();
    result.initialise(cap);
    return result;
  }


  public T headElement()
  {
    T result = null;
    if ((elems.size() > 0))
    {
      return ((T) elems.get(0 + 1 - 1));
    }
    else {
      {}
    }
    return null;
  }

}

