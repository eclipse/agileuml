package com.example.app.ui.main;

import android.content.Context;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.app.R;

public class listStudentFragment extends Fragment
{ private static final String ARG_COLUMN_COUNT = "column-count";
  private int mColumnCount = 1;
  private OnListFragmentInteractionListener mListener;
  private ModelFacade model;
  private Context myContext;
  private View root;

  public listStudentFragment() { }

  @SuppressWarnings("unused")
  public static listStudentFragment newInstance(Context context)
  { listStudentFragment fragment = new listStudentFragment();
    Bundle args = new Bundle();
    args.putInt(ARG_COLUMN_COUNT, 1);
    fragment.setArguments(args);
    fragment.myContext = context;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState);
    if (getArguments() != null)
    { mColumnCount = getArguments().getInt(ARG_COLUMN_COUNT); }
  }

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { View view = inflater.inflate(R.layout.liststudent_layout, container, false);
    model = ModelFacade.getInstance(myContext);
    if (view instanceof RecyclerView)
    { Context context = view.getContext();
      RecyclerView recyclerView = (RecyclerView) view;
      if (mColumnCount <= 1)
      { recyclerView.setLayoutManager(new LinearLayoutManager(context)); }
      else
      { recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount)); }
    }
    root = view;
    return view;
  }

  @Override
  public void onAttach(Context context) 
  { super.onAttach(context);
    if (context instanceof OnListFragmentInteractionListener) 
    { mListener = (OnListFragmentInteractionListener) context; }
    else
    { throw new RuntimeException(context.toString() + " must implement OnListFragmentInteractionListener"); }
  }

  @Override
  public void onResume()
  { super.onResume();
    ((RecyclerView) root).setAdapter(new StudentRecyclerViewAdapter(model.listStudent(), mListener));
  }

  @Override
  public void onDetach()
  { super.onDetach();
    mListener = null;
  }

  public interface OnListFragmentInteractionListener {
    void onListFragmentInteraction(StudentVO item);
  }
}
