package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class Bond { static ArrayList<Bond> Bond_allInstances = new ArrayList<Bond>();

  Bond() { Bond_allInstances.add(this); }

  static Bond createBond() { Bond result = new Bond();
    return result; }

  String name = "";
  double term = 0.0;
  double coupon = 0.0;
  double price = 0.0;
  int frequency = 0;
  double irr = 0.0;
  double duration = 0.0;
  String bondId = ""; /* primary */
  static Map<String,Bond> Bond_index = new HashMap<String,Bond>();

  static Bond createByPKBond(String bondIdx)
  { Bond result = Bond.Bond_index.get(bondIdx);
    if (result != null) { return result; }
    result = new Bond();
    Bond.Bond_index.put(bondIdx,result);
    result.bondId = bondIdx;
    return result; }

  static void killBond(String bondIdx)
  { Bond rem = Bond_index.get(bondIdx);
    if (rem == null) { return; }
    ArrayList<Bond> remd = new ArrayList<Bond>();
    remd.add(rem);
    Bond_index.remove(bondIdx);
    Bond_allInstances.removeAll(remd);
  }


  public void initialise()
  {
    this.name = "";
    this.term = 0.0;
    this.coupon = 0.0;
    this.price = 0.0;
    this.frequency = 0;
    this.irr = 0.0;
    this.duration = 0.0;
  }


  public static Bond newBond()
  {
    Bond result = null;
    result = Bond.createBond();
    result.initialise();
    return result;
  }


  public double discount(double amount, double r, double time)
  {
    double result = 0.0;
    result = 0;
    if ((r <= -1 || time < 0))
    {
      return result;
    }
    else {
      {}
    }
    result = amount / Math.pow((1 + r),time);
    return result;
  }


  public double value(double r)
  {
    double result = 0.0;
    result = 0.0;
    if ((r <= -1))
    {
      return result;
    }
    else {
      {}
    }
    int upper = 0;
    upper = ((int) (((int) Math.floor((term * frequency)))));
    double c = 0.0;
    c = coupon / frequency;
    double period = 0.0;
    period = 1.0 / frequency;
    int i = 0;
    i = 1;
    while (i <= upper)
    {
      result = result + this.discount(c, r, i * period);
    i = (i + 1);
    }
    result = result + this.discount(100, r, term);
    return result;
  }


  public double timeDiscount(double amount, double r, double time)
  {
    double result = 0.0;
    result = 0.0;
    if ((r <= -1 || time < 0))
    {
      return result;
    }
    else {
      {}
    }
    result = (amount * time) / Math.pow((1 + r),time);
    return result;
  }


  public double macaulayDuration(double r)
  {
    double result = 0.0;
    result = 0;
    if ((r <= -1))
    {
      return result;
    }
    else {
      {}
    }
    int upper = 0;
    upper = ((int) (((int) Math.floor((term * frequency)))));
    double c = 0.0;
    c = coupon / frequency;
    double period = 0.0;
    period = 1.0 / frequency;
    int i = 0;
    i = 1;
    while (i <= upper)
    {
      result = result + this.timeDiscount(c, r, i * period);
    i = (i + 1);
    }
    result = result + this.timeDiscount(100, r, term);
    result = result / this.value(r);
    return result;
  }


  public double bisection(double r, double rl, double ru)
  {
    double result = 0.0;
    result = 0;
    if ((r <= -1 || rl <= -1 || ru <= -1))
    {
      return result;
    }
    else {
      {}
    }
    double v = 0.0;
    v = this.value(r);
    result = (((ru - rl < 0.001)) ? r : (((v > price)) ? this.bisection((ru + r) / 2, r, ru) : this.bisection((r + rl) / 2, rl, r)));
    return result;
  }

}

