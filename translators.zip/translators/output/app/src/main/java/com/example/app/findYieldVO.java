package com.example.app5.ui.main;

public class findYieldVO
{ 
 private Bond bond;

  public findYieldVO() {}

  public findYieldVO(Bond bondx)
  {    bond = bondx;
  }

  public Bond getbond()
  { return bond; }

  public void setbond(Bond _x)
  { bond = _x; }

}


