package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Bond { static HashSet<Bond> Bond_allInstances = new HashSet<Bond>();

  Bond() { Bond_allInstances.add(this); }

  static Bond createBond() { Bond result = new Bond();
    return result; }

  String name = ""; /* primary */
  static Map<String,Bond> Bond_index = new HashMap<String,Bond>();

  static Bond createByPKBond(String namex) { Bond result = new Bond();
    Bond.Bond_index.put(namex,result);
    result.name = namex;
    return result; }

  double term = 0;
  double coupon = 0;
  double price = 0;
  int frequency = 0;
  double yield = 0;
  double duration = 0;

  public double discount(double amount, double r, double time)
  {
    double result = 0;
    result = amount / (Math.pow((1 + r),time));
    return result;
  }


  public double value(double r)
  {
    double result = 0;
    result = Ocl.sumdouble(Ocl.collectSequence(Ocl.integerSubrange(1,(int) Math.floor(term * frequency)),(i)->{return this.discount(( coupon / frequency ), r, ( i * 1.0 ) / frequency);})) + this.discount(100, r, term);
    return result;
  }


  public double bisection(double r, double rl, double ru)
  { System.out.println(">>> range [" + rl + " " + r + " " + ru + "]"); 
    double result = 0;
    double v = 0;
    v = value(r);
	System.out.println(">>> value(r) = " + v); 
	
    if (ru - rl < 0.001)
    {
      result = r;
    }
    else {
      if (v > price)
    {
      result = this.bisection(( ru + r ) / 2, r, ru);
    }
    else {
      if (v < price)
    {
      result = this.bisection(( r + rl ) / 2, rl, r);
    }
    else {
      result = r;
    }
    }
    }
    return result;
  }
  
  public static void main(String[] args)
  { Bond b = Bond.createByPKBond("5Year1%Gilt"); 
    b.term = 5; 
	b.coupon = 1; 
	b.price = 98; 
	System.out.println(b.value(0.01)); 
	double r = b.bisection(0.5,0,1); 
	System.out.println(r); 
  } 
    

}

