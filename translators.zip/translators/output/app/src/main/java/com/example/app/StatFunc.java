package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class StatFunc { static ArrayList<StatFunc> StatFunc_allInstances = new ArrayList<StatFunc>();

  StatFunc() { StatFunc_allInstances.add(this); }

  static StatFunc createStatFunc() { StatFunc result = new StatFunc();
    return result; }

  String statfuncId = ""; /* primary */
  static Map<String,StatFunc> StatFunc_index = new HashMap<String,StatFunc>();

  static StatFunc createByPKStatFunc(String statfuncIdx)
  { StatFunc result = StatFunc.StatFunc_index.get(statfuncIdx);
    if (result != null) { return result; }
    result = new StatFunc();
    StatFunc.StatFunc_index.put(statfuncIdx,result);
    result.statfuncId = statfuncIdx;
    return result; }

  static void killStatFunc(String statfuncIdx)
  { StatFunc rem = StatFunc_index.get(statfuncIdx);
    if (rem == null) { return; }
    ArrayList<StatFunc> remd = new ArrayList<StatFunc>();
    remd.add(rem);
    StatFunc_index.remove(statfuncIdx);
    StatFunc_allInstances.removeAll(remd);
  }


  public static int multiplyRange(int st, int en)
  {
    int result = 0;
    int res = 0;
    res = 1;
    int i = 0;
    i = st;
    while (i <= en)
    {
      res = res * i;
    i = (i + 1);
    }
    return res;
  }


  public static int comb(int n, int m)
  {
    int result = 0;
    result = 0;
    if ((n < m || m < 0))
    {
      return result;
    }
    else {
      {}
    }
    if ((n - m < m))
    {
      result = StatFunc.multiplyRange(m + 1, n) / StatFunc.multiplyRange(1, n - m);
    }
    else {
      if ((n - m >= m))
    {
      result = StatFunc.multiplyRange(n - m + 1, n) / StatFunc.multiplyRange(1, m);
    }
    else {
      {}
    }
    }
    return result;
  }


  public static StatFunc newStatFunc()
  {
    StatFunc result = null;
    result = StatFunc.createStatFunc();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

