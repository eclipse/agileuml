package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class FromC { static ArrayList<FromC> FromC_allInstances = new ArrayList<FromC>();

  FromC() { FromC_allInstances.add(this); }

  static FromC createFromC() { FromC result = new FromC();
    return result; }

  String fromcId = ""; /* primary */
  static Map<String,FromC> FromC_index = new HashMap<String,FromC>();

  static FromC createByPKFromC(String fromcIdx)
  { FromC result = FromC.FromC_index.get(fromcIdx);
    if (result != null) { return result; }
    result = new FromC();
    FromC.FromC_index.put(fromcIdx,result);
    result.fromcId = fromcIdx;
    return result; }

  static void killFromC(String fromcIdx)
  { FromC rem = FromC_index.get(fromcIdx);
    if (rem == null) { return; }
    ArrayList<FromC> remd = new ArrayList<FromC>();
    remd.add(rem);
    FromC_index.remove(fromcIdx);
    FromC_allInstances.removeAll(remd);
  }


  public static int op()
  {
    int result = 0;
    Point[] points = (new Point[10]);
    points[0 + 1-1] = aa;
    points[1 + 1-1] = bb;
    points[0 + 1-1].x = 0;
    return 0;
  }


  public static FromC newFromC()
  {
    FromC result = null;
    FromC res = null;
    res = createFromC();
    res.initialise();
    return res;
  }


  public void initialise()
  {
    {}
  }

}

