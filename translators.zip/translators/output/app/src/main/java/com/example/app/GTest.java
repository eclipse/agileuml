package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class GTest { static ArrayList<GTest> GTest_allInstances = new ArrayList<GTest>();

  GTest() { GTest_allInstances.add(this); }

  static GTest createGTest() { GTest result = new GTest();
    return result; }

  String gtestId = ""; /* primary */
  static Map<String,GTest> GTest_index = new HashMap<String,GTest>();

  static GTest createByPKGTest(String gtestIdx)
  { GTest result = GTest.GTest_index.get(gtestIdx);
    if (result != null) { return result; }
    result = new GTest();
    GTest.GTest_index.put(gtestIdx,result);
    result.gtestId = gtestIdx;
    return result; }

  static void killGTest(String gtestIdx)
  { GTest rem = GTest_index.get(gtestIdx);
    if (rem == null) { return; }
    ArrayList<GTest> remd = new ArrayList<GTest>();
    remd.add(rem);
    GTest_index.remove(gtestIdx);
    GTest_allInstances.removeAll(remd);
  }


  public static void main(ArrayList<String> args)
  {
    ArrayList<Integer> iarr = new ArrayList<Integer>();
    iarr = Ocl.initialiseSequence(1,2,3,4);
    ArrayList<Double> darr = new ArrayList<Double>();
    darr = Ocl.initialiseSequence(1.0,2.0,3.0);
    ArrayList<String> sarr = new ArrayList<String>();
    sarr = Ocl.initialiseSequence("A","B","C");
    Ocl.displayString(GTest.printArray(iarr));
    Ocl.displayString(GTest.printArray(darr));
    Ocl.displayString(GTest.printArray(sarr));
  }


  public static String printArray<T>(ArrayList<T> arr)
  {
    String result = "";
    String res = "";
    res = "";
    for (T elem : arr)
    {
      res = res + elem + " ";
    }
    return res;
  }


  public static GTest newGTest()
  {
    GTest result = null;
    result = GTest.createGTest();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

