package com.example.app14.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app14.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.widget.TextView;


public class createRestaurantFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  RestaurantBean restaurantbean;
  EditText nameTextField;
  String nameData = "";
  EditText websiteTextField;
  String websiteData = "";
  Button okButton;
  Button cancelButton;


 public createRestaurantFragment() {}

  public static createRestaurantFragment newInstance(Context c)
  { createRestaurantFragment fragment = new createRestaurantFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.createrestaurant_layout, container, false);
    Bundle data = getArguments();
    nameTextField = (EditText) root.findViewById(R.id.createRestaurantnameField);
    websiteTextField = (EditText) root.findViewById(R.id.createRestaurantwebsiteField);
    restaurantbean = new RestaurantBean(myContext);
    okButton = root.findViewById(R.id.createRestaurantOK);
    okButton.setOnClickListener(this);
    cancelButton = root.findViewById(R.id.createRestaurantCancel);
    cancelButton.setOnClickListener(this);
    return root;
  }




  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.createRestaurantOK)
    { createRestaurantOK(_v); }
    else if (_v.getId() == R.id.createRestaurantCancel)
    { createRestaurantCancel(_v); }
  }

  public void createRestaurantOK(View _v) 
  { 
    nameData = nameTextField.getText() + "";
    restaurantbean.setname(nameData);
    websiteData = websiteTextField.getText() + "";
    restaurantbean.setwebsite(websiteData);
    if (restaurantbean.iscreateRestauranterror())
    { Log.w(getClass().getName(), restaurantbean.errors());
      Toast.makeText(myContext, "Errors: " + restaurantbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { restaurantbean.createRestaurant(); }
  }


  public void createRestaurantCancel(View _v)
  { restaurantbean.resetData();
    nameTextField.setText("");
    websiteTextField.setText("");
  }
}
