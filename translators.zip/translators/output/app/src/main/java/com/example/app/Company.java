package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Company { static ArrayList<Company> Company_allInstances = new ArrayList<Company>();

  Company() { Company_allInstances.add(this); }

  static Company createCompany() { Company result = new Company();
    return result; }

  String id = "";
  String companyId = ""; /* primary */
  static Map<String,Company> Company_index = new HashMap<String,Company>();

  static Company createByPKCompany(String companyIdx)
  { Company result = Company.Company_index.get(companyIdx);
    if (result != null) { return result; }
    result = new Company();
    Company.Company_index.put(companyIdx,result);
    result.companyId = companyIdx;
    return result; }

  static void killCompany(String companyIdx)
  { Company rem = Company_index.get(companyIdx);
    if (rem == null) { return; }
    ArrayList<Company> remd = new ArrayList<Company>();
    remd.add(rem);
    Company_index.remove(companyIdx);
    Company_allInstances.removeAll(remd);
  }

}

