package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class DClass { static ArrayList<DClass> DClass_allInstances = new ArrayList<DClass>();

  DClass() { DClass_allInstances.add(this); }

  static DClass createDClass() { DClass result = new DClass();
    return result; }

  String dclassId = ""; /* primary */
  static Map<String,DClass> DClass_index = new HashMap<String,DClass>();

  static DClass createByPKDClass(String dclassIdx)
  { DClass result = DClass.DClass_index.get(dclassIdx);
    if (result != null) { return result; }
    result = new DClass();
    DClass.DClass_index.put(dclassIdx,result);
    result.dclassId = dclassIdx;
    return result; }

  static void killDClass(String dclassIdx)
  { DClass rem = DClass_index.get(dclassIdx);
    if (rem == null) { return; }
    ArrayList<DClass> remd = new ArrayList<DClass>();
    remd.add(rem);
    DClass_index.remove(dclassIdx);
    DClass_allInstances.removeAll(remd);
  }


  public boolean dop()
  {
    boolean result = false;
    double dd = 0.0;
    dd = (2 - Math.pow(2,-52)) * (Math.pow(2,1023));
    dd = Double.NaN;
    int p = 0;
    p = ((0.0 < dd) ? -1 : ((0.0 > dd) ? 1 : 0 ));
    double xx = 0.0;
    xx = Double.parseDouble(((1.0 / 3.0) + "")).doubleValue();
    xx = Double.parseDouble(("1.0" + "")).doubleValue();
    dd = Double.parseDouble((xx + "")).doubleValue();
    dd = Double.parseDouble((xx + "")).doubleValue();
    return (Double.isNaN(dd));
  }

}

