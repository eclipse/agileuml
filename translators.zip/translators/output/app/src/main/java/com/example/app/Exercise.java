package com.example.app4;

public enum Exercise { walking, jogging, running, swimming, weights }


