package com.example.app;

public class testsVO
{ 

  public testsVO() {}

}


