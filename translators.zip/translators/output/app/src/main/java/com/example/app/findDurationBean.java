package com.example.app5.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class findDurationBean
{ ModelFacade model = null;

  private String bond = "";
  private Bond instance_bond = null;
  private List errors = new ArrayList();

  public findDurationBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setbond(String bondx)
  { bond = bondx; }

  public void resetData()
  { bond = "";
    }

  public boolean isfindDurationerror()
  { errors.clear(); 
    instance_bond = model.getBondByPK(bond);
    if (instance_bond == null)
    { errors.add("bond must be a valid Bond id"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public String findDuration()
  { return model.findDuration(instance_bond); }

}

