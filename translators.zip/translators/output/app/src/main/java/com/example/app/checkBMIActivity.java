package com.example.app;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
// import android.app.Activity;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;


public class checkBMIActivity extends AppCompatActivity
{ checkBMIBean checkbmibean;

  EditText weightTextField;
  String weightData = "";
  EditText heightTextField;
  String heightData = "";
  TextView checkBMIResult;


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.checkbmi_layout);
    weightTextField = (EditText) findViewById(R.id.checkBMIweightField);
    heightTextField = (EditText) findViewById(R.id.checkBMIheightField);
    checkBMIResult = (TextView) findViewById(R.id.checkBMIResult);
    checkbmibean = new checkBMIBean(this);
  }


  public void checkBMIOK(View _v) 
  { InputMethodManager _imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0);
    weightData = weightTextField.getText() + "";
    checkbmibean.setweight(weightData);
    heightData = heightTextField.getText() + "";
    checkbmibean.setheight(heightData);
    if (checkbmibean.ischeckBMIerror())
    { Log.w(getClass().getName(), checkbmibean.errors());
      Toast.makeText(this, "Errors: " + checkbmibean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { checkBMIResult.setText(checkbmibean.checkBMI() + ""); }
  }


  public void checkBMICancel(View _v)
  { checkbmibean.resetData();
    weightTextField.setText("");
    heightTextField.setText("");
    checkBMIResult.setText("checkBMI result");
  }
}
