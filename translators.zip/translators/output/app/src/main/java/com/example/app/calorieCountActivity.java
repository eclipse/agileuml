package com.example.app;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;


public class calorieCountActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener
{ calorieCountBean caloriecountbean;
  auxCalcBean auxcalcbean;

  RadioGroup genderGroup
  String genderData = "";
  Spinner exerciseSpinner;
  String[] exerciseListItems = {"walking", "jogging", "running", "swimming", "weights"};
  String exerciseData = "";
  EditText timeTextField;
  String timeData = "";
  TextView calorieCountResult;
  EditText ageTextField;
  String ageData = "";
  EditText weightTextField;
  String weightData = "";
  TextView auxCalcResult;


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.caloriecount_layout);
    genderGroup = (RadioGroup) findViewById(R.id.calorieCountgenderGroup);
    exerciseSpinner = (Spinner) findViewById(R.id.calorieCountexerciseSpinner);
    ArrayAdapter<String> exerciseAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,exerciseListItems);
    exerciseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    exerciseSpinner.setAdapter(exerciseAdapter);
    exerciseSpinner.setOnItemSelectedListener(this);

    timeTextField = (EditText) findViewById(R.id.calorieCounttimeField);
    calorieCountResult = (TextView) findViewById(R.id.calorieCountResult);
    caloriecountbean = new calorieCountBean(this);
    ageTextField = (EditText) findViewById(R.id.auxCalcageField);
    auxCalcResult = (TextView) findViewById(R.id.auxCalcResult);
    weightTextField = (EditText) findViewById(R.id.auxCalcweightField);
    auxCalcResult = (TextView) findViewById(R.id.auxCalcResult);
    auxcalcbean = new auxCalcBean(this);
  }


  public void onItemSelected(AdapterView<?> _parent, View _v, int _position, long _id)
  {     if (_parent == exerciseSpinner)
    { exerciseData = exerciseListItems[_position]; }
 }

  public void onNothingSelected(AdapterView<?> _parent)
  {     exerciseData = exerciseListItems[0];
 }


  public void calorieCountOK(View _v) 
  { InputMethodManager _imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
   if (genderGroup.getCheckedRadioButtonId() == R.id.calorieCountgendermale) { genderData = "male"; }
    else
   if (genderGroup.getCheckedRadioButtonId() == R.id.calorieCountgenderfemale) { genderData = "female"; }

    caloriecountbean.setgender(genderData);
    caloriecountbean.setexercise(exerciseData);
    timeData = timeTextField.getText() + "";
    caloriecountbean.settime(timeData);
    if (caloriecountbean.iscalorieCounterror())
    { Log.w(getClass().getName(), caloriecountbean.errors());
      Toast.makeText(this, "Errors: " + caloriecountbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { calorieCountResult.setText(caloriecountbean.calorieCount() + ""); }
  }


  public void calorieCountCancel(View _v)
  { caloriecountbean.resetData();
    timeTextField.setText("");
    calorieCountResult.setText("");
  }
  public void auxCalcOK(View _v) 
  {
    ageData = ageTextField.getText() + "";
    auxcalcbean.setage(ageData);
    weightData = weightTextField.getText() + "";
    auxcalcbean.setweight(weightData);
    if (auxcalcbean.isauxCalcerror())
    { Log.w(getClass().getName(), auxcalcbean.errors()); 
      Toast.makeText(this, "Errors: " + auxcalcbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { auxCalcResult.setText(auxcalcbean.auxCalc() + ""); }
  }


}
