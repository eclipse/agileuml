package com.example.app.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class newCompanyBean
{ ModelFacade model = null;

  private String iden = "";
  private List errors = new ArrayList();

  public newCompanyBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setiden(String idenx)
  { iden = idenx; }

  public void resetData()
  { iden = "";
    }

  public boolean isnewCompanyerror()
  { errors.clear(); 
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void newCompany()
  { model.newCompany(iden); }

}

