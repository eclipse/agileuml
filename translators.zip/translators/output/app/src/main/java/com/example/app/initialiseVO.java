package com.example.app.ui.main;

public class initialiseVO
{ 

  public initialiseVO() {}

}


