package com.example.app.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidx.core.content.res.ResourcesCompat;
import android.content.res.AssetManager;
import android.graphics.drawable.BitmapDrawable;
import java.io.InputStream;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.webkit.ImageView;
import android.widget.TextView;


public class processTheAdmissionOfAPatientToAWardFragment extends Fragment implements OnClickListener, AdapterView.OnItemSelectedListener
{ View root;
  Context myContext;
  processTheAdmissionOfAPatientToAWardBean processtheadmissionofapatienttoawardbean;

  Spinner processTheAdmissionOfAPatientToAWardnursexSpinner;
  List<String> processTheAdmissionOfAPatientToAWardnursexListItems = new ArrayList<String>();
  String processTheAdmissionOfAPatientToAWardnursexData = "";
  Button processTheAdmissionOfAPatientToAWardOkButton;
  Button processTheAdmissionOfAPatientToAWardcancelButton;


 public processTheAdmissionOfAPatientToAWardFragment() {}

  public static processTheAdmissionOfAPatientToAWardFragment newInstance(Context c)
  { processTheAdmissionOfAPatientToAWardFragment fragment = new processTheAdmissionOfAPatientToAWardFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.processtheadmissionofapatienttoaward_layout, container, false);
    Bundle data = getArguments();
    processTheAdmissionOfAPatientToAWardnursexSpinner = (Spinner) root.findViewById(R.id.processTheAdmissionOfAPatientToAWardnursexSpinner);
    processTheAdmissionOfAPatientToAWardnursexListItems = ModelFacade.getInstance(myContext).allNurseids();
    ArrayAdapter<String> processTheAdmissionOfAPatientToAWardnursexAdapter = new ArrayAdapter<String>(myContext, android.R.layout.simple_spinner_item,processTheAdmissionOfAPatientToAWardnursexListItems);
    processTheAdmissionOfAPatientToAWardnursexAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    processTheAdmissionOfAPatientToAWardnursexSpinner.setAdapter(processTheAdmissionOfAPatientToAWardnursexAdapter);
    processTheAdmissionOfAPatientToAWardnursexSpinner.setOnItemSelectedListener(this);

    processtheadmissionofapatienttoawardbean = new processTheAdmissionOfAPatientToAWardBean(myContext);
    processTheAdmissionOfAPatientToAWardOkButton = root.findViewById(R.id.processTheAdmissionOfAPatientToAWardOK);
    processTheAdmissionOfAPatientToAWardOkButton.setOnClickListener(this);
    processTheAdmissionOfAPatientToAWardcancelButton = root.findViewById(R.id.processTheAdmissionOfAPatientToAWardCancel);
    processTheAdmissionOfAPatientToAWardcancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.processTheAdmissionOfAPatientToAWardOK)
    { processTheAdmissionOfAPatientToAWardOK(_v); }
    else if (_v.getId() == R.id.processTheAdmissionOfAPatientToAWardCancel)
    { processTheAdmissionOfAPatientToAWardCancel(_v); }
  }

  public void processTheAdmissionOfAPatientToAWardOK(View _v) 
  { 
    processtheadmissionofapatienttoawardbean.setnursex(processTheAdmissionOfAPatientToAWardnursexData);
    if (processtheadmissionofapatienttoawardbean.isprocessTheAdmissionOfAPatientToAWarderror())
    { Log.w(getClass().getName(), processtheadmissionofapatienttoawardbean.errors());
      Toast.makeText(myContext, "Errors: " + processtheadmissionofapatienttoawardbean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { processtheadmissionofapatienttoawardbean.processTheAdmissionOfAPatientToAWard(); }
  }


  public void processTheAdmissionOfAPatientToAWardCancel(View _v)
  { processtheadmissionofapatienttoawardbean.resetData();
  }
  public void onItemSelected(AdapterView<?> _parent, View _v, int _position, long _id)
  {     if (_parent == processTheAdmissionOfAPatientToAWardnursexSpinner)
    { processTheAdmissionOfAPatientToAWardnursexData = processTheAdmissionOfAPatientToAWardnursexListItems.get(_position); }
 }

  public void onNothingSelected(AdapterView<?> _parent)
  {     processTheAdmissionOfAPatientToAWardnursexData = "";
 }

}
