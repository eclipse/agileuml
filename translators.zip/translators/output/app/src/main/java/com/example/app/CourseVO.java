package com.example.app.ui.main;

import java.util.List;
import java.util.ArrayList;

public class CourseVO
{ 
  String code;

  public CourseVO() {}

  public CourseVO(String codex)
  {    code = codex;
  }

  public CourseVO(Course _x)
  {
   code = _x.code;
  }

  public String toString()
  { return ("code= " + code); }

  public static List<String> toStringList(List<CourseVO> list)
  { List<String> _res = new ArrayList<String>();
    for (int i = 0; i < list.size(); i++)
    { CourseVO _x = (CourseVO) list.get(i);
      _res.add(_x.toString()); 
    }
    return _res;
  }

  public String getcode()
  { return code; }

  public void setcode(String _x)
  { code = _x; }

}


