package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class STest { static ArrayList<STest> STest_allInstances = new ArrayList<STest>();

  STest() { STest_allInstances.add(this); }

  static STest createSTest() { STest result = new STest();
    return result; }

  static int objCount = 0;
  static ArrayList<String> ids = (new ArrayList());
  String stestId = ""; /* primary */
  static Map<String,STest> STest_index = new HashMap<String,STest>();

  static STest createByPKSTest(String stestIdx)
  { STest result = STest.STest_index.get(stestIdx);
    if (result != null) { return result; }
    result = new STest();
    STest.STest_index.put(stestIdx,result);
    result.stestId = stestIdx;
    return result; }

  static void killSTest(String stestIdx)
  { STest rem = STest_index.get(stestIdx);
    if (rem == null) { return; }
    ArrayList<STest> remd = new ArrayList<STest>();
    remd.add(rem);
    STest_index.remove(stestIdx);
    STest_allInstances.removeAll(remd);
  }


  public static void initialiseClass0()
  {
    ids = (new ArrayList());
    ids = Ocl.includingSequence(ids,"aa");
    ids = Ocl.includingSequence(ids,"bb");
  }


  public static void initialiseClass1()
  {
    ids = (new ArrayList());
    ids = Ocl.includingSequence(ids,"aa");
    ids = Ocl.includingSequence(ids,"bb");
  }


  public static STest newSTest()
  {
    STest result = null;
    result = STest.createSTest();
    result.initialise();
    return result;
  }


  public void initialise()
  {
    {}
  }

}

