package com.example.app7;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class InternetAccessCompleted { static ArrayList<InternetAccessCompleted> InternetAccessCompleted_allInstances = new ArrayList<InternetAccessCompleted>();

  InternetAccessCompleted() { InternetAccessCompleted_allInstances.add(this); }

  static InternetAccessCompleted createInternetAccessCompleted() { InternetAccessCompleted result = new InternetAccessCompleted();
    return result; }


  public void internetAccessCompleted(String response)
  {
  }

}

