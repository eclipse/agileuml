package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Route { static ArrayList<Route> Route_allInstances = new ArrayList<Route>();

  Route() { Route_allInstances.add(this); }

  static Route createRoute() { Route result = new Route();
    return result; }

  String routeId = ""; /* primary */
  static Map<String,Route> Route_index = new HashMap<String,Route>();

  static Route createByPKRoute(String routeIdx) { Route result = new Route();
    Route.Route_index.put(routeIdx,result);
    result.routeId = routeIdx;
    return result; }

  double totalDistance = 0;
  double totalEmissions = 0;
  String currentLeg = "";
  ArrayList<MapLocation> places = new ArrayList<MapLocation>();
  MapLocation currentLocation = null;
  ArrayList<RouteLeg> legs = new ArrayList<RouteLeg>();

  public static double greatCircleDistance(MapLocation loc1, MapLocation loc2)
  {
    double result = 0;
    double lat1 = 0;
    lat1 = (loc1.latitude * 180) / 3.14159;
    double lat2 = 0;
    lat2 = (loc2.latitude * 180) / 3.14159;
    double lng1 = 0;
    lng1 = (loc1.longitude * 180) / 3.14159;
    double lng2 = 0;
    lng2 = (loc2.longitude * 180) / 3.14159;
    double dlat = 0;
    dlat = Math.abs((lat1 - lat2));
    double cos1 = 0;
    cos1 = Math.cos(lng1);
    double cos2 = 0;
    cos2 = Math.cos(lng2);
    double sin1 = 0;
    sin1 = Math.sin(lng1);
    double sin2 = 0;
    sin2 = Math.sin(lng2);
    double dsin = 0;
    dsin = Math.sin(dlat);
    double dcos = 0;
    dcos = Math.cos(dlat);
    double top = 0;
    top = ((cos2 * dsin))*((cos2 * dsin)) + ((cos1 * sin2 - sin1 * cos2 * dcos))*((cos1 * sin2 - sin1 * cos2 * dcos));
    double topsqrt = 0;
    topsqrt = Math.sqrt(top);
    double bot = 0;
    bot = sin1 * sin2 + cos1 * cos2 * dcos;
    result = 6371 * Math.atan((topsqrt / bot));
    return result;
  }


  public double calculateEmissions()
  {
    double result = 0;
    result = Ocl.sumdouble(Ocl.collectSequence(legs,(leg)->{return leg.distance * leg.rate;}));
    return result;
  }

}

