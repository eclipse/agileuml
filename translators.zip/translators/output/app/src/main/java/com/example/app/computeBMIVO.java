package com.example.app4;

public class computeBMIVO
{ 
 private double height;
 private double weight;

  public computeBMIVO() {}

  public computeBMIVO(double heightx,double weightx)
  {    height = heightx;
   weight = weightx;
  }

  public double getheight()
  { return height; }

  public double getweight()
  { return weight; }

  public void setheight(double _x)
  { height = _x; }

  public void setweight(double _x)
  { weight = _x; }

}


