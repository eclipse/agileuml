package com.example.app.ui.main;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class processTheAdmissionOfAPatientToAWardBean
{ ModelFacade model = null;

  private String nursex = "";
  private Nurse instance_nursex = null;
  private List errors = new ArrayList();

  public processTheAdmissionOfAPatientToAWardBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setnursex(String nursexx)
  { nursex = nursexx; }

  public void resetData()
  { nursex = "";
    }

  public boolean isprocessTheAdmissionOfAPatientToAWarderror()
  { errors.clear(); 
    instance_nursex = model.getNurseByPK(nursex);
    if (instance_nursex == null)
    { errors.add("nursex must be a valid Nurse id"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public void processTheAdmissionOfAPatientToAWard()
  { model.processTheAdmissionOfAPatientToAWard(instance_nursex); }

}

