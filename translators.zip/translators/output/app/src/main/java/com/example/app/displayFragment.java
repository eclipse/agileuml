package com.example.app14.ui.main;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.inputmethod.InputMethodManager;
import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.example.app14.R;
import android.content.Context;
import androidx.annotation.LayoutRes;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.fragment.app.FragmentManager;
import android.view.View.OnClickListener;
import java.util.List;
import java.util.ArrayList;
import android.view.View;
import android.util.Log;
import android.widget.Toast;
import android.widget.RadioGroup;
import android.widget.EditText;
import android.webkit.WebView;
import android.widget.TextView;


public class displayFragment extends Fragment implements OnClickListener
{ View root;
  Context myContext;
  displayBean displaybean;

  EditText displaynameTextField;
  String displaynameData = "";
  WebView displayResult;
  Button displayOkButton;
  Button displaycancelButton;


 public displayFragment() {}

  public static displayFragment newInstance(Context c)
  { displayFragment fragment = new displayFragment();
    Bundle args = new Bundle();
    fragment.setArguments(args);
    fragment.myContext = c;
    return fragment;
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState); }

  @Override
  public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
  { root = inflater.inflate(R.layout.display_layout, container, false);
    Bundle data = getArguments();
    displaynameTextField = (EditText) root.findViewById(R.id.displaynameField);
    displayResult = (WebView) root.findViewById(R.id.displayResult);
    displaybean = new displayBean(myContext);
    displayOkButton = root.findViewById(R.id.displayOK);
    displayOkButton.setOnClickListener(this);
    displaycancelButton = root.findViewById(R.id.displayCancel);
    displaycancelButton.setOnClickListener(this);
    return root;
  }


  public void onClick(View _v)
  { InputMethodManager _imm = (InputMethodManager) myContext.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
    try { _imm.hideSoftInputFromWindow(_v.getWindowToken(), 0); } catch (Exception _e) { }
    if (_v.getId() == R.id.displayOK)
    { displayOK(_v); }
    else if (_v.getId() == R.id.displayCancel)
    { displayCancel(_v); }
  }

  public void displayOK(View _v) 
  { 
    displaynameData = displaynameTextField.getText() + "";
    displaybean.setname(displaynameData);
    if (displaybean.isdisplayerror())
    { Log.w(getClass().getName(), displaybean.errors());
      Toast.makeText(myContext, "Errors: " + displaybean.errors(), Toast.LENGTH_LONG).show();
    }
    else
    { displayResult.loadUrl(displaybean.display().url + ""); }
  }


  public void displayCancel(View _v)
  { displaybean.resetData();
    displaynameTextField.setText("");
  }
}
