package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.StringTokenizer;
import java.util.Date; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.*;
import android.net.Uri;
import android.os.Bundle;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.*;
import com.google.firebase.database.*;

public class FirebaseDbi
{ static FirebaseDbi instance = null;
  DatabaseReference database = null;

  public static FirebaseDbi getInstance()
  { if (instance == null)
    { instance = new FirebaseDbi(); }
    return instance;
  }

  FirebaseDbi() { }

  public void connectByURL(String url)
  { database = FirebaseDatabase.getInstance(url).getReference();
    if (database == null) { return; }
    ValueEventListener person_listener = new ValueEventListener()
    {
      @Override
      public void onDataChange(DataSnapshot dataSnapshot)
      { // Get instances from the cloud database
        Map<String,Object> _persons = (Map<String,Object>) dataSnapshot.getValue();
        if (_persons != null)
        { Set<String> _keys = _persons.keySet();
          for (String _key : _keys)
          { Object _x = _persons.get(_key);
            Person_DAO.parseRaw(_x);
          }
          // Delete local objects which are not in the cloud:
          ArrayList<Person> _locals = new ArrayList<Person>();
          _locals.addAll(Person.Person_allInstances);
          for (Person _x : _locals)
          { if (_keys.contains(_x.id)) { }
            else { Person.killPerson(_x.id); }
          }
        }
      }
  
      @Override
      public void onCancelled(DatabaseError databaseError)
      { }
    };
    database.child("persons").addValueEventListener(person_listener);
  
  }
  
  public void persistPerson(Person ex)
  { PersonVO _evo = new PersonVO(ex); 
    String _key = _evo.id; 
    if (database == null) { return; }
    database.child("persons").child(_key).setValue(_evo);
  }
  
  public void deletePerson(Person ex)
  { String _key = ex.id; 
    if (database == null) { return; }
    database.child("persons").child(_key).removeValue();
  }

}
