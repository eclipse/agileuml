package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Strings2Java8 { static ArrayList<Strings2Java8> Strings2Java8_allInstances = new ArrayList<Strings2Java8>();

  Strings2Java8() { Strings2Java8_allInstances.add(this); }

  static Strings2Java8 createStrings2Java8() { Strings2Java8 result = new Strings2Java8();
    return result; }

  String strings2java8Id = ""; /* primary */
  static Map<String,Strings2Java8> Strings2Java8_index = new HashMap<String,Strings2Java8>();

  static Strings2Java8 createByPKStrings2Java8(String strings2java8Idx)
  { Strings2Java8 result = Strings2Java8.Strings2Java8_index.get(strings2java8Idx);
    if (result != null) { return result; }
    result = new Strings2Java8();
    Strings2Java8.Strings2Java8_index.put(strings2java8Idx,result);
    result.strings2java8Id = strings2java8Idx;
    return result; }

  static void killStrings2Java8(String strings2java8Idx)
  { Strings2Java8 rem = Strings2Java8_index.get(strings2java8Idx);
    if (rem == null) { return; }
    ArrayList<Strings2Java8> remd = new ArrayList<Strings2Java8>();
    remd.add(rem);
    Strings2Java8_index.remove(strings2java8Idx);
    Strings2Java8_allInstances.removeAll(remd);
  }


  public String strings2op()
  {
    String result = "";
    String ss = "";
    ss = ("" + "test string");
    ArrayList<Integer> bb = new ArrayList<Integer>();
    bb = Ocl.collectSequence(Ocl.characters(ss),(_ch)->{return Ocl.char2byte(_ch);});
    ArrayList<String> cc = new ArrayList<String>();
    cc = Ocl.collectSequence(Ocl.integerSubrange(1,3),(var0)->{return "";});
    cc = Ocl.concatenate(Ocl.subrange(cc,1,0),(Ocl.characters(Ocl.subrange(ss,1 + 1,3))));
    int i = 0;
    i = ((ss.indexOf(" ") + 1) - 1);
    i = (((Ocl.subrange(ss,5 + 1,ss.length()).indexOf(" " + "") + 1) > 0) ? ((Ocl.subrange(ss,5 + 1,ss.length()).indexOf(" " + "") + 1) + 5 - 1) : -1);
    i = ((ss.lastIndexOf("s") + 1) - 1);
    i = ss.length();
    String pp = "";
    pp = Ocl.subrange(ss,5 + 1,ss.length());
    return Ocl.subrange(ss,0 + 1,5);
  }

}

