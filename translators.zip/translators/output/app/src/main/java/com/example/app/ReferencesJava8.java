package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class ReferencesJava8 { static ArrayList<ReferencesJava8> ReferencesJava8_allInstances = new ArrayList<ReferencesJava8>();

  ReferencesJava8() { ReferencesJava8_allInstances.add(this); }

  static ReferencesJava8 createReferencesJava8() { ReferencesJava8 result = new ReferencesJava8();
    return result; }

  String referencesjava8Id = ""; /* primary */
  static Map<String,ReferencesJava8> ReferencesJava8_index = new HashMap<String,ReferencesJava8>();

  static ReferencesJava8 createByPKReferencesJava8(String referencesjava8Idx)
  { ReferencesJava8 result = ReferencesJava8.ReferencesJava8_index.get(referencesjava8Idx);
    if (result != null) { return result; }
    result = new ReferencesJava8();
    ReferencesJava8.ReferencesJava8_index.put(referencesjava8Idx,result);
    result.referencesjava8Id = referencesjava8Idx;
    return result; }

  static void killReferencesJava8(String referencesjava8Idx)
  { ReferencesJava8 rem = ReferencesJava8_index.get(referencesjava8Idx);
    if (rem == null) { return; }
    ArrayList<ReferencesJava8> remd = new ArrayList<ReferencesJava8>();
    remd.add(rem);
    ReferencesJava8_index.remove(referencesjava8Idx);
    ReferencesJava8_allInstances.removeAll(remd);
  }


  public void refop()
  {
    ArrayList<Integer> a = new ArrayList<Integer>();
    a = Ocl.initialiseSequence(1,2,3,4);
    ArrayList<Integer> b = new ArrayList<Integer>();
    b = Ocl.initialiseSequence(2,4,6,8);
    boolean tst = false;
    tst = (a == b);
    tst = (a == b);
    tst = (a.equals(b));
    a = b;
    tst = (a == b);
    tst = (a == b);
    tst = (a.equals(b));
  }

}

