package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class BitsetJava8 { static ArrayList<BitsetJava8> BitsetJava8_allInstances = new ArrayList<BitsetJava8>();

  BitsetJava8() { BitsetJava8_allInstances.add(this); }

  static BitsetJava8 createBitsetJava8() { BitsetJava8 result = new BitsetJava8();
    return result; }

  String bitsetjava8Id = ""; /* primary */
  static Map<String,BitsetJava8> BitsetJava8_index = new HashMap<String,BitsetJava8>();

  static BitsetJava8 createByPKBitsetJava8(String bitsetjava8Idx)
  { BitsetJava8 result = BitsetJava8.BitsetJava8_index.get(bitsetjava8Idx);
    if (result != null) { return result; }
    result = new BitsetJava8();
    BitsetJava8.BitsetJava8_index.put(bitsetjava8Idx,result);
    result.bitsetjava8Id = bitsetjava8Idx;
    return result; }

  static void killBitsetJava8(String bitsetjava8Idx)
  { BitsetJava8 rem = BitsetJava8_index.get(bitsetjava8Idx);
    if (rem == null) { return; }
    ArrayList<BitsetJava8> remd = new ArrayList<BitsetJava8>();
    remd.add(rem);
    BitsetJava8_index.remove(bitsetjava8Idx);
    BitsetJava8_allInstances.removeAll(remd);
  }


  public void bitsetop()
  {
    ArrayList<Boolean> bs = new ArrayList<Boolean>();
    bs = Ocl.collectSequence(Ocl.integerSubrange(1,4),(var0)->{return false;});
    bs.set(0 + 1 - 1,true);
    bs.set(2 + 1 - 1,true);
    bs.set(1 + 1 - 1,!(((boolean) (bs).get(1 + 1 - 1))));
    int i = 0;
    i = Collections.frequency(bs,true);
    i = bs.size();
    i = (bs.lastIndexOf(true) + 1);
    bs = Ocl.union(Ocl.union(Ocl.subrange(bs,1,0),Ocl.collectSequence(Ocl.integerSubrange(0 + 1,2),(_i)->{return !(((boolean) (bs).get(_i - 1)));})),Ocl.subrange(bs,2 + 1));
    ArrayList<Boolean> bs1 = new ArrayList<Boolean>();
    bs1 = Ocl.collectSequence(Ocl.integerSubrange(1,64),(var1)->{return false;});
    i = bs1.size();
    bs1 = Ocl.union(Ocl.union(Ocl.subrange(bs1,1,0),Ocl.collectSequence(Ocl.integerSubrange(0 + 1,3),(var2)->{return true;})),Ocl.subrange(bs1,3 + 1));
    bs = Ocl.collectSequence(Ocl.integerSubrange(1,Ocl.min(Ocl.initialiseSet(bs.size(),bs1.size()))),(_i)->{return ((boolean) (bs).get(_i - 1)) || ((boolean) (bs1).get(_i - 1));});
  }

}

