package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class Example { static ArrayList<Example> Example_allInstances = new ArrayList<Example>();

  Example() { Example_allInstances.add(this); }

  static Example createExample() { Example result = new Example();
    return result; }

   String exampleId = ""; /* primary */
  static Map< String,Example> Example_index = new HashMap< String,Example>();

  static Example createByPKExample( String exampleIdx)
  { Example result = Example.Example_index.get(exampleIdx);
    if (result != null) { return result; }
    result = new Example();
    Example.Example_index.put(exampleIdx,result);
    result.exampleId = exampleIdx;
    return result; }

  static void killExample( String exampleIdx)
  { Example rem = Example_index.get(exampleIdx);
    if (rem == null) { return; }
    ArrayList<Example> remd = new ArrayList<Example>();
    remd.add(rem);
    Example_index.remove(exampleIdx);
    Example_allInstances.removeAll(remd);
  }


  public  void op()
  {
     int x = 0;
    x = 1000;
    assert x > 0 : "invalid x";
    x = 0;
    throw "error";
    try {     x = x / 0;
    }
      catch (Throwable e) {     x = x + 1;
    e.printStackTrace();
      }
       finally {     x = -1;
      }

  }

}

