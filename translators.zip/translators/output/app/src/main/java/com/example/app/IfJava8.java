package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class IfJava8 { static ArrayList<IfJava8> IfJava8_allInstances = new ArrayList<IfJava8>();

  IfJava8() { IfJava8_allInstances.add(this); }

  static IfJava8 createIfJava8() { IfJava8 result = new IfJava8();
    return result; }

  String ifjava8Id = ""; /* primary */
  static Map<String,IfJava8> IfJava8_index = new HashMap<String,IfJava8>();

  static IfJava8 createByPKIfJava8(String ifjava8Idx)
  { IfJava8 result = IfJava8.IfJava8_index.get(ifjava8Idx);
    if (result != null) { return result; }
    result = new IfJava8();
    IfJava8.IfJava8_index.put(ifjava8Idx,result);
    result.ifjava8Id = ifjava8Idx;
    return result; }

  static void killIfJava8(String ifjava8Idx)
  { IfJava8 rem = IfJava8_index.get(ifjava8Idx);
    if (rem == null) { return; }
    ArrayList<IfJava8> remd = new ArrayList<IfJava8>();
    remd.add(rem);
    IfJava8_index.remove(ifjava8Idx);
    IfJava8_allInstances.removeAll(remd);
  }


  public boolean ifop()
  {
    boolean result = false;
    int x = 0;
    x = 5;
    if ((x < 0))
    {
      return true;
    }
    else {
      if ((x == 0))
    {
      return false;
    }
    else {
      {}
    }
    }
    return true;
  }

}

