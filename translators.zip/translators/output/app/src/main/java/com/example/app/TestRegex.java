package com.example.app;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class TestRegex { static ArrayList<TestRegex> TestRegex_allInstances = new ArrayList<TestRegex>();

  TestRegex() { TestRegex_allInstances.add(this); }

  static TestRegex createTestRegex() { TestRegex result = new TestRegex();
    return result; }

  String testregexId = ""; /* primary */
  static Map<String,TestRegex> TestRegex_index = new HashMap<String,TestRegex>();

  static TestRegex createByPKTestRegex(String testregexIdx)
  { TestRegex result = TestRegex.TestRegex_index.get(testregexIdx);
    if (result != null) { return result; }
    result = new TestRegex();
    TestRegex.TestRegex_index.put(testregexIdx,result);
    result.testregexId = testregexIdx;
    return result; }

  static void killTestRegex(String testregexIdx)
  { TestRegex rem = TestRegex_index.get(testregexIdx);
    if (rem == null) { return; }
    ArrayList<TestRegex> remd = new ArrayList<TestRegex>();
    remd.add(rem);
    TestRegex_index.remove(testregexIdx);
    TestRegex_allInstances.removeAll(remd);
  }


  public void test1(String s1, String s2)
  {
    displayString(("Trim: " + s1.trim()));
    displayString(("Last index of: " + (s1.lastIndexOf(s2) + 1)));
    displayString(("Equals ignore case: " + s1.equalsIgnoreCase(s2)));
  }


  public void test2(String s1, String s2)
  {
    displayString(("Is match: " + Ocl.isMatch(s1,s2)));
    displayString(("Has match: " + Ocl.hasMatch(s1,s2)));
    displayString(("All matches: " + Ocl.allMatches(s1,s2)));
  }


  public void test3(String s1, String s2, String rep)
  {
    displayString(("Replace: " + Ocl.replace(s1,s2,rep)));
  }


  public void test4(String s1, String s2, String rep)
  {
    displayString(("Split: " + Ocl.split(s1,s2)));
    displayString(("Replace all: " + Ocl.replaceAll(s1,s2,rep)));
  }

}

