package com.example.bmicalc;

import android.os.Bundle;
import android.app.ListActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class ViewsearchByPersonheight extends ListActivity
{ private ModelFacade model;

  ArrayList<PersonVO> personList;
  EditText searchByPersonheightFieldText;
  String searchByPersonheightFieldData = "";

  @Override
  protected void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState);
    setContentView(R.layout.searchByPersonheight_layout);
    model = ModelFacade.getInstance(this);
    searchByPersonheightFieldText = (EditText) findViewById(R.id.searchByPersonheightField);
    personList = new ArrayList<String>();
    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,personList);
    setListAdapter(adapter);
  }

  public void searchByPersonheightOK(View _v) 
  {
    searchByPersonheightFieldData = searchByPersonheightFieldText.getText() + "";
    personList = PersonVO.getStringList(model.searchByPersonheight(searchByPersonheightFieldData));
  }

  public void searchByPersonheightCancel(View _v) 
  { } // go back to main screen

  public void onListItemClick(ListView parent, View v, int position, long id)
  { model.setSelectedPerson(position); }

}
