package com.example.app;

import android.content.Context;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModelFacade
{ Dbi dbi; 

  static ModelFacade instance = null; 

  public static ModelFacade getInstance(Context context)
  { if (instance == null) 
    { instance = new ModelFacade(context); }
    return instance;
  }


  PersonVO currentPerson = null;

  public List<PersonVO> currentPersons = new ArrayList<PersonVO>();

  private ModelFacade(Context context)
  { dbi = new Dbi(context); }

  public String checkRetirement(int age)
  { 
    String result;
    if age < 65
    {
      result = "you cannot retire"
    }
    else {
      }
    if age >= 65
    {
      result = "you can retire"
    }
    else {
      }

    return result;
  }

  public List<PersonVO> listPerson()
  { currentPersons = dbi.listPerson();
    return currentPersons;
  }

  public List<String> stringListPerson()
  { currentPersons = dbi.listPerson();
    List<String> res = new ArrayList<String>();
    for (int x = 0; x < currentPersons.size(); x++)
    { PersonVO _item = (PersonVO) currentPersons.get(x);
      res.add(_item + "");
    }
    return res;
  }

  private Person getPersonByPK(String _val)
  { ArrayList<PersonVO> _res = dbi.searchByPersonname(_val);
    if (_res.size() == 0)
    { return null; }
    else
    { PersonVO _vo = _res.get(0);
      Person _itemx = new Person(_val);
      _itemx.name = _vo.name;
      _itemx.age = _vo.age;
      return _itemx;
    }
  }

  public void setSelectedPerson(PersonVO x)
  { currentPerson = x; }

  public void setSelectedPerson(int i)
  { if (i < currentPersons.size())
    { currentPerson = currentPersons.get(i); }
  }

  public PersonVO getSelectedPerson()
  { return currentPerson; }

  public void editPerson(PersonVO _x)
  { dbi.editPerson(_x); 
    currentPerson = _x;
  }

  public void createPerson(PersonVO _x)
  { dbi.createPerson(_x);
    currentPerson = _x;
  }

  public void deletePerson(String _id)
  { dbi.deletePerson(_id);
    currentPerson = null;
  }

  public List<PersonVO> searchByPersonname(String namex)
  { currentPersons = dbi.searchByPersonname(namex);
    return currentPersons;
  }

  public List<PersonVO> searchByPersonage(String agex)
  { currentPersons = dbi.searchByPersonage(agex);
    return currentPersons;
  }

}
