package com.example.app9;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.fragment.app.DialogFragment;


public class MarkerDialogFragment extends DialogFragment
{  ModelFacade model;
   Context myContext;

    public MarkerDialogFragment(Context context)
    { myContext = context; }

    public static MarkerDialogFragment newInstance(Context context)
    {
        MarkerDialogFragment fragment = new MarkerDialogFragment(context);
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        model = ModelFacade.getInstance(myContext);
        AlertDialog.Builder builder = new AlertDialog.Builder(myContext);
        LayoutInflater inflater = requireActivity().getLayoutInflater();

        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View view = inflater.inflate(R.layout.dialog_layout, null);
        builder.setView(view);

        final EditText name = view.findViewById(R.id.markername);
        builder.setTitle("Create marker here?").setNegativeButton("No",
                   null).setPositiveButton("Yes",
                new DialogInterface.OnClickListener()
                { @Override
                public void onClick(DialogInterface dialog, int which)
                { model.markerCreated(name.getText() + ""); }});
        return builder.create();
    }

  /*   @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    { return super.onCreateView(inflater, container, savedInstanceState);
        // Inflate the layout for this fragment
        // return inflater.inflate(R.layout.dialog_layout, container, false);
    } */
}
