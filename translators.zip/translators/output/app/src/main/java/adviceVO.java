package com.example.app;

public class adviceVO
{ 

  public adviceVO() {}

}


