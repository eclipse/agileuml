package com.example.app;

public class includedCaseVO
{ 

  public includedCaseVO() {}

}


