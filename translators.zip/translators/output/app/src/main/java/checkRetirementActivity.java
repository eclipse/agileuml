package com.example.app;


import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.util.Log;
import android.widget.EditText;


public class checkRetirementActivity extends Activity
{ checkRetirementBean checkretirementbean;

  EditText ageTextField;
  String ageData = "";
  TextView checkRetirementResult;


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.checkRetirement_layout);
    ageTextField = (EditText) findViewById(R.id.checkRetirementageField);
    checkRetirementResult = (TextView) findViewById(R.id.checkRetirementResult);
    checkretirementbean = new checkRetirementBean(this);
  }


  public void checkRetirementOK(View _v) 
  {
    ageData = ageTextField.getText() + "";
    checkretirementbean.setage(ageData);
    if (checkretirementbean.ischeckRetirementerror())
    { Log.w(getClass().getName(), checkretirementbean.errors()); }
    else
    { checkRetirementResult.setText(checkretirementbean.checkRetirement()); }
  }


  public void checkRetirementCancel(View _v) {}
}
