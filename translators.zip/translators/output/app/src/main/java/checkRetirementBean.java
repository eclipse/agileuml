package com.example.app;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class checkRetirementBean
{ ModelFacade model = null;

  private String age = "";
  private int iage = 0;
  private List errors = new ArrayList();

  public checkRetirementBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setage(String agex)
  { age = agex; }

  public void resetData()
  { age = "";
    }

  public boolean ischeckRetirementerror()
  { errors.clear(); 
    try { iage = Integer.parseInt(age); }
    catch (Exception e)
    { errors.add(age + " is not an integer"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public String checkRetirement()
  { return model.checkRetirement(iage); }

}

