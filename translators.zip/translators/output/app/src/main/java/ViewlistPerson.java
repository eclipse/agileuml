package com.example.app;

import android.os.Bundle;
import android.app.ListActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class listPersonActivity extends ListActivity
{ private ModelFacade model;

  ArrayList<PersonVO> personList;

  @Override
  protected void onCreate(Bundle savedInstanceState)
  { super.onCreate(savedInstanceState);
    setContentView(R.layout.listPerson_layout);
    model = ModelFacade.getInstance(this);
    ArrayList<String> itemList = model.stringListPerson();
    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,itemList);
    setListAdapter(adapter);
  }

  public void onListItemClick(ListView parent, View v, int position, long id)
  { model.setSelectedPerson(position); }

}
