package com.example.app10;

import android.telephony.SmsManager;

import java.util.ArrayList;

/* Note: Using this component requires Manifest.permission.SEND_SMS permission */

public class SMSComponent
{  public boolean canSendText()
   { return SmsManager.getDefault() != null; }

    public void sendText(String text, ArrayList<String> receivers)
    { SmsManager sms = SmsManager.getDefault();
        for (int x = 0; x < receivers.size(); x++)
        { String r = receivers.get(x);
          sms.sendTextMessage(r,null,text,null,null);
        }
    }

}
