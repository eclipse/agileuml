import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class FirebaseAuthenticator
{ FirebaseAuth authenticator = FirebaseAuth.getInstance();

  static FirebaseAuthenticator instance = null; 
  
  public static FirebaseAuthenticator getInstance()
  { if (instance == null) 
    { instance = new FirebaseAuthenticator(); }
	return instance; 
  }

  public String createUser(String email, String password)
  { authenticator.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this, 
      task -> 
      { if (task.isSuccessful()) { return "Success"; }
        else 
        { return task.getException().getMessage(); }
      });
  }

  public String signIn(String email, String password) 
  { authenticator.signInWithEmailAndPassword(email,password).addOnCompleteListener(this, 
      task -> 
      { if (task.isSuccessful()) { return "Success"; }
        else 
        { return task.getException().getMessage(); }
      });
  }

  public String userId()
  { String res = null;
    FirebaseUser user = authenticator.getCurrentUser();
    if (user != null)
    { res = user.getUid(); }
    return res;
  }

  public String signOut()
  { try
    { authenticator.signOut();
      return "Success";
    } catch (Exception e)
      { return e + ""; }
  }
}
