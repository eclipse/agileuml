package com.example.app;

public class computeBMIVO
{ 
 private String name;
 private double weight;
 private double height;

  public computeBMIVO() {}

  public computeBMIVO(String namex,double weightx,double heightx)
  {    name = namex;
   weight = weightx;
   height = heightx;
  }

  public String getname()
  { return name; }

  public double getweight()
  { return weight; }

  public double getheight()
  { return height; }

  public void setname(String _x)
  { name = _x; }

  public void setweight(double _x)
  { weight = _x; }

  public void setheight(double _x)
  { height = _x; }

}


