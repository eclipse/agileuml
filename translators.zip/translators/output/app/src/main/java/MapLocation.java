package com.example.app9;

public class MapLocation
{ double latitude = 0;
  double longitude = 0;
  double altitude = 0;
  String name = "";

  MapLocation(double lat, double lng)
  { latitude = lat;
    longitude = lng;
  }

  public double distanceTo(MapLocation loc)
  { double result = 0;

    double lat1 = (latitude/180)*Math.PI;
    double lat2 = (loc.latitude/180)*Math.PI;
    double lng1 = (longitude/180)*Math.PI;
    double lng2 = (loc.longitude/180)*Math.PI;
    double dlat = Math.abs(( lat1 - lat2 ));
    double cos1 = Math.cos(lng1);
    double cos2 = Math.cos(lng2);
    double sin1 = Math.sin(lng1);
    double sin2 = Math.sin(lng2);
    double dsin = Math.sin(dlat);
    double dcos = Math.cos(dlat);
    double top = ((( cos2 * dsin ))*(( cos2 * dsin ))) + ((( cos1 * sin2 - sin1 * cos2 * dcos ))*(( cos1 * sin2 - sin1 * cos2 * dcos )));
    double topsqrt = Math.sqrt(top);
    double bot = sin1 * sin2 + cos1 * cos2 * dcos;
    result = 6371 * Math.atan(( topsqrt / bot ));
    return result;
  }
}
