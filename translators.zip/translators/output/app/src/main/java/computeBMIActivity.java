package com.example.app;


import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.util.Log;
import android.widget.EditText;


public class computeBMIActivity extends Activity
{ computeBMIBean computebmibean;
  adviceBean advicebean;

  EditText nameTextField;
  String nameData = "";
  EditText weightTextField;
  String weightData = "";
  EditText heightTextField;
  String heightData = "";
  TextView computeBMIResult;


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.computeBMI_layout);
    nameTextField = (EditText) findViewById(R.id.computeBMInameField);
    weightTextField = (EditText) findViewById(R.id.computeBMIweightField);
    heightTextField = (EditText) findViewById(R.id.computeBMIheightField);
    computeBMIResult = (TextView) findViewById(R.id.computeBMIResult);
    computebmibean = new computeBMIBean(this);
    advicebean = new adviceBean(this);
  }


  public void computeBMIOK(View _v) 
  {
    nameData = nameTextField.getText() + "";
    computebmibean.setname(nameData);
    weightData = weightTextField.getText() + "";
    computebmibean.setweight(weightData);
    heightData = heightTextField.getText() + "";
    computebmibean.setheight(heightData);
    if (computebmibean.iscomputeBMIerror())
    { Log.w(getClass().getName(), computebmibean.errors()); }
    else
    { computeBMIResult.setText(computebmibean.computeBMI()); }
  }


  public void computeBMICancel(View _v) {}
  public void adviceOK(View _v) 
  {
    if (advicebean.iscomputeBMIerror())
    { Log.w(getClass().getName(), advicebean.errors()); }
    else
    { advicebean.advice(); }
  }


}
