package com.example.app;


import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.util.Log;
import android.widget.EditText;


public class ViewdeletePerson extends Activity
{ PersonBean personbean;
  ModelFacade model = null;

  EditText nameTextField;
  String nameData = "";


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.deletePerson_layout);
    nameTextField = (EditText) findViewById(R.id.deletePersonname);
    personbean = new PersonBean(this);
    model = ModelFacade.getInstance(this);
    PersonVO _current = model.getSelectedPerson();
    if (_current != null)
    { nameTextField.setText(_current.name); }
  }


  public void deletePersonOK(View _v) 
  {
    nameData = nameTextField.getText() + "";
    personbean.setname(nameData);
    if (personbean.isdeletePersonerror())
    { Log.w(getClass().getName(), personbean.errors()); }
    else
    { personbean.deletePerson(); }
  }


  public void deletePersonCancel(View _v) {}
}
