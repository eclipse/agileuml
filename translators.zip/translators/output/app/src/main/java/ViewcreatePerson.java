package com.example.bmicalc;


import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.util.Log;
import android.widget.EditText;


public class ViewcreatePerson extends Activity
{ PersonBean personbean;
  EditText nameTextField;
  String nameData = "";
  EditText weightTextField;
  String weightData = "";
  EditText heightTextField;
  String heightData = "";
  EditText BMITextField;
  String BMIData = "";


  @Override
  protected void onCreate(Bundle bundle)
  { super.onCreate(bundle);
    setContentView(R.layout.createPerson_layout);
    nameTextField = (EditText) findViewById(R.id.createPersonname);
    weightTextField = (EditText) findViewById(R.id.createPersonweight);
    heightTextField = (EditText) findViewById(R.id.createPersonheight);
    BMITextField = (EditText) findViewById(R.id.createPersonBMI);
    personbean = new PersonBean(this);
  }


  public void createPersonOK(View _v) 
  {
    nameData = nameTextField.getText() + "";
    personbean.setname(nameData);
    weightData = weightTextField.getText() + "";
    personbean.setweight(weightData);
    heightData = heightTextField.getText() + "";
    personbean.setheight(heightData);
    BMIData = BMITextField.getText() + "";
    personbean.setBMI(BMIData);
    if (personbean.iscreatePersonerror())
    { Log.w(getClass().getName(), personbean.errors()); }
    else
    { personbean.createPerson(); }
  }


  public void createPersonCancel(View _v) {}
}
