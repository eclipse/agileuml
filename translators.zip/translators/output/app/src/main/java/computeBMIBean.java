package com.example.app;

import java.util.ArrayList;

import java.util.List;

import android.content.Context;

public class computeBMIBean
{ ModelFacade model = null;

  private String name = "";
  private String weight = "";
  private double dweight = 0;
  private String height = "";
  private double dheight = 0;
  private List errors = new ArrayList();

  public computeBMIBean(Context _c) { model = ModelFacade.getInstance(_c); }

  public void setname(String namex)
  { name = namex; }

  public void setweight(String weightx)
  { weight = weightx; }

  public void setheight(String heightx)
  { height = heightx; }

  public void resetData()
  { name = "";
    weight = "";
    height = "";
    }

  public boolean iscomputeBMIerror()
  { errors.clear(); 
    try { dweight = Double.parseDouble(weight); }
    catch (Exception e)
    { errors.add(weight + " is not a double"); }
    try { dheight = Double.parseDouble(height); }
    catch (Exception e)
    { errors.add(height + " is not a double"); }
    return errors.size() > 0;
  }

  public String errors() { return errors.toString(); }

  public String computeBMI()
  { return model.computeBMI(name,dweight,dheight); }

}

