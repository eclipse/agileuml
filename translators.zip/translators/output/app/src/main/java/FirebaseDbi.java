package com.example.app.ui.main;

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.StringTokenizer;
import java.util.Date; 
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.*;
import com.google.firebase.auth.*;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirebaseDbi
{ static FirebaseDbi instance = null;
  DatabaseReference database = null;

  public static FirebaseDbi getInstance()
  { if (instance == null)
    { instance = new FirebaseDbi(); }
    return instance;
  }

  FirebaseDbi()
  { database = FirebaseDatabase.getInstance().getReference();
    
    ValueEventListener listener = new ValueEventListener()
    {
      @Override
      public void onDataChange(DataSnapshot dataSnapshot)
      { // Get object
        PersonVO _ex = dataSnapshot.getValue(PersonVO.class);
        Person _x = Person.Person_index.get(_ex.id);
        if (_x == null)        
        { _x = Person.createByPKPerson(_ex.id); }
        _x.id = _ex.id;
        _x.name = _ex.name;
        _x.age = _ex.age;
      }
  
      @Override
      public void onCancelled(DatabaseError databaseError)
      { }
    };
    database.child("persons").addValueEventListener(listener);
  }
  
  public void persistPerson(Person ex)
  { PersonVO _evo = new PersonVO(ex); 
    String _key = _evo.id; 
    database.child("persons").child(_key).setValue(_evo);
  }
  
  public void deletePerson(Person ex)
  { String _key = ex.id; 
    database.child("persons").child(_key).removeValue();
  }
}
