package com.example.app;

public class checkRetirementVO
{ 
 private int age;

  public checkRetirementVO() {}

  public checkRetirementVO(int agex)
  {    age = agex;
  }

  public int getage()
  { return age; }

  public void setage(int _x)
  { age = _x; }

}


