package com.example.app;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import java.util.List;
import java.util.ArrayList;

public class Dbi extends SQLiteOpenHelper
{ SQLiteDatabase database;
  private static final String DBNAME = "app.db";
  private static final int DBVERSION = 1;

  static final String Person_TABLE_NAME = "Person";
  static final int Person_COL_ID = 0;
  static final int Person_COL_NAME = 1;
  static final int Person_COL_AGE = 2;
  static final String[] Person_COLS = new String[]{"_id", "name", "age"};
  static final int Person_NUMBER_COLS = 2;

  private static final String Person_CREATE_SCHEMA =
     "create table Person (_id integer primary key autoincrement" + 
    ", name VARCHAR(50) not null" + 
    ", age integer not null" + 
    " )";

  public Dbi(Context context)
  { super(context, DBNAME, null, DBVERSION); }

  @Override
  public void onCreate(SQLiteDatabase db)
  { db.execSQL(Person_CREATE_SCHEMA);
   }


  public ArrayList<PersonVO> listPerson()
  { ArrayList<PersonVO> res = new ArrayList<PersonVO>();
    database = getWritableDatabase();
    Cursor cursor = database.query(Person_TABLE_NAME,Person_COLS,null,null,null,null,null);
    cursor.moveToFirst();
    while(!cursor.isAfterLast())
    { PersonVO personvo = new PersonVO();
      personvo.setname(cursor.getString(Person_COL_NAME));
      personvo.setage(cursor.getInt(Person_COL_AGE));
      res.add(personvo);
      cursor.moveToNext();
    }
    cursor.close();
    return res;
  }

  public void createPerson(PersonVO personvo)
  { database = getWritableDatabase();
    ContentValues _wr = new ContentValues(Person_NUMBER_COLS);
    _wr.put(Person_COLS[Person_COL_NAME],personvo.getname());
    _wr.put(Person_COLS[Person_COL_AGE],personvo.getage());
    database.insert(Person_TABLE_NAME,Person_COLS[1],_wr);
  }


  public ArrayList<PersonVO> searchByPersonname(String _val)
  { ArrayList<PersonVO> res = new ArrayList<PersonVO>();
    database = getWritableDatabase();
    String[] _args = new String[]{_val};
    Cursor cursor = database.rawQuery("select name, age from Person where name = ?", _args);
    cursor.moveToFirst();
    while(!cursor.isAfterLast())
    { PersonVO personvo = new PersonVO();
      personvo.setname(cursor.getString(Person_COL_NAME));
      personvo.setage(cursor.getInt(Person_COL_AGE));
      res.add(personvo);
      cursor.moveToNext();
    }
    cursor.close();
    return res;
  }


  public ArrayList<PersonVO> searchByPersonage(String _val)
  { ArrayList<PersonVO> res = new ArrayList<PersonVO>();
    database = getWritableDatabase();
    String[] _args = new String[]{_val};
    Cursor cursor = database.rawQuery("select name, age from Person where age = ?", _args);
    cursor.moveToFirst();
    while(!cursor.isAfterLast())
    { PersonVO personvo = new PersonVO();
      personvo.setname(cursor.getString(Person_COL_NAME));
      personvo.setage(cursor.getInt(Person_COL_AGE));
      res.add(personvo);
      cursor.moveToNext();
    }
    cursor.close();
    return res;
  }

  public void editPerson(PersonVO personvo)
  { database = getWritableDatabase();
    ContentValues _wr = new ContentValues(Person_NUMBER_COLS);
    _wr.put(Person_COLS[Person_COL_NAME],personvo.getname());
    _wr.put(Person_COLS[Person_COL_AGE],personvo.getage());
    String[] _args = new String[]{personvo.getname() };
    database.update(Person_TABLE_NAME, _wr, "name =?", _args);
  }

  public void deletePerson(String _val)
  { database = getWritableDatabase();
    String[] _args = new String[]{ _val };
    database.delete(Person_TABLE_NAME, "name = ?", _args);
  }

  // @Override
  public void onDestroy()
  { // super.onDestroy();
    database.close(); }

  public void onUpgrade(SQLiteDatabase d, int x, int y) {}

}
