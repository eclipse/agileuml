package com.example.app9;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
// import android.location.Location;
// import android.location.LocationListener;
import android.os.Bundle;
import android.widget.Toast;

// import com.google.android.material.snackbar.Snackbar;

// import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnSuccessListener;

// import com.google.android.gms.location.LocationServices;

// import com.google.android.gms.common.api.GoogleApi;
// import com.google.android.gms.common.api.FusedLocationProviderClient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MapsActivity extends FragmentActivity
        implements OnMapReadyCallback, GoogleMap.OnMapClickListener,  GoogleMap.OnMarkerClickListener,
        GoogleMap.OnInfoWindowClickListener,
        GoogleMap.OnMarkerDragListener
{
    ModelFacade model;
    private GoogleMap myMap;
    private LatLng currentLocation;
    private float zoomLevel = 10;
    private ArrayList<Marker> markers = new ArrayList<Marker>();
    private ArrayList<Polyline> lines = new ArrayList<Polyline>();
    private HashMap<Marker,Polyline> targetOfLine = new HashMap<Marker,Polyline>();
    private HashMap<Marker,Polyline> sourceOfLine = new HashMap<Marker,Polyline>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        model = ModelFacade.getInstance(this);
        model.setMapDelegate(this);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.

     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    @Override
    public void onMapReady(GoogleMap googleMap) 
    { myMap = googleMap;

      LatLng london = new LatLng(51.5, 0);
      Marker m = myMap.addMarker(new MarkerOptions().position(london).title("Marker in London"));
      markers.add(m);
      myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(london,zoomLevel));
      myMap.getUiSettings().setZoomControlsEnabled(true);
      myMap.getUiSettings().setCompassEnabled(true);
      myMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
      myMap.setOnMapClickListener(this);
      myMap.setOnMarkerClickListener(this);
      myMap.setOnInfoWindowClickListener(this);
      myMap.setOnMarkerDragListener(this);
    }

    public void setZoomLevel(float z)
    { zoomLevel = z; }

    public void clearMap()
    { myMap.clear(); }

    public void redraw()
    { myMap.clear(); 
      lines.clear(); 
      targetOfLine.clear(); 
      sourceOfLine.clear(); 
      
      for (int i = 0; i < markers.size(); i++) 
      { Marker m1 = (Marker) markers.get(i); 
        myMap.addMarker(new MarkerOptions().position(m1.getPosition()).title(m1.getTitle()));
        LatLng startPoint = m1.getPosition(); 
        if (i < markers.size() - 1) 
        { Marker m2 = (Marker) markers.get(i+1);
          LatLng endPoint = m2.getPosition();  
          Polyline p = myMap.addPolyline(new PolylineOptions().geodesic(true).add(startPoint,endPoint));
          lines.add(p);
          targetOfLine.put(m2,p); 
          sourceOfLine.put(m1,p);   
        }
      } 
    } 

    public void addMarker(MapLocation location, String label)
    { Marker m = myMap.addMarker(new MarkerOptions().position(
            new LatLng(location.latitude, location.longitude)).draggable(true).title(label));
      m.setTag(location);
      markers.add(m);
    }

    public void addMarkerWithLine(MapLocation location1, MapLocation location2, String label)
    { LatLng startPoint = new LatLng(location1.latitude, location1.longitude);
      LatLng endPoint = new LatLng(location2.latitude, location2.longitude);
      Marker m = myMap.addMarker(new MarkerOptions().position(endPoint).draggable(true).title(label));
      Polyline poly = myMap.addPolyline(
              new PolylineOptions().clickable(false).geodesic(true).add(startPoint,endPoint));
      m.setTag(location2);
      markers.add(m);
      lines.add(poly);
      targetOfLine.put(m,poly);
      Marker mold = findMarkerAt(startPoint); 
      if (mold != null) 
      { sourceOfLine.put(mold,poly); } 
    }

    private Marker findMarkerAt(LatLng pos)
    { for (int i = 0; i < markers.size(); i++)
      { Marker m = (Marker) markers.get(i); 
        LatLng p = m.getPosition(); 
        if (pos.equals(p))
        { return m; } 
      }
      return null; 
    }  

    public void moveTo(MapLocation location)
    { LatLng point = new LatLng(location.latitude, location.longitude);
      myMap.animateCamera(CameraUpdateFactory.newLatLngZoom(point,zoomLevel));
    }

    public void setMapType(String type) 
    { if ("Satellite".equals(type)) 
      { myMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE); } 
      else if ("Hybrid".equals(type)) 
      { myMap.setMapType(GoogleMap.MAP_TYPE_HYBRID); } 
      else 
      { myMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); }
    }

  @Override
  public void onMapClick(LatLng point)
  { myMap.animateCamera(CameraUpdateFactory.newLatLngZoom(point, zoomLevel));
    Toast.makeText(getApplicationContext(), point.toString(),
                Toast.LENGTH_LONG).show();
    final MapLocation loc = new MapLocation(point.latitude, point.longitude);
    model.locationSelected(loc);
    DialogFragment dialog = new MarkerDialogFragment(this);
    dialog.show(getSupportFragmentManager(), "Create marker here?");

    /* new AlertDialog.Builder(this).setTitle("Create marker here?").setNegativeButton("No", null).setPositiveButton("Yes",
                new DialogInterface.OnClickListener()
                { @Override
                  public void onClick(DialogInterface dialog, int which)
                  { model.markerCreated(loc); }}).show(); */
  }

  @Override
  public boolean onMarkerClick(final Marker marker)
  { LatLng pos = marker.getPosition();
    String label = marker.getTitle();
    model.markerClicked(label,new MapLocation(pos.latitude, pos.longitude));
    return false;
  }

    @Override
    public void onInfoWindowClick(Marker marker) 
    { LatLng pos = marker.getPosition();
      String label = marker.getTitle();
      model.markerInfoClicked(label,
                  new MapLocation(pos.latitude, pos.longitude));
    }

    @Override
    public void onMarkerDragStart(Marker marker) {
    }



    @Override

    public void onMarkerDragEnd(Marker marker) {
      Toast.makeText(this, "New marker position = " + marker.getPosition(), Toast.LENGTH_LONG).show();
      LatLng pos = marker.getPosition();
      MapLocation oldlocation = (MapLocation) marker.getTag();
      String label = marker.getTitle();
      model.markerMoved(label,oldlocation,new MapLocation(pos.latitude, pos.longitude));
      Polyline line = targetOfLine.get(marker);
      if (line != null) {
          List<LatLng> points = line.getPoints();
          ArrayList<LatLng> newpoints = new ArrayList<LatLng>();
          newpoints.add(points.get(0));
          newpoints.add(new LatLng(pos.latitude, pos.longitude));
          line.setPoints(newpoints);
      }
      Polyline line2 = sourceOfLine.get(marker);
      if (line2 != null) {
          List<LatLng> points2 = line2.getPoints();
          ArrayList<LatLng> newpoints2 = new ArrayList<LatLng>();
          newpoints2.add(new LatLng(pos.latitude, pos.longitude));
          newpoints2.add(points2.get(1));
          line2.setPoints(newpoints2);
      }
    }

    @Override
    public void onMarkerDrag(Marker marker)
    {  }

    public void userDialog(String mess, final ArrayList<String> labels)
    { CharSequence[] items = new String[labels.size()];
      for (int i = 0; i < labels.size(); i++)
      { items[i] = labels.get(i); }

      new AlertDialog.Builder(this).setTitle(mess).setItems(items,
              new DialogInterface.OnClickListener() {
          @Override
          public void onClick(DialogInterface dialog, int which) {
              model.dialogResponse(labels.get(which));
          }
      }).show();
    }

    public void userPopup(String mess)
    { Toast.makeText(this,mess,Toast.LENGTH_LONG).show(); }

}
