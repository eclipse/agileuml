package com.example.app; 

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.*;

public class FirebaseAuthenticator
{ 
  static FirebaseAuthenticator instance = null; 
  
  public static FirebaseAuthenticator getInstance()
  { if (instance == null) 
    { instance = new FirebaseAuthenticator(); }
	return instance; 
  }


  public static String createUser(String email, String password)
  { FirebaseAuth authenticator = FirebaseAuth.getInstance();
    final String[] res = new String[1];
    authenticator.createUserWithEmailAndPassword(email,password).addOnCompleteListener(
          new OnCompleteListener<AuthResult>() {
            public void onComplete(Task<AuthResult> task) {
              if (task.isSuccessful()) {
                res[0] = "Success";
              } else {
                res[0] = task.getException().getMessage();
              }
            }
      });
    return res[0];
  }

  public static String signIn(String email, String password) 
  { FirebaseAuth authenticator = FirebaseAuth.getInstance();

    final String[] res = new String[1];
    authenticator.signInWithEmailAndPassword(email,password).addOnCompleteListener(
          new OnCompleteListener<AuthResult>() {
            public void onComplete(Task<AuthResult> task) {
              if (task.isSuccessful()) {
                res[0] = "Success";
              } else {
                res[0] = task.getException().getMessage();
              }
            }
      });
    return res[0];
  }

  public String userId()
  { String res = null;
    FirebaseAuth authenticator = FirebaseAuth.getInstance();

    FirebaseUser user = authenticator.getCurrentUser();
    if (user != null)
    { res = user.getUid(); }
    return res;
  }

  public static String signOut()
  { FirebaseAuth authenticator = FirebaseAuth.getInstance();
    try
    { authenticator.signOut();
      return "Success";
    } catch (Exception e)
      { return e + ""; }
  }
}
