import ocl
import math
import re
import copy

from oclfile import *
from ocltype import *
from ocldate import *
from oclprocess import *
from mathlib import *
from ocliterator import *
from enum import Enum

def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)

def displaySequence(x):
  print(x)

def displaySet(x):
  print(x)

def displayMap(x):
  print(x)


class FromJavaScript : 
  fromjavascript_instances = []
  fromjavascript_index = dict({})

  def __init__(self):
    self.object1 = dict({})
    FromJavaScript.fromjavascript_instances.append(self)



  def newFromJavaScript() :
    result = None
    result = createFromJavaScript()
    result.object1 = dict({})
    result.initialise()
    return result

  def initialise(self) :
    self.object1 = dict({})
    self.object1 = ocl.unionMap(self.object1, dict({"property1":(dict({"value":42,"writable":False}))["value"]}))
    (self.object1)["property1"] = 77
    print(str((self.object1)["property1"]))

  def killFromJavaScript(fromjavascript_x) :
    fromjavascript_instances = ocl.excludingSet(fromjavascript_instances, fromjavascript_x)
    free(fromjavascript_x)

def createFromJavaScript():
  fromjavascript = FromJavaScript()
  return fromjavascript

def allInstances_FromJavaScript():
  return FromJavaScript.fromjavascript_instances


fromjavascript_OclType = createByPKOclType("FromJavaScript")
fromjavascript_OclType.instance = createFromJavaScript()
fromjavascript_OclType.actualMetatype = type(fromjavascript_OclType.instance)


js = FromJavaScript.newFromJavaScript()
