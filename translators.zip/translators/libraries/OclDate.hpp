class OclDate {
private: 
  long time; 
  long systemTime; 

public:
	
  static OclDate* newOclDate(long t)
  { OclDate* res = new OclDate();
    res->time = t; 
    res->systemTime = UmlRsdsLib<long>::getTime(); 
    return res; 
  }

  static OclDate* newOclDate()
  { OclDate* res = new OclDate();
    res->systemTime = UmlRsdsLib<long>::getTime(); 
    res->time = res->systemTime; 
    return res; 
  }

  void setTime(long t)
  { time = t; } 

  long getTime()
  { return time; } 

  long getSystemTime()
  { systemTime = UmlRsdsLib<long>::getTime();
    return systemTime; 
  } 

  bool dateBefore(OclDate* d)
  { if (time < d->time)
    { return true; }
    return false; 
  }

  bool dateAfter(OclDate* d)
  { if (time > d->time)
    { return true; }
    return false; 
  } 
}; 

