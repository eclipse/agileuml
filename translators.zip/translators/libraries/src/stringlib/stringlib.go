package stringlib

import "fmt"
import "container/list"
import "ocl"
// import "strings"
// import "reflect"

var v1 int = 0
var v2 float64 = 0.0
var v3 string = ""
  

func Format(f string, args *list.List) string {
  arglist := ocl.AsArray(args)
  return fmt.Sprintf(f, arglist...)
} 

/* func Scan(s string, f string) *list.List { 
  // count %'s in f to identify size of result
  n := strings.Count(f,"%")
  fmt.Println(n)
  res := make([]interface{}, n)
  res[0] = &v1
  res[1] = &v2
  res[2] = &v3
  fmt.Sscanf(s,f,res...)
  return ocl.SequenceRange(res)
} */

func main() {
  var TYPEintPointer reflect.Type = reflect.TypeOf(&v1)
  var TYPEdoublePointer reflect.Type = reflect.TypeOf(&v2)
  var TYPEStringPointer reflect.Type = reflect.TypeOf(&v3)

  lst := Scan("100 3.3 text", "%d %f %s")
  for x := lst.Front(); x != nil; x = x.Next() { 
    ptr := x.Value
    if reflect.TypeOf(ptr) == TYPEintPointer { 
      fmt.Println(*(ptr.(*int)))
    } 
    if reflect.TypeOf(ptr) == TYPEdoublePointer { 
      fmt.Println(*(ptr.(*float64)))
    } 
    if reflect.TypeOf(ptr) == TYPEStringPointer { 
      fmt.Println(*(ptr.(*string)))
    } 
  } 
} 


  



