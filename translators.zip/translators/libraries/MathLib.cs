
    class MathLib
    {
        private static int ix; // internal
        private static int iy; // internal
        private static int iz; // internal
        private static ArrayList hexdigit; // internal

        public MathLib()
        {
            ix = 0;
            iy = 0;
            iz = 0;
            hexdigit = (new ArrayList());
        }

        static MathLib()
        { initialiseMathLib();  }

        public override string ToString()
        {
            string _res_ = "(MathLib) ";
            _res_ = _res_ + ix + ",";
            _res_ = _res_ + iy + ",";
            _res_ = _res_ + iz + ",";
            _res_ = _res_ + hexdigit;
            return _res_;
        }

        public static void setix(int ix_x) { ix = ix_x; }

        public void localSetix(int ix_x) { }

        public static void setiy(int iy_x) { iy = iy_x; }

        public void localSetiy(int iy_x) { }

        public static void setiz(int iz_x) { iz = iz_x; }

        public void localSetiz(int iz_x) { }

        public static void sethexdigit(ArrayList hexdigit_x) { hexdigit = hexdigit_x; }

        public void localSethexdigit(ArrayList hexdigit_x) { }

        public static void sethexdigit(int _ind, string hexdigit_x) { hexdigit[_ind] = hexdigit_x; }

        public void localSethexdigit(int _ind, string hexdigit_x) { }

        public static void addhexdigit(string hexdigit_x)
        { hexdigit.Add(hexdigit_x); }

        public static void removehexdigit(string hexdigit_x)
        { hexdigit = SystemTypes.subtract(hexdigit, hexdigit_x); }

        public static int getix() { return ix; }

        public static ArrayList getAllix(ArrayList mathlib_s)
        {
            ArrayList result = new ArrayList();
            if (mathlib_s.Count > 0)
            { result.Add(MathLib.ix); }
            return result;
        }

        public static ArrayList getAllOrderedix(ArrayList mathlib_s)
        {
            ArrayList result = new ArrayList();
            for (int i = 0; i < mathlib_s.Count; i++)
            {
                MathLib mathlibx = (MathLib)mathlib_s[i];
                result.Add(MathLib.ix);
            }
            return result;
        }

        public static int getiy() { return iy; }

        public static ArrayList getAlliy(ArrayList mathlib_s)
        {
            ArrayList result = new ArrayList();
            if (mathlib_s.Count > 0)
            { result.Add(MathLib.iy); }
            return result;
        }

        public static ArrayList getAllOrderediy(ArrayList mathlib_s)
        {
            ArrayList result = new ArrayList();
            for (int i = 0; i < mathlib_s.Count; i++)
            {
                MathLib mathlibx = (MathLib)mathlib_s[i];
                result.Add(MathLib.iy);
            }
            return result;
        }

        public static int getiz() { return iz; }

        public static ArrayList getAlliz(ArrayList mathlib_s)
        {
            ArrayList result = new ArrayList();
            if (mathlib_s.Count > 0)
            { result.Add(MathLib.iz); }
            return result;
        }

        public static ArrayList getAllOrderediz(ArrayList mathlib_s)
        {
            ArrayList result = new ArrayList();
            for (int i = 0; i < mathlib_s.Count; i++)
            {
                MathLib mathlibx = (MathLib)mathlib_s[i];
                result.Add(MathLib.iz);
            }
            return result;
        }

        public static ArrayList gethexdigit() { return hexdigit; }


        public static void initialiseMathLib()
        {
            MathLib.sethexdigit(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet(SystemTypes.addSet((new ArrayList()), "0"), "1"), "2"), "3"), "4"), "5"), "6"), "7"), "8"), "9"), "A"), "B"), "C"), "D"), "E"), "F"));
            MathLib.setSeeds(1001, 781, 913);
        }

        public static double pi()
        {
            double result = 0.0;

            result = 3.14159265;
            return result;
        }


        public static double eValue()
        {
            double result = 0.0;

            result = Math.Exp(1);
            return result;
        }

        public static double piValue()
        {
            double result = 0.0;

            result = 3.14159265;
            return result;
        }


        public static double e()
        {
            double result = 0.0;

            result = Math.Exp(1);
            return result;
        }


        public static void setSeeds(int x, int y, int z)
        {
            MathLib.setix(x);
            MathLib.setiy(y);
            MathLib.setiz(z);
        }

        public static double nrandom()
        {
            MathLib.setix((MathLib.getix() * 171) % 30269);
            MathLib.setiy((MathLib.getiy() * 172) % 30307);
            MathLib.setiz((MathLib.getiz() * 170) % 30323);
            return (MathLib.getix() / 30269.0 + MathLib.getiy() / 30307.0 + MathLib.getiz() / 30323.0);
        }


        public static double random()
        {
            double result = 0.0;

            double r = MathLib.nrandom();
            result = (r - ((int)Math.Floor(r)));
            return result;
        }


        public static long combinatorial(int n, int m)
        {
            long result = 0;
            if (n < m || m < 0) { return result; }

            if (n - m < m)
            {
                result = SystemTypes.prdint(SystemTypes.integerSubrange(m + 1, n)) / 
                             SystemTypes.prdint(SystemTypes.integerSubrange(1, n - m));
            }
            else
              if (n - m >= m)
            {
                result = SystemTypes.prdint(SystemTypes.integerSubrange(n - m + 1, n)) / 
                             SystemTypes.prdint(SystemTypes.integerSubrange(1, m));
            }
            return result;
        }


        public static long factorial(int x)
        {
            long result = 0;

            if (x < 2)
            {
                result = 1;
            }
            else
              if (x >= 2)
            {
                result = SystemTypes.prdint(SystemTypes.integerSubrange(2, x));
            }
            return result;
        }


        public static double asinh(double x)
        {
            double result = 0.0;

            result = Math.Log((x + Math.Sqrt((x * x + 1))));
            return result;
        }


        public static double acosh(double x)
        {
            double result = 0.0;
            if (x < 1) { return result; }

            result = Math.Log((x + Math.Sqrt((x * x - 1))));
            return result;
        }


        public static double atanh(double x)
        {
            double result = 0.0;
            if (x == 1) { return result; }

            result = 0.5 * Math.Log(((1 + x) / (1 - x)));
            return result;
        }


        public static string decimal2bits(long x)
        {
            string result = "";

            if (x == 0) { result = ""; }
            else { result = MathLib.decimal2bits(x / 2) + "" + (x % 2); }
            return result;
        }


        public static string decimal2binary(long x)
        {
            string result = "";

            if (x < 0) { result = "-" + MathLib.decimal2bits(-x); }
            else
            {
                if (x == 0) { result = "0"; }
                else { result = MathLib.decimal2bits(x); }
            }
            return result;
        }


        public static string decimal2oct(long x)
        {
            string result = "";

            if (x == 0) { result = ""; }
            else { result = MathLib.decimal2oct(x / 8) + "" + (x % 8); }
            return result;
        }


        public static string decimal2octal(long x)
        {
            string result = "";

            if (x < 0) { result = "-" + MathLib.decimal2oct(-x); }
            else
            {
                if (x == 0) { result = "0"; }
                else { result = MathLib.decimal2oct(x); }
            }
            return result;
        }


        public static string decimal2hx(long x)
        {
            string result = "";

            if (x == 0) 
            { result = ""; }
            else 
            { result = MathLib.decimal2hx(x / 16) + ("" + ((string)MathLib.gethexdigit()[((int)(x % 16))])); }
            return result;
        }


        public static string decimal2hex(long x)
        {
            string result = "";

            if (x < 0) { result = "-" + MathLib.decimal2hx(-x); }
            else
            {
                if (x == 0) { result = "0"; }
                else 
                { result = MathLib.decimal2hx(x); }
            }
            return result;
        }

        public static long bytes2integer(ArrayList bs)
        {
            if (bs.Count == 0)
            { return 0; }
            if (bs.Count == 1)
            { return (int) bs[0]; }
            if (bs.Count == 2)
            { return (256 * ((int) bs[0])) + (int) bs[1]; }

            int lowdigit = (int) bs[bs.Count - 1];
            ArrayList highdigits = SystemTypes.front(bs);
            return 256 * MathLib.bytes2integer(highdigits) + lowdigit;
        }

        public static ArrayList integer2bytes(long x)
        {
            ArrayList result = new ArrayList();

            long y = x / 256;
            int z = (int)(x % 256);
            if (y == 0)
            {
                result.Add(z);
                return result;
            }
            ArrayList highbytes = MathLib.integer2bytes(y);
            result.AddRange(highbytes);
            result.Add(z);
            return result;
        }

        public static ArrayList integer2Nbytes(long x, int n)
        {
            ArrayList res = MathLib.integer2bytes(x);

            while (res.Count < n)
            { res.Insert(0, 0); }
            return res;
        }


        public static int bitwiseAnd(int x, int y)
        { return x & y; }

        public static long bitwiseAnd(long x, long y)
        { return x & y; }


        public static int bitwiseOr(int x, int y)
        { return x | y; }

       public static long bitwiseOr(long x, long y)
        {
            return x | y;
        }


        public static int bitwiseXor(int x, int y)
        { return x^y; }

        public static long bitwiseXor(long x, long y)
        {
            return x ^ y;
        }

        public static ArrayList toBitSequence(long x)
        {
            long x1;
            x1 = x;
            ArrayList res;
            res = (new ArrayList());
            while (x1 > 0)
            {
                if (x1 % 2 == 0)
                { res = SystemTypes.concatenate(SystemTypes.makeSet(false), res); }
                else { res = SystemTypes.concatenate(SystemTypes.makeSet(true), res); }

                x1 = x1 / 2;
            }
            return res;
        }


     
        public static long modInverse(long n, long p)
        {
            if (p <= 0) { return 0; }

            long x = (n % p);
            for (int i = 1; i < p; i++)
            {
                if (((i * x) % p) == 1)
                { return i; }
            }
            return 0;
        }


        public static long modPow(long n, long m, long p)
        { if (p <= 0) { return 0; }
          long res = 1;
          long x = (n % p);
          for (int i = 1; i <= m; i++)
          {
            res = ((res * x) % p);
          }
          return res;
        }

        public static long doubleToLongBits(double d)
        { return BitConverter.DoubleToInt64Bits(d); }

        public static double longBitsToDouble(long x)
        { return BitConverter.Int64BitsToDouble(x); }

        public static double discountDiscrete(double amount, double rate, double time)
        {
            double result = 0;
            result = 0.0;
            if ((rate <= -1 || time < 0))
            { return result; }

            result = amount / Math.Pow((1 + rate), time);
            return result;
        }

        public static double netPresentValueDiscrete(double rate, ArrayList values)
        {
            double result = 0;
            result = 0.0;
            if ((rate <= -1))
            { return result; }

            int upper = values.Count; 
            int i = 0;
            for (; i < upper; i++)
            { result = result + MathLib.discountDiscrete((double) values[i], rate, i); }
            return result;
        }

        public static double bisectionDiscrete(double r, double rl, double ru, ArrayList values)
        {
            double result = 0;
            result = 0;
            if ((r <= -1 || rl <= -1 || ru <= -1))
            { return result; }

            double v = 0;
            v = MathLib.netPresentValueDiscrete(r, values);
            if (ru - rl < 0.001)
            { return r; }
            if (v > 0)
            { return MathLib.bisectionDiscrete((ru + r) / 2, r, ru, values); }
            else if (v < 0)
            { return MathLib.bisectionDiscrete((r + rl) / 2, rl, r, values); }
            return r;
        }

        public static double irrDiscrete(ArrayList values)
        {
            double res = bisectionDiscrete(0.1, -0.5, 1.0, values);
            return res;
        }
  }