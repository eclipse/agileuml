class StringLib : 
  def format(f,sq) : 
    return (f % tuple(sq))


