import Foundation
import Darwin

class ModelFacade
{ static var instance : ModelFacade? = nil


  static func getInstance() -> ModelFacade
  { if (instance == nil)
    { instance = ModelFacade() }
    return instance! }

  init() { }

  func wordCount(sq : [String]) -> Dictionary<String, Int>
  { 
    var result : Dictionary<String, Int>
    result = ["":1]
    for x in sq
    {
      result[x] = Ocl.count(s: sq, x: x)
    }

    return result
  }


}
