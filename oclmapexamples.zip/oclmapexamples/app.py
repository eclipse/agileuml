import ocl
import math

from enum import Enum

def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)


class MapsTest:
  mapstest_instances = []
  mapstest_index = dict({})

  def __init__(self):
    self.preferences = dict({})
    MapsTest.mapstest_instances.append(self)


  def makeMap(self) :
    x = createPreference()
    x.name = "LightStyle"
    self.preferences["view"] = x

  def op1(self, style, value) :
    x = createPreference()
    x.name = value
    self.preferences[style] = x

  def op2(self) :
    m = dict({})
    m = dict({"button":"plain"})
    self.makeMap()
    m["list"] = "selection"
    m["enum"] = "radio"
    m = ocl.unionMap(m, dict({"form":"table"}))
    prefs = dict({})
    pref1 = createPreference()
    prefs["0"] = pref1
    m = ocl.excludeAllMap(m, ocl.collectMap(prefs, lambda p : p.name))
    
    
    print(m)
    m = ocl.intersectionMap(m, dict({"list":"selection","enum":"picker"}))
    
    print((m)["list"])

  def killMapsTest(mapstest_x) :
    mapstest_instances = ocl.excludingSet(mapstest_instances, mapstest_x)
    free(mapstest_x)

class Preference:
  preference_instances = []
  preference_index = dict({})

  def __init__(self):
    self.name = ""
    Preference.preference_instances.append(self)


  def killPreference(preference_x) :
    preference_instances = ocl.excludingSet(preference_instances, preference_x)
    mapstest_preferences_deleted = set({})
    for mapstest_xx in allInstances_MapsTest() :
      if mapstest_xx.preferences == preference_x :
        mapstest_xx.preferences = None
        mapstest_preferences_deleted = ocl.includingSet(mapstest_preferences_deleted, mapstest_xx)
    for mapstest_xx in mapstest_preferences_deleted :
      pass
    free(mapstest_preferences_deleted)
    free(preference_x)

def createMapsTest():
  mapstest = MapsTest()
  return mapstest

def allInstances_MapsTest():
  return MapsTest.mapstest_instances


def createPreference():
  preference = Preference()
  return preference

def allInstances_Preference():
  return Preference.preference_instances


mt = createMapsTest()
mt.op2()

