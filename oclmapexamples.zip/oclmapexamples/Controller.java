import java.util.List;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

import java.lang.*;
import java.lang.reflect.*;
import java.util.StringTokenizer;
import java.io.*;



class MapsTest
  implements SystemTypes
{
  private java.util.Map preferences = new java.util.HashMap();

  public MapsTest()
  {

  }



  public String toString()
  { String _res_ = "(MapsTest) ";
    return _res_;
  }

  public static MapsTest parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    MapsTest mapstestx = new MapsTest();
    return mapstestx;
  }


  public void writeCSV(PrintWriter _out)
  { MapsTest mapstestx = this;
    _out.println();
  }


   public void setpreferences(String _ind, Preference preferencesxx) { preferences.put(_ind, preferencesxx); }

 public void removepreferences(Preference preferencesxx)
 { Vector _removedKeys = new Vector();
   java.util.Iterator _keys = preferences.keySet().iterator();
   while (_keys.hasNext())
   { Object _k = _keys.next();
     if (preferencesxx.equals(preferences.get(_k)))
     { _removedKeys.add(_k); }
   }
   for (int _i = 0; _i < _removedKeys.size(); _i++)
   { preferences.remove(_removedKeys.get(_i)); }
 }



  public static void setAllpreferences(List mapstests, String _arg, Preference _val)
  { for (int _i = 0; _i < mapstests.size(); _i++)
    { MapsTest mapstestx = (MapsTest) mapstests.get(_i);
      Controller.inst().setpreferences(mapstestx,_arg,  _val); } }

  public Preference getpreferences(String _ind) { return (Preference) preferences.get(_ind); }

  public HashMap getpreferences() { return (HashMap) preferences; }


  

  

    public void makeMap()
  { Preference x = new Preference();
    Controller.inst().addPreference(x);
    Controller.inst().setname(x,"LightStyle");
    Controller.inst().setpreferences(this,"view", x);
  }

    public void op1(String style,String value)
  { Preference x = new Preference();
    Controller.inst().addPreference(x);
    Controller.inst().setname(x,value);
    Controller.inst().setpreferences(this,style, x);
  }

    public void op2()
  {  MapsTest mapstestx = this;
    Map m = new HashMap();
  m = Set.includingMap((new HashMap()),"button","plain");
     this.makeMap();
  m.put("list", "selection");
  m.put("enum", "radio");
  m = Set.unionMap(m,Set.includingMap((new HashMap()),"form","table"));
    Map prefs = new HashMap();
    Preference pref1 = Controller.inst().createPreference();
  prefs.put("0", pref1);
    pref1.setname("newpreference"); 
  m = Set.unionMap(m,Set.collect_0(prefs));
       System.out.println("" + m);

       System.out.println("" + m.keySet());

       System.out.println("" + (m).size());

  m = Set.intersectionMap(m,Set.includingMap(Set.includingMap((new HashMap()),"list","selection"),"enum","picker"));
       System.out.println("" + m.values());

       System.out.println("" + ((String) m.get("list")));


  }



}


class Preference
  implements SystemTypes
{
  private String name = ""; // internal

  public Preference()
  {
    this.name = "";

  }



  public String toString()
  { String _res_ = "(Preference) ";
    _res_ = _res_ + name;
    return _res_;
  }

  public static Preference parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Preference preferencex = new Preference();
    preferencex.name = (String) _line1vals.get(0);
    return preferencex;
  }


  public void writeCSV(PrintWriter _out)
  { Preference preferencex = this;
    _out.print("" + preferencex.name);
    _out.println();
  }


  public void setname(String name_x) { name = name_x;  }


    public static void setAllname(List preferences,String val)
  { for (int i = 0; i < preferences.size(); i++)
    { Preference preferencex = (Preference) preferences.get(i);
      Controller.inst().setname(preferencex,val); } }


    public String getname() { return name; }

    public static List getAllname(List preferences)
  { List result = new Vector();
    for (int i = 0; i < preferences.size(); i++)
    { Preference preferencex = (Preference) preferences.get(i);
      if (result.contains(preferencex.getname())) { }
      else { result.add(preferencex.getname()); } }
    return result; }

    public static List getAllOrderedname(List preferences)
  { List result = new Vector();
    for (int i = 0; i < preferences.size(); i++)
    { Preference preferencex = (Preference) preferences.get(i);
      result.add(preferencex.getname()); } 
    return result; }


}



public class Controller implements SystemTypes, ControllerInterface
{
  Vector mapstests = new Vector();
  Vector preferences = new Vector();
  private static Controller uniqueInstance; 


  private Controller() { } 


  public static Controller inst() 
    { if (uniqueInstance == null) 
    { uniqueInstance = new Controller(); }
    return uniqueInstance; } 


  public static void loadModel(String file)
  {
    try
    { BufferedReader br = null;
      File f = new File(file);
      try 
      { br = new BufferedReader(new FileReader(f)); }
      catch (Exception ex) 
      { System.err.println("No file: " + file); return; }
      Class cont = Class.forName("Controller");
      java.util.Map objectmap = new java.util.HashMap();
      while (true)
      { String line1;
        try { line1 = br.readLine(); }
        catch (Exception e)
        { return; }
        if (line1 == null)
        { return; }
        line1 = line1.trim();

        if (line1.length() == 0) { continue; }
        if (line1.startsWith("//")) { continue; }
        String left;
        String op;
        String right;
        if (line1.charAt(line1.length() - 1) == '"')
        { int eqind = line1.indexOf("="); 
          if (eqind == -1) { continue; }
          else 
          { left = line1.substring(0,eqind-1).trim();
            op = "="; 
            right = line1.substring(eqind+1,line1.length()).trim();
          }
        }
        else
        { StringTokenizer st1 = new StringTokenizer(line1);
          Vector vals1 = new Vector();
          while (st1.hasMoreTokens())
          { String val1 = st1.nextToken();
            vals1.add(val1);
          }
          if (vals1.size() < 3)
          { continue; }
          left = (String) vals1.get(0);
          op = (String) vals1.get(1);
          right = (String) vals1.get(2);
        }
        if (":".equals(op))
        { int i2 = right.indexOf(".");
          if (i2 == -1)
          { Class cl;
            try { cl = Class.forName("" + right); }
            catch (Exception _x) { System.err.println("No entity: " + right); continue; }
            Object xinst = cl.newInstance();
            objectmap.put(left,xinst);
            Class[] cargs = new Class[] { cl };
            Method addC = null;
            try { addC = cont.getMethod("add" + right,cargs); }
            catch (Exception _xx) { System.err.println("No entity: " + right); continue; }
            if (addC == null) { continue; }
            Object[] args = new Object[] { xinst };
            addC.invoke(Controller.inst(),args);
          }
          else
          { String obj = right.substring(0,i2);
            String role = right.substring(i2+1,right.length());
            Object objinst = objectmap.get(obj); 
            if (objinst == null) 
            { continue; }
            Object val = objectmap.get(left);
            if (val == null) 
            { continue; }
            Class objC = objinst.getClass();
            Class typeclass = val.getClass(); 
            Object[] args = new Object[] { val }; 
            Class[] settypes = new Class[] { typeclass };
            Method addrole = Controller.findMethod(objC,"add" + role);
            if (addrole != null) 
            { addrole.invoke(objinst, args); }
            else { System.err.println("Error: cannot add to " + role); }
          }
        }
        else if ("=".equals(op))
        { int i1 = left.indexOf(".");
          if (i1 == -1) 
          { continue; }
          String obj = left.substring(0,i1);
          String att = left.substring(i1+1,left.length());
          Object objinst = objectmap.get(obj); 
          if (objinst == null) 
          { System.err.println("No object: " + obj); continue; }
          Class objC = objinst.getClass();
          Class typeclass; 
          Object val; 
          if (right.charAt(0) == '"' &&
              right.charAt(right.length() - 1) == '"')
          { typeclass = String.class;
            val = right.substring(1,right.length() - 1);
          } 
          else if ("true".equals(right) || "false".equals(right))
          { typeclass = boolean.class;
            if ("true".equals(right))
            { val = new Boolean(true); }
            else
            { val = new Boolean(false); }
          }
          else 
          { val = objectmap.get(right);
            if (val != null)
            { typeclass = val.getClass(); }
            else 
            { int i;
              long l; 
              double d;
              try 
              { i = Integer.parseInt(right);
                typeclass = int.class;
                val = new Integer(i); 
              }
              catch (Exception ee)
              { try 
                { l = Long.parseLong(right);
                  typeclass = long.class;
                  val = new Long(l); 
                }
                catch (Exception eee)
                { try
                  { d = Double.parseDouble(right);
                    typeclass = double.class;
                    val = new Double(d);
                  }
                  catch (Exception ff)
                  { continue; }
                }
              }
            }
          }
          Object[] args = new Object[] { val }; 
          Class[] settypes = new Class[] { typeclass };
          Method setatt = Controller.findMethod(objC,"set" + att);
          if (setatt != null) 
          { setatt.invoke(objinst, args); }
          else { System.err.println("No attribute: " + objC.getName() + "::" + att); }
        }
      }
    } catch (Exception e) { }
  }

  public static Method findMethod(Class c, String name)
  { Method[] mets = c.getMethods(); 
    for (int i = 0; i < mets.length; i++)
    { Method m = mets[i];
      if (m.getName().equals(name))
      { return m; }
    } 
    return null;
  }


  public static void loadCSVModel()
  { boolean __eof = false;
    String __s = "";
    Controller __cont = Controller.inst();
    BufferedReader __br = null;
    try
    { File _mapstest = new File("MapsTest.csv");
      __br = new BufferedReader(new FileReader(_mapstest));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { MapsTest mapstestx = MapsTest.parseCSV(__s.trim());
          if (mapstestx != null)
          { __cont.addMapsTest(mapstestx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _preference = new File("Preference.csv");
      __br = new BufferedReader(new FileReader(_preference));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Preference preferencex = Preference.parseCSV(__s.trim());
          if (preferencex != null)
          { __cont.addPreference(preferencex); }
        }
      }
    }
    catch(Exception __e) { }
  }


  public void checkCompleteness()
  {   }


  public void saveModel(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
  for (int _i = 0; _i < mapstests.size(); _i++)
  { MapsTest mapstestx_ = (MapsTest) mapstests.get(_i);
    out.println("mapstestx_" + _i + " : MapsTest");
  }

  for (int _i = 0; _i < preferences.size(); _i++)
  { Preference preferencex_ = (Preference) preferences.get(_i);
    out.println("preferencex_" + _i + " : Preference");
    out.println("preferencex_" + _i + ".name = \"" + preferencex_.getname() + "\"");
  }

  for (int _i = 0; _i < mapstests.size(); _i++)
  { MapsTest mapstestx_ = (MapsTest) mapstests.get(_i);
  }
    out.close(); 
  }


  public static void loadXSI()
  { boolean __eof = false;
    String __s = "";
    String xmlstring = "";
    BufferedReader __br = null;
    try
    { File _classmodel = new File("in.xmi");
      __br = new BufferedReader(new FileReader(_classmodel));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { xmlstring = xmlstring + __s; }
      } 
      __br.close();
    } 
    catch (Exception _x) { }
    Vector res = convertXsiToVector(xmlstring);
    File outfile = new File("_in.txt");
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    for (int i = 0; i < res.size(); i++)
    { String r = (String) res.get(i); 
      out.println(r);
    } 
    out.close();
    loadModel("_in.txt");
  }

  public static Vector convertXsiToVector(String xmlstring)
  { Vector res = new Vector();
    XMLParser comp = new XMLParser();
    comp.nospacelexicalanalysisxml(xmlstring);
    XMLNode xml = comp.parseXML();
    if (xml == null) { return res; } 
    java.util.Map instancemap = new java.util.HashMap(); // String --> Vector
    java.util.Map entmap = new java.util.HashMap();       // String --> String
    Vector entcodes = new Vector(); 
    java.util.Map allattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map stringattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map onerolesmap = new java.util.HashMap(); // String --> Vector
    java.util.Map actualtype = new java.util.HashMap(); // XMLNode --> String
    Vector eallatts = new Vector();
    instancemap.put("mapstests", new Vector()); 
    instancemap.put("mapstest",new Vector()); 
    entcodes.add("mapstests");
    entcodes.add("mapstest");
    entmap.put("mapstests","MapsTest");
    entmap.put("mapstest","MapsTest");
    eallatts = new Vector();
    allattsmap.put("MapsTest", eallatts);
    eallatts = new Vector();
    stringattsmap.put("MapsTest", eallatts);
    eallatts = new Vector();
    eallatts.add("preferences");
    onerolesmap.put("MapsTest", eallatts);
    instancemap.put("preferences", new Vector()); 
    instancemap.put("preference",new Vector()); 
    entcodes.add("preferences");
    entcodes.add("preference");
    entmap.put("preferences","Preference");
    entmap.put("preference","Preference");
    eallatts = new Vector();
    eallatts.add("name");
    allattsmap.put("Preference", eallatts);
    eallatts = new Vector();
    eallatts.add("name");
    stringattsmap.put("Preference", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Preference", eallatts);
    eallatts = new Vector();
  Vector enodes = xml.getSubnodes();
  for (int i = 0; i < enodes.size(); i++)
  { XMLNode enode = (XMLNode) enodes.get(i);
    String cname = enode.getTag();
    Vector einstances = (Vector) instancemap.get(cname); 
    if (einstances == null) 
    { einstances = (Vector) instancemap.get(cname + "s"); }
    if (einstances != null) 
    { einstances.add(enode); }
  }
  for (int j = 0; j < entcodes.size(); j++)
  { String ename = (String) entcodes.get(j);
    Vector elems = (Vector) instancemap.get(ename);
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = enode.getAttributeValue("xsi:type"); 
      if (tname == null) 
      { tname = (String) entmap.get(ename); } 
      else 
      { int colonind = tname.indexOf(":"); 
        if (colonind >= 0)
        { tname = tname.substring(colonind + 1,tname.length()); }
      }
      res.add(ename + k + " : " + tname);
      actualtype.put(enode,tname);
    }   
  }
  for (int j = 0; j < entcodes.size(); j++) 
  { String ename = (String) entcodes.get(j); 
    Vector elems = (Vector) instancemap.get(ename); 
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = (String) actualtype.get(enode);
      Vector tallatts = (Vector)  allattsmap.get(tname);
      Vector tstringatts = (Vector)  stringattsmap.get(tname);
      Vector toneroles = (Vector)  onerolesmap.get(tname);
      Vector atts = enode.getAttributes();
      for (int p = 0; p < atts.size(); p++) 
      { XMLAttribute patt = (XMLAttribute) atts.get(p); 
        if (patt.getName().equals("xsi:type") || patt.getName().equals("xmi:id")) {} 
        else 
        { patt.getDataDeclarationFromXsi(res,tallatts,tstringatts,toneroles,ename + k, (String) entmap.get(ename)); } 
      }
    } 
  }  
  return res; } 

  public void saveXSI(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    out.println("<UMLRSDS:model xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\">");
    for (int _i = 0; _i < mapstests.size(); _i++)
    { MapsTest mapstestx_ = (MapsTest) mapstests.get(_i);
       out.print("<mapstests xsi:type=\"My:MapsTest\"");
    out.println(" />");
  }

    for (int _i = 0; _i < preferences.size(); _i++)
    { Preference preferencex_ = (Preference) preferences.get(_i);
       out.print("<preferences xsi:type=\"My:Preference\"");
    out.print(" name=\"" + preferencex_.getname() + "\" ");
    out.println(" />");
  }

    out.println("</UMLRSDS:model>");
    out.close(); 
  }


  public void saveCSVModel()
  { try {
      File _mapstest = new File("MapsTest.csv");
      PrintWriter _out_mapstest = new PrintWriter(new BufferedWriter(new FileWriter(_mapstest)));
      for (int __i = 0; __i < mapstests.size(); __i++)
      { MapsTest mapstestx = (MapsTest) mapstests.get(__i);
        mapstestx.writeCSV(_out_mapstest);
      }
      _out_mapstest.close();
      File _preference = new File("Preference.csv");
      PrintWriter _out_preference = new PrintWriter(new BufferedWriter(new FileWriter(_preference)));
      for (int __i = 0; __i < preferences.size(); __i++)
      { Preference preferencex = (Preference) preferences.get(__i);
        preferencex.writeCSV(_out_preference);
      }
      _out_preference.close();
    }
    catch(Exception __e) { }
  }



  public void addMapsTest(MapsTest oo) { mapstests.add(oo); }

  public void addPreference(Preference oo) { preferences.add(oo); }



  public MapsTest createMapsTest()
  { MapsTest mapstestx = new MapsTest();
    addMapsTest(mapstestx);
    return mapstestx;
  }

  public Preference createPreference()
  { Preference preferencex = new Preference();
    addPreference(preferencex);
    return preferencex;
  }


 public void setpreferences(MapsTest _mapstestx, String _ind, Preference _preferencesxx)
 { _mapstestx.setpreferences(_ind, _preferencesxx); } 

 public void removepreferences(MapsTest _mapstestx, Preference _preferencesxx)
 { _mapstestx.removepreferences(_preferencesxx); }

public void setname(Preference preferencex, String name_x) 
  { preferencex.setname(name_x);
    }



  public void makeMap(MapsTest mapstestx)
  {   mapstestx.makeMap();
   }

  public  List AllMapsTestmakeMap(List mapstestxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < mapstestxs.size(); _i++)
    { MapsTest mapstestx = (MapsTest) mapstestxs.get(_i);
      makeMap(mapstestx);
    }
    return result; 
  }

  public void op1(MapsTest mapstestx,String style,String value)
  {   mapstestx.op1(style, value);
   }

  public  List AllMapsTestop1(List mapstestxs,String style,String value)
  { 
    List result = new Vector();
    for (int _i = 0; _i < mapstestxs.size(); _i++)
    { MapsTest mapstestx = (MapsTest) mapstestxs.get(_i);
      op1(mapstestx,style, value);
    }
    return result; 
  }

  public void op2(MapsTest mapstestx)
  {   mapstestx.op2();
   }

  public  List AllMapsTestop2(List mapstestxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < mapstestxs.size(); _i++)
    { MapsTest mapstestx = (MapsTest) mapstestxs.get(_i);
      op2(mapstestx);
    }
    return result; 
  }



  public void killAllMapsTest(List mapstestxx)
  { for (int _i = 0; _i < mapstestxx.size(); _i++)
    { killMapsTest((MapsTest) mapstestxx.get(_i)); }
  }

  public void killMapsTest(MapsTest mapstestxx)
  { if (mapstestxx == null) { return; }
   mapstests.remove(mapstestxx);
  }



  public void killAllPreference(List preferencexx)
  { for (int _i = 0; _i < preferencexx.size(); _i++)
    { killPreference((Preference) preferencexx.get(_i)); }
  }

  public void killPreference(Preference preferencexx)
  { if (preferencexx == null) { return; }
   preferences.remove(preferencexx);
    Vector _1removedpreferencesMapsTest = new Vector();
    Vector _1qrangepreferencesMapsTest = new Vector();
    _1qrangepreferencesMapsTest.addAll(mapstests);
    for (int _i = 0; _i < _1qrangepreferencesMapsTest.size(); _i++)
    { MapsTest mapstestx = (MapsTest) _1qrangepreferencesMapsTest.get(_i);
      removepreferences(mapstestx,preferencexx); 
    }
    for (int _i = 0; _i < _1removedpreferencesMapsTest.size(); _i++)
    { killMapsTest((MapsTest) _1removedpreferencesMapsTest.get(_i)); }
  }


  public static void main(String[] args)
  { MapsTest mt = Controller.inst().createMapsTest(); 
    mt.op2(); 
	}

   
}



