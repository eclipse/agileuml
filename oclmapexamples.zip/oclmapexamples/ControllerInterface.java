import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

public interface ControllerInterface
{
  public void addMapsTest(MapsTest oo);
    public void killMapsTest(MapsTest mapstestxx);
 public void setpreferences(MapsTest mapstestx,  String _ind, Preference preferencesxx);
 public void removepreferences(MapsTest mapstestx, Preference preferencesx);
  public void addPreference(Preference oo);
    public void killPreference(Preference preferencexx);
}

