package OclFile

import "os"
import "io/fs"


type OclFile struct {
  name string
  position int64
  actualFile *os.File
  readable bool
  writable bool
  eof bool
}


func NewOclFile(nme string) *OclFile { 
  res := &OclFile{}
  res.name = nme
  res.position = 0
  res.readable = false
  res.writable = false
  return res
} 

func (fle *OclFile) GetName() string { 
  return fle.name
} 



func NewOclFile_Read(fle *OclFile) *OclFile {
  f, err := os.Open(fle.name)
  if err == nil { 
    fle.actualFile = f
    fle.readable = true
    fle.writable = false
    fle.eof = false
  } 
  return fle
}

func NewOclFile_Write(fle *OclFile) *OclFile { 
  f, err := os.Create(fle.name)
  if err == nil { 
    fle.actualFile = f
    fle.writable = true
    fle.eof = false
  } 
  return fle
}

func (fle *OclFile) IsFile() bool { 
  finfo, err := os.Lstat(fle.name)
  if err != nil { 
    return false
  } 

  mde := finfo.Mode()
  if mde.IsRegular() { 
    return true
  } 
  return false
} 

func (fle *OclFile) IsDirectory() bool { 
  finfo, err := os.Lstat(fle.name)
  if err != nil { 
    return false
  } 

  mde := finfo.Mode()
  if mde.IsDir() { 
    return true
  } 
  return false
} 

func (self *OclFile) CloseFile() {
  if self.actualFile != nil { 
    self.actualFile.Close()
    self.readable = false
    self.writable = false
  } 
}

func (self *OclFile) SetPosition(pos int64) { 
  if self.actualFile != nil { 
    self.actualFile.Seek(pos,0)
    self.position = pos
  } 
} 

func (self *OclFile) GetPosition() int64 { 
  return self.position 
} 

func (self *OclFile) GetEof() bool { 
  return self.eof 
} 
 
func (self *OclFile) Read() string {
  if self.readable && self.actualFile != nil { 
    b := make([]byte, 1)
    n, err := self.actualFile.Read(b)
    if n > 0 && err == nil { 
      return string(b[0])
    } else { 
      self.eof = true
    } 
  }
  return ""
}

func (self *OclFile) Flush() { 
  if self.writable && self.actualFile != nil { 
    self.actualFile.Sync()
  } 
}

func (self *OclFile) Write(s string) { 
  if self.writable && self.actualFile != nil { 
    self.actualFile.Write([]byte(s))
  } 
}

func (self *OclFile) Mkdir() bool { 
  err = os.Mkdir(self.name, fs.ModeDir)
  if err != nil { 
    return false
  } 
  return true
} 

func (self *OclFile) Delete() bool { 
  err = os.Remove(self.name)
  if err != nil { 
    return false
  } 
  return true
} 

func DeleteFile(nme string) bool { 
  err = os.Remove(nme)
  if err != nil { 
    return false
  } 
  return true
} 

func RenameFile(oldnme string, newnme string) bool { 
  err = os.Rename(oldnme, newnme)
  if err != nil { 
    return false
  } 
  return true
} 



