import Foundation
import Darwin

class OclDate
{ static var instance : OclDate? = nil

  init() { }

  init(copyFrom: OclDate) {
    self.time = copyFrom.time
    self.year = copyFrom.year
    self.month = copyFrom.month
    self.day = copyFrom.day
    self.hour = copyFrom.hour
    self.minute = copyFrom.minute
    self.second = copyFrom.second
  }
    

  func copy() -> OclDate
  { let res : OclDate = OclDate(copyFrom: self)
    addOclDate(instance: res)
    return res
  }

  static func defaultInstance() -> OclDate
  { if (instance == nil)
    { instance = createOclDate() }
    return instance!
  }

  deinit
  { killOclDate(obj: self) }

  static var systemTime : Int64 = 0

  static func getSystemTime() -> Int64
  { let d = Date()
    return Int64(d.timeIntervalSince1970 * 1000)
  }
  
    
  var time : Int64 = 0
  var year : Int = 0
  var month : Int = 0
  var day : Int = 0
  var hour : Int = 0
  var minute : Int = 0
  var second : Int = 0

  static func newOclDate() -> OclDate
  { let dte = Date()
    let d : OclDate = createOclDate()
    d.time = Int64(dte.timeIntervalSince1970*1000)
    return d
  }


  static func newOclDate(t : Int64) -> OclDate
  {
    let d : OclDate = createOclDate()
    d.time = t
    return d
  }


  func setTime(t : Int64) -> Void
  {
    time = t
  }


  func getTime() -> Int64
  { return time }


  func dateBefore(d : OclDate) -> Bool
  {
    var result : Bool = false
    if time < d.time
    {
      result = true
    }
    else {
      result = false
    }
    return result

  }


  func dateAfter(d : OclDate) -> Bool
  {
    var result : Bool = false
    if time > d.time
    {
      result = true
    }
    else {
      result = false
    }
    return result

  }

}


var OclDate_allInstances : [OclDate] = [OclDate]()

func createOclDate() -> OclDate
{ let result : OclDate = OclDate()
  OclDate_allInstances.append(result)
  return result
}

func addOclDate(instance : OclDate)
{ OclDate_allInstances.append(instance) }

func killOclDate(obj: OclDate)
{ OclDate_allInstances = OclDate_allInstances.filter{ $0 !== obj } }


