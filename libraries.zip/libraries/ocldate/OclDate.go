package ocldate

import "time"

type OclDate struct {
  time int64
}

func createOclDate() *OclDate {
  var res *OclDate
  res = &OclDate{}
  return res
}

func NewOclDate(t int64) *OclDate {
  var result *OclDate
  result = createOclDate()
  result.time = t
  return result

}

func (self *OclDate) getTime() int64 { 
  return self.time
}

func GetSystemTime() int64 {
  t := time.Now()
  // return time.UnixMilli(time.Now())
  return t.Unix()*1000 
}





