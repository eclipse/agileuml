package ocldate

import "time"

var SystemTime int64

type OclDate struct {
  time int64
  year int
  month int
  day int
  weekday int
  hour int
  minute int
  second int
}

func createOclDate() *OclDate {
  var res *OclDate
  res = &OclDate{}
  return res
}

func NewOclDate() *OclDate {
  var result *OclDate
  result = createOclDate()
  t := time.Now()
  
  result.time = t.Unix()*1000
  SystemTime = result.time
  result.year = t.Year()
  result.month = int(t.Month())
  result.day = t.Day()
  result.weekday = int(t.Weekday())
  result.hour = t.Hour()
  result.minute = t.Minute()
  result.second = t.Second()

  return result
}

func NewOclDate_Time(t int64) *OclDate {
  var result *OclDate
  result = createOclDate()
  result.time = t
  tt := time.Unix(t/1000,0)
  result.year = tt.Year()
  result.month = int(tt.Month())
  result.day = tt.Day()
  result.weekday = int(tt.Weekday())
  result.hour = tt.Hour()
  result.minute = tt.Minute()
  result.second = tt.Second()
  return result

}

func (self *OclDate) SetTime(t int64) { 
  tt := time.Unix(t/1000,0)
  self.time = t
  self.year = tt.Year()
  self.month = int(tt.Month())
  self.day = tt.Day()
  self.weekday = int(tt.Weekday())
  self.hour = tt.Hour()
  self.minute = tt.Minute()
  self.second = tt.Second()
}

func (self *OclDate) GetTime() int64 { 
  return self.time
}

func GetSystemTime() int64 {
  t := time.Now()
  SystemTime = t.Unix()*1000
  // return time.UnixMilli(time.Now())
  return SystemTime
}

func (self *OclDate) GetYear() int { 
  return self.year
} 

func (self *OclDate) GetMonth() int { 
  return self.month
} 

func (self *OclDate) GetDate() int { 
  return self.day
} 

func (self *OclDate) GetDay() int { 
  return self.weekday
} 

func (self *OclDate) GetHour() int { 
  return self.hour
} 

func (self *OclDate) GetMinute() int { 
  return self.minute
} 

func (self *OclDate) GetSecond() int { 
  return self.second
} 

func (self *OclDate) GetMinutes() int { 
  return self.minute
} 

func (self *OclDate) GetSeconds() int { 
  return self.second
} 













