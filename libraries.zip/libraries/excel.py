import ocl
import math
import re
import copy

from mathlib import *
from oclfile import *
from ocltype import *
from ocldate import *
from oclprocess import *
from ocliterator import *
from ocldatasource import *
from enum import Enum

def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)

def displaySequence(x):
  print(x)

def displaySet(x):
  print(x)

def displayMap(x):
  print(x)


class SpreadsheetFont : 
  spreadsheetfont_instances = []
  spreadsheetfont_index = dict({})

  def __init__(self):
    self.Name = ""
    self.Size = 0
    self.Color = None
    self.Bold = False
    self.Italic = False
    SpreadsheetFont.spreadsheetfont_instances.append(self)



  def killSpreadsheetFont(spreadsheetfont_x) :
    spreadsheetfont_instances = ocl.excludingSet(spreadsheetfont_instances, spreadsheetfont_x)
    free(spreadsheetfont_x)

class SpreadsheetCell : 
  spreadsheetcell_instances = []
  spreadsheetcell_index = dict({})

  def __init__(self):
    self.Name = ""
    self.RowNumber = 0
    self.ColumnName = ""
    self.Value = None
    self.Font = None
    SpreadsheetCell.spreadsheetcell_instances.append(self)



  def newSpreadsheetCell(nme,val) :
    result = None
    c = createSpreadsheetCell()
    c.Name = nme
    c.RowNumber = ocl.toInteger(ocl.firstMatch(nme, "[0-9]+"))
    c.ColumnName = ocl.firstMatch(nme, "[A-Z]+")
    c.Value = val
    result = c
    return result

  def precedes(self, c) :
    result = False
    if self.ColumnName <= c.ColumnName and ((self.RowNumber < c.RowNumber) if (self.ColumnName == c.ColumnName) else (True)) :
      result = True
    return result

  def startColumn(s) :
    result = ""
    result = ocl.firstMatch(s, "[A-Z]+")
    return result

  def endColumn(s) :
    result = ""
    if (s.find(":") + 1) > 0 :
      result = ocl.firstMatch(ocl.after(s, ":"), "[A-Z]+")
    else :
      if (s.find(":") + 1) == 0 :
        result = ocl.firstMatch(s, "[A-Z]+")
    return result

  def startRow(s) :
    result = 0
    result = ocl.toInteger(ocl.firstMatch(s, "[0-9]+"))
    return result

  def endRow(s) :
    result = ""
    if (s.find(":") + 1) > 0 :
      result = ocl.toInteger(ocl.firstMatch(ocl.after(s, ":"), "[0-9]+"))
    else :
      if (s.find(":") + 1) == 0 :
        result = ocl.toInteger(ocl.firstMatch(s, "[0-9]+"))
    return result

  def killSpreadsheetCell(spreadsheetcell_x) :
    spreadsheetcell_instances = ocl.excludingSet(spreadsheetcell_instances, spreadsheetcell_x)
    free(spreadsheetcell_x)

class Worksheet : 
  worksheet_instances = []
  worksheet_index = dict({})

  def __init__(self):
    self.Visible = False
    self.ColumnNames = []
    self.AllCells = []
    self.Range = dict({})
    Worksheet.worksheet_instances.append(self)



  def Activate(self) :
    self.Visible = True

  def getOneCell(self, s) :
    result = None
    result = ocl.any([c for c in self.AllCells if c.ColumnName == ocl.firstMatch(s, "[A-Z]+") and str(c.RowNumber) + "" == ocl.firstMatch(s, "[0-9]+")])
    return result

  def getCellRange(self, s) :
    result = []
    startcol = ""
    startcol = SpreadsheetCell.startColumn(s)
    endcol = ""
    endcol = SpreadsheetCell.endColumn(s)
    startrow = 0
    startrow = SpreadsheetCell.startRow(s)
    endrow = ""
    endrow = SpreadsheetCell.endRow(s)
    result = [c for c in self.AllCells if c.ColumnName >= startcol and c.ColumnName <= endcol and ((c.RowNumber <= endrow) if (c.ColumnName == endcol) else (True)) and ((c.RowNumber >= startrow) if (c.ColumnName == startcol) else (True))]
    return result

  def getRange(self, s) : 
    if (s.find(":") + 1) > 0 :
      return self.getCellRange(s)
    else : 
      return self.getOneCell(s)


  def getRow(self, j) :
    result = []
    result = sorted([c for c in self.AllCells if c.RowNumber == j], key = lambda cx : cx.ColumnName)
    return result

  def getColumn(self, i) :
    result = []
    result = sorted([c for c in self.AllCells if c.ColumnName == (self.ColumnNames)[i - 1]], key = lambda cx : cx.RowNumber)
    return result

  def getCell(self, i) :
    result = None
    result = (self.AllCells)[i - 1]
    return result

  def getCell(self, i, j) :
    result = None
    result = ocl.any([c for c in self.AllCells if c.ColumnName == (self.ColumnNames)[j - 1] and c.RowNumber == i])
    return result

  def killWorksheet(worksheet_x) :
    worksheet_instances = ocl.excludingSet(worksheet_instances, worksheet_x)
    free(worksheet_x)

class Excel : 
  excel_instances = []
  excel_index = dict({})
  Worksheets = dict({})

  def __init__(self):
    Excel.excel_instances.append(self)



  def Min(r) :
    result = None
    result = ocl.minSequence([c.Value for c in r])
    return result

  def Max(r) :
    result = None
    result = ocl.maxSequence([c.Value for c in r])
    return result

  def AccrInt(issueDate,firstInterestDate,settlement,rate,par,freq,basis) :
    result = 0.0
    pass
    return result

  def AccrIntM(issueDate,maturityDate,couponRate,par,basis) :
    result = 0.0
    pass
    return result

  def Acos(v) :
    result = 0.0
    result = math.acos(v)
    return result

  def Acosh(v) :
    result = 0.0
    result = MathLib.acosh(v)
    return result

  def Acot(v) :
    result = 0.0
    result = 1.0/math.atan(v)
    return result

  def Acoth(v) :
    result = 0.0
    result = 1.0/MathLib.atanh(v)
    return result

  def AmorDegrc(cost,purchaseDate,firstPeriodEnd,salvageValue,period,rate,basis) :
    pass

  def AmorLinc(cost,purchaseDate,firstPeriodEnd,salvageValue,period,rate,basis) :
    pass

  def And(sq) :
    result = False
    result = ocl.forAll(sq, lambda v : v == True)
    return result

  def Arabic(romanString) :
    result = 0.0
    pass
    return result

  def Asc(s) :
    result = ""
    result = s
    return result

  def Asin(v) :
    result = 0.0
    result = math.asin(v)
    return result

  def Asinh(v) :
    result = 0.0
    result = MathLib.asinh(v)
    return result

  def Atan2(x,y) :
    result = 0.0
    if x > 0 :
      result = math.atan(y/x)
    else :
      if x < 0 and y >= 0 :
        result = math.atan(y/x) + MathLib.piValue()
      else :
        if x < 0 and y < 0 :
          result = math.atan(y/x) - MathLib.piValue()
        else :
          if x == 0 and y > 0 :
            result = MathLib.piValue()/2
          else :
            if x == 0 and y < 0 :
              result = -MathLib.piValue()/2
    return result

  def Atanh(v) :
    result = 0.0
    result = MathLib.atanh(v)
    return result

  def AveDev(sq) :
    result = False
    n = 0
    n = len(sq)
    m = 0.0
    m = MathLib.mean(sq)
    result = 1.0/n * ocl.sum([math.abs(v-m) for v in sq])
    return result

  def Average(sq) :
    result = False
    result = MathLib.mean(sq)
    return result

  def Base(v,bse) :
    result = ""
    if bse == 2 :
      result = MathLib.decimal2binary(v)
    else :
      if bse == 8 :
        result = MathLib.decimal2octal(v)
      else :
        if bse == 16 :
          result = MathLib.decimal2hex(v)
        else :
          if True :
            result = v
    return result

  def Bessell(x,ord) :
    result = 0.0
    pass
    return result

  def BessellJ(x,ord) :
    result = 0.0
    pass
    return result

  def BessellK(x,ord) :
    result = 0.0
    pass
    return result

  def BessellY(x,ord) :
    result = 0.0
    pass
    return result

  def Beta_Dist(v,a,b) :
    result = 0.0
    pass
    return result

  def Beta_Inv(v,a,b) :
    result = 0.0
    pass
    return result

  def BetaDist(v,a,b) :
    result = 0.0
    pass
    return result

  def BetaInv(v,a,b) :
    result = 0.0
    pass
    return result

  def Bin2Dec(v) :
    result = ""
    result = "" + str(float(str(v) + ""))
    return result

  def Bin2Hex(v) :
    result = ""
    pass
    return result

  def Bin2Oct(v) :
    result = ""
    pass
    return result

  def Binom_Dist(num,trials,prob,cum) :
    result = 0.0
    if cum == False :
      result = MathLib.combinatorial(int(num), int(trials)) * math.pow(prob, trials) * math.pow((1 - prob), numb - trials)
    else :
      if cum == True :
        result = ocl.sum([Excel.Binom_Dist(num, i, prob, False) for i in range(0, trials +1)])
    return result

  def Binom_Dist_Range(num,trials,prob,cum) :
    result = 0.0
    pass
    return result

  def Binom_Inv(trials,prob,alpha) :
    result = 0.0
    pass
    return result

  def BinomDist(num,trials,prob,cum) :
    result = 0.0
    result = self.Binom_Dist(num, trials, prob, cum)
    return result

  def Bitand(x,y) :
    result = 0.0
    result = MathLib.bitwiseAnd(x, y)
    return result

  def Bitor(x,y) :
    result = 0.0
    result = MathLib.bitwiseOr(x, y)
    return result

  def Bitxor(x,y) :
    result = 0.0
    result = MathLib.bitwiseXor(x, y)
    return result

  def Bitlshift(x,y) :
    result = 0.0
    result = x * math.pow(2, y)
    return result

  def Bitrshift(x,y) :
    result = 0.0
    result = x/math.pow(2, y)
    return result

  def killExcel(excel_x) :
    excel_instances = ocl.excludingSet(excel_instances, excel_x)
    free(excel_x)

def createSpreadsheetFont():
  spreadsheetfont = SpreadsheetFont()
  return spreadsheetfont

def allInstances_SpreadsheetFont():
  return SpreadsheetFont.spreadsheetfont_instances


spreadsheetfont_OclType = createByPKOclType("SpreadsheetFont")
spreadsheetfont_OclType.instance = createSpreadsheetFont()
spreadsheetfont_OclType.actualMetatype = type(spreadsheetfont_OclType.instance)


def createSpreadsheetCell():
  spreadsheetcell = SpreadsheetCell()
  return spreadsheetcell

def allInstances_SpreadsheetCell():
  return SpreadsheetCell.spreadsheetcell_instances


spreadsheetcell_OclType = createByPKOclType("SpreadsheetCell")
spreadsheetcell_OclType.instance = createSpreadsheetCell()
spreadsheetcell_OclType.actualMetatype = type(spreadsheetcell_OclType.instance)


def createWorksheet():
  worksheet = Worksheet()
  return worksheet

def allInstances_Worksheet():
  return Worksheet.worksheet_instances


worksheet_OclType = createByPKOclType("Worksheet")
worksheet_OclType.instance = createWorksheet()
worksheet_OclType.actualMetatype = type(worksheet_OclType.instance)


def createExcel():
  excel = Excel()
  return excel

def allInstances_Excel():
  return Excel.excel_instances


excel_OclType = createByPKOclType("Excel")
excel_OclType.instance = createExcel()
excel_OclType.actualMetatype = type(excel_OclType.instance)


# cell1 = SpreadsheetCell.newSpreadsheetCell("A1", 100)
# cell2 = SpreadsheetCell.newSpreadsheetCell("A2", 200)
# cell3 = SpreadsheetCell.newSpreadsheetCell("A3", 300)
# cell4 = SpreadsheetCell.newSpreadsheetCell("A4", 400)
# cell5 = SpreadsheetCell.newSpreadsheetCell("B1", 100)
# cell6 = SpreadsheetCell.newSpreadsheetCell("B2", 200)

# print(cell3.Value)
# print(cell3.ColumnName)
# print(cell3.RowNumber)

# wk = createWorksheet()
# wk.AllCells = [cell1, cell2, cell3, cell4, cell5, cell6]

# c = wk.getOneCell("A3")
# print(c.Value)
# print(c.ColumnName)
# print(c.RowNumber)

# cs = wk.getRange("A2:B1")

# print(len(cs))
# print(cs[0].Value)
# print(cs[1].Value)
# print(cs[2].Value)
# print(cs[3].Value)


