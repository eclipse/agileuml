Entity:
ExcelLib 267 9
null  * abstract 




Entity:
Application 567 9
ExcelLib  *  auxilliary





Generalisation:
ExcelLib Application 565 13 456 41





Entity:
$Bond 768 121
null  *  auxilliary
price double 3 false false false coupon double 3 false false false frequency int 3 false false false period double 3 false false false maturity double 3 false false false yield double 3 false false false duration double 3 false false false weight double 3 false false false redemption double 3 false false false





Entity:
$BondGroup 736 23
null  * auxilliary
inverseDsum double 3 false false false



Association:
$BondGroup $Bond -1 838 61 840 123 0 bonds null 





Entity:
$CashFlow 1144 111
null  * auxilliary
amount double 3 false false false timePoint double 3 false false false rate double 3 false false false discount double 3 false false false





Association:
$Bond $CashFlow -1 945 127 1142 131 0 flows null 
ordered 






Operation:
defineFlows0
$Bond



true
$CashFlow->exists( f | f.amount = -price & f.timePoint = 0 & f : flows )








Operation:
defineFlows1
$Bond



true
Integer.subrange(1,( maturity * frequency )->floor())->forAll( t | $CashFlow->exists( f | f.amount = coupon & f.timePoint = ( t * 1.0 ) / frequency & f : flows ) )





Operation:
defineFlows2
$Bond



true
$CashFlow->exists( f | f.amount = 100 & f.timePoint = maturity & f : flows )





Operation:
totalValue
$Bond
double
r double
 query
true
result = flows->collect( f | f.amount/((1 + r)->pow(f.timePoint)) )->sum()





Operation:
presentValue
$Bond
double
r double
 query
true
result = flows->collect( f | f.amount *((-yield * f.timePoint)->exp()) )->sum()





Operation:
macaulayDuration
$Bond
double

 query
true
pv = totalValue(yield) & duration = flows->collect( f | ( f.timePoint * f.amount ) / ((1 + yield)->pow(f.timePoint)) )->sum() & result = duration/pv











Operation:
macaulayDurationC
$Bond
double

 query
true
pv = presentValue(yield) & duration = flows->collect( f | f.timePoint * f.amount *((-yield * f.timePoint)->exp()) )->sum() & result = duration/pv





















Operation:
secant
$Bond
double
rn double rminus double tvminus double tol double
 query
true
  tvn = totalValue(rn) & (tvn.abs < tol =>  result = rn) & (tvn.abs >= tol =>  result = secant(rn - tvn*((rn-rminus)/(tvn-tvminus)), rn, tvn, tol) )








Operation:
dosecant
$Bond
double
tol double
 query
flows.size > 0
a = flows->collect(amount)->sum() + price & r1 = (a/price)->pow(2.0/flows.size) - 1 & totalValue1 = totalValue(r1) + price & p = ((a / price)->log())/((a / totalValue1)->log()) & r2 = (1 + r1)->pow(p) - 1 & result = secant(r2, r1, totalValue1 - price, tol)







Operation:
nelsonseigalx
$Bond
double
t double v1 double v2 double v3 double lambda1 double lambda2 double 
 query static
true
tscaled1 = t/lambda1 & tscaled2 = t/lambda2 & exptscaled1 = -tscaled1->exp() & exptscaled2 = -tscaled2->exp() & expratio1 = ( 1 - exptscaled1 ) / tscaled1 & expratio2 = ( 1 - exptscaled2 ) / tscaled2 & result = v1 + v2 * expratio1 + v3 * ( expratio2 - exptscaled2 )





Operation:
nsx
$Bond
double
t double v1 double v2 double v3 double lambda1 double lambda2 double 
 query static
true
( t = 0 => result = v1 + v2 ) & ( t > 0 => result = $Bond.nelsonseigalx(t,v1,v2,v3,lambda1,lambda2) )








Operation:
nsxrow
$Bond
Sequence(double)
r $Bond lambda1 double lambda2 double
 query static
true
tscaled1 = r.duration/lambda1 & exptscaled1 = (-tscaled1)->exp() & expratio1 = (1 - exptscaled1)/tscaled1 & tscaled2 = r.duration/lambda2 & exptscaled2 = (-tscaled2)->exp() & expratio2 = (1 - exptscaled2)/tscaled2 & result = Sequence{1.0, expratio1, expratio2 - exptscaled2}




Operation:
nsxmatrix
$Bond
Sequence(Sequence(double))
r1 $Bond r2 $Bond r3 $Bond lambda1 double lambda2 double 
 query static
true
row1 = $Bond.nsxrow(r1,lambda1,lambda2) & row2 = $Bond.nsxrow(r2,lambda1,lambda2) & row3 = $Bond.nsxrow(r3,lambda1,lambda2) & result = Sequence{ row1, row2, row3 }





Entity:
NelsonSeigal 368 921
null  *  
beta1 double 3 false false false beta2 double 3 false false false beta3 double 3 false false false lambda1 double 3 false false false lambda2 double 3 false false false





Entity:
$GAIndividual 365 469
null  *  auxilliary
fitnessval double 3 false false false




Operation:
isValid
$GAIndividual
boolean

 query
true
(traits[1].value + traits[2].value > 0  =>  result = true)





Operation:
fitnessnsx
$GAIndividual
double

 query
true
sumsquares = $Bond->collect( r | ( r.yield - $Bond.nsx(r.duration, traits[1].value, traits[2].value, traits[3].value, traits[4].value, traits[5].value) )->sqr() )->sum() & result = 100.0 / ( 1 + sumsquares->sqrt() )






Entity:
$GATrait 677 464
null  * auxilliary
item String 3 false false false value double 3 false false false





Association:
$GAIndividual $GATrait 0 582 473 675 466 0 traits null 
ordered 





Entity:
$GeneticAlgorithm 369 589
null  *  auxilliary
maxfitness double 3 false false true 





Association:
$GeneticAlgorithm $GAIndividual -1 360 597 365 525 0 population null 







Entity:
$Sequences 636 669
null  * auxilliary






Operation:
toColumn
$Sequences
Sequence(Sequence(double))
s Sequence(double) 
 query static
true
result = s->collect( x | Sequence{ x } )









Operation:
subItems
$Sequences
Sequence(double)
s Sequence(double) inds Sequence(int) 
 query static
true
result = inds->select( i | 1 <= i & i <= s.size )->collect( j | s[j] )


Operation:
sqFloor
$Sequences
Sequence(int)
s Sequence(double) 
 query static
true
result = s->collect( x | x.floor )


Operation:
sqRound
$Sequences
Sequence(int)
s Sequence(double) 
 query static
true
result = s->collect( x | x.round )


Operation:
sqAbs
$Sequences
Sequence(double)
s Sequence(double) 
 query static
true
result = s->collect( x | x.abs )


Operation:
sqCeil
$Sequences
Sequence(int)
s Sequence(double) 
 query static
true
result = s->collect( x | x.ceil )


Operation:
sqEq
$Sequences
Sequence(boolean)
s Sequence(double) v double 
 query static
true
result = s->collect( e | e = v )


Operation:
sqLeq
$Sequences
Sequence(boolean)
s Sequence(double) v double 
 query static
true
result = s->collect( e | e <= v )


Operation:
sqLess
$Sequences
Sequence(boolean)
s Sequence(double) v double 
 query static
true
result = s->collect( e | e < v )


Operation:
sqAdd
$Sequences
Sequence(double)
s Sequence(double) v double 
 query static
true
result = s->collect( e | e + v )




Operation:
sqAverage
$Sequences
Sequence(double)
m Sequence(Sequence(double)) 
 query static
true
result = Integer.subrange(1,m[1].size)->collect( i | ( ( m->collect( row | row[i] )->sum() ) / m.size ) )




Operation:
ssAdd
$Sequences
Sequence(double)
s1 Sequence(double) s2 Sequence(double) 
 query static
s1.size = s2.size
result = Integer.subrange(1,s1.size)->collect( i | s1[i] + s2[i] )


Operation:
ssSubtract
$Sequences
Sequence(double)
s1 Sequence(double) s2 Sequence(double) 
 query static
s1.size = s2.size
result = Integer.subrange(1,s1.size)->collect( i | s1[i] - s2[i] )


Operation:
sqMult
$Sequences
Sequence(double)
ss Sequence(double) v double 
 query static
true
result = ss->collect( e | e * v )


Operation:
ssMult
$Sequences
Sequence(double)
s1 Sequence(double) s2 Sequence(double) 
 query static
s1.size = s2.size
result = Integer.subrange(1,s1.size)->collect( i | s1[i] * s2[i] )




Operation:
distance
$Sequences
double
s1 Sequence(double) s2 Sequence(double) 
 query static
s1.size = s2.size
result = Integer.subrange(1,s1.size)->collect( i | (s1[i] - s2[i])->sqr() )->sum()->sqrt() 






Entity:
$Matrix 992 685
null  * auxilliary


Operation:
determinant2
$Matrix
double
m Sequence(Sequence(double)) 
 query static
m.size = 2 & m[1]->size() = 2
a1 = m[1]->at(1) & a2 = m[1]->at(2) & b1 = m[2]->at(1) & b2 = m[2]->at(2) & result = a1 * b2 - a2 * b1


Operation:
detaux
$Matrix
double
x1 double y1 double x2 double y2 double 
 query static
true
result = x1 * y1 - x2 * y2


Operation:
determinant3
$Matrix
double
m Sequence(Sequence(double)) 
 query static
m.size = 3 & m[1]->size() = 3
result = ( m[1]->at(1) ) * $Matrix.detaux(m[2]->at(2),m[3]->at(3),m[2]->at(3),m[3]->at(2)) - ( m[1]->at(2) ) * $Matrix.detaux(m[2]->at(1),m[3]->at(3),m[3]->at(1),m[2]->at(3)) + ( m[1]->at(3) ) * $Matrix.detaux(m[2]->at(1),m[3]->at(2),m[2]->at(2),m[3]->at(1))


Operation:
lineqn3solution1
$Matrix
double
m Sequence(Sequence(double)) d double d1 double d2 double d3 double 
 query static
m.size = 3 & m[1]->size() = 3 & d /= 0
m1 = Sequence{Sequence{m[1]->at(2),m[1]->at(3),d1},Sequence{m[2]->at(2),m[2]->at(3),d2},Sequence{m[3]->at(2),m[3]->at(3),d3}} & result = -$Matrix.determinant3(m1) / d


Operation:
lineqn3solution2
$Matrix
double
m Sequence(Sequence(double)) d double d1 double d2 double d3 double 
 query static
m.size = 3 & m[1]->size() = 3 & d /= 0
m1 = Sequence{Sequence{m[1]->at(1),m[1]->at(3),d1},Sequence{m[2]->at(1),m[2]->at(3),d2},Sequence{m[3]->at(1),m[3]->at(3),d3}} & result = $Matrix.determinant3(m1) / d


Operation:
lineqn3solution3
$Matrix
double
m Sequence(Sequence(double)) d double d1 double d2 double d3 double 
 query static
m.size = 3 & m[1]->size() = 3 & d /= 0
m1 = Sequence{Sequence{m[1]->at(1),m[1]->at(2),d1},Sequence{m[2]->at(1),m[2]->at(2),d2},Sequence{m[3]->at(1),m[3]->at(2),d3}} & result = -$Matrix.determinant3(m1) / d




Operation:
matrixMult
$Matrix
Sequence(Sequence(double))
s Sequence(Sequence(double)) v double 
 query static
true
result = s->collect( sq | $Sequences.sqMult(sq,v) )


Operation:
mmMult
$Matrix
Sequence(Sequence(double))
m1 Sequence(Sequence(double)) m2 Sequence(Sequence(double)) 
 query static
m1.size = m2.size
result = Integer.subrange(1,m1.size)->collect( i | $Sequences.ssMult(m1[i],m2[i]) )


Operation:
rowMult
$Matrix
Sequence(double)
s Sequence(double) m Sequence(Sequence(double)) 
 query static
true
sze = Set{ s.size, m[1].size }->min() & result = Integer.subrange(1,sze)->collect( i | Integer.Sum(1,m.size,k,s[k] * ( m[k]->at(i) )) )


Operation:
matrixProd
$Matrix
Sequence(Sequence(double))
m1 Sequence(Sequence(double)) m2 Sequence(Sequence(double)) 
 query static
true
result = m1->collect( row | $Matrix.rowMult(row,m2) )










Operation:
toRow
$Matrix
Sequence(double)
m Sequence(Sequence(double)) 
 query static
true
result = m->collect( r | r[1] )








Operation:
cofactorMatrix
$Matrix
Sequence(Sequence(double))
m Sequence(Sequence(double)) i int j int
 query static
true
result = (m.subrange(1, i-1) ^ m.subrange(i+1, m.size))->collect( r | r.subrange(1,j-1) ^ r.subrange(j+1,r.size))







Operation:
cofactor
$Matrix
double
m Sequence(Sequence(double)) i int j int
 query static
true
weight = 1 - 2*((i+j) mod 2) & result = weight * $Matrix.determinant($Matrix.cofactorMatrix(m,i,j))






Operation:
determinant4
$Matrix
double
m Sequence(Sequence(double)) 
 query static
m.size >= 3 & m[1]->size() >= 3
result = Integer.subrange(1, m[1].size)->collect( i | (m[1]->at(i)) * $Matrix.cofactor(m, 1, i) )->sum()  






Operation:
determinant
$Matrix
double
m Sequence(Sequence(double)) 
 query static
m.size = m[1]->size()
(m.size = 1 => result = (m[1]->at(1))) & (m.size = 2 => result = $Matrix.determinant2(m)) & (m.size = 3 => result = $Matrix.determinant3(m)) & (m.size > 3 => result = $Matrix.determinant4(m))










Operation:
adjoint
$Matrix
Sequence(Sequence(double))
m Sequence(Sequence(double)) 
 query static
true
result = Integer.subrange(1, m.size)->collect( i | Integer.subrange(1, m[i].size)->collect( j | $Matrix.cofactor(m, j, i) ) ) 






Operation:
inverse
$Matrix
Sequence(Sequence(double))
m Sequence(Sequence(double)) 
 query static
true
result = $Matrix.matrixMult( $Matrix.adjoint(m), 1.0/$Matrix.determinant(m) )







Operation:
solveEquations
$Matrix
Sequence(double)
m Sequence(Sequence(double)) y Sequence(double) 
 query static
true
result = $Matrix.toRow( $Matrix.matrixProd( $Matrix.inverse(m), $Sequences.toColumn(y) ) )







GeneralUseCase:
initialisensx s1 Sequence(double) s2 Sequence(double)



false


Constraint:
null
true
$GeneticAlgorithm->exists( g | true )
null initialisensx
false




Constraint:
null
true
self->isDeleted()
$Bond@pre initialisensx
false




Constraint:
null
i : Integer.subrange(1,s1.size)
$Bond->exists( b | b.duration = s1->at(i) & b.yield = s2->at(i) )
null initialisensx
false





Constraint:
lambda1 : Sequence{0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5} 
lambda2 : Sequence{0.75, 1.2, 1.7, 2.2, 2.7} & r1 : $Bond & r2 : $Bond & r3 : $Bond & r1.duration < r2.duration & r2.duration < r3.duration & m = $Bond.nsxmatrix(r1,r2,r3,lambda1, lambda2) & d = $Matrix.determinant3(m) & d /= 0
$GAIndividual->exists( ind | $GATrait->exists( t1 | t1.item = "beta1" & t1.value = $Matrix.lineqn3solution1(m,d,-r1.yield,-r2.yield,-r3.yield) & t1 : ind.traits ) & $GATrait->exists( t2 | t2.item = "beta2" & t2.value = $Matrix.lineqn3solution2(m,d,-r1.yield,-r2.yield,-r3.yield) & t2 : ind.traits ) & $GATrait->exists( t3 | t3.item = "beta3" & t3.value = $Matrix.lineqn3solution3(m,d,-r1.yield,-r2.yield,-r3.yield) & t3 : ind.traits ) & $GATrait->exists( t4 | t4.item = "lambda1" & t4.value = lambda1 & t4 : ind.traits )& $GATrait->exists( t5 | t5.item = "lambda2" & t5.value = lambda2 & t5 : ind.traits ) & ind : population )
$GeneticAlgorithm initialisensx
false









Constraint:
p : population
p.isValid()
p.fitnessval = p.fitnessnsx()
$GeneticAlgorithm initialisensx
false



Constraint:
population.size > 0
null
$GeneticAlgorithm.maxfitness = population->collect(fitnessval)->max()
$GeneticAlgorithm initialisensx
false



Constraint:
null
true
( "Population size = " + population.size )->display() & ( "Max fitness = " + $GeneticAlgorithm.maxfitness )->display()
$GeneticAlgorithm initialisensx
false





Constraint:
maxresult = population->selectMaximals(fitnessval)->any()
null
NelsonSeigal->exists( ns | ns.beta1 = maxresult.traits[1].value & ns.beta2 = maxresult.traits[2].value & ns.beta3 = maxresult.traits[3].value & ns.lambda1 = maxresult.traits[4].value & ns.lambda2 = maxresult.traits[5].value )
$GeneticAlgorithm initialisensx
false





Constraint:
maxresult = population->selectMaximals(fitnessval)->any()
null
$NSXFunction->exists( nsxf | $SimplexPoint->exists( p | p.coords = Sequence{ maxresult.traits[1].value, maxresult.traits[2].value, maxresult.traits[3].value, maxresult.traits[4].value, maxresult.traits[5].value } & $Simplex->exists( sx | sx.f = nsxf & sx.dim = 5 & sx.iterate(p, 0.00001)->display() ) ) )
$GeneticAlgorithm initialisensx
false











Operation:
SUM
ExcelLib
double
s Sequence(double) 
 query
true
result = s->sum()




Operation:
PRODUCT
ExcelLib
double
s Sequence(double) 
 query
true
result = s->prd()





Operation:
SUMPRODUCT
ExcelLib
double
s1 Sequence(double) s2 Sequence(double) 
 query
s1.size = s2.size
result = Integer.subrange(1,s1.size)->collect( i | s1[i]*s2[i] )->sum()




Operation:
ESTIMATENSX
ExcelLib
double
s1 Sequence(double) s2 Sequence(double) 

s1.size = s2.size
initialisensx(s1,s2) & result = $GeneticAlgorithm.maxfitness





Operation:
AVERAGE
ExcelLib
double
s Sequence(double) 
 query
true
( s.size = 0 => result = 0 ) & ( s.size > 0 => result = s.sum / s.size )





Operation:
DATE
ExcelLib
int
yr int month int day int 
 query
yr >= 1900 & month >= 1 & day >= 1
result = (yr - 1900)*360 + (month - 1)*30 + (day - 1)





Operation:
DURATION
ExcelLib
double
sett int mat int coupon double yield double freq int
 query
true
period = (mat - sett)/360.0 & $Bond->exists( b | b.coupon = coupon/freq & b.yield = yield & b.maturity = period & b.frequency = freq & b.defineFlows1() & b.defineFlows2() & result = b.macaulayDuration() )







Operation:
DURATIONC
ExcelLib
double
sett int mat int coupon double yield double freq int
 query
true
period = (mat - sett)/360.0 & $Bond->exists( b | b.coupon = coupon/freq & b.yield = yield & b.maturity = period & b.frequency = freq & b.defineFlows1() & b.defineFlows2() & result = b.macaulayDurationC() )






Operation:
RATE
ExcelLib
double
npays int payment double pv double
 query
true
$Bond->exists( b | b.coupon = payment & b.price = pv & b.maturity = npays & b.frequency = 1 & b.defineFlows0() & b.defineFlows1() & result = b.dosecant(0.0001) )







Operation:
RATE
ExcelLib
double
npays int payment double pv double fv double
 query
true
$Bond->exists( b | b.coupon = payment & b.price = pv & b.maturity = npays & b.frequency = 1 & b.defineFlows0() & b.defineFlows1() & b.defineFlows2() & result = b.dosecant(0.0001) )








Operation:
PRICE
ExcelLib
double
sett int mat int crate double yield double redempt double freq int
 query
true
period = (mat - sett)/360.0 & $Bond->exists( b | b.coupon = crate/freq & b.yield = yield & b.maturity = period & b.frequency = freq & b.defineFlows1() & b.defineFlows2() & result = b.totalValue(yield) )










Operation:
MAX
ExcelLib
double
s Sequence(double) 
 query
true
( s.size = 0 => result = 0 ) & ( s.size > 0 => result = s.max )




Operation:
MIN
ExcelLib
double
s Sequence(double) 
 query
true
( s.size = 0 => result = 0 ) & ( s.size > 0 => result = s.min )






Operation:
SIN
ExcelLib
double
x double 
 query
true
result = x.sin



Operation:
COS
ExcelLib
double
x double 
 query
true
result = x.cos





Operation:
TAN
ExcelLib
double
x double 
 query
true
result = x.tan








Operation:
EXP
ExcelLib
double
x double 
 query
true
result = x.exp





Operation:
LOG
ExcelLib
double
x double 
 query
true
result = x.log








Operation:
SQRT
ExcelLib
double
x double 
 query
x >= 0
result = x.sqrt






Entity:
$SimplexPoint 366 1037
null  *  auxilliary
coords Sequence(double) 3 false false false fval double 3 false false false



Entity:
$NFunction 48 1142
null  * abstract auxilliary 



Operation:
apply
$NFunction
double
p $SimplexPoint 
 query abstract
true
true









Entity:
$NSXFunction 48 1342
$NFunction  * auxilliary


Operation:
apply
$NSXFunction
double
p $SimplexPoint 
 query
true
beta1 = p.coords[1] & beta2 = p.coords[2] & beta3 = p.coords[3] & lambda1 = p.coords[4] & lambda2 = p.coords[5] & ( ( beta1 + beta2 <= 0 => result = 1000 ) & ( beta1 + beta2 > 0 => result = $Bond->collect( r | ( r.yield - $Bond.nsx(r.duration,beta1,beta2,beta3,lambda1,lambda2) )->sqr() )->sum() ) ) 











Entity:
$Simplex 259 1149
null  * auxilliary
dim int 3 false false false


Operation:
sortPoints
$Simplex
boolean


true
points = points@pre->sortedBy(fval) & result = true



Operation:
diameter
$Simplex
double

query
true
result = $Sequences.distance(points.first.coords, points.last.coords)




Operation:
initialise
$Simplex
void
x $SimplexPoint 

true
x : points & dim = x.coords.size & Integer.subrange(1,dim)->forAll( i | $SimplexPoint->exists( p | p.coords = ( x.coords.subrange(1,i - 1) ^ Sequence{( x.coords->at(i) ) * 1.05} ^ x.coords.subrange(i + 1,dim) ) & p : points ) ) & points->forAll( p | p.fval = f.apply(p) )




Operation:
computeMeanReflection
$Simplex
void


true
$SimplexPoint->exists( m | m.coords = $Sequences.sqAverage(points.front->collect(coords)) & m.fval = f.apply(m) & mean = m ) & $SimplexPoint->exists( r | r.coords = $Sequences.ssSubtract($Sequences.sqMult(mean.coords,2.0),points.last.coords) & r.fval = f.apply(r) & reflection = r )



Operation:
expand
$Simplex
void


true
$SimplexPoint->exists( s | s.coords = $Sequences.ssAdd(mean.coords,$Sequences.sqMult($Sequences.ssSubtract(mean.coords,points.last.coords),2.0)) & s.fval = f.apply(s) & ( ( s.fval < reflection.fval => points[( dim + 1 )] = s ) & ( reflection.fval <= s.fval => points[( dim + 1 )] = reflection ) ) )



Operation:
shrink
$Simplex
void
x1 $SimplexPoint 

true
Integer.subrange(2,dim + 1)->forAll( i | points[i].coords = $Sequences.ssAdd(x1.coords,$Sequences.sqMult($Sequences.ssSubtract(points[i].coords,x1.coords),0.5)) & points[i].fval = f.apply(points[i]) )



Operation:
contractInside
$Simplex
void
c $SimplexPoint 

true
( ( c.fval < reflection.fval => points[( dim + 1 )] = c ) & ( reflection.fval <= c.fval => self.shrink(points.first) ) )


Operation:
contractOutside
$Simplex
void
cc $SimplexPoint 

true
( ( cc.fval < points.last.fval => points[( dim + 1 )] = cc ) & ( points.last.fval <= cc.fval => self.shrink(points.first) ) )



Operation:
contract
$Simplex
void


true
( reflection.fval < points.last.fval => $SimplexPoint->exists( c | c.coords = $Sequences.ssAdd(mean.coords,$Sequences.sqMult($Sequences.ssSubtract(reflection.coords,mean.coords),0.5)) & c.fval = f.apply(c) & self.contractInside(c) ) ) & ( reflection.fval >= points.last.fval => $SimplexPoint->exists( cc | cc.coords = $Sequences.ssAdd(mean.coords,$Sequences.sqMult($Sequences.ssSubtract(points.last.coords,mean.coords),0.5)) & cc.fval = f.apply(cc) & self.contractOutside(cc) ) )



Operation:
reflectExpand
$Simplex
void


true
( points.first.fval <= reflection.fval & reflection.fval < points[dim].fval => points[( dim + 1 )] = reflection ) & ( reflection.fval < points.first.fval => self.expand() ) & ( points[dim].fval <= reflection.fval => self.contract() )




Operation:
iterate
$Simplex
$SimplexPoint
x $SimplexPoint tol double 
 query
true
result = points[1]






Association:
$Simplex $SimplexPoint -1 289 1150 358 1051 0 points null 
ordered 



Association:
$Simplex $NFunction 0 257 1155 189 1149 1 f null 



Association:
$Simplex $SimplexPoint 0 443 1147 557 1106 1 mean null 



Association:
$Simplex $SimplexPoint 0 485 1180 650 1104 1 reflection null 





Generalisation:
$NFunction $NSXFunction 127 1346 122 1178






Activity:
$Simplex iterate
 execute ( initialise(x) & sortPoints() ) ; while diameter() > tol do execute ( computeMeanReflection() & reflectExpand() & sortPoints() & points[1]->display() & diameter()->display() )  ; return points[1] 







