import Foundation
import Darwin

class MathLib
{ static var instance : MathLib? = nil

  init() { }

  init(copyFrom: MathLib) {
  }

  func copy() -> MathLib
  { let res : MathLib = MathLib(copyFrom: self)
    return res
  }

  static func defaultInstance() -> MathLib
  { if (instance == nil)
    { instance = createMathLib() }
    return instance!
  }

  deinit
  { killMathLib(obj: self) }

  static var ix : Int = 0
  static var iy : Int = 0
  static var iz : Int = 0
  static var hexdigit : [String] = []

  static func initialiseMathLib() -> Void
  {
    MathLib.hexdigit = ["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"]
    MathLib.setSeeds(x: 1001, y: 781, z: 913)

  }


  static func pi() -> Double
  {
    var result : Double = 0.0
    result = 3.14159265
    return result

  }


  static func e() -> Double
  {
    var result : Double = 0.0
    result = exp(_: 1)
    return result

  }


  static func setSeeds(x : Int, y : Int, z : Int) -> Void
  {
    MathLib.ix = x
    MathLib.iy = y
    MathLib.iz = z

  }


  static func nrandom() -> Double
  {
    MathLib.ix = ( MathLib.ix * 171) % 30269
    MathLib.iy = ( MathLib.iy * 172) % 30307
    MathLib.iz = ( MathLib.iz * 170) % 30323
    return (Double(MathLib.ix)/30269.0 + Double(MathLib.iy)/30307.0 + Double(MathLib.iz)/30323.0)

  }


  static func random() -> Double
  {
    var result : Double = 0.0
    var r : Double = 0.0
    r = MathLib.nrandom()
    result = (r - Double(Int(floor(_: r))))
    return result

  }


  static func combinatorial(n : Int, m : Int) -> Int64
  {
    var result : Int64 = 0
    if n - m < m
    {
      result = Int64(Ocl.prd(s: ((m + 1)...(n)).map({i in i})) / Ocl.prd(s: ((1)...(n - m)).map({j in j})))
    }
    else {
      if n - m >= m
      {
        result = Int64(Ocl.prd(s: ((n - m + 1)...(n)).map({i in i})) / Ocl.prd(s: ((1)...(m)).map({j in j})))
      }
    }
    return result

  }


  static func factorial(x : Int) -> Int64
  {
    var result : Int64 = 0
    if x < 2
    {
      result = 1
    }
    else {
      if x >= 2
      {
        result = Int64(Ocl.prd(s: ((2)...(x)).map({i in i})))
      }
    }
    return result
  }


  static func asinh(x : Double) -> Double
  {
    var result : Double = 0.0
    result = log(_: (x + sqrt(_: ( x * x + 1))))
    return result
  }


  static func acosh(x : Double) -> Double
  {
    var result : Double = 0.0
    result = log(_: (x + sqrt(_: ( x * x - Double(1)))))
    return result
  }


  static func atanh(x : Double) -> Double
  {
    var result : Double = 0.0
    result =  0.5 * log(_: ((1 + x) / (Double(1) - x)))
    return result
  }


  static func decimal2bits(x : Int64) -> String
  {
    var result : String = ""
    if x == 0
    {
      result = ""
    }
    else {
      result = MathLib.decimal2bits(x: x / 2) + "" + String((x % 2))
    }
    return result
  }


  static func decimal2binary(x : Int64) -> String
  {
    var result : String = ""
    if x < 0
    {
      result = "-" + MathLib.decimal2bits(x: -x)
    }
    else {
      if x == 0
      {
        result = "0"
      }
      else {
        result = MathLib.decimal2bits(x: x)
      }
    }
    return result
  }


  static func decimal2oct(x : Int64) -> String
  {
    var result : String = ""
    if x == 0
    {
      result = ""
    }
    else {
      result = MathLib.decimal2oct(x: x / 8) + "" + String((x % 8))
    }
    return result
  }


  static func decimal2octal(x : Int64) -> String
  {
    var result : String = ""
    if x < 0
    {
      result = "-" + MathLib.decimal2oct(x: -x)
    }
    else {
      if x == 0
      {
        result = "0"
      }
      else {
        result = MathLib.decimal2oct(x: x)
      }
    }
    return result
  }


  static func decimal2hx(x : Int64) -> String
  {
    var result : String = ""
    if x == 0
    {
      result = ""
    }
    else {
      result = MathLib.decimal2hx(x: x / 16) + ("" + MathLib.hexdigit[Int((x % 16)) + 1 - 1])
    }
    return result
  }


  static func decimal2hex(x : Int64) -> String
  {
    var result : String = ""
    if x < 0
    {
      result = "-" + MathLib.decimal2hx(x: -x)
    }
    else {
      if x == 0
      {
        result = "0"
      }
      else {
        result = MathLib.decimal2hx(x: x)
      }
    }
    return result
  }


  static func bitwiseAnd(x : Int, y : Int) -> Int
  {
    var x1 : Int = x
    var y1 : Int = y
    var k : Int = 1
    var res : Int = 0
    
    while ((x1 > 0 && y1 > 0))
    {
      if x1 % 2 == 1 && y1 % 2 == 1
      {
        res = res + k
      }
      k =  k * 2
      x1 = x1 / 2
      y1 = y1 / 2
    }
    return res
  }


  static func bitwiseOr(x : Int, y : Int) -> Int
  {
    var x1 : Int = x
    var y1 : Int = y
    var k : Int = 1
    var res : Int = 0
    
    while ((x1 > 0 || y1 > 0))
    {
      if x1 % 2 == 1 || y1 % 2 == 1
      {
        res = res + k
      }

      k =  k * 2
      x1 = x1 / 2
      y1 = y1 / 2
    }
    return res
  }


  static func bitwiseXor(x : Int, y : Int) -> Int
  {
    var x1 : Int = x
    var y1 : Int = y
    var k : Int = 1
    var res : Int = 0
    
    while ((x1 > 0 || y1 > 0))
    {
      if (x1 % 2) != (y1 % 2)
      {
        res = res + k
      }
      k =  k * 2
      x1 = x1 / 2
      y1 = y1 / 2
    }
    return res
  }

  static func bitwiseNot(x : Int) -> Int
  { return ~x } 

  static func toBitSequence(x : Int64) -> [Bool]
  { var res : [Bool] = []
    var x1 : Int64 = x;
  
    while (x1 > 0) 
    { if x1 % 2 == 0
      { res = [false] + res }
      else 
      { res = [true] + res }
      x1 = x1 / 2;
    }
    return res
  }

  static func modInverse(n : Int64, p : Int64) -> Int64
  {
    let x : Int64 = (n % p)
    for i in ((1)...(p - 1))
    {
      if (( i * x) % p) == 1
      {
        return i
      }
    }
    return 0
  }


  static func modPow(n : Int64, m : Int64, p : Int64) -> Int64
  {
    var res : Int64 = Int64(1)
    let x : Int64 = (n % p)
    for i in ((1)...(m))
    {
      res = (( res * x) % p)
    }
    return res
  }

}


var MathLib_allInstances : [MathLib] = [MathLib]()

func createMathLib() -> MathLib
{ let result : MathLib = MathLib()
  MathLib_allInstances.append(result)
  return result
}

func killMathLib(obj: MathLib)
{ MathLib_allInstances = MathLib_allInstances.filter{ $0 !== obj } }


