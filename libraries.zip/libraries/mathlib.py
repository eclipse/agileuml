
import ocl
import math

def free(x):
  del x



class MathLib:
  mathlib_instances = []
  mathlib_index = dict({})
  ix = 0
  iy = 0
  iz = 0
  hexdigit = []

  def __init__(self):
    MathLib.mathlib_instances.append(self)


  def initialiseMathLib() :
    MathLib.hexdigit = ["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"]
    MathLib.setSeeds(1001, 781, 913)

  def pi() :
    result = 0.0
    result = 3.14159265
    return result

  def e() :
    result = 0.0
    result = math.exp(1)
    return result

  def setSeeds(x,y,z) :
    MathLib.ix = x
    MathLib.iy = y
    MathLib.iz = z

  def nrandom() :
    result = 0.0
    MathLib.ix = (MathLib.ix * 171) % 30269
    MathLib.iy = (MathLib.iy * 172) % 30307
    MathLib.iz = (MathLib.iz * 170) % 30323
    return (MathLib.ix/30269.0 + MathLib.iy/30307.0 + MathLib.iz/30323.0)

  def random() :
    result = 0.0
    r = 0.0
    r = MathLib.nrandom()
    result = (r - int(math.floor(r)))
    return result

  def combinatorial(n,m) :
    result = 0
    if n - m < m :
      result = ocl.prd([(i) for i in range(m + 1, n + 1)])//ocl.prd([(j) for j in range(1, n - m + 1)])
    else :
      if n - m >= m :
        result = ocl.prd([(i) for i in range(n - m + 1, n + 1)])//ocl.prd([(j) for j in range(1, m + 1)])
    return result

  def factorial(x) :
    result = 0
    if x < 2 :
      result = 1
    else :
      if x >= 2 :
        result = ocl.prd([(i) for i in range(2, x + 1)])
    return result

  def asinh(x) :
    result = 0.0
    result = math.log((x + math.sqrt((x * x + 1))))
    return result

  def acosh(x) :
    result = 0.0
    result = math.log((x + math.sqrt((x * x - 1))))
    return result

  def atanh(x) :
    result = 0.0
    result = 0.5 * math.log((1 + x)/(1 - x))
    return result

  def decimal2bits(x) :
    result = ""
    if x == 0 :
      result = ""
    else :
      result = MathLib.decimal2bits(x//2) + "" + str(x % 2)
    return result

  def decimal2binary(x) :
    result = ""
    if x < 0 :
      result = "-" + MathLib.decimal2bits(-x)
    else :
      if x == 0 :
        result = "0"
      else :
        result = MathLib.decimal2bits(x)
    return result

  def decimal2oct(x) :
    result = ""
    if x == 0 :
      result = ""
    else :
      result = MathLib.decimal2oct(x//8) + "" + str(x % 8)
    return result

  def decimal2octal(x) :
    result = ""
    if x < 0 :
      result = "-" + MathLib.decimal2oct(-x)
    else :
      if x == 0 :
        result = "0"
      else :
        result = MathLib.decimal2oct(x)
    return result

  def decimal2hx(x) :
    result = ""
    if x == 0 :
      result = ""
    else :
      result = MathLib.decimal2hx(x//16) + "" + (MathLib.hexdigit)[int(x % 16) + 1 - 1]
    return result

  def decimal2hex(x) :
    result = ""
    if x < 0 :
      result = "-" + MathLib.decimal2hx(-x)
    else :
      if x == 0 :
        result = "0"
      else :
        result = MathLib.decimal2hx(x)
    return result

  def bitwiseAnd(x,y) :
    result = 0
    x1 = x
    y1 = y
    k = 1
    res = 0
    while x1 > 0 and y1 > 0 :
      if x1 % 2 == 1 and y1 % 2 == 1 :
        res = res + k
      else :
        pass
      k = k * 2
      x1 = x1//2
      y1 = y1//2
    return res

  def bitwiseOr(x,y) :
    result = 0
    x1 = x
    y1 = y
    k = 1
    res = 0
    while x1 > 0 or y1 > 0 :
      if x1 % 2 == 1 or y1 % 2 == 1 :
        res = res + k
      else :
        pass
      k = k * 2
      x1 = x1//2
      y1 = y1//2
    return res

  def bitwiseXor(x,y) :
    result = 0
    x1 = x
    y1 = y
    k = 1
    res = 0
    while x1 > 0 or y1 > 0 :
      if (x1 % 2) != (y1 % 2) :
        res = res + k
      else :
        pass
      k = k * 2
      x1 = x1//2
      y1 = y1//2
    return res

  def bitwiseNot(x) : 
    return ~x


  def toBitSequence(x) : 
    x1 = x  
    res = [] 
    while x1 > 0 :
      if x1 % 2 == 0 : 
        res = ocl.prepend(res,False)
      else :
        res = ocl.prepend(res,True)  
      x1 = x1//2
    return res   

  def modInverse(n,p) : 
    x = (n % p)
    for i in range(1,p) : 
      if ((i*x) % p) == 1 : 
        return i
    return 0

  def modPow(n,m,p) : 
    res = 1
    x = (n % p) 
    for i in range(1,m+1) : 
      res = (res*x) % p
    return res


  def killMathLib(mathlib_x) :
    mathlib_instances = ocl.excludingSet(mathlib_instances, mathlib_x)
    free(mathlib_x)


def createMathLib():
  mathlib = MathLib()
  return mathlib

def allInstances_MathLib():
  return MathLib.mathlib_instances

MathLib.initialiseMathLib()

