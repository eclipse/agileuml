// package ocliterator

package main

import "container/list"
// import "ocl"
// import "fmt"
import "reflect"

type OclAttribute struct {
  name string
  fieldtype *OclType
}

type OclOperation struct {
  name string
  returntype *OclType
  parameters *list.List
}

type OclType struct {
  name string
  actualType reflect.Type
  attributes *list.List
  operations *list.List
  constructors *list.List
  superclasses *list.List
}

func createOclAttribute() *OclAttribute {
  var res *OclAttribute
  res = &OclAttribute{}
  return res
}

func (self *OclAttribute) GetName() string {
  return self.name
}

func (self *OclAttribute) GetType() *OclType {
  return self.fieldtype
}

func (self *OclOperation) GetName() string {
  return self.name
}

func (self *OclOperation) GetType() *OclType {
  return self.returntype
}

func (self *OclOperation) GetParameters() *list.List {
  return self.parameters
}

func (self *OclOperation) GetReturnType() *OclType {
  return self.returntype
}

func createOclOperation() *OclOperation {
  var res *OclOperation
  res = &OclOperation{}
  return res
}

func createOclType() *OclType {
  var res *OclType
  res = &OclType{}
  return res
}

func (self *OclType) GetName() string {
  return self.name
}

func (self *OclType) GetFields() *list.List {
  self.attributes = list.New()
  if self.actualType.Kind() == reflect.Struct { 
  } else { 
    return self.attributes
  } 

  nf := self.actualType.NumField()
  for i := 0; i < nf; i++ {
    fld := self.actualType.Field(i)
    att := createOclAttribute()
    att.name = fld.Name
    typ := createOclType()
    typ.name = fld.Type.Name()
    typ.actualType = fld.Type
    att.fieldtype = typ
    self.attributes.PushBack(att)
  } 
  return self.attributes
}

func (self *OclType) GetMethods() *list.List {
  self.operations = list.New()
  nf := self.actualType.NumMethod()
  for i := 0; i < nf; i++ {
    met := self.actualType.Method(i)
    op := createOclOperation()
    op.name = met.Name
    typ := createOclType()
    typ.name = met.Type.Name()
    typ.actualType = met.Type
    op.returntype = typ
    self.operations.PushBack(op)
  } 
  return self.operations
}

func (self *OclType) GetConstructors() *list.List {
  return self.constructors
}

func (self *OclType) GetSuperclass() *OclType {
  if self.superclasses != nil && self.superclasses.Len() > 0 {
    frst := self.superclasses.Front()
    return frst.Value.(*OclType)
  } 
  return nil
}



func main() { 
} 
