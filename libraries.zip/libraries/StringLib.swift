import Foundation
import Darwin


class StringLib
{ 
  static func format(f : String, sq : [CVarArg])
  { let txt = String(format: f, arguments: sq)
    return txt
  }
}




