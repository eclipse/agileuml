import java.util.List;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

import java.lang.*;
import java.lang.reflect.*;
import java.util.StringTokenizer;
import java.io.*;



class Distribution
  implements SystemTypes
{
  private String label = ""; // internal
  private List points = new Vector(); // internal
  private int datasize = 0; // internal

  public Distribution()
  {
    this.label = "";
    this.points = (new SystemTypes.Set()).getElements();
    this.datasize = 0;

  }



  public String toString()
  { String _res_ = "(Distribution) ";
    _res_ = _res_ + label + ",";
    _res_ = _res_ + points + ",";
    _res_ = _res_ + datasize;
    return _res_;
  }

  public static Distribution parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Distribution distributionx = new Distribution();
    distributionx.label = (String) _line1vals.get(0);
      Controller.inst().distributionlabelindex.put(distributionx.getlabel(), distributionx);
    distributionx.datasize = Integer.parseInt((String) _line1vals.get(2));
    return distributionx;
  }


  public void writeCSV(PrintWriter _out)
  { Distribution distributionx = this;
    _out.print("" + distributionx.label);
    _out.print(" , ");
    _out.print("" + distributionx.points);
    _out.print(" , ");
    _out.print("" + distributionx.datasize);
    _out.println();
  }


  public void setlabel(String label_x) { label = label_x;  }


    public static void setAlllabel(List distributions,String val)
  { for (int i = 0; i < distributions.size(); i++)
    { Distribution distributionx = (Distribution) distributions.get(i);
      Controller.inst().setlabel(distributionx,val); } }


  public void setpoints(List points_x) { points = points_x;  }


    public void addpoints(double points_x)
  { points.add(new Double(points_x)); }

  public void removepoints(double points_x)
  { points.remove(new Double(points_x)); }



  

  public void setdatasize(int datasize_x) { datasize = datasize_x;  }


    public static void setAlldatasize(List distributions,int val)
  { for (int i = 0; i < distributions.size(); i++)
    { Distribution distributionx = (Distribution) distributions.get(i);
      Controller.inst().setdatasize(distributionx,val); } }


    public String getlabel() { return label; }

    public static List getAlllabel(List distributions)
  { List result = new Vector();
    for (int i = 0; i < distributions.size(); i++)
    { Distribution distributionx = (Distribution) distributions.get(i);
      if (result.contains(distributionx.getlabel())) { }
      else { result.add(distributionx.getlabel()); } }
    return result; }

    public static List getAllOrderedlabel(List distributions)
  { List result = new Vector();
    for (int i = 0; i < distributions.size(); i++)
    { Distribution distributionx = (Distribution) distributions.get(i);
      result.add(distributionx.getlabel()); } 
    return result; }

    public List getpoints() { return points; }

  

  

    public int getdatasize() { return datasize; }

    public static List getAlldatasize(List distributions)
  { List result = new Vector();
    for (int i = 0; i < distributions.size(); i++)
    { Distribution distributionx = (Distribution) distributions.get(i);
      if (result.contains(new Integer(distributionx.getdatasize()))) { }
      else { result.add(new Integer(distributionx.getdatasize())); } }
    return result; }

    public static List getAllOrdereddatasize(List distributions)
  { List result = new Vector();
    for (int i = 0; i < distributions.size(); i++)
    { Distribution distributionx = (Distribution) distributions.get(i);
      result.add(new Integer(distributionx.getdatasize())); } 
    return result; }

    public double pdf(double x)
  {   double result = 0;
    if (points.size() <= 0) { return result; } 
   
  datasize = points.size();
   result = Set.count(points,new Double(x)) / ( 1.0 * datasize );
       return result;
  }


    public double cdf(double x)
  {   double result = 0;
    if (points.size() <= 0) { return result; } 
   
  datasize = points.size();
   result = (Set.select_0(points,x)).size() / ( 1.0 * datasize );
       return result;
  }



}


class StatLib
  implements SystemTypes
{

  public StatLib()
  {

  }



  public String toString()
  { String _res_ = "(StatLib) ";
    return _res_;
  }

  public static StatLib parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    StatLib statlibx = new StatLib();
    return statlibx;
  }


  public void writeCSV(PrintWriter _out)
  { StatLib statlibx = this;
    _out.println();
  }


    public static double mean(List s)
  {   double result = 0;
    if (s.size() <= 0) { return result; } 
   
  result = ( 1.0 * Set.sumdouble(s) ) / s.size();
    return result;
  }


    public static double median(List s)
  {   double result = 0;
    if (s.size() <= 0) { return result; } 
   
  List s1 = Set.sort(s); 
     if (s.size() % 2 == 1) 
  {   result = ((Double) s1.get(( 1 + s.size() ) / 2 - 1)).doubleValue();
 
  }  else
      if (s.size() % 2 == 0) 
  {   result = ( ((Double) s1.get(s.size() / 2 - 1)).doubleValue() + ((Double) s1.get(1 + ( s.size() / 2 ) - 1)).doubleValue() ) / 2;
 
  }          return result;
  }


    public static double variance(List s)
  {   double result = 0;
    if (s.size() <= 0) { return result; } 
   
  double m = StatLib.mean(s); 
     result = Set.sumdouble(Set.collect_1(s,m)) / s.size();
       return result;
  }


    public static double uvariance(List s)
  {   double result = 0;
    if (s.size() <= 0) { return result; } 
   
  double m = StatLib.mean(s); 
     result = ( Set.sumdouble(Set.collect_1(s,m)) / ( s.size() - 1 ) );
       return result;
  }


    public static double sumsqdiffs(List s,List t)
  {   double result = 0;
    if (s.size() != t.size()) { return result; } 
   
  result = Set.sumdouble(Set.collect_2(Set.integerSubrange(1,s.size()),s,t));
    return result;
  }


    public static double sumsqdiff(List s,double t)
  {   double result = 0;
 
  result = Set.sumdouble(Set.collect_3(Set.integerSubrange(1,s.size()),s,t));
    return result;
  }


    public static List frequencyDist(List s)
  {   List result = new Vector();
 
  result = Set.collect_4(s,s);
    return result;
  }


    public static List histogram(List s,double l,double step,double u)
  {   List result = new Vector();
    if (u <= l) { return result; } 
   
  int maxindex = ((int) Math.ceil(( ( u - l ) / step ))); 
     result = Set.collect_6(Set.integerSubrange(0,maxindex),l,step,s);
       return result;
  }


    public static double mode(List s)
  {   double result = 0;
    if (s.size() <= 0) { return result; } 
   
  List fd = StatLib.frequencyDist(s); 
     int maxfreq = ((Integer) Set.max(fd)).intValue(); 
     result = ((Double) Set.any(Set.select_7(s,s,maxfreq))).doubleValue();
          return result;
  }


    public static double skewness(List s)
  {   double result = 0;
    if (s.size() <= 0) { return result; } 
   
  double var = StatLib.variance(s); 
     result = ( StatLib.mean(s) - StatLib.median(s) ) / Math.sqrt(var);
       return result;
  }


    public static double fit(List s,double x)
  {   double result = 0;
    if (s.size() <= 0) { return result; } 
   
  double var = StatLib.variance(s); 
     result = Math.abs(( x - StatLib.mean(s) )) / Math.sqrt(var);
       return result;
  }


    public static void moments(List s)
  {   //  if (s.size() <= 0)) { return; } 
    System.out.println("" + StatLib.variance(s));

      System.out.println("" + StatLib.skewness(s));

  }

    public static double pi()
  {   double result = 0;
 
  result = 3.14159265;
    return result;
  }



}


class NormalDist
  implements SystemTypes
{

  public NormalDist()
  {

  }



  public String toString()
  { String _res_ = "(NormalDist) ";
    return _res_;
  }

  public static NormalDist parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    NormalDist normaldistx = new NormalDist();
    return normaldistx;
  }


  public void writeCSV(PrintWriter _out)
  { NormalDist normaldistx = this;
    _out.println();
  }


    public static double normal(double m,double sigma,double x)
  {   double result = 0;
 
  double disp = x - m; 
     double denom = Math.exp(( -0.5 * disp * disp / ( sigma * sigma ) )); 
     double num = sigma * Math.sqrt(( 2 * StatLib.pi() )); 
     result = denom / num;
             return result;
  }


    public static double cumulative(double m,double sigma,double x)
  {   double result = 0;
    if (x < m) { return result; } 
   
  double k = ( 1 / ( 1 + 0.2316419 * ( x - m ) ) ); 
     double poly = ( 0.31938153 * k ) + ( -0.356563782 * k * k ) + ( 1.781477937 * k * k * k ) + ( -1.821255978 * k * k * k * k ) + ( 1.330274429 * k * k * k * k * k ); 
     result = 1 - NormalDist.normal(m,sigma,x) * poly;
          return result;
  }


    public static double cdf(double x)
  {   double result = 0;
 
  if (x >= 0) 
  {   result = NormalDist.cumulative(0,1,x);
 
  }  else
      if (x < 0) 
  {   result = 1 - NormalDist.cumulative(0,1,-x);
 
  }       return result;
  }



}


class Stattest
  implements SystemTypes
{

  public Stattest()
  {

  }



  public String toString()
  { String _res_ = "(Stattest) ";
    return _res_;
  }

  public static Stattest parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Stattest stattestx = new Stattest();
    return stattestx;
  }


  public void writeCSV(PrintWriter _out)
  { Stattest stattestx = this;
    _out.println();
  }


  


}


class WelchTTest
  implements SystemTypes
{
  private List s1 = new Vector(); // internal
  private List s2 = new Vector(); // internal

  public WelchTTest()
  {
    this.s1 = (new SystemTypes.Set()).getElements();
    this.s2 = (new SystemTypes.Set()).getElements();

  }



  public String toString()
  { String _res_ = "(WelchTTest) ";
    _res_ = _res_ + s1 + ",";
    _res_ = _res_ + s2;
    return _res_;
  }

  public static WelchTTest parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    WelchTTest welchttestx = new WelchTTest();
    return welchttestx;
  }


  public void writeCSV(PrintWriter _out)
  { WelchTTest welchttestx = this;
    _out.print("" + welchttestx.s1);
    _out.print(" , ");
    _out.print("" + welchttestx.s2);
    _out.println();
  }


  public void sets1(List s1_x) { s1 = s1_x;  }


    public void adds1(double s1_x)
  { s1.add(new Double(s1_x)); }

  public void removes1(double s1_x)
  { s1.remove(new Double(s1_x)); }



  

  public void sets2(List s2_x) { s2 = s2_x;  }


    public void adds2(double s2_x)
  { s2.add(new Double(s2_x)); }

  public void removes2(double s2_x)
  { s2.remove(new Double(s2_x)); }



  

    public List gets1() { return s1; }

  

  

    public List gets2() { return s2; }

  

  

    public double tstatistic()
  {   double result = 0;
 
  int n1 = s1.size(); 
     int n2 = s2.size(); 
     double sigma1 = StatLib.uvariance(s1); 
     double sigma2 = StatLib.uvariance(s2); 
     double var = Math.sqrt(( ( sigma1 / n1 ) + ( sigma2 / n2 ) )); 
     double m1 = StatLib.mean(s1); 
     double m2 = StatLib.mean(s2); 
     result = ( m1 - m2 ) / var;
                         return result;
  }


    public double doff()
  {   double result = 0;
 
  int n1 = s1.size(); 
     int n2 = s2.size(); 
     double sigma1 = StatLib.uvariance(s1); 
     double sigma2 = StatLib.uvariance(s2); 
     double var = ( ( sigma1 / n1 ) + ( sigma2 / n2 ) ); 
     double m1 = ( ((( sigma1 / n1 ))*(( sigma1 / n1 ))) / ( n1 - 1 ) ); 
     double m2 = ( ((( sigma2 / n2 ))*(( sigma2 / n2 ))) / ( n2 - 1 ) ); 
     result = ( ((var)*(var)) / ( m1 + m2 ) );
                         return result;
  }



}


class CliffsDelta
  implements SystemTypes
{
  private List d = new Vector(); // internal
  private List di = new Vector(); // internal
  private List dj = new Vector(); // internal
  private double delta = 0; // internal
  private double variance = 0; // internal
  private double z90 = 0; // internal
  private double z95 = 0; // internal
  private double z99 = 0; // internal

  public CliffsDelta()
  {
    this.d = (new SystemTypes.Set()).getElements();
    this.di = (new SystemTypes.Set()).getElements();
    this.dj = (new SystemTypes.Set()).getElements();
    this.delta = 0;
    this.variance = 0;
    this.z90 = 0;
    this.z95 = 0;
    this.z99 = 0;

  }



  public String toString()
  { String _res_ = "(CliffsDelta) ";
    _res_ = _res_ + d + ",";
    _res_ = _res_ + di + ",";
    _res_ = _res_ + dj + ",";
    _res_ = _res_ + delta + ",";
    _res_ = _res_ + variance + ",";
    _res_ = _res_ + z90 + ",";
    _res_ = _res_ + z95 + ",";
    _res_ = _res_ + z99;
    return _res_;
  }

  public static CliffsDelta parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    CliffsDelta cliffsdeltax = new CliffsDelta();
    cliffsdeltax.delta = Double.parseDouble((String) _line1vals.get(3));
    cliffsdeltax.variance = Double.parseDouble((String) _line1vals.get(4));
    cliffsdeltax.z90 = Double.parseDouble((String) _line1vals.get(5));
    cliffsdeltax.z95 = Double.parseDouble((String) _line1vals.get(6));
    cliffsdeltax.z99 = Double.parseDouble((String) _line1vals.get(7));
    return cliffsdeltax;
  }


  public void writeCSV(PrintWriter _out)
  { CliffsDelta cliffsdeltax = this;
    _out.print("" + cliffsdeltax.d);
    _out.print(" , ");
    _out.print("" + cliffsdeltax.di);
    _out.print(" , ");
    _out.print("" + cliffsdeltax.dj);
    _out.print(" , ");
    _out.print("" + cliffsdeltax.delta);
    _out.print(" , ");
    _out.print("" + cliffsdeltax.variance);
    _out.print(" , ");
    _out.print("" + cliffsdeltax.z90);
    _out.print(" , ");
    _out.print("" + cliffsdeltax.z95);
    _out.print(" , ");
    _out.print("" + cliffsdeltax.z99);
    _out.println();
  }


  public void setd(List d_x) { d = d_x;  }


    public void addd(List d_x)
  { d.add(d_x); }

  public void removed(List d_x)
  { d.remove(d_x); }



  

  public void setdi(List di_x) { di = di_x;  }


    public void adddi(double di_x)
  { di.add(new Double(di_x)); }

  public void removedi(double di_x)
  { di.remove(new Double(di_x)); }



  

  public void setdj(List dj_x) { dj = dj_x;  }


    public void adddj(double dj_x)
  { dj.add(new Double(dj_x)); }

  public void removedj(double dj_x)
  { dj.remove(new Double(dj_x)); }



  

  public void setdelta(double delta_x) { delta = delta_x;  }


    public static void setAlldelta(List cliffsdeltas,double val)
  { for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      Controller.inst().setdelta(cliffsdeltax,val); } }


  public void setvariance(double variance_x) { variance = variance_x;  }


    public static void setAllvariance(List cliffsdeltas,double val)
  { for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      Controller.inst().setvariance(cliffsdeltax,val); } }


  public void setz90(double z90_x) { z90 = z90_x;  }


    public static void setAllz90(List cliffsdeltas,double val)
  { for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      Controller.inst().setz90(cliffsdeltax,val); } }


  public void setz95(double z95_x) { z95 = z95_x;  }


    public static void setAllz95(List cliffsdeltas,double val)
  { for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      Controller.inst().setz95(cliffsdeltax,val); } }


  public void setz99(double z99_x) { z99 = z99_x;  }


    public static void setAllz99(List cliffsdeltas,double val)
  { for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      Controller.inst().setz99(cliffsdeltax,val); } }


    public List getd() { return d; }

  

  

    public List getdi() { return di; }

  

  

    public List getdj() { return dj; }

  

  

    public double getdelta() { return delta; }

    public static List getAlldelta(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      if (result.contains(new Double(cliffsdeltax.getdelta()))) { }
      else { result.add(new Double(cliffsdeltax.getdelta())); } }
    return result; }

    public static List getAllOrdereddelta(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      result.add(new Double(cliffsdeltax.getdelta())); } 
    return result; }

    public double getvariance() { return variance; }

    public static List getAllvariance(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      if (result.contains(new Double(cliffsdeltax.getvariance()))) { }
      else { result.add(new Double(cliffsdeltax.getvariance())); } }
    return result; }

    public static List getAllOrderedvariance(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      result.add(new Double(cliffsdeltax.getvariance())); } 
    return result; }

    public double getz90() { return z90; }

    public static List getAllz90(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      if (result.contains(new Double(cliffsdeltax.getz90()))) { }
      else { result.add(new Double(cliffsdeltax.getz90())); } }
    return result; }

    public static List getAllOrderedz90(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      result.add(new Double(cliffsdeltax.getz90())); } 
    return result; }

    public double getz95() { return z95; }

    public static List getAllz95(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      if (result.contains(new Double(cliffsdeltax.getz95()))) { }
      else { result.add(new Double(cliffsdeltax.getz95())); } }
    return result; }

    public static List getAllOrderedz95(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      result.add(new Double(cliffsdeltax.getz95())); } 
    return result; }

    public double getz99() { return z99; }

    public static List getAllz99(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      if (result.contains(new Double(cliffsdeltax.getz99()))) { }
      else { result.add(new Double(cliffsdeltax.getz99())); } }
    return result; }

    public static List getAllOrderedz99(List cliffsdeltas)
  { List result = new Vector();
    for (int i = 0; i < cliffsdeltas.size(); i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(i);
      result.add(new Double(cliffsdeltax.getz99())); } 
    return result; }

    public static double diff(double x,double y)
  {   double result = 0;
 
  if (x < y) 
  {   result = -1.0;
 
  }  else
      {   if (x > y) 
  {   result = 1.0;
 
  }  else
      if (x == y) 
  {   result = 0.0;
 
  }   
   }     return result;
  }


    public static List dominanceMatrix(List x,List y)
  {   List result = new Vector();
    if (x.size() <= 0 || y.size() <= 0) { return result; } 
   
  int n = x.size(); 
     int m = y.size(); 
     List nseq = Set.integerSubrange(1,n); 
     List mseq = Set.integerSubrange(1,m); 
     result = Set.collect_9(nseq,x,y,mseq);
                return result;
  }


    public double computeDelta(int n,int m)
  {   double result = 0;
    if (n <= 0 || m <= 0) { return result; } 
   
  List nseq = Set.integerSubrange(1,n); 
     List mseq = Set.integerSubrange(1,m); 
     di = Set.collect_10(nseq,this);
   dj = Set.collect_12(mseq,this);
   delta = StatLib.mean(di);
   result = delta;
                   return result;
  }


    public double computeVariance(int n,int m)
  {   double result = 0;
    if (n <= 0 || m <= 0) { return result; } 
   
  double diffi = StatLib.sumsqdiff(di,delta) / ( n - 1 ); 
     double diffj = StatLib.sumsqdiff(dj,delta) / ( m - 1 ); 
     double diffij = Set.sumdouble(Set.collect_14(d,this)) / ( ( n - 1 ) * ( m - 1 ) ); 
     variance = ( ( m - 1 ) * diffi + ( n - 1 ) * diffj + diffij ) / ( n * m );
   result = variance;
                return result;
  }


    public double computeZ()
  {   double result = 0;
    if (variance <= 0) { return result; } 
   
  result = delta / Math.sqrt(variance);
    return result;
  }


    public List compute99limits()
  {   List result = new Vector();
    if (variance <= 0) { return result; } 
   
  double ci99factor = ( z99 * Math.sqrt(variance) ) * Math.sqrt(( ((( 1 - delta * delta ))*(( 1 - delta * delta ))) + z99 * z99 * variance )); 
     double den = 1 - delta * delta + z99 * z99 * variance; 
     double ci99u = ( delta - Math.pow(delta,3) + ci99factor ) / den; 
     double ci99l = ( delta - Math.pow(delta,3) - ci99factor ) / den; 
     result = (new SystemTypes.Set()).add(new Double(ci99l)).add(new Double(ci99u)).getElements();
                return result;
  }


    public List compute95limits()
  {   List result = new Vector();
 
  double ci95factor = ( z95 * Math.sqrt(variance) ) * Math.sqrt(( ((( 1 - delta * delta ))*(( 1 - delta * delta ))) + z95 * z95 * variance )); 
     double den = 1 - delta * delta + z95 * z95 * variance; 
     double ci95u = ( delta - Math.pow(delta,3) + ci95factor ) / den; 
     double ci95l = ( delta - Math.pow(delta,3) - ci95factor ) / den; 
     result = (new SystemTypes.Set()).add(new Double(ci95l)).add(new Double(ci95u)).getElements();
                return result;
  }


    public List compute90limits()
  {   List result = new Vector();
 
  double ci90factor = ( z90 * Math.sqrt(variance) ) * Math.sqrt(( ((( 1 - delta * delta ))*(( 1 - delta * delta ))) + z90 * z90 * variance )); 
     double den = 1 - delta * delta + z90 * z90 * variance; 
     double ci90u = ( delta - Math.pow(delta,3) + ci90factor ) / den; 
     double ci90l = ( delta - Math.pow(delta,3) - ci90factor ) / den; 
     result = (new SystemTypes.Set()).add(new Double(ci90l)).add(new Double(ci90u)).getElements();
                return result;
  }


    public void deltatest2()
  { Controller.inst().setd(this,CliffsDelta.dominanceMatrix((new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements(),(new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements()));
  }

    public void deltatest3()
  {   System.out.println("" + ( "Delta = " + this.computeDelta(25,25) ));

  }

    public void deltatest4()
  {   System.out.println("" + ( "di = " + this.getdi() ));

      System.out.println("" + ( "dj = " + this.getdj() ));

  }

    public void deltatest5()
  {   System.out.println("" + ( "Variance = " + this.computeVariance(25,25) ));

  }

    public void deltatest6()
  {   System.out.println("" + ( "Z = " + this.computeZ() ));

  }

    public void deltatest7()
  {   System.out.println("" + ( "99% confidence limits: " + this.compute99limits() ));

  }

    public void deltatest8()
  {   System.out.println("" + ( "95% confidence limits: " + this.compute95limits() ));

  }

    public void deltatest9()
  {   System.out.println("" + ( "90% confidence limits: " + this.compute90limits() ));

  }


}


class Deltatest
  implements SystemTypes
{

  public Deltatest()
  {

  }



  public String toString()
  { String _res_ = "(Deltatest) ";
    return _res_;
  }

  public static Deltatest parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Deltatest deltatestx = new Deltatest();
    return deltatestx;
  }


  public void writeCSV(PrintWriter _out)
  { Deltatest deltatestx = this;
    _out.println();
  }


  


}


class AndersonDarling
  implements SystemTypes
{

  public AndersonDarling()
  {

  }



  public String toString()
  { String _res_ = "(AndersonDarling) ";
    return _res_;
  }

  public static AndersonDarling parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    AndersonDarling andersondarlingx = new AndersonDarling();
    return andersondarlingx;
  }


  public void writeCSV(PrintWriter _out)
  { AndersonDarling andersondarlingx = this;
    _out.println();
  }


    public static double adNormalTerm(int i,List y)
  {   double result = 0;
 
  int n = y.size(); 
     result = ( 2 * i - 1 ) * ( Math.log(NormalDist.cdf(((Double) y.get(i - 1)).doubleValue())) + Math.log(( 1 - NormalDist.cdf(((Double) y.get(( n + 1 - i ) - 1)).doubleValue()) )) );
       return result;
  }


    public static double andersonDarlingNormal(List x)
  {   double result = 0;
    if (x.size() <= 0) { return result; } 
   
  int n = x.size(); 
     double mu = StatLib.mean(x); 
     double variance = StatLib.variance(x); 
     double sigma = Math.sqrt(variance); 
     List y = Set.collect_15(x,mu,sigma); 
     result = -n - ( 1.0 / n ) * Set.sumdouble(Set.collect_16(Set.integerSubrange(1,n),y));
                   return result;
  }


    public void normtest2()
  {   System.out.println("" + ( "Anderson-Darling for ATL: " + AndersonDarling.andersonDarlingNormal((new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements()) ));

  }

    public void normtest3()
  {   System.out.println("" + ( "Anderson-Darling for ETL: " + AndersonDarling.andersonDarlingNormal((new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements()) ));

  }

    public void normtest4()
  {   System.out.println("" + ( "Anderson-Darling for QVT-R: " + AndersonDarling.andersonDarlingNormal((new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements()) ));

  }

    public void normtest5()
  {   System.out.println("" + ( "Anderson-Darling for UML-RSDS: " + AndersonDarling.andersonDarlingNormal((new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0050)).add(new Double(0.0080)).add(new Double(0.0090)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.028)).add(new Double(0.032)).add(new Double(0.033)).add(new Double(0.036)).add(new Double(0.038)).add(new Double(0.041)).add(new Double(0.052)).add(new Double(0.083)).getElements()) ));

  }


}


class Normtest
  implements SystemTypes
{

  public Normtest()
  {

  }



  public String toString()
  { String _res_ = "(Normtest) ";
    return _res_;
  }

  public static Normtest parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Normtest normtestx = new Normtest();
    return normtestx;
  }


  public void writeCSV(PrintWriter _out)
  { Normtest normtestx = this;
    _out.println();
  }


  


}


class KolmogorovSmirnov
  implements SystemTypes
{

  public KolmogorovSmirnov()
  {

  }



  public String toString()
  { String _res_ = "(KolmogorovSmirnov) ";
    return _res_;
  }

  public static KolmogorovSmirnov parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    KolmogorovSmirnov kolmogorovsmirnovx = new KolmogorovSmirnov();
    return kolmogorovsmirnovx;
  }


  public void writeCSV(PrintWriter _out)
  { KolmogorovSmirnov kolmogorovsmirnovx = this;
    _out.println();
  }


    public static double kstest2(Distribution d1,Distribution d2)
  {   double result = 0;
 
  result = ((Double) Set.max(Set.concatenate(Set.collect_17(d1.getpoints(),d1,d2), Set.collect_18(d2.getpoints(),d2,d1)))).doubleValue();
    return result;
  }


    public static double kstest1(Distribution d1,Distribution d2)
  {   double result = 0;
 
  double ks = KolmogorovSmirnov.kstest2(d1,d2); 
     int n = d1.getpoints().size(); 
     int m = d2.getpoints().size(); 
     double factor = Math.sqrt(( ( 1.0 * ( n + m ) ) / ( n * m ) )); 
     double c = ks / factor; 
     result = Math.exp(( -2.0 * c * c ));
                   return result;
  }



}


class Kstest
  implements SystemTypes
{

  public Kstest()
  {

  }



  public String toString()
  { String _res_ = "(Kstest) ";
    return _res_;
  }

  public static Kstest parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Kstest kstestx = new Kstest();
    return kstestx;
  }


  public void writeCSV(PrintWriter _out)
  { Kstest kstestx = this;
    _out.println();
  }


  


}


class Wtest
  implements SystemTypes
{

  public Wtest()
  {

  }



  public String toString()
  { String _res_ = "(Wtest) ";
    return _res_;
  }

  public static Wtest parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Wtest wtestx = new Wtest();
    return wtestx;
  }


  public void writeCSV(PrintWriter _out)
  { Wtest wtestx = this;
    _out.println();
  }


  


}


class Normdist
  implements SystemTypes
{

  public Normdist()
  {

  }



  public String toString()
  { String _res_ = "(Normdist) ";
    return _res_;
  }

  public static Normdist parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    Normdist normdistx = new Normdist();
    return normdistx;
  }


  public void writeCSV(PrintWriter _out)
  { Normdist normdistx = this;
    _out.println();
  }


  


}



public class Controller implements SystemTypes, ControllerInterface
{
  Vector distributions = new Vector();
  Map distributionlabelindex = new HashMap(); // String --> Distribution

  Vector statlibs = new Vector();
  Vector normaldists = new Vector();
  Vector stattests = new Vector();
  Vector welchttests = new Vector();
  Vector cliffsdeltas = new Vector();
  Vector deltatests = new Vector();
  Vector andersondarlings = new Vector();
  Vector normtests = new Vector();
  Vector kolmogorovsmirnovs = new Vector();
  Vector kstests = new Vector();
  Vector wtests = new Vector();
  Vector normdists = new Vector();
  private static Controller uniqueInstance; 


  private Controller() { } 


  public static Controller inst() 
    { if (uniqueInstance == null) 
    { uniqueInstance = new Controller(); }
    return uniqueInstance; } 


  public static void loadModel(String file)
  {
    try
    { BufferedReader br = null;
      File f = new File(file);
      try 
      { br = new BufferedReader(new FileReader(f)); }
      catch (Exception ex) 
      { System.err.println("No file: " + file); return; }
      Class cont = Class.forName("Controller");
      java.util.Map objectmap = new java.util.HashMap();
      while (true)
      { String line1;
        try { line1 = br.readLine(); }
        catch (Exception e)
        { return; }
        if (line1 == null)
        { return; }
        line1 = line1.trim();

        if (line1.length() == 0) { continue; }
        if (line1.startsWith("//")) { continue; }
        String left;
        String op;
        String right;
        if (line1.charAt(line1.length() - 1) == '"')
        { int eqind = line1.indexOf("="); 
          if (eqind == -1) { continue; }
          else 
          { left = line1.substring(0,eqind-1).trim();
            op = "="; 
            right = line1.substring(eqind+1,line1.length()).trim();
          }
        }
        else
        { StringTokenizer st1 = new StringTokenizer(line1);
          Vector vals1 = new Vector();
          while (st1.hasMoreTokens())
          { String val1 = st1.nextToken();
            vals1.add(val1);
          }
          if (vals1.size() < 3)
          { continue; }
          left = (String) vals1.get(0);
          op = (String) vals1.get(1);
          right = (String) vals1.get(2);
        }
        if (":".equals(op))
        { int i2 = right.indexOf(".");
          if (i2 == -1)
          { Class cl;
            try { cl = Class.forName("" + right); }
            catch (Exception _x) { System.err.println("No entity: " + right); continue; }
            Object xinst = cl.newInstance();
            objectmap.put(left,xinst);
            Class[] cargs = new Class[] { cl };
            Method addC = null;
            try { addC = cont.getMethod("add" + right,cargs); }
            catch (Exception _xx) { System.err.println("No entity: " + right); continue; }
            if (addC == null) { continue; }
            Object[] args = new Object[] { xinst };
            addC.invoke(Controller.inst(),args);
          }
          else
          { String obj = right.substring(0,i2);
            String role = right.substring(i2+1,right.length());
            Object objinst = objectmap.get(obj); 
            if (objinst == null) 
            { continue; }
            Object val = objectmap.get(left);
            if (val == null) 
            { continue; }
            Class objC = objinst.getClass();
            Class typeclass = val.getClass(); 
            Object[] args = new Object[] { val }; 
            Class[] settypes = new Class[] { typeclass };
            Method addrole = Controller.findMethod(objC,"add" + role);
            if (addrole != null) 
            { addrole.invoke(objinst, args); }
            else { System.err.println("Error: cannot add to " + role); }
          }
        }
        else if ("=".equals(op))
        { int i1 = left.indexOf(".");
          if (i1 == -1) 
          { continue; }
          String obj = left.substring(0,i1);
          String att = left.substring(i1+1,left.length());
          Object objinst = objectmap.get(obj); 
          if (objinst == null) 
          { System.err.println("No object: " + obj); continue; }
          Class objC = objinst.getClass();
          Class typeclass; 
          Object val; 
          if (right.charAt(0) == '"' &&
              right.charAt(right.length() - 1) == '"')
          { typeclass = String.class;
            val = right.substring(1,right.length() - 1);
          } 
          else if ("true".equals(right) || "false".equals(right))
          { typeclass = boolean.class;
            if ("true".equals(right))
            { val = new Boolean(true); }
            else
            { val = new Boolean(false); }
          }
          else 
          { val = objectmap.get(right);
            if (val != null)
            { typeclass = val.getClass(); }
            else 
            { int i;
              long l; 
              double d;
              try 
              { i = Integer.parseInt(right);
                typeclass = int.class;
                val = new Integer(i); 
              }
              catch (Exception ee)
              { try 
                { l = Long.parseLong(right);
                  typeclass = long.class;
                  val = new Long(l); 
                }
                catch (Exception eee)
                { try
                  { d = Double.parseDouble(right);
                    typeclass = double.class;
                    val = new Double(d);
                  }
                  catch (Exception ff)
                  { continue; }
                }
              }
            }
          }
          Object[] args = new Object[] { val }; 
          Class[] settypes = new Class[] { typeclass };
          Method setatt = Controller.findMethod(objC,"set" + att);
          if (setatt != null) 
          { setatt.invoke(objinst, args); }
          else { System.err.println("No attribute: " + objC.getName() + "::" + att); }
        }
      }
    } catch (Exception e) { }
  }

  public static Method findMethod(Class c, String name)
  { Method[] mets = c.getMethods(); 
    for (int i = 0; i < mets.length; i++)
    { Method m = mets[i];
      if (m.getName().equals(name))
      { return m; }
    } 
    return null;
  }


  public static void loadCSVModel()
  { boolean __eof = false;
    String __s = "";
    Controller __cont = Controller.inst();
    BufferedReader __br = null;
    try
    { File _distribution = new File("Distribution.csv");
      __br = new BufferedReader(new FileReader(_distribution));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Distribution distributionx = Distribution.parseCSV(__s.trim());
          if (distributionx != null)
          { __cont.addDistribution(distributionx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _statlib = new File("StatLib.csv");
      __br = new BufferedReader(new FileReader(_statlib));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { StatLib statlibx = StatLib.parseCSV(__s.trim());
          if (statlibx != null)
          { __cont.addStatLib(statlibx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _normaldist = new File("NormalDist.csv");
      __br = new BufferedReader(new FileReader(_normaldist));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { NormalDist normaldistx = NormalDist.parseCSV(__s.trim());
          if (normaldistx != null)
          { __cont.addNormalDist(normaldistx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _stattest = new File("Stattest.csv");
      __br = new BufferedReader(new FileReader(_stattest));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Stattest stattestx = Stattest.parseCSV(__s.trim());
          if (stattestx != null)
          { __cont.addStattest(stattestx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _welchttest = new File("WelchTTest.csv");
      __br = new BufferedReader(new FileReader(_welchttest));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { WelchTTest welchttestx = WelchTTest.parseCSV(__s.trim());
          if (welchttestx != null)
          { __cont.addWelchTTest(welchttestx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _cliffsdelta = new File("CliffsDelta.csv");
      __br = new BufferedReader(new FileReader(_cliffsdelta));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { CliffsDelta cliffsdeltax = CliffsDelta.parseCSV(__s.trim());
          if (cliffsdeltax != null)
          { __cont.addCliffsDelta(cliffsdeltax); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _deltatest = new File("Deltatest.csv");
      __br = new BufferedReader(new FileReader(_deltatest));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Deltatest deltatestx = Deltatest.parseCSV(__s.trim());
          if (deltatestx != null)
          { __cont.addDeltatest(deltatestx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _andersondarling = new File("AndersonDarling.csv");
      __br = new BufferedReader(new FileReader(_andersondarling));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { AndersonDarling andersondarlingx = AndersonDarling.parseCSV(__s.trim());
          if (andersondarlingx != null)
          { __cont.addAndersonDarling(andersondarlingx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _normtest = new File("Normtest.csv");
      __br = new BufferedReader(new FileReader(_normtest));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Normtest normtestx = Normtest.parseCSV(__s.trim());
          if (normtestx != null)
          { __cont.addNormtest(normtestx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _kolmogorovsmirnov = new File("KolmogorovSmirnov.csv");
      __br = new BufferedReader(new FileReader(_kolmogorovsmirnov));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { KolmogorovSmirnov kolmogorovsmirnovx = KolmogorovSmirnov.parseCSV(__s.trim());
          if (kolmogorovsmirnovx != null)
          { __cont.addKolmogorovSmirnov(kolmogorovsmirnovx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _kstest = new File("Kstest.csv");
      __br = new BufferedReader(new FileReader(_kstest));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Kstest kstestx = Kstest.parseCSV(__s.trim());
          if (kstestx != null)
          { __cont.addKstest(kstestx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _wtest = new File("Wtest.csv");
      __br = new BufferedReader(new FileReader(_wtest));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Wtest wtestx = Wtest.parseCSV(__s.trim());
          if (wtestx != null)
          { __cont.addWtest(wtestx); }
        }
      }
    }
    catch(Exception __e) { }
    try
    { File _normdist = new File("Normdist.csv");
      __br = new BufferedReader(new FileReader(_normdist));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { Normdist normdistx = Normdist.parseCSV(__s.trim());
          if (normdistx != null)
          { __cont.addNormdist(normdistx); }
        }
      }
    }
    catch(Exception __e) { }
  }


  public void checkCompleteness()
  {   for (int _i = 0; _i < distributions.size(); _i++)
  { Distribution distribution_x = (Distribution) distributions.get(_i);
    Distribution distribution_obj = (Distribution) distributionlabelindex.get(distribution_x.getlabel());
    if (distribution_obj == distribution_x) { }
    else if (distribution_obj == null)
    { distributionlabelindex.put(distribution_x.getlabel(),distribution_x); }
    else
    { System.out.println("Error: multiple objects with label = " + distribution_x.getlabel()); }
  }
  }


  public void saveModel(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
  for (int _i = 0; _i < distributions.size(); _i++)
  { Distribution distributionx_ = (Distribution) distributions.get(_i);
    out.println("distributionx_" + _i + " : Distribution");
    out.println("distributionx_" + _i + ".label = \"" + distributionx_.getlabel() + "\"");
    List distribution_points = distributionx_.getpoints();
    for (int _j = 0; _j < distribution_points.size(); _j++)
    { out.println(distribution_points.get(_j) + " : distributionx_" + _i + ".points");
    }
    out.println("distributionx_" + _i + ".datasize = " + distributionx_.getdatasize());
  }

  for (int _i = 0; _i < statlibs.size(); _i++)
  { StatLib statlibx_ = (StatLib) statlibs.get(_i);
    out.println("statlibx_" + _i + " : StatLib");
  }

  for (int _i = 0; _i < normaldists.size(); _i++)
  { NormalDist normaldistx_ = (NormalDist) normaldists.get(_i);
    out.println("normaldistx_" + _i + " : NormalDist");
  }

  for (int _i = 0; _i < stattests.size(); _i++)
  { Stattest stattestx_ = (Stattest) stattests.get(_i);
    out.println("stattestx_" + _i + " : Stattest");
  }

  for (int _i = 0; _i < welchttests.size(); _i++)
  { WelchTTest welchttestx_ = (WelchTTest) welchttests.get(_i);
    out.println("welchttestx_" + _i + " : WelchTTest");
    List welchttest_s1 = welchttestx_.gets1();
    for (int _j = 0; _j < welchttest_s1.size(); _j++)
    { out.println(welchttest_s1.get(_j) + " : welchttestx_" + _i + ".s1");
    }
    List welchttest_s2 = welchttestx_.gets2();
    for (int _j = 0; _j < welchttest_s2.size(); _j++)
    { out.println(welchttest_s2.get(_j) + " : welchttestx_" + _i + ".s2");
    }
  }

  for (int _i = 0; _i < cliffsdeltas.size(); _i++)
  { CliffsDelta cliffsdeltax_ = (CliffsDelta) cliffsdeltas.get(_i);
    out.println("cliffsdeltax_" + _i + " : CliffsDelta");
    List cliffsdelta_d = cliffsdeltax_.getd();
    for (int _j = 0; _j < cliffsdelta_d.size(); _j++)
    { out.println(cliffsdelta_d.get(_j) + " : cliffsdeltax_" + _i + ".d");
    }
    List cliffsdelta_di = cliffsdeltax_.getdi();
    for (int _j = 0; _j < cliffsdelta_di.size(); _j++)
    { out.println(cliffsdelta_di.get(_j) + " : cliffsdeltax_" + _i + ".di");
    }
    List cliffsdelta_dj = cliffsdeltax_.getdj();
    for (int _j = 0; _j < cliffsdelta_dj.size(); _j++)
    { out.println(cliffsdelta_dj.get(_j) + " : cliffsdeltax_" + _i + ".dj");
    }
    out.println("cliffsdeltax_" + _i + ".delta = " + cliffsdeltax_.getdelta());
    out.println("cliffsdeltax_" + _i + ".variance = " + cliffsdeltax_.getvariance());
    out.println("cliffsdeltax_" + _i + ".z90 = " + cliffsdeltax_.getz90());
    out.println("cliffsdeltax_" + _i + ".z95 = " + cliffsdeltax_.getz95());
    out.println("cliffsdeltax_" + _i + ".z99 = " + cliffsdeltax_.getz99());
  }

  for (int _i = 0; _i < deltatests.size(); _i++)
  { Deltatest deltatestx_ = (Deltatest) deltatests.get(_i);
    out.println("deltatestx_" + _i + " : Deltatest");
  }

  for (int _i = 0; _i < andersondarlings.size(); _i++)
  { AndersonDarling andersondarlingx_ = (AndersonDarling) andersondarlings.get(_i);
    out.println("andersondarlingx_" + _i + " : AndersonDarling");
  }

  for (int _i = 0; _i < normtests.size(); _i++)
  { Normtest normtestx_ = (Normtest) normtests.get(_i);
    out.println("normtestx_" + _i + " : Normtest");
  }

  for (int _i = 0; _i < kolmogorovsmirnovs.size(); _i++)
  { KolmogorovSmirnov kolmogorovsmirnovx_ = (KolmogorovSmirnov) kolmogorovsmirnovs.get(_i);
    out.println("kolmogorovsmirnovx_" + _i + " : KolmogorovSmirnov");
  }

  for (int _i = 0; _i < kstests.size(); _i++)
  { Kstest kstestx_ = (Kstest) kstests.get(_i);
    out.println("kstestx_" + _i + " : Kstest");
  }

  for (int _i = 0; _i < wtests.size(); _i++)
  { Wtest wtestx_ = (Wtest) wtests.get(_i);
    out.println("wtestx_" + _i + " : Wtest");
  }

  for (int _i = 0; _i < normdists.size(); _i++)
  { Normdist normdistx_ = (Normdist) normdists.get(_i);
    out.println("normdistx_" + _i + " : Normdist");
  }

    out.close(); 
  }


  public static void loadXSI()
  { boolean __eof = false;
    String __s = "";
    String xmlstring = "";
    BufferedReader __br = null;
    try
    { File _classmodel = new File("in.xmi");
      __br = new BufferedReader(new FileReader(_classmodel));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { xmlstring = xmlstring + __s; }
      } 
      __br.close();
    } 
    catch (Exception _x) { }
    Vector res = convertXsiToVector(xmlstring);
    File outfile = new File("_in.txt");
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    for (int i = 0; i < res.size(); i++)
    { String r = (String) res.get(i); 
      out.println(r);
    } 
    out.close();
    loadModel("_in.txt");
  }

  public static Vector convertXsiToVector(String xmlstring)
  { Vector res = new Vector();
    XMLParser comp = new XMLParser();
    comp.nospacelexicalanalysisxml(xmlstring);
    XMLNode xml = comp.parseXML();
    if (xml == null) { return res; } 
    java.util.Map instancemap = new java.util.HashMap(); // String --> Vector
    java.util.Map entmap = new java.util.HashMap();       // String --> String
    Vector entcodes = new Vector(); 
    java.util.Map allattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map stringattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map onerolesmap = new java.util.HashMap(); // String --> Vector
    java.util.Map actualtype = new java.util.HashMap(); // XMLNode --> String
    Vector eallatts = new Vector();
    instancemap.put("distributions", new Vector()); 
    instancemap.put("distribution",new Vector()); 
    entcodes.add("distributions");
    entcodes.add("distribution");
    entmap.put("distributions","Distribution");
    entmap.put("distribution","Distribution");
    eallatts = new Vector();
    eallatts.add("label");
    eallatts.add("points");
    eallatts.add("datasize");
    allattsmap.put("Distribution", eallatts);
    eallatts = new Vector();
    eallatts.add("label");
    stringattsmap.put("Distribution", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Distribution", eallatts);
    instancemap.put("statlibs", new Vector()); 
    instancemap.put("statlib",new Vector()); 
    entcodes.add("statlibs");
    entcodes.add("statlib");
    entmap.put("statlibs","StatLib");
    entmap.put("statlib","StatLib");
    eallatts = new Vector();
    allattsmap.put("StatLib", eallatts);
    eallatts = new Vector();
    stringattsmap.put("StatLib", eallatts);
    eallatts = new Vector();
    onerolesmap.put("StatLib", eallatts);
    instancemap.put("normaldists", new Vector()); 
    instancemap.put("normaldist",new Vector()); 
    entcodes.add("normaldists");
    entcodes.add("normaldist");
    entmap.put("normaldists","NormalDist");
    entmap.put("normaldist","NormalDist");
    eallatts = new Vector();
    allattsmap.put("NormalDist", eallatts);
    eallatts = new Vector();
    stringattsmap.put("NormalDist", eallatts);
    eallatts = new Vector();
    onerolesmap.put("NormalDist", eallatts);
    instancemap.put("stattests", new Vector()); 
    instancemap.put("stattest",new Vector()); 
    entcodes.add("stattests");
    entcodes.add("stattest");
    entmap.put("stattests","Stattest");
    entmap.put("stattest","Stattest");
    eallatts = new Vector();
    allattsmap.put("Stattest", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Stattest", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Stattest", eallatts);
    instancemap.put("welchttests", new Vector()); 
    instancemap.put("welchttest",new Vector()); 
    entcodes.add("welchttests");
    entcodes.add("welchttest");
    entmap.put("welchttests","WelchTTest");
    entmap.put("welchttest","WelchTTest");
    eallatts = new Vector();
    eallatts.add("s1");
    eallatts.add("s2");
    allattsmap.put("WelchTTest", eallatts);
    eallatts = new Vector();
    stringattsmap.put("WelchTTest", eallatts);
    eallatts = new Vector();
    onerolesmap.put("WelchTTest", eallatts);
    instancemap.put("cliffsdeltas", new Vector()); 
    instancemap.put("cliffsdelta",new Vector()); 
    entcodes.add("cliffsdeltas");
    entcodes.add("cliffsdelta");
    entmap.put("cliffsdeltas","CliffsDelta");
    entmap.put("cliffsdelta","CliffsDelta");
    eallatts = new Vector();
    eallatts.add("d");
    eallatts.add("di");
    eallatts.add("dj");
    eallatts.add("delta");
    eallatts.add("variance");
    eallatts.add("z90");
    eallatts.add("z95");
    eallatts.add("z99");
    allattsmap.put("CliffsDelta", eallatts);
    eallatts = new Vector();
    stringattsmap.put("CliffsDelta", eallatts);
    eallatts = new Vector();
    onerolesmap.put("CliffsDelta", eallatts);
    instancemap.put("deltatests", new Vector()); 
    instancemap.put("deltatest",new Vector()); 
    entcodes.add("deltatests");
    entcodes.add("deltatest");
    entmap.put("deltatests","Deltatest");
    entmap.put("deltatest","Deltatest");
    eallatts = new Vector();
    allattsmap.put("Deltatest", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Deltatest", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Deltatest", eallatts);
    instancemap.put("andersondarlings", new Vector()); 
    instancemap.put("andersondarling",new Vector()); 
    entcodes.add("andersondarlings");
    entcodes.add("andersondarling");
    entmap.put("andersondarlings","AndersonDarling");
    entmap.put("andersondarling","AndersonDarling");
    eallatts = new Vector();
    allattsmap.put("AndersonDarling", eallatts);
    eallatts = new Vector();
    stringattsmap.put("AndersonDarling", eallatts);
    eallatts = new Vector();
    onerolesmap.put("AndersonDarling", eallatts);
    instancemap.put("normtests", new Vector()); 
    instancemap.put("normtest",new Vector()); 
    entcodes.add("normtests");
    entcodes.add("normtest");
    entmap.put("normtests","Normtest");
    entmap.put("normtest","Normtest");
    eallatts = new Vector();
    allattsmap.put("Normtest", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Normtest", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Normtest", eallatts);
    instancemap.put("kolmogorovsmirnovs", new Vector()); 
    instancemap.put("kolmogorovsmirnov",new Vector()); 
    entcodes.add("kolmogorovsmirnovs");
    entcodes.add("kolmogorovsmirnov");
    entmap.put("kolmogorovsmirnovs","KolmogorovSmirnov");
    entmap.put("kolmogorovsmirnov","KolmogorovSmirnov");
    eallatts = new Vector();
    allattsmap.put("KolmogorovSmirnov", eallatts);
    eallatts = new Vector();
    stringattsmap.put("KolmogorovSmirnov", eallatts);
    eallatts = new Vector();
    onerolesmap.put("KolmogorovSmirnov", eallatts);
    instancemap.put("kstests", new Vector()); 
    instancemap.put("kstest",new Vector()); 
    entcodes.add("kstests");
    entcodes.add("kstest");
    entmap.put("kstests","Kstest");
    entmap.put("kstest","Kstest");
    eallatts = new Vector();
    allattsmap.put("Kstest", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Kstest", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Kstest", eallatts);
    instancemap.put("wtests", new Vector()); 
    instancemap.put("wtest",new Vector()); 
    entcodes.add("wtests");
    entcodes.add("wtest");
    entmap.put("wtests","Wtest");
    entmap.put("wtest","Wtest");
    eallatts = new Vector();
    allattsmap.put("Wtest", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Wtest", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Wtest", eallatts);
    instancemap.put("normdists", new Vector()); 
    instancemap.put("normdist",new Vector()); 
    entcodes.add("normdists");
    entcodes.add("normdist");
    entmap.put("normdists","Normdist");
    entmap.put("normdist","Normdist");
    eallatts = new Vector();
    allattsmap.put("Normdist", eallatts);
    eallatts = new Vector();
    stringattsmap.put("Normdist", eallatts);
    eallatts = new Vector();
    onerolesmap.put("Normdist", eallatts);
    eallatts = new Vector();
  Vector enodes = xml.getSubnodes();
  for (int i = 0; i < enodes.size(); i++)
  { XMLNode enode = (XMLNode) enodes.get(i);
    String cname = enode.getTag();
    Vector einstances = (Vector) instancemap.get(cname); 
    if (einstances == null) 
    { einstances = (Vector) instancemap.get(cname + "s"); }
    if (einstances != null) 
    { einstances.add(enode); }
  }
  for (int j = 0; j < entcodes.size(); j++)
  { String ename = (String) entcodes.get(j);
    Vector elems = (Vector) instancemap.get(ename);
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = enode.getAttributeValue("xsi:type"); 
      if (tname == null) 
      { tname = (String) entmap.get(ename); } 
      else 
      { int colonind = tname.indexOf(":"); 
        if (colonind >= 0)
        { tname = tname.substring(colonind + 1,tname.length()); }
      }
      res.add(ename + k + " : " + tname);
      actualtype.put(enode,tname);
    }   
  }
  for (int j = 0; j < entcodes.size(); j++) 
  { String ename = (String) entcodes.get(j); 
    Vector elems = (Vector) instancemap.get(ename); 
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = (String) actualtype.get(enode);
      Vector tallatts = (Vector)  allattsmap.get(tname);
      Vector tstringatts = (Vector)  stringattsmap.get(tname);
      Vector toneroles = (Vector)  onerolesmap.get(tname);
      Vector atts = enode.getAttributes();
      for (int p = 0; p < atts.size(); p++) 
      { XMLAttribute patt = (XMLAttribute) atts.get(p); 
        if (patt.getName().equals("xsi:type") || patt.getName().equals("xmi:id")) {} 
        else 
        { patt.getDataDeclarationFromXsi(res,tallatts,tstringatts,toneroles,ename + k, (String) entmap.get(ename)); } 
      }
    } 
  }  
  return res; } 

  public void saveXSI(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    out.println("<UMLRSDS:model xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\">");
    for (int _i = 0; _i < distributions.size(); _i++)
    { Distribution distributionx_ = (Distribution) distributions.get(_i);
       out.print("<distributions xsi:type=\"My:Distribution\"");
    out.print(" label=\"" + distributionx_.getlabel() + "\" ");
    out.print(" datasize=\"" + distributionx_.getdatasize() + "\" ");
    out.println(" />");
  }

    for (int _i = 0; _i < statlibs.size(); _i++)
    { StatLib statlibx_ = (StatLib) statlibs.get(_i);
       out.print("<statlibs xsi:type=\"My:StatLib\"");
    out.println(" />");
  }

    for (int _i = 0; _i < normaldists.size(); _i++)
    { NormalDist normaldistx_ = (NormalDist) normaldists.get(_i);
       out.print("<normaldists xsi:type=\"My:NormalDist\"");
    out.println(" />");
  }

    for (int _i = 0; _i < stattests.size(); _i++)
    { Stattest stattestx_ = (Stattest) stattests.get(_i);
       out.print("<stattests xsi:type=\"My:Stattest\"");
    out.println(" />");
  }

    for (int _i = 0; _i < welchttests.size(); _i++)
    { WelchTTest welchttestx_ = (WelchTTest) welchttests.get(_i);
       out.print("<welchttests xsi:type=\"My:WelchTTest\"");
    out.println(" />");
  }

    for (int _i = 0; _i < cliffsdeltas.size(); _i++)
    { CliffsDelta cliffsdeltax_ = (CliffsDelta) cliffsdeltas.get(_i);
       out.print("<cliffsdeltas xsi:type=\"My:CliffsDelta\"");
    out.print(" delta=\"" + cliffsdeltax_.getdelta() + "\" ");
    out.print(" variance=\"" + cliffsdeltax_.getvariance() + "\" ");
    out.print(" z90=\"" + cliffsdeltax_.getz90() + "\" ");
    out.print(" z95=\"" + cliffsdeltax_.getz95() + "\" ");
    out.print(" z99=\"" + cliffsdeltax_.getz99() + "\" ");
    out.println(" />");
  }

    for (int _i = 0; _i < deltatests.size(); _i++)
    { Deltatest deltatestx_ = (Deltatest) deltatests.get(_i);
       out.print("<deltatests xsi:type=\"My:Deltatest\"");
    out.println(" />");
  }

    for (int _i = 0; _i < andersondarlings.size(); _i++)
    { AndersonDarling andersondarlingx_ = (AndersonDarling) andersondarlings.get(_i);
       out.print("<andersondarlings xsi:type=\"My:AndersonDarling\"");
    out.println(" />");
  }

    for (int _i = 0; _i < normtests.size(); _i++)
    { Normtest normtestx_ = (Normtest) normtests.get(_i);
       out.print("<normtests xsi:type=\"My:Normtest\"");
    out.println(" />");
  }

    for (int _i = 0; _i < kolmogorovsmirnovs.size(); _i++)
    { KolmogorovSmirnov kolmogorovsmirnovx_ = (KolmogorovSmirnov) kolmogorovsmirnovs.get(_i);
       out.print("<kolmogorovsmirnovs xsi:type=\"My:KolmogorovSmirnov\"");
    out.println(" />");
  }

    for (int _i = 0; _i < kstests.size(); _i++)
    { Kstest kstestx_ = (Kstest) kstests.get(_i);
       out.print("<kstests xsi:type=\"My:Kstest\"");
    out.println(" />");
  }

    for (int _i = 0; _i < wtests.size(); _i++)
    { Wtest wtestx_ = (Wtest) wtests.get(_i);
       out.print("<wtests xsi:type=\"My:Wtest\"");
    out.println(" />");
  }

    for (int _i = 0; _i < normdists.size(); _i++)
    { Normdist normdistx_ = (Normdist) normdists.get(_i);
       out.print("<normdists xsi:type=\"My:Normdist\"");
    out.println(" />");
  }

    out.println("</UMLRSDS:model>");
    out.close(); 
  }


  public void saveCSVModel()
  { try {
      File _distribution = new File("Distribution.csv");
      PrintWriter _out_distribution = new PrintWriter(new BufferedWriter(new FileWriter(_distribution)));
      for (int __i = 0; __i < distributions.size(); __i++)
      { Distribution distributionx = (Distribution) distributions.get(__i);
        distributionx.writeCSV(_out_distribution);
      }
      _out_distribution.close();
      File _statlib = new File("StatLib.csv");
      PrintWriter _out_statlib = new PrintWriter(new BufferedWriter(new FileWriter(_statlib)));
      for (int __i = 0; __i < statlibs.size(); __i++)
      { StatLib statlibx = (StatLib) statlibs.get(__i);
        statlibx.writeCSV(_out_statlib);
      }
      _out_statlib.close();
      File _normaldist = new File("NormalDist.csv");
      PrintWriter _out_normaldist = new PrintWriter(new BufferedWriter(new FileWriter(_normaldist)));
      for (int __i = 0; __i < normaldists.size(); __i++)
      { NormalDist normaldistx = (NormalDist) normaldists.get(__i);
        normaldistx.writeCSV(_out_normaldist);
      }
      _out_normaldist.close();
      File _stattest = new File("Stattest.csv");
      PrintWriter _out_stattest = new PrintWriter(new BufferedWriter(new FileWriter(_stattest)));
      for (int __i = 0; __i < stattests.size(); __i++)
      { Stattest stattestx = (Stattest) stattests.get(__i);
        stattestx.writeCSV(_out_stattest);
      }
      _out_stattest.close();
      File _welchttest = new File("WelchTTest.csv");
      PrintWriter _out_welchttest = new PrintWriter(new BufferedWriter(new FileWriter(_welchttest)));
      for (int __i = 0; __i < welchttests.size(); __i++)
      { WelchTTest welchttestx = (WelchTTest) welchttests.get(__i);
        welchttestx.writeCSV(_out_welchttest);
      }
      _out_welchttest.close();
      File _cliffsdelta = new File("CliffsDelta.csv");
      PrintWriter _out_cliffsdelta = new PrintWriter(new BufferedWriter(new FileWriter(_cliffsdelta)));
      for (int __i = 0; __i < cliffsdeltas.size(); __i++)
      { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltas.get(__i);
        cliffsdeltax.writeCSV(_out_cliffsdelta);
      }
      _out_cliffsdelta.close();
      File _deltatest = new File("Deltatest.csv");
      PrintWriter _out_deltatest = new PrintWriter(new BufferedWriter(new FileWriter(_deltatest)));
      for (int __i = 0; __i < deltatests.size(); __i++)
      { Deltatest deltatestx = (Deltatest) deltatests.get(__i);
        deltatestx.writeCSV(_out_deltatest);
      }
      _out_deltatest.close();
      File _andersondarling = new File("AndersonDarling.csv");
      PrintWriter _out_andersondarling = new PrintWriter(new BufferedWriter(new FileWriter(_andersondarling)));
      for (int __i = 0; __i < andersondarlings.size(); __i++)
      { AndersonDarling andersondarlingx = (AndersonDarling) andersondarlings.get(__i);
        andersondarlingx.writeCSV(_out_andersondarling);
      }
      _out_andersondarling.close();
      File _normtest = new File("Normtest.csv");
      PrintWriter _out_normtest = new PrintWriter(new BufferedWriter(new FileWriter(_normtest)));
      for (int __i = 0; __i < normtests.size(); __i++)
      { Normtest normtestx = (Normtest) normtests.get(__i);
        normtestx.writeCSV(_out_normtest);
      }
      _out_normtest.close();
      File _kolmogorovsmirnov = new File("KolmogorovSmirnov.csv");
      PrintWriter _out_kolmogorovsmirnov = new PrintWriter(new BufferedWriter(new FileWriter(_kolmogorovsmirnov)));
      for (int __i = 0; __i < kolmogorovsmirnovs.size(); __i++)
      { KolmogorovSmirnov kolmogorovsmirnovx = (KolmogorovSmirnov) kolmogorovsmirnovs.get(__i);
        kolmogorovsmirnovx.writeCSV(_out_kolmogorovsmirnov);
      }
      _out_kolmogorovsmirnov.close();
      File _kstest = new File("Kstest.csv");
      PrintWriter _out_kstest = new PrintWriter(new BufferedWriter(new FileWriter(_kstest)));
      for (int __i = 0; __i < kstests.size(); __i++)
      { Kstest kstestx = (Kstest) kstests.get(__i);
        kstestx.writeCSV(_out_kstest);
      }
      _out_kstest.close();
      File _wtest = new File("Wtest.csv");
      PrintWriter _out_wtest = new PrintWriter(new BufferedWriter(new FileWriter(_wtest)));
      for (int __i = 0; __i < wtests.size(); __i++)
      { Wtest wtestx = (Wtest) wtests.get(__i);
        wtestx.writeCSV(_out_wtest);
      }
      _out_wtest.close();
      File _normdist = new File("Normdist.csv");
      PrintWriter _out_normdist = new PrintWriter(new BufferedWriter(new FileWriter(_normdist)));
      for (int __i = 0; __i < normdists.size(); __i++)
      { Normdist normdistx = (Normdist) normdists.get(__i);
        normdistx.writeCSV(_out_normdist);
      }
      _out_normdist.close();
    }
    catch(Exception __e) { }
  }



  public void addDistribution(Distribution oo) { distributions.add(oo); }

  public Distribution getDistributionByPK(String labelx)
  {  return (Distribution) distributionlabelindex.get(labelx); }

  public List getDistributionByPK(List labelx)
  { Vector res = new Vector(); 
    for (int _i = 0; _i < labelx.size(); _i++)
    { Distribution distributionx = getDistributionByPK((String) labelx.get(_i));
      if (distributionx != null) { res.add(distributionx); }
    }
    return res; 
  }

  public void addStatLib(StatLib oo) { statlibs.add(oo); }

  public void addNormalDist(NormalDist oo) { normaldists.add(oo); }

  public void addStattest(Stattest oo) { stattests.add(oo); }

  public void addWelchTTest(WelchTTest oo) { welchttests.add(oo); }

  public void addCliffsDelta(CliffsDelta oo) { cliffsdeltas.add(oo); }

  public void addDeltatest(Deltatest oo) { deltatests.add(oo); }

  public void addAndersonDarling(AndersonDarling oo) { andersondarlings.add(oo); }

  public void addNormtest(Normtest oo) { normtests.add(oo); }

  public void addKolmogorovSmirnov(KolmogorovSmirnov oo) { kolmogorovsmirnovs.add(oo); }

  public void addKstest(Kstest oo) { kstests.add(oo); }

  public void addWtest(Wtest oo) { wtests.add(oo); }

  public void addNormdist(Normdist oo) { normdists.add(oo); }



  public Distribution createDistribution()
  { Distribution distributionx = new Distribution();
    addDistribution(distributionx);
    return distributionx;
  }

  public StatLib createStatLib()
  { StatLib statlibx = new StatLib();
    addStatLib(statlibx);
    return statlibx;
  }

  public NormalDist createNormalDist()
  { NormalDist normaldistx = new NormalDist();
    addNormalDist(normaldistx);
    return normaldistx;
  }

  public Stattest createStattest()
  { Stattest stattestx = new Stattest();
    addStattest(stattestx);
    return stattestx;
  }

  public WelchTTest createWelchTTest()
  { WelchTTest welchttestx = new WelchTTest();
    addWelchTTest(welchttestx);
    return welchttestx;
  }

  public CliffsDelta createCliffsDelta()
  { CliffsDelta cliffsdeltax = new CliffsDelta();
    addCliffsDelta(cliffsdeltax);
    return cliffsdeltax;
  }

  public Deltatest createDeltatest()
  { Deltatest deltatestx = new Deltatest();
    addDeltatest(deltatestx);
    return deltatestx;
  }

  public AndersonDarling createAndersonDarling()
  { AndersonDarling andersondarlingx = new AndersonDarling();
    addAndersonDarling(andersondarlingx);
    return andersondarlingx;
  }

  public Normtest createNormtest()
  { Normtest normtestx = new Normtest();
    addNormtest(normtestx);
    return normtestx;
  }

  public KolmogorovSmirnov createKolmogorovSmirnov()
  { KolmogorovSmirnov kolmogorovsmirnovx = new KolmogorovSmirnov();
    addKolmogorovSmirnov(kolmogorovsmirnovx);
    return kolmogorovsmirnovx;
  }

  public Kstest createKstest()
  { Kstest kstestx = new Kstest();
    addKstest(kstestx);
    return kstestx;
  }

  public Wtest createWtest()
  { Wtest wtestx = new Wtest();
    addWtest(wtestx);
    return wtestx;
  }

  public Normdist createNormdist()
  { Normdist normdistx = new Normdist();
    addNormdist(normdistx);
    return normdistx;
  }


public void setlabel(Distribution distributionx, String label_x) 
  { if (distributionlabelindex.get(label_x) != null) { return; }
  distributionlabelindex.remove(distributionx.getlabel());
  distributionx.setlabel(label_x);
  distributionlabelindex.put(label_x,distributionx);
    }


public void setpoints(Distribution distributionx, List points_x) 
  { distributionx.setpoints(points_x);
    }


  public void addpoints(Distribution distributionx, double points_x)
  { distributionx.addpoints(points_x); }


  public void removepoints(Distribution distributionx, double points_x)
  { distributionx.removepoints(points_x); }


public void setdatasize(Distribution distributionx, int datasize_x) 
  { distributionx.setdatasize(datasize_x);
    }


public void sets1(WelchTTest welchttestx, List s1_x) 
  { welchttestx.sets1(s1_x);
    }


  public void adds1(WelchTTest welchttestx, double s1_x)
  { welchttestx.adds1(s1_x); }


  public void removes1(WelchTTest welchttestx, double s1_x)
  { welchttestx.removes1(s1_x); }


public void sets2(WelchTTest welchttestx, List s2_x) 
  { welchttestx.sets2(s2_x);
    }


  public void adds2(WelchTTest welchttestx, double s2_x)
  { welchttestx.adds2(s2_x); }


  public void removes2(WelchTTest welchttestx, double s2_x)
  { welchttestx.removes2(s2_x); }


public void setd(CliffsDelta cliffsdeltax, List d_x) 
  { cliffsdeltax.setd(d_x);
    }


  public void addd(CliffsDelta cliffsdeltax, List d_x)
  { cliffsdeltax.addd(d_x); }


  public void removed(CliffsDelta cliffsdeltax, List d_x)
  { cliffsdeltax.removed(d_x); }


public void setdi(CliffsDelta cliffsdeltax, List di_x) 
  { cliffsdeltax.setdi(di_x);
    }


  public void adddi(CliffsDelta cliffsdeltax, double di_x)
  { cliffsdeltax.adddi(di_x); }


  public void removedi(CliffsDelta cliffsdeltax, double di_x)
  { cliffsdeltax.removedi(di_x); }


public void setdj(CliffsDelta cliffsdeltax, List dj_x) 
  { cliffsdeltax.setdj(dj_x);
    }


  public void adddj(CliffsDelta cliffsdeltax, double dj_x)
  { cliffsdeltax.adddj(dj_x); }


  public void removedj(CliffsDelta cliffsdeltax, double dj_x)
  { cliffsdeltax.removedj(dj_x); }


public void setdelta(CliffsDelta cliffsdeltax, double delta_x) 
  { cliffsdeltax.setdelta(delta_x);
    }


public void setvariance(CliffsDelta cliffsdeltax, double variance_x) 
  { cliffsdeltax.setvariance(variance_x);
    }


public void setz90(CliffsDelta cliffsdeltax, double z90_x) 
  { cliffsdeltax.setz90(z90_x);
    }


public void setz95(CliffsDelta cliffsdeltax, double z95_x) 
  { cliffsdeltax.setz95(z95_x);
    }


public void setz99(CliffsDelta cliffsdeltax, double z99_x) 
  { cliffsdeltax.setz99(z99_x);
    }



  public  List AllDistributionpdf(List distributionxs,double x)
  { 
    List result = new Vector();
    for (int _i = 0; _i < distributionxs.size(); _i++)
    { Distribution distributionx = (Distribution) distributionxs.get(_i);
      result.add(new Double(distributionx.pdf(x)));
    }
    return result; 
  }

  public  List AllDistributioncdf(List distributionxs,double x)
  { 
    List result = new Vector();
    for (int _i = 0; _i < distributionxs.size(); _i++)
    { Distribution distributionx = (Distribution) distributionxs.get(_i);
      result.add(new Double(distributionx.cdf(x)));
    }
    return result; 
  }

  public static void moments(List s)
  { StatLib.moments(s); }

  public  List AllWelchTTesttstatistic(List welchttestxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < welchttestxs.size(); _i++)
    { WelchTTest welchttestx = (WelchTTest) welchttestxs.get(_i);
      result.add(new Double(welchttestx.tstatistic()));
    }
    return result; 
  }

  public  List AllWelchTTestdoff(List welchttestxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < welchttestxs.size(); _i++)
    { WelchTTest welchttestx = (WelchTTest) welchttestxs.get(_i);
      result.add(new Double(welchttestx.doff()));
    }
    return result; 
  }

  public  List AllCliffsDeltacomputeDelta(List cliffsdeltaxs,int n,int m)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cliffsdeltaxs.size(); _i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltaxs.get(_i);
      result.add(new Double(cliffsdeltax.computeDelta(n, m)));
    }
    return result; 
  }

  public  List AllCliffsDeltacomputeVariance(List cliffsdeltaxs,int n,int m)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cliffsdeltaxs.size(); _i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltaxs.get(_i);
      result.add(new Double(cliffsdeltax.computeVariance(n, m)));
    }
    return result; 
  }

  public  List AllCliffsDeltacomputeZ(List cliffsdeltaxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cliffsdeltaxs.size(); _i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltaxs.get(_i);
      result.add(new Double(cliffsdeltax.computeZ()));
    }
    return result; 
  }

  public  List AllCliffsDeltacompute99limits(List cliffsdeltaxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cliffsdeltaxs.size(); _i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltaxs.get(_i);
      result.addAll(cliffsdeltax.compute99limits());
    }
    return result; 
  }

  public  List AllCliffsDeltacompute95limits(List cliffsdeltaxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cliffsdeltaxs.size(); _i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltaxs.get(_i);
      result.addAll(cliffsdeltax.compute95limits());
    }
    return result; 
  }

  public  List AllCliffsDeltacompute90limits(List cliffsdeltaxs)
  { 
    List result = new Vector();
    for (int _i = 0; _i < cliffsdeltaxs.size(); _i++)
    { CliffsDelta cliffsdeltax = (CliffsDelta) cliffsdeltaxs.get(_i);
      result.addAll(cliffsdeltax.compute90limits());
    }
    return result; 
  }

  public void deltatest2(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest2();
   }

  public void deltatest3(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest3();
   }

  public void deltatest4(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest4();
   }

  public void deltatest5(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest5();
   }

  public void deltatest6(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest6();
   }

  public void deltatest7(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest7();
   }

  public void deltatest8(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest8();
   }

  public void deltatest9(CliffsDelta cliffsdeltax)
  {   cliffsdeltax.deltatest9();
   }

  public void normtest2(AndersonDarling andersondarlingx)
  {   andersondarlingx.normtest2();
   }

  public void normtest3(AndersonDarling andersondarlingx)
  {   andersondarlingx.normtest3();
   }

  public void normtest4(AndersonDarling andersondarlingx)
  {   andersondarlingx.normtest4();
   }

  public void normtest5(AndersonDarling andersondarlingx)
  {   andersondarlingx.normtest5();
   }



  public void killAllDistribution(List distributionxx)
  { for (int _i = 0; _i < distributionxx.size(); _i++)
    { killDistribution((Distribution) distributionxx.get(_i)); }
  }

  public void killDistribution(Distribution distributionxx)
  { if (distributionxx == null) { return; }
   distributions.remove(distributionxx);
    distributionlabelindex.remove(distributionxx.getlabel());
  }



  public void killAllStatLib(List statlibxx)
  { for (int _i = 0; _i < statlibxx.size(); _i++)
    { killStatLib((StatLib) statlibxx.get(_i)); }
  }

  public void killStatLib(StatLib statlibxx)
  { if (statlibxx == null) { return; }
   statlibs.remove(statlibxx);
  }



  public void killAllNormalDist(List normaldistxx)
  { for (int _i = 0; _i < normaldistxx.size(); _i++)
    { killNormalDist((NormalDist) normaldistxx.get(_i)); }
  }

  public void killNormalDist(NormalDist normaldistxx)
  { if (normaldistxx == null) { return; }
   normaldists.remove(normaldistxx);
  }



  public void killAllStattest(List stattestxx)
  { for (int _i = 0; _i < stattestxx.size(); _i++)
    { killStattest((Stattest) stattestxx.get(_i)); }
  }

  public void killStattest(Stattest stattestxx)
  { if (stattestxx == null) { return; }
   stattests.remove(stattestxx);
  }



  public void killAllWelchTTest(List welchttestxx)
  { for (int _i = 0; _i < welchttestxx.size(); _i++)
    { killWelchTTest((WelchTTest) welchttestxx.get(_i)); }
  }

  public void killWelchTTest(WelchTTest welchttestxx)
  { if (welchttestxx == null) { return; }
   welchttests.remove(welchttestxx);
  }



  public void killAllCliffsDelta(List cliffsdeltaxx)
  { for (int _i = 0; _i < cliffsdeltaxx.size(); _i++)
    { killCliffsDelta((CliffsDelta) cliffsdeltaxx.get(_i)); }
  }

  public void killCliffsDelta(CliffsDelta cliffsdeltaxx)
  { if (cliffsdeltaxx == null) { return; }
   cliffsdeltas.remove(cliffsdeltaxx);
  }



  public void killAllDeltatest(List deltatestxx)
  { for (int _i = 0; _i < deltatestxx.size(); _i++)
    { killDeltatest((Deltatest) deltatestxx.get(_i)); }
  }

  public void killDeltatest(Deltatest deltatestxx)
  { if (deltatestxx == null) { return; }
   deltatests.remove(deltatestxx);
  }



  public void killAllAndersonDarling(List andersondarlingxx)
  { for (int _i = 0; _i < andersondarlingxx.size(); _i++)
    { killAndersonDarling((AndersonDarling) andersondarlingxx.get(_i)); }
  }

  public void killAndersonDarling(AndersonDarling andersondarlingxx)
  { if (andersondarlingxx == null) { return; }
   andersondarlings.remove(andersondarlingxx);
  }



  public void killAllNormtest(List normtestxx)
  { for (int _i = 0; _i < normtestxx.size(); _i++)
    { killNormtest((Normtest) normtestxx.get(_i)); }
  }

  public void killNormtest(Normtest normtestxx)
  { if (normtestxx == null) { return; }
   normtests.remove(normtestxx);
  }



  public void killAllKolmogorovSmirnov(List kolmogorovsmirnovxx)
  { for (int _i = 0; _i < kolmogorovsmirnovxx.size(); _i++)
    { killKolmogorovSmirnov((KolmogorovSmirnov) kolmogorovsmirnovxx.get(_i)); }
  }

  public void killKolmogorovSmirnov(KolmogorovSmirnov kolmogorovsmirnovxx)
  { if (kolmogorovsmirnovxx == null) { return; }
   kolmogorovsmirnovs.remove(kolmogorovsmirnovxx);
  }



  public void killAllKstest(List kstestxx)
  { for (int _i = 0; _i < kstestxx.size(); _i++)
    { killKstest((Kstest) kstestxx.get(_i)); }
  }

  public void killKstest(Kstest kstestxx)
  { if (kstestxx == null) { return; }
   kstests.remove(kstestxx);
  }



  public void killAllWtest(List wtestxx)
  { for (int _i = 0; _i < wtestxx.size(); _i++)
    { killWtest((Wtest) wtestxx.get(_i)); }
  }

  public void killWtest(Wtest wtestxx)
  { if (wtestxx == null) { return; }
   wtests.remove(wtestxx);
  }



  public void killAllNormdist(List normdistxx)
  { for (int _i = 0; _i < normdistxx.size(); _i++)
    { killNormdist((Normdist) normdistxx.get(_i)); }
  }

  public void killNormdist(Normdist normdistxx)
  { if (normdistxx == null) { return; }
   normdists.remove(normdistxx);
  }




  
  
  public void stattest() 
  { 

     StatLib.moments((new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements());
     StatLib.moments((new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements());
     StatLib.moments((new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements());

  }



  
  public void deltatest() 
  { 

     CliffsDelta cd = new CliffsDelta();
    Controller.inst().addCliffsDelta(cd);
    Controller.inst().setz90(cd,1.645);
    Controller.inst().setz95(cd,1.96);
    Controller.inst().setz99(cd,2.576);
    List _range13 = new Vector();
  _range13.addAll(Controller.inst().cliffsdeltas);
  for (int _i12 = 0; _i12 < _range13.size(); _i12++)
  { CliffsDelta loopvar_0 = (CliffsDelta) _range13.get(_i12);
       Controller.inst().deltatest2(loopvar_0);
  }
    List _range15 = new Vector();
  _range15.addAll(Controller.inst().cliffsdeltas);
  for (int _i14 = 0; _i14 < _range15.size(); _i14++)
  { CliffsDelta loopvar_1 = (CliffsDelta) _range15.get(_i14);
       Controller.inst().deltatest3(loopvar_1);
  }
    List _range17 = new Vector();
  _range17.addAll(Controller.inst().cliffsdeltas);
  for (int _i16 = 0; _i16 < _range17.size(); _i16++)
  { CliffsDelta loopvar_2 = (CliffsDelta) _range17.get(_i16);
       Controller.inst().deltatest4(loopvar_2);
  }
    List _range19 = new Vector();
  _range19.addAll(Controller.inst().cliffsdeltas);
  for (int _i18 = 0; _i18 < _range19.size(); _i18++)
  { CliffsDelta loopvar_3 = (CliffsDelta) _range19.get(_i18);
       Controller.inst().deltatest5(loopvar_3);
  }
    List _range21 = new Vector();
  _range21.addAll(Controller.inst().cliffsdeltas);
  for (int _i20 = 0; _i20 < _range21.size(); _i20++)
  { CliffsDelta loopvar_4 = (CliffsDelta) _range21.get(_i20);
       Controller.inst().deltatest6(loopvar_4);
  }
    List _range23 = new Vector();
  _range23.addAll(Controller.inst().cliffsdeltas);
  for (int _i22 = 0; _i22 < _range23.size(); _i22++)
  { CliffsDelta loopvar_5 = (CliffsDelta) _range23.get(_i22);
       Controller.inst().deltatest7(loopvar_5);
  }
    List _range25 = new Vector();
  _range25.addAll(Controller.inst().cliffsdeltas);
  for (int _i24 = 0; _i24 < _range25.size(); _i24++)
  { CliffsDelta loopvar_6 = (CliffsDelta) _range25.get(_i24);
       Controller.inst().deltatest8(loopvar_6);
  }
    List _range27 = new Vector();
  _range27.addAll(Controller.inst().cliffsdeltas);
  for (int _i26 = 0; _i26 < _range27.size(); _i26++)
  { CliffsDelta loopvar_7 = (CliffsDelta) _range27.get(_i26);
       Controller.inst().deltatest9(loopvar_7);
  }

  }



  
  public void normtest() 
  { 

     AndersonDarling ad = new AndersonDarling();
    Controller.inst().addAndersonDarling(ad);
    {} /* No update form for: true */
    List _range29 = new Vector();
  _range29.addAll(Controller.inst().andersondarlings);
  for (int _i28 = 0; _i28 < _range29.size(); _i28++)
  { AndersonDarling loopvar_8 = (AndersonDarling) _range29.get(_i28);
       Controller.inst().normtest2(loopvar_8);
  }
    List _range31 = new Vector();
  _range31.addAll(Controller.inst().andersondarlings);
  for (int _i30 = 0; _i30 < _range31.size(); _i30++)
  { AndersonDarling loopvar_9 = (AndersonDarling) _range31.get(_i30);
       Controller.inst().normtest3(loopvar_9);
  }
    List _range33 = new Vector();
  _range33.addAll(Controller.inst().andersondarlings);
  for (int _i32 = 0; _i32 < _range33.size(); _i32++)
  { AndersonDarling loopvar_10 = (AndersonDarling) _range33.get(_i32);
       Controller.inst().normtest4(loopvar_10);
  }
    List _range35 = new Vector();
  _range35.addAll(Controller.inst().andersondarlings);
  for (int _i34 = 0; _i34 < _range35.size(); _i34++)
  { AndersonDarling loopvar_11 = (AndersonDarling) _range35.get(_i34);
       Controller.inst().normtest5(loopvar_11);
  }

  }



  
  public void kstest() 
  { 

       System.out.println("" + "ATL and ETL:");

    Distribution d1 = new Distribution();
    Controller.inst().addDistribution(d1);
    Controller.inst().setpoints(d1,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements());
    Distribution d2 = new Distribution();
    Controller.inst().addDistribution(d2);
    Controller.inst().setpoints(d2,(new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements());
      System.out.println("" + KolmogorovSmirnov.kstest1(d1,d2));

       System.out.println("" + "QVT and UML-RSDS:");

    Distribution d3 = new Distribution();
    Controller.inst().addDistribution(d3);
    Controller.inst().setpoints(d3,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements());
    Distribution d4 = new Distribution();
    Controller.inst().addDistribution(d4);
    Controller.inst().setpoints(d4,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0050)).add(new Double(0.0080)).add(new Double(0.0090)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.028)).add(new Double(0.032)).add(new Double(0.033)).add(new Double(0.036)).add(new Double(0.038)).add(new Double(0.041)).add(new Double(0.052)).add(new Double(0.083)).getElements());
      System.out.println("" + KolmogorovSmirnov.kstest1(d3,d4));

       System.out.println("" + "ATL and QVT:");

    Distribution d5 = new Distribution();
    Controller.inst().addDistribution(d5);
    Controller.inst().setpoints(d5,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements());
    Distribution d6 = new Distribution();
    Controller.inst().addDistribution(d6);
    Controller.inst().setpoints(d6,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements());
      System.out.println("" + KolmogorovSmirnov.kstest1(d5,d6));

       System.out.println("" + "ATL and UMLRSDS:");

    Distribution d7 = new Distribution();
    Controller.inst().addDistribution(d7);
    Controller.inst().setpoints(d7,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements());
    Distribution d8 = new Distribution();
    Controller.inst().addDistribution(d8);
    Controller.inst().setpoints(d8,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0050)).add(new Double(0.0080)).add(new Double(0.0090)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.028)).add(new Double(0.032)).add(new Double(0.033)).add(new Double(0.036)).add(new Double(0.038)).add(new Double(0.041)).add(new Double(0.052)).add(new Double(0.083)).getElements());
      System.out.println("" + KolmogorovSmirnov.kstest1(d7,d8));

       System.out.println("" + "QVT and ETL:");

    Distribution d9 = new Distribution();
    Controller.inst().addDistribution(d9);
    Controller.inst().setpoints(d9,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements());
    Distribution d10 = new Distribution();
    Controller.inst().addDistribution(d10);
    Controller.inst().setpoints(d10,(new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements());
      System.out.println("" + KolmogorovSmirnov.kstest1(d9,d10));

       System.out.println("" + "UMLRSDS and ETL:");

    Distribution d11 = new Distribution();
    Controller.inst().addDistribution(d11);
    Controller.inst().setpoints(d11,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0050)).add(new Double(0.0080)).add(new Double(0.0090)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.028)).add(new Double(0.032)).add(new Double(0.033)).add(new Double(0.036)).add(new Double(0.038)).add(new Double(0.041)).add(new Double(0.052)).add(new Double(0.083)).getElements());
    Distribution d12 = new Distribution();
    Controller.inst().addDistribution(d12);
    Controller.inst().setpoints(d12,(new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements());
      System.out.println("" + KolmogorovSmirnov.kstest1(d11,d12));


  }



  
  public void wtest() 
  { 

       System.out.println("" + "ATL and ETL:");

    WelchTTest w1 = new WelchTTest();
    Controller.inst().addWelchTTest(w1);
    Controller.inst().sets1(w1,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements());
    Controller.inst().sets2(w1,(new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements());
      System.out.println("" + w1.tstatistic());

      System.out.println("" + w1.doff());

       System.out.println("" + "QVT and UML-RSDS:");

    WelchTTest w2 = new WelchTTest();
    Controller.inst().addWelchTTest(w2);
    Controller.inst().sets1(w2,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements());
    Controller.inst().sets2(w2,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0050)).add(new Double(0.0080)).add(new Double(0.0090)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.028)).add(new Double(0.032)).add(new Double(0.033)).add(new Double(0.036)).add(new Double(0.038)).add(new Double(0.041)).add(new Double(0.052)).add(new Double(0.083)).getElements());
      System.out.println("" + w2.tstatistic());

      System.out.println("" + w2.doff());

       System.out.println("" + "ATL and QVT:");

    WelchTTest w3 = new WelchTTest();
    Controller.inst().addWelchTTest(w3);
    Controller.inst().sets1(w3,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements());
    Controller.inst().sets2(w3,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements());
      System.out.println("" + w3.tstatistic());

      System.out.println("" + w3.doff());

       System.out.println("" + "ATL and UMLRSDS:");

    WelchTTest w4 = new WelchTTest();
    Controller.inst().addWelchTTest(w4);
    Controller.inst().sets1(w4,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0.0070)).add(new Double(0.012)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.013)).add(new Double(0.014)).add(new Double(0.018)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.019)).add(new Double(0.02)).add(new Double(0.02)).add(new Double(0.021)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.022)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.026)).add(new Double(0.031)).add(new Double(0.033)).add(new Double(0.038)).add(new Double(0.044)).getElements());
    Controller.inst().sets2(w4,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0050)).add(new Double(0.0080)).add(new Double(0.0090)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.028)).add(new Double(0.032)).add(new Double(0.033)).add(new Double(0.036)).add(new Double(0.038)).add(new Double(0.041)).add(new Double(0.052)).add(new Double(0.083)).getElements());
      System.out.println("" + w4.tstatistic());

      System.out.println("" + w4.doff());

       System.out.println("" + "QVT and ETL:");

    WelchTTest w5 = new WelchTTest();
    Controller.inst().addWelchTTest(w5);
    Controller.inst().sets1(w5,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0090)).add(new Double(0.012)).add(new Double(0.0145)).add(new Double(0.0235)).add(new Double(0.025)).add(new Double(0.027)).add(new Double(0.029)).add(new Double(0.031)).add(new Double(0.032)).add(new Double(0.036)).add(new Double(0.04)).add(new Double(0.042)).add(new Double(0.042)).getElements());
    Controller.inst().sets2(w5,(new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements());
      System.out.println("" + w5.tstatistic());

      System.out.println("" + w5.doff());

       System.out.println("" + "UMLRSDS and ETL:");

    WelchTTest w6 = new WelchTTest();
    Controller.inst().addWelchTTest(w6);
    Controller.inst().sets1(w6,(new SystemTypes.Set()).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0)).add(new Double(0.0050)).add(new Double(0.0080)).add(new Double(0.0090)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.014)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.024)).add(new Double(0.025)).add(new Double(0.028)).add(new Double(0.032)).add(new Double(0.033)).add(new Double(0.036)).add(new Double(0.038)).add(new Double(0.041)).add(new Double(0.052)).add(new Double(0.083)).getElements());
    Controller.inst().sets2(w6,(new SystemTypes.Set()).add(new Double(0.0060)).add(new Double(0.0060)).add(new Double(0.0070)).add(new Double(0.011)).add(new Double(0.0115)).add(new Double(0.012)).add(new Double(0.015)).add(new Double(0.015)).add(new Double(0.019)).add(new Double(0.021)).add(new Double(0.022)).add(new Double(0.023)).add(new Double(0.028)).add(new Double(0.029)).add(new Double(0.029)).add(new Double(0.038)).add(new Double(0.047)).add(new Double(0.053)).add(new Double(0.057)).add(new Double(0.059)).add(new Double(0.0625)).add(new Double(0.067)).add(new Double(0.083)).add(new Double(0.105)).add(new Double(0.173)).getElements());
      System.out.println("" + w6.tstatistic());

      System.out.println("" + w6.doff());


  }



  
  public void normdist() 
  { 

    List _range37 = new Vector();
  _range37.addAll(Set.integerSubrange(-40,40));
  for (int _i36 = 0; _i36 < _range37.size(); _i36++)
  { int i = ((Integer) _range37.get(_i36)).intValue();
         System.out.println("" + NormalDist.normal(0,1,i / 10.0));

  }

  }


 
}



