import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

public interface ControllerInterface
{
  public void addDistribution(Distribution oo);
    public void killDistribution(Distribution distributionxx);
  public void addStatLib(StatLib oo);
    public void killStatLib(StatLib statlibxx);
  public void addNormalDist(NormalDist oo);
    public void killNormalDist(NormalDist normaldistxx);
  public void addStattest(Stattest oo);
    public void killStattest(Stattest stattestxx);
  public void addWelchTTest(WelchTTest oo);
    public void killWelchTTest(WelchTTest welchttestxx);
  public void addCliffsDelta(CliffsDelta oo);
    public void killCliffsDelta(CliffsDelta cliffsdeltaxx);
  public void addDeltatest(Deltatest oo);
    public void killDeltatest(Deltatest deltatestxx);
  public void addAndersonDarling(AndersonDarling oo);
    public void killAndersonDarling(AndersonDarling andersondarlingxx);
  public void addNormtest(Normtest oo);
    public void killNormtest(Normtest normtestxx);
  public void addKolmogorovSmirnov(KolmogorovSmirnov oo);
    public void killKolmogorovSmirnov(KolmogorovSmirnov kolmogorovsmirnovxx);
  public void addKstest(Kstest oo);
    public void killKstest(Kstest kstestxx);
  public void addWtest(Wtest oo);
    public void killWtest(Wtest wtestxx);
  public void addNormdist(Normdist oo);
    public void killNormdist(Normdist normdistxx);
}

