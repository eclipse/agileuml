package OclProcess

// import "container/list"
// import "fmt"
import "../ocl"
import "os"
// import "math"

type OclProcess struct {
  name string 
  priority int 
  executes interface{}
 
  deadline int64 
  delay int64 
  period int64 
}

func createOclProcess() *OclProcess {
  var res *OclProcess
  res = &OclProcess{}
  return res
}

func NewOclProcess(obj interface{}, s string) *OclProcess {
  var result *OclProcess
  result = createOclProcess()
  result.executes = obj
  result.name = s
  return result
}

func GetEnvironmentProperty(vbl string) string {
  return os.Getenv(vbl)
} 

func GetEnvironmentProperties() map[string]string { 
  res := make(map[string]string)
  vars := os.Environ()
  for i := 0; i < len(vars); i++ {
      strs := ocl.Split(vars[i],"=")
      if strs.Len() > 1 { 
        res[ocl.First(strs).(string)] = ocl.Last(strs).(string)
      } 
  } 
  return res
}

func Exit(n int) { 
  os.Exit(n)
} 





