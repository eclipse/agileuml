package OclException

import "errors"
import "fmt"


type OclException struct {
  message string
}


func NewOclException(msg string) *OclException { 
  res := &OclException{}
  res.message = msg
  return res
} 

func (self *OclException) Error() string { 
  return self.message
} 


func (self *OclException) PrintStackTrace() { 
  fmt.Println(self.message)
}

func (self *OclException) GetMessage() string { 
  return self.message
}

func (self *OclException) GetCause() *OclException { 
  err := errors.Unwrap(self)
  return NewOclException(err.Error())
} 


type SystemException struct {
  message string
}


func NewSystemException(msg string) *SystemException { 
  res := &SystemException{}
  res.message = msg
  return res
} 

func (self *SystemException) Error() string { 
  return self.message
} 


func (self *SystemException) PrintStackTrace() { 
  fmt.Println(self.message)
}

func (self *SystemException) GetMessage() string { 
  return self.message
}

func (self *SystemException) GetCause() *OclException { 
  err := errors.Unwrap(self)
  return NewOclException(err.Error())
} 


type ArithmeticException struct {
  message string
}


func NewArithmeticException(msg string) *ArithmeticException { 
  res := &ArithmeticException{}
  res.message = msg
  return res
} 

func (self *ArithmeticException) Error() string { 
  return self.message
} 


func (self *ArithmeticException) PrintStackTrace() { 
  fmt.Println(self.message)
}

func (self *ArithmeticException) GetMessage() string { 
  return self.message
}

func (self *ArithmeticException) GetCause() *OclException { 
  err := errors.Unwrap(self)
  return NewOclException(err.Error())
} 


type IndexingException struct {
  message string
}


func NewIndexingException(msg string) *IndexingException { 
  res := &IndexingException{}
  res.message = msg
  return res
} 

func (self *IndexingException) Error() string { 
  return self.message
} 


func (self *IndexingException) PrintStackTrace() { 
  fmt.Println(self.message)
}

func (self *IndexingException) GetMessage() string { 
  return self.message
}

func (self *IndexingException) GetCause() *OclException { 
  err := errors.Unwrap(self)
  return NewOclException(err.Error())
} 


type AssertionException struct {
  message string
}


func NewAssertionException(msg string) *AssertionException { 
  res := &AssertionException{}
  res.message = msg
  return res
} 

func (self *AssertionException) Error() string { 
  return self.message
} 


func (self *AssertionException) PrintStackTrace() { 
  fmt.Println(self.message)
}

func (self *AssertionException) GetMessage() string { 
  return self.message
}

func (self *AssertionException) GetCause() *OclException { 
  err := errors.Unwrap(self)
  return NewOclException(err.Error())
} 


