import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class OclOperation 
{ OclOperation() { }


  String name = "";
  OclType type = null;
  ArrayList<OclAttribute> parameters = new ArrayList<OclAttribute>();

  public String getName()
  { return name; }


  public OclType getType()
  { return type; }


  public OclType getReturnType()
  { return type; }


  public ArrayList<OclAttribute> getParameters()
  {
    ArrayList<OclAttribute> result = new ArrayList<OclAttribute>();
    result = parameters;
    return result;
  }

}

