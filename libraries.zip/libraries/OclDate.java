import java.util.*;

class OclDate { 

  static OclDate createOclDate() 
  { OclDate result = new OclDate();
    return result; 
  }

  public static long systemTime = 0;
  public long time = 0;

  int year = 0;
  int month = 0;
  int day = 0;
  int weekday = 0; 
  int hour = 0;
  int minute = 0;
  int second = 0;

  public static OclDate newOclDate()
  { Date dd = new Date(); 
    OclDate d = new OclDate();
    d.time = dd.getTime();
    d.year = dd.getYear();
    d.month = dd.getMonth();
    d.day = dd.getDate(); // day of month
    d.weekday = dd.getDay(); 
    d.hour = dd.getHours(); 
    d.minute = dd.getMinutes(); 
    d.second = dd.getSeconds();   
    OclDate.systemTime = d.time; 
    return d; 
  }


  public static OclDate newOclDate_Time(long t)
  { Date dd = new Date(t); 
    
    OclDate d = new OclDate();
    d.time = t;
    d.year = dd.getYear();
    d.month = dd.getMonth();
    d.day = dd.getDate(); // day of month
    d.weekday = dd.getDay(); 
    d.hour = dd.getHours(); 
    d.minute = dd.getMinutes(); 
    d.second = dd.getSeconds();   
    return d; 
  }

  public Object clone()
  { return OclDate.newOclDate_Time(time); } 

  public String toString()
  { Date dte = new Date(time); 
    return "" + dte; 
  } 

  public void setTime(long t)
  { Date dd = new Date(t); 
    
    time = t;
    year = dd.getYear();
    month = dd.getMonth();
    day = dd.getDate(); // day of month
    weekday = dd.getDay(); 
    hour = dd.getHours(); 
    minute = dd.getMinutes(); 
    second = dd.getSeconds();   
  }


  public long getTime()
  { return time; }

  public int getYear()
  { return year; } 

  public int getMonth()
  { return month; } 

  public int getDate()
  { return day; } 

  public int getDay()
  { return weekday; } 

  public int getHours()
  { return hour; } 

  public int getHour()
  { return hour; } 

  public int getMinutes()
  { return minute; } 

  public int getMinute()
  { return minute; } 

  public int getSeconds()
  { return second; } 

  public int getSecond()
  { return second; } 
  
  public boolean dateBefore(OclDate d)
  {
    boolean result = false;
    if (time < d.time)
    {
      result = true;
    }
    else {
      result = false;
    }
    return result;
  }

  public boolean dateAfter(OclDate d)
  {
    boolean result = false;
    if (time > d.time)
    {
      result = true;
    }
    else {
      result = false;
    }
    return result;
  }

  public static long getSystemTime()
  { Date d = new Date(); 
    long result = d.getTime();
    OclDate.systemTime = result;
    return result;
  }

}

