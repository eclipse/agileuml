
/* C header for mathlib library */


double pi_MathLib(void)
{ return 3.14159265; } 

double e_MathLib(void)
{ return exp(1); } 

void setSeeds_MathLib(int x, int y, int z)
{ srand(x); } 

double nrandom_MathLib(void) 
{ double total = 0.0; 
  int i = 0; 
  for ( ; i < 10; i++) 
  { total += rand()/(10.0*RAND_MAX); } 
  return total - 0.5; 
} 

double random_MathLib(void)
{ return rand()/(1.0*RAND_MAX); } 

long factorial_MathLib(int n) 
{ long res = 1; 
  int i = 2; 
  for ( ; i <= n; i++) 
  { res = res*i; } 
  return res; 
} 

long combinatorial_MathLib(int n, int m) 
{ if (n < m) 
  { return 0; } 
  if (m < 0)
  { return 0; } 

  long res = 1;
  if (n - m < m)
  { int i = m+1; 
    for ( ; i <= n; i++) 
    { res = res*i; }
    return res/factorial_MathLib(n-m); 
  }  
  else if (n - m >= m)
  { int i = n-m+1; 
    for ( ; i <= n; i++) 
    { res = res*i; }
    return res/factorial_MathLib(m); 
  }  
  return res; 
} 

double asinh_MathLib(double x)
{ return log(x + sqrt( x * x + 1 ) ); } 

double acosh_MathLib(double x)
{ return log(x + sqrt( x * x - 1 ) ); } 

double atanh_MathLib(double x)
{ return 0.5 * log( ( 1 + x ) / ( 1 - x ) ); } 


int bitwiseAnd_MathLib(int x, int y)
{ return x&y; } 

int bitwiseOr_MathLib(int x, int y)
{ return x|y; } 

int bitwiseXor_MathLib(int x, int y)
{ return x^y; } 

char* decimal2hex_MathLib(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(log10(y+1) + 3); 
  char* s = (char*) calloc(xwidth, sizeof(char)); 
  if (x < 0)
  { sprintf(s, "-0x%X", y); } 
  else 
  { sprintf(s, "0x%X", y); } 
 
  return s; 
}

char* decimal2octal_MathLib(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(2*log10(y+1) + 3); 
  char* s = (char*) calloc(xwidth, sizeof(char)); 
  if (x < 0) 
  { sprintf(s, "-0%o", y); } 
  else 
  { sprintf(s, "0%o", y); } 
 
  return s; 
}

char* decimal2bits_MathLib(long x)
{ if (x == 0) 
  { return ""; }
  else 
  { char* res = decimal2bits_MathLib(x / 2);
    char* dig = "0"; 
    if (x % 2 == 1)
    { dig = "1"; } 
    char* s = concatenateStrings(res,dig); 
    return s;
  }
} 


char* decimal2binary_MathLib(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(4*log10(y+1) + 3); 
  char* s = (char*) calloc(xwidth, sizeof(char));
  if (x == 0)
  { return "0b0"; } 
  if (x > 0)
  { s[0] = '0'; s[1] = 'b'; } 
  else 
  { s[0] = '-'; s[1] = '0'; s[2] = 'b'; }
  return concatenateStrings(s, decimal2bits_MathLib(y));  
}

char* toBitSequence_MathLib(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(4*log10(y+1) + 3); 
  
  char* res = (char*) calloc(xwidth, sizeof(char));

  int index = 0; 
  while (y > 0)
  { if (y % 2 == 0)
    { res[index] = '\060'; }
    else 
    { res[index] = '\061'; } 
    y = y/2;
    index++; 
  } 
  res[index] = '\0'; 
  return reverseStrings(res);   
}

long modInverse_MathLib(long n, long p)
{ long x = n % p; 
  int i;
  i = 1;   
  for ( ; i < p; i++)
  { if (((i*x) % p) == 1)  
    { return i; }
  }  
  return 0; 
}

long modPow_MathLib(long n, long m, long p) 
{ long res = 1L; 
  long x = n % p;  
  int i = 1; 
  for ( ; i <= m; i++) 
  { res = ((res*x) % p); }  
  return res; 
}
