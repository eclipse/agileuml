class MathLib
{ 
 private:
  static int ix;
  static int iy;
  static int iz;
  static vector<string>* hexdigit;

 public:
   MathLib() {
     ix = 0;
     iy = 0;
     iz = 0;
     hexdigit = (new vector<string>());
  }

  static void setix(int ix_x) { ix = ix_x; }

  static void setiy(int iy_x) { iy = iy_x; }

  static void setiz(int iz_x) { iz = iz_x; }

  static void sethexdigit(vector<string>* hexdigit_x) 
  { hexdigit = hexdigit_x; }

  static void sethexdigit(int _ind, string hexdigit_x)   
  { (*hexdigit)[_ind] = hexdigit_x; }

  static void addhexdigit(string hexdigit_x)
  { hexdigit->push_back(hexdigit_x); }

  static int getix() { return ix; }

  static int getiy() { return iy; }
  
  static int getiz() { return iz; }
  
  static vector<string>* gethexdigit() { return hexdigit; }
  
  static double pi();

  static double e();

  static void setSeeds(int x,int y,int z);

  static double nrandom();

  static double random();

  static long combinatorial(int n,int m);

  static long factorial(int x);

  static double asinh(double x);

  static double acosh(double x);

  static double atanh(double x);

  static string decimal2bits(long x);

  static string decimal2binary(long x);

  static string decimal2oct(long x);

  static string decimal2octal(long x);

  static string decimal2hx(long x);

  static string decimal2hex(long x);

  static int bitwiseAnd(int x,int y);

  static int bitwiseOr(int x,int y);

  static int bitwiseXor(int x,int y);

  static vector<bool>* toBitSequence(long x);

  static long modInverse(long n,long p);

  static long modPow(long n,long m,long p);

  ~MathLib() {
  }

};
