/* C header for OclType library */

struct OclAttribute { 
  char* name; 
  struct OclType* type; 
}; 

struct OclOperation { 
  char* name; 
  struct OclType* type; 
  struct OclAttribute** parameters; 
}; 

struct OclType {
  char* name; 
  struct OclAttribute** attributes; 
  struct OclOperation** operations; 
  struct OclOperation** constructors; 
  struct OclType* superclass;
};


char* getName_OclAttribute(struct OclAttribute* self)
{ return self->name; } 

struct OclType* getType_OclAttribute(struct OclAttribute* self)
{ return self->type; } 

char* getName_OclOperation(struct OclOperation* self)
{ return self->name; } 

struct OclType* getType_OclOperation(struct OclOperation* self)
{ return self->type; } 

struct OclType* getReturnType_OclOperation(struct OclOperation* self)
{ return self->type; } 

struct OclAttribute** getParameters_OclOperation(struct OclOperation* self)
{ return self->parameters; } 


char* getName_OclType(struct OclType* self)
{ return self->name; } 

struct OclType* getSuperclass_OclType(struct OclType* self)
{ return self->superclass; } 

struct OclAttribute** getFields_OclType(struct OclType* self)
{ return self->attributes; } 

struct OclOperation** getMethods_OclType(struct OclType* self)
{ return self->operations; } 

struct OclOperation** getConstructors_OclType(struct OclType* self)
{ return self->constructors; } 

char* getOclType_name(struct OclType* self)
{ return self->name; }

void setOclType_name(struct OclType* self, char* _value)
{ self->name = _value; }

void setOclType_superclass(struct OclType* self, struct OclType* sup)
{ self->superclass = sup; }

struct OclType* getOclTypeByPK(char* _ex); 

struct OclType* createOclType(char* _value); 

struct OclAttribute* createOclAttribute(void);

struct OclOperation* createOclOperation(void);

struct OclAttribute** oclattribute_instances = NULL;
int oclattribute_size = 0;

struct OclOperation** ocloperation_instances = NULL;
int ocloperation_size = 0;

struct OclType** ocltype_instances = NULL;
int ocltype_size = 0;

struct OclAttribute** newOclAttributeList()
{ return (struct OclAttribute**) calloc(ALLOCATIONSIZE, sizeof(struct OclAttribute*)); }

struct OclOperation** newOclOperationList()
{ return (struct OclOperation**) calloc(ALLOCATIONSIZE, sizeof(struct OclOperation*)); }

struct OclType** newOclTypeList()
{ return (struct OclType**) calloc(ALLOCATIONSIZE, sizeof(struct OclType*)); }


struct OclAttribute** appendOclAttribute(struct OclAttribute* col[], struct OclAttribute* ex)
{ struct OclAttribute** result;
  int len = length((void**) col);
  if (len % ALLOCATIONSIZE == 0)
  { result = (struct OclAttribute**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct OclAttribute*));
    int i = 0;
    for ( ; i < len; i++) { result[i] = col[i]; }
  }
  else { result = col; }
    result[len] = ex;
    result[len+1] = NULL;
    return result;
  }

struct OclOperation** appendOclOperation(struct OclOperation* col[], struct OclOperation* ex)
   { struct OclOperation** result;
     int len = length((void**) col);
     if (len % ALLOCATIONSIZE == 0)
     { result = (struct OclOperation**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct OclOperation*));
       int i = 0;
       for ( ; i < len; i++) { result[i] = col[i]; }
     }
    else { result = col; }
    result[len] = ex;
    result[len+1] = NULL;
    return result;
  }

struct OclType** appendOclType(struct OclType* col[], struct OclType* ex)
   { struct OclType** result;
     int len = length((void**) col);
     if (len % ALLOCATIONSIZE == 0)
     { result = (struct OclType**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct OclType*));
       int i = 0;
       for ( ; i < len; i++) { result[i] = col[i]; }
     }
    else { result = col; }
    result[len] = ex;
    result[len+1] = NULL;
    return result;
  }

struct OclType* createOclType(char* _value)
{ struct OclType* result = NULL;
  result = getOclTypeByPK(_value);
  if (result != NULL) { return result; }
  result = (struct OclType*) malloc(sizeof(struct OclType));
  result->attributes = NULL;
  result->operations = NULL;
  setOclType_name(result, _value);
  ocltype_instances = appendOclType(ocltype_instances, result);
  ocltype_size++;
  return result;
}

struct OclAttribute* createOclAttribute()
{ struct OclAttribute* result = (struct OclAttribute*) malloc(sizeof(struct OclAttribute));
  result->name = NULL;
  result->type = NULL;
  oclattribute_instances = appendOclAttribute(oclattribute_instances, result);
  oclattribute_size++;
  return result;
}

struct OclOperation* createOclOperation()
{ struct OclOperation* result = (struct OclOperation*) malloc(sizeof(struct OclOperation));
  result->name = NULL;
  result->type = NULL;
  result->parameters = NULL;
  ocloperation_instances = appendOclOperation(ocloperation_instances, result);
  ocloperation_size++;
  return result;
}

struct OclType* getOclTypeByPK(char* _ex)
{ int n = length((void**) ocltype_instances);
  int i = 0;
  for ( ; i < n; i++)
  { char* _v = getOclType_name(ocltype_instances[i]);
    if (_v != NULL && strcmp(_v,_ex) == 0)
    { return ocltype_instances[i]; }
  }
  return NULL;
}

void addOclType_attributes(struct OclType* ocltype_x, struct OclAttribute* oclattribute_x)
{ ocltype_x->attributes = appendOclAttribute(ocltype_x->attributes, oclattribute_x);
}

void addOclType_operations(struct OclType* ocltype_x, struct OclOperation* ocloperation_x)
{ ocltype_x->operations = appendOclOperation(ocltype_x->operations, ocloperation_x);
}

