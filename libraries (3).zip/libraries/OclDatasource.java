import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

import java.sql.Connection; 
import java.sql.Statement; 
import java.sql.DriverManager; 
import java.sql.ResultSet; 
import java.sql.ResultSetMetaData;
import java.sql.SQLException; 
 


class OclDatasource { 
  static ArrayList<OclDatasource> OclDatasource_allInstances = new ArrayList<OclDatasource>();

  OclDatasource() { OclDatasource_allInstances.add(this); }

  static OclDatasource createOclDatasource() 
  { OclDatasource result = new OclDatasource();
    return result; 
  }

  String url = "";
  String protocol = "";
  String host = "";
  String file = "";
  int port = 0;
  String name = "";
  String passwd = "";
  String schema = "";
  String ocldatasourceId = ""; /* primary */
  static Map<String,OclDatasource> OclDatasource_index = new HashMap<String,OclDatasource>();

  Connection connection = null; 
  Statement statement = null; 
  ResultSet resultSet = null; 

  static OclDatasource createByPKOclDatasource(String ocldatasourceIdx)
  { OclDatasource result = OclDatasource.OclDatasource_index.get(ocldatasourceIdx);
    if (result != null) { return result; }
    result = new OclDatasource();
    OclDatasource.OclDatasource_index.put(ocldatasourceIdx,result);
    result.ocldatasourceId = ocldatasourceIdx;
    return result; 
  }

  static void killOclDatasource(String ocldatasourceIdx)
  { OclDatasource rem = OclDatasource_index.get(ocldatasourceIdx);
    if (rem == null) { return; }
    ArrayList<OclDatasource> remd = new ArrayList<OclDatasource>();
    remd.add(rem);
    OclDatasource_index.remove(ocldatasourceIdx);
    OclDatasource_allInstances.removeAll(remd);
  }


  public static OclDatasource getConnection(String url, String name, String passwd)
  {
    OclDatasource db = createOclDatasource();
    db.url = url;
    db.name = name;
    db.passwd = passwd;

    try { 
      db.connection = 
        DriverManager.getConnection(url,name,passwd); 
      db.statement = db.connection.createStatement(); 
    } 
    catch (SQLException ex) 
    { ex.printStackTrace(); }
  
    return db; 
  }


  public static OclDatasource newOclDatasource()
  {
    OclDatasource result = createOclDatasource(); 
    return result;
  }


  public static OclDatasource newSocket(String host, int port)
  {
    OclDatasource db = createOclDatasource();
    db.host = host;
    db.port = port;
    return db; 
  }


  public static OclDatasource newURL(String s)
  {
    OclDatasource db = createOclDatasource();
    db.url = s;
    return db; 
  }


  public static OclDatasource newURL_PHF(String p, String h, String f)
  {
    OclDatasource db = createOclDatasource();
    db.protocol = p;
    db.host = h;
    db.file = f;
    return db; 
  }


  public static OclDatasource newURL_PHNF(String p, String h, int n, String f)
  {
    OclDatasource db = createOclDatasource();
    db.protocol = p;
    db.host = h;
    db.port = n;
    db.file = f;
    return db; 
  }


  public SQLStatement createStatement()
  {
    SQLStatement ss = SQLStatement.createSQLStatement();
    ss.text = "";
    ss.connection = connection; 

    if (connection != null) 
    { try { 
        statement = connection.createStatement();
        ss.statement = statement;  
      } 
      catch (SQLException ex) 
      { ex.printStackTrace(); }
    } 

    return ss; 
  }


  public SQLStatement prepare(String stat)
  {
    SQLStatement ss = SQLStatement.createSQLStatement();
    ss.text = stat;
    ss.connection = connection; 
    ss.database = this; 

    if (connection != null) 
    { try { 
        statement = connection.prepareStatement(stat);
        ss.statement = statement;  
      } 
      catch (SQLException ex) 
      { ex.printStackTrace(); }
    } 

    return ss; 
  }


  public SQLStatement prepareStatement(String stat)
  {
    return prepare(stat);
  }


  public SQLStatement prepareCall(String stat)
  {
    SQLStatement ss = SQLStatement.createSQLStatement();
    ss.text = stat;
    ss.connection = connection; 
    ss.database = this; 

    if (connection != null) 
    { try { 
        statement = connection.prepareCall(stat);
        ss.statement = statement;  
      } 
      catch (SQLException ex) 
      { ex.printStackTrace(); }
    } 

    return ss; 
  }


  public OclIterator query_String(String stat)
  {
    OclIterator result = null;
    ArrayList<String> cnames = new ArrayList<String>(); 
    ArrayList<Map<String,Object>> records = 
        new ArrayList<Map<String,Object>>(); 

    SQLStatement queryStatement = prepare(stat); 
    
    if (statement != null) 
    { try { 
        ResultSet rs = statement.executeQuery(stat); 

        ResultSetMetaData md = rs.getMetaData(); 
        int nc = md.getColumnCount(); 
        
        for (int i = 1; i <= nc; i++) 
        { cnames.add(md.getColumnName(i)); } 

        while (rs.next())
        { Map<String,Object> record = 
            new HashMap<String,Object>();
          for (int j = 1; j <= nc; j++) 
          { Object val = rs.getObject(j); 
            record.put(md.getColumnName(j), val); 
          } 
          records.add(record); 
        }  
      } 
      catch (SQLException ex) 
      { ex.printStackTrace(); } 
    } 

    result = OclIterator.newOclIterator_Sequence(records); 
    result.columnNames = cnames;  
    return result;
  }


  public OclIterator rawQuery(String stat, ArrayList pos)
  {
    return query_String(stat);
  }


  public String nativeSQL(String stat)
  {
    if (connection != null) 
    try { 
      return connection.nativeSQL(stat); 
    } catch (Exception ex) { } 

    return null;
  }


  public OclIterator query_String_Sequence(String stat, ArrayList<String> cols)
  {
    return query_String(stat);
  }


  public void execSQL(String stat)
  {
    SQLStatement updateStatement = prepare(stat); 
    if (statement != null) 
    { try { 
        statement.execute(stat);   
      } 
      catch (SQLException ex) 
      { ex.printStackTrace(); } 
    } 
  }


  public void abort()
  { if (connection != null) 
    { try 
      { connection.abort(null); } 
      catch (Exception ex) { }
    }  
  }


  public void close()
  { if (connection != null)
    { try { 
        connection.close(); 
      } 
      catch (SQLException sq) { } 
    } 
  }


  public void commit()
  { if (connection != null) 
    { try 
      { connection.commit(); } 
      catch (Exception ex) { }
    }
  }


  public void rollback()
  { if (connection != null) 
    { try 
      { connection.rollback(); } 
      catch (Exception ex) { }
    }
  }


  public void connect()
  {
  }


  public OclDatasource openConnection()
  {
    OclDatasource result = null;
    result = this;
    return result;
  }


  public void setSchema(String s)
  {
    schema = s;
  }


  public String getSchema()
  {
    String result = null;
    result = schema;
    return result;
  }


  public OclFile getInputStream()
  {
    OclFile result = null;
    return result;
  }


  public OclFile getOutputStream()
  {
    OclFile result = null;
    return result;
  }


  public String getURL()
  {
    return url; 
  }


  public Object getContent()
  {
    Object result = null;
    return result;
  }


  public String getFile()
  {
    return file; 
  }


  public String getHost()
  {
    return host; 
  }


  public int getPort()
  {
    return port; 
  }


  public String getProtocol()
  {
    return protocol;
  }

}

