   public class OclDate : IComparable
    {
        long time;
        static long systemTime;
        int year;
        int month;
        int day;
        int weekday;
        int hour;
        int minute;
        int second;

        const long YEARMS = 31536000000L;
        const long MONTHMS = 2628000000L;
        const long DAYMS = 86400000L;
        const long HOURMS = 3600000L;
        const long MINUTEMS = 60000L;
        const long SECONDMS = 1000L;

        private static long getUnixTime(DateTime dd)
        {
            DateTimeOffset doff = new DateTimeOffset(dd);
            return doff.ToUnixTimeMilliseconds();
        }

        public static OclDate newOclDate()
        {
            DateTime dd = DateTime.Now;
            OclDate d = new OclDate();
            d.time = OclDate.getUnixTime(dd);
            d.year = dd.Year;
            d.month = dd.Month;
            d.day = dd.Day;
            d.weekday = (int)dd.DayOfWeek;
            d.hour = dd.Hour;
            d.minute = dd.Minute;
            d.second = dd.Second;
            OclDate.systemTime = d.time;
            return d;
        }

        public static OclDate newOclDate_Time(long t)
        {
            DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(t).DateTime;
            OclDate d = new OclDate();
            d.time = t;
            d.year = dd.Year;
            d.month = dd.Month;
            d.day = dd.Day;
            d.weekday = (int)dd.DayOfWeek;
            d.hour = dd.Hour;
            d.minute = dd.Minute;
            d.second = dd.Second;

            return d;
        }

        public void setTime(long t)
        {
            DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(t).DateTime;
            time = t;
            year = dd.Year;
            month = dd.Month;
            day = dd.Day;
            weekday = (int)dd.DayOfWeek;
            hour = dd.Hour;
            minute = dd.Minute;
            second = dd.Second;
        }

        public long getTime()
        { return time; }

        public static long getSystemTime()
        {
            DateTime dd = DateTime.Now;
            OclDate.systemTime = OclDate.getUnixTime(dd);
            return OclDate.systemTime;
        }


        public int getYear()
        { return year; }

        public int getMonth()
        { return month; }

        public int getDate()
        { return day; }

        public int getDay()
        { return weekday; }

        public int getHours()
        { return hour; }

        public int getHour()
        { return hour; }

        public int getMinutes()
        { return minute; }

        public int getMinute()
        { return minute; }

        public int getSeconds()
        { return second; }

        public int getSecond()
        { return second; }

        public OclDate addYears(int y)
        {
            long newtime = time + y * YEARMS;
            return newOclDate_Time(newtime);
        }

        public OclDate addMonths(int m)
        {
            long newtime = time + m * MONTHMS;
            return newOclDate_Time(newtime);
        }

        public OclDate addDays(int d)
        {
            long newtime = time + d * DAYMS;
            return newOclDate_Time(newtime);
        }

        public OclDate addHours(int h)
        {
            long newtime = time + h * HOURMS;
            return newOclDate_Time(newtime);
        }

        public OclDate addMinutes(int m)
        {
            long newtime = time + m * MINUTEMS;
            return newOclDate_Time(newtime);
        }

        public OclDate addSeconds(int s)
        {
            long newtime = time + s * SECONDMS;
            return newOclDate_Time(newtime);
        }

        public long yearDifference(OclDate d)
        {
            long newtime = time - d.time;
            return newtime / YEARMS;
        }

        public long monthDifference(OclDate d)
        {
            long newtime = time - d.time;
            return newtime / MONTHMS;
        }

        public long dayDifference(OclDate d)
        {
            long newtime = time - d.time;
            return newtime / DAYMS;
        }

        public long hourDifference(OclDate d)
        {
            long newtime = time - d.time;
            return newtime / HOURMS;
        }

        public long minuteDifference(OclDate d)
        {
            long newtime = time - d.time;
            return newtime / MINUTEMS;
        }

        public long secondDifference(OclDate d)
        {
            long newtime = time - d.time;
            return newtime / SECONDMS;
        }

        public int CompareTo(object obj)
        {
            if (obj is OclDate)
            {
                OclDate dd = (OclDate)obj;
                if (time < dd.time) { return -1; }
                if (time > dd.time) { return 1; }
                return 0;
            }
            return 0;
        } 
          
        public bool dateBefore(OclDate d)
        {
            bool result = false;
            if (time < d.time)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }


        public bool dateAfter(OclDate d)
        {
            bool result = false;
            if (time > d.time)
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }

        public override string ToString()
        {
            DateTime dd = DateTimeOffset.FromUnixTimeMilliseconds(time).DateTime;
            return dd.ToString();
        }
    }
