
/* C header for mathlib library */


double pi_MathLib(void)
{ return 3.14159265; } 

double piValue(void)
{ return 3.14159265; } 


double e_MathLib(void)
{ return exp(1); } 

double eValue(void)
{ return exp(1); } 

void setSeeds(int x, int y, int z)
{ srand(x); } 

double nrandom(void) 
{ double total = 0.0; 
  int i = 0; 
  for ( ; i < 10; i++) 
  { total += rand()/(10.0*RAND_MAX); } 
  return total - 0.5; 
} 

double random(void)
{ return rand()/(1.0*RAND_MAX); } 

long factorial(int n) 
{ long res = 1; 
  int i = 2; 
  for ( ; i <= n; i++) 
  { res = res*i; } 
  return res; 
} 

long combinatorial(int n, int m) 
{ if (n < m) 
  { return 0; } 
  if (m < 0)
  { return 0; } 

  long res = 1;
  if (n - m < m)
  { int i = m+1; 
    for ( ; i <= n; i++) 
    { res = res*i; }
    return res/factorial(n-m); 
  }  
  else if (n - m >= m)
  { int i = n-m+1; 
    for ( ; i <= n; i++) 
    { res = res*i; }
    return res/factorial(m); 
  }  
  return res; 
} 

double asinh(double x)
{ return log(x + sqrt( x * x + 1 ) ); } 

double acosh(double x)
{ return log(x + sqrt( x * x - 1 ) ); } 

double atanh(double x)
{ return 0.5 * log( ( 1 + x ) / ( 1 - x ) ); } 


int bitwiseAnd(int x, int y)
{ return x&y; } 

int bitwiseOr(int x, int y)
{ return x|y; } 

int bitwiseXor(int x, int y)
{ return x^y; } 

char* decimal2hex(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(log10(y+1) + 3); 
  char* s = (char*) calloc(xwidth, sizeof(char)); 
  if (x < 0)
  { sprintf(s, "-0x%X", y); } 
  else 
  { sprintf(s, "0x%X", y); } 
 
  return s; 
}

char* decimal2octal(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(2*log10(y+1) + 3); 
  char* s = (char*) calloc(xwidth, sizeof(char)); 
  if (x < 0) 
  { sprintf(s, "-0%o", y); } 
  else 
  { sprintf(s, "0%o", y); } 
 
  return s; 
}

char* decimal2bits(long x)
{ /* char* sign = ""; 
  if (x < 0) 
  { sign = "-"; } */ 

  if (x == 0) 
  { return ""; }
  else 
  { char* res = decimal2bits(x / 2);
    char* dig = "0"; 
    if (x % 2 == 1)
    { dig = "1"; } 
    char* s = concatenateStrings(res,dig); 
    return s;
  }
} 


char* decimal2binary(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(4*log10(y+1) + 3); 
  char* s = (char*) calloc(xwidth, sizeof(char));
  if (x == 0)
  { return "0b0"; } 
  if (x > 0)
  { s[0] = '0'; s[1] = 'b'; } 
  else 
  { s[0] = '-'; s[1] = '0'; s[2] = 'b'; }
  return concatenateStrings(s, decimal2bits(y));  
}

long bytes2integer(int** bs)
{ long result = 0;
  if (length((void**) bs) == 0)
  { result = 0; }
  else
  { if (length((void**) bs) == 1)
    { result = (int) at((void**) bs, 1); }
    else
    { if (length((void**) bs) == 2)
      { result = 256 * atint(bs, 1) + atint(bs, 2); }
      else
      { if (length((void**) bs) > 2)
        { result = 256 * bytes2integer(frontint(bs)) + lastint(bs); }
      }
    }
  }
  return result;
}

int** integer2bytes(long x)
{ int** result = NULL;
  if ((x / 256) == 0)
  { result = appendint(newintList(), (x % 256)); }
  else
  { result = appendint(integer2bytes(x / 256), x % 256); }
  return result;
}

int** integer2Nbytes(long x, int n)
{ int** result = NULL;
  int** bs = NULL;
  bs = integer2bytes(x);
  if (length((void**) bs) < n)
  { result = bs; }
  else
  { if (length((void**) bs) >= n)
    { result = subrangeint(bs,1,n); }
  }
  return result;
}


char* toBitSequence(long x)
{ long y = x; 
  if (x < 0) { y = -x; } 
  int xwidth = (int) ceil(4*log10(y+1) + 3); 
  
  char* res = (char*) calloc(xwidth, sizeof(char));

  int index = 0; 
  while (y > 0)
  { if (y % 2 == 0)
    { res[index] = '\060'; }
    else 
    { res[index] = '\061'; } 
    y = y/2;
    index++; 
  } 
  res[index] = '\0'; 
  return reverseStrings(res);   
}

long modInverse(long n, long p)
{ long x = n % p; 
  int i;
  i = 1;   
  for ( ; i < p; i++)
  { if (((i*x) % p) == 1)  
    { return i; }
  }  
  return 0; 
}

long modPow(long n, long m, long p) 
{ long res = 1L; 
  long x = n % p;  
  int i = 1; 
  for ( ; i <= m; i++) 
  { res = ((res*x) % p); }  
  return res; 
}

long doubleToLongBits(double d)
{ double* dx = &d; 
  long* lx = (long*) dx; 

  char* sbufl = (char*) calloc(21, sizeof(char)); 

  sprintf(sbufl, "%ld", *lx);
  return strtol(sbufl,NULL,10);  
} 

double longBitsToDouble(long x) {
  long bits;
  memcpy(&bits, &x, sizeof bits);
  double* ptr = (double*) &bits;
  return *ptr; 
}

