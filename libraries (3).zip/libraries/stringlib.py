import ocl

class StringLib : 
  def leftTrim(s) :
    result = s[s.find(ocl.trim(s)):]
    return result

  def rightTrim(s) :
    result = ocl.before(s, ocl.trim(s)) + ocl.trim(s)
    return result

  def padLeftWithInto(s,c,n) :
    result = ocl.sumString([c for self in range(1, n - len(s) +1)]) + s
    return result

  def leftAlignInto(s,n) :
    result = ""
    if n <= len(s) :
      result = s[0:n]
    else :
      if n > len(s) :
        result = s + ocl.sumString([" " for self in range(1, n - len(s) +1)])
    return result

  def rightAlignInto(s,n) :
    result = ""
    if n <= len(s) :
      result = s[0:n]
    else :
      if n > len(s) :
        result = ocl.sumString([" " for self in range(1, n - len(s) +1)]) + s
    return result

  def format(f,sq) : 
    return (f % tuple(sq))

  def scan(s, fmt) :
    result = []
    
    ind = 0; # s upto ind has been consumed
    slen = len(s)

    i = 0
    while i < len(fmt) :  
      c = fmt[i] 
      if c == "%" and i < len(fmt) - 1 : 
        d = fmt[i+1] 
        if d == "s" : 
          endstring = s[ind:slen].find(" ") 
          if endstring == -1 : 
            result.append(s[ind:slen])
            return result 
          else : 
            result.append(s[ind:(ind+endstring)])
            ind = ind + endstring
          i = i + 1  
        else : 
          if d == "d" : 
            inchars = "" 
            for j in range(ind, slen) : 
              x = s[j] 
              if x.isdecimal() :
                inchars = inchars + x
              else : 
                break
            result.append(inchars)
            ind = ind + len(inchars)
            i = i + 1
          else : 
            if d == "f" : 
              incharsf = "" 
              for j in range(ind, slen) : 
                y = s[j] 
                if y.isdecimal() or y == "." :
                  incharsf = incharsf + y
                else : 
                  break
              result.append(incharsf)
              ind = ind + len(incharsf)
              i = i + 1
      else :
        if s[ind] == c :  
          ind = ind+1 
        else :  
          return result
      i = i + 1
    return result 


print(StringLib.scan("30=100.5#45", "%d=%f#%d"))
