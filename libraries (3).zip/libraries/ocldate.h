#include <time.h>


/* C header for OclDate library */


struct OclDate {
  long long time; 
  long long systemTime; 
};

struct OclDate* newOclDate(long long t)
{ struct OclDate* res = (struct OclDate*) malloc(sizeof(struct OclDate));
  res->time = t; 
  res->systemTime = (long long) time(NULL)*1000; 
  return res; 
}


void setTime_OclDate(struct OclDate* self, long long t)
{ self->time = t; } 

long long getTime_OclDate(struct OclDate* self)
{ return self->time; } 

long long getSystemTime_OclDate(void)
{ return (long long) time(NULL)*1000; } 

unsigned char dateBefore_OclDate(struct OclDate* self, struct OclDate* d)
{ if (self->time < d->time)
  { return TRUE; }
  return FALSE; 
}

unsigned char dateAfter_OclDate(struct OclDate* self, struct OclDate* d)
{ if (self->time > d->time)
  { return TRUE; }
  return FALSE; 
} 

