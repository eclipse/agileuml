
class OclDate {
private:
    long time;
    long systemTime;
    struct tm* actualDate; 

public:
    static long getUnixTime()
    {
        return 1000 * std::time(NULL);
    }

    static struct tm* getDate(long t)
    {
        time_t tx = t/1000;
        struct tm* res = localtime(&tx);
        return res;
    }

    static OclDate* newOclDate_Time(long t)
    {
        OclDate* res = new OclDate();
        res->time = t;
        res->systemTime = getUnixTime();
        res->actualDate = getDate(t); 
        return res;
    }

    static OclDate* newOclDate()
    {
        OclDate* res = new OclDate();
        res->systemTime = getUnixTime();
        res->time = res->systemTime;
        res->actualDate = getDate(res->time); 
        return res;
    }

    static OclDate* newOclDate_YMD(int y, int m, int d)
    {
        OclDate* res = new OclDate();
        res->systemTime = getUnixTime();
        
        res->actualDate = getDate(0);
        res->actualDate->tm_year = y; 
        res->actualDate->tm_mon = m; 
        res->actualDate->tm_mday = d;
        res->time = mktime(res->actualDate); 
        return res;
    }

    static OclDate* newOclDate_YMDHMS(int y, int m, int d, int h, int mn, int s)
    {
        OclDate* res = new OclDate();
        res->systemTime = getUnixTime();

        res->actualDate = getDate(0);
        res->actualDate->tm_year = y;
        res->actualDate->tm_mon = m;
        res->actualDate->tm_mday = d;
        res->actualDate->tm_hour = h; 
        res->actualDate->tm_min = mn; 
        res->actualDate->tm_sec = s; 
        res->time = mktime(res->actualDate);
        return res;
    }

    void setTime(long t)
    {
        time = t;
    }

    long getTime()
    {
        return time;
    }

    long getSystemTime()
    {
        systemTime = getUnixTime();
        return systemTime;
    }

    bool dateBefore(OclDate* d)
    {
        if (time < d->time)
        {
            return true;
        }
        return false;
    }

    bool dateAfter(OclDate* d)
    {
        if (time > d->time)
        {
            return true;
        }
        return false;
    }

    int getYear()
    {
        return actualDate->tm_year;
    }

    int getMonth()
    {
        return actualDate->tm_mon;
    }

    int getDate()
    {
        return actualDate->tm_mday;
    }

    int getDay()
    {
        return actualDate->tm_wday;
    }

    int getHour()
    {
        return actualDate->tm_hour;
    }

    int getMinute()
    {
        return actualDate->tm_min;
    }

    int getMinutes()
    {
        return actualDate->tm_min;
    }

    int getSecond()
    {
        return actualDate->tm_sec;
    }

    int getSeconds()
    {
        return actualDate->tm_sec;
    }

    OclDate* addYears(int y)
    {
        long newtime = time + y * (30758400000L);
        return newOclDate_Time(newtime);
    }

    OclDate* addMonths(int y)
    {
        long newtime = time + y * (2563200000L);
        return newOclDate_Time(newtime);
    }

    OclDate* addDays(int y)
    {
        long newtime = time + y * (86400000L);
        return newOclDate_Time(newtime);
    }

    OclDate* addHours(int y)
    {
        long newtime = time + y * (3600000L);
        return newOclDate_Time(newtime);
    }

    OclDate* addMinutes(int y)
    {
        long newtime = time + y * (60000);
        return newOclDate_Time(newtime);
    }

    OclDate* addSeconds(int y)
    {
        long newtime = time + y * (1000);
        return newOclDate_Time(newtime);
    }

    long yearDifference(OclDate* d)
    {
        long result = (time - d->time) / 31536000000L;
        return result;
    }

    long monthDifference(OclDate* d)
    {
        long result = (time - d->time) / 2563200000L;
        return result;
    }

    long dayDifference(OclDate* d)
    {
        long result = (time - d->time) / 86400000L;
        return result;
    }

    long hourDifference(OclDate* d)
    {
        long result = (time - d->time) / 3600000L;
        return result;
    }

    long minuteDifference(OclDate* d)
    {
        long result = (time - d->time) / 60000;
        return result;
    }

    long secondDifference(OclDate* d)
    {
        long result = (time - d->time) / 1000;
        return result;
    }

    string toString()
    {
        const time_t secs = (const time_t)(time / 1000);
        string res = "";
        return res.append(ctime(&secs));
    }

};
