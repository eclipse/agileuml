import ocl
import math
import re
import copy

from oclfile import *
from ocltype import *
from ocliterator import *
from enum import Enum

import sqlite3


def free(x):
  del x


class SQLTypes(Enum) :
  sqlARRAY = 1
  sqlBIGINT = 2
  sqlBINARY = 3
  sqlBIT = 4
  sqlBLOB = 5
  sqlBOOLEAN = 6
  sqlCHAR = 7
  sqlCLOB = 8
  sqlDATALINK = 9
  sqlDATE = 10
  sqlDECIMAL = 11
  sqlDISTINCT = 12
  sqlDOUBLE = 13
  sqlFLOAT = 14
  sqlINTEGER = 15
  sqlJAVA_OBJECT = 16
  sqlLONGNVARCHAR = 17
  sqlLONGVARBINARY = 18
  sqlNCHAR = 19
  sqlNCLOB = 20
  sqlNULL = 21
  sqlNUMERIC = 22
  sqlNVARCHAR = 23
  sqlOTHER = 24
  sqlREAL = 25
  sqlREF = 26
  sqlREF_CURSOR = 27
  sqlROWID = 28
  sqlSMALLINT = 29
  sqlSQLXML = 30
  sqlSTRUCT = 31
  sqlTIME = 32
  sqlTIME_WITH_TIMEZONE = 33
  sqlTIMESTAMP = 34
  sqlTIMESTAMP_WITH_TIMEZONE = 35
  sqlTINYINT = 36
  sqlVARBINARY = 37
  sqlVARCHAR = 38



class SQLStatement : 
  sqlstatement_instances = []
  sqlstatement_index = dict({})

  def __init__(self):
    self.text = ""
    self.statement = None   # Cursor
    self.connection = None  # Connection
    SQLStatement.sqlstatement_instances.append(self)

  def convertRowsToMaps(self) : 
    if self.statement != None : 
      resset = self.statement.fetchall()
      if resset == None : 
        return [] 
      if len(resset) == 0 : 
        return []
      row1 = resset[0]
      keys = row1.keys()
      result = [] 
      for x in resset : 
        record = dict({})
        for k in keys : 
          record[k] = x[k]
        result.append(record)
      return (result,keys)
    return []


  def close(self) :
    pass

  def closeOnCompletion(self) :
    pass

  def setString(self, field, value) :
    pass

  def setInt(self, field, value) :
    pass

  def setByte(self, field, value) :
    pass

  def setShort(self, field, value) :
    pass

  def setBoolean(self, field, value) :
    pass

  def setLong(self, field, value) :
    pass

  def setDouble(self, field, value) :
    pass

  def setTimestamp(self, field, value) :
    pass

  def setNull(self, field, value) :
    pass

  def executeUpdate(self) :
    if self.statement != None : 
      self.statement.execute(self.text)
      if self.connection != None : 
        self.connection.commit()


  def executeQuery(self, stat=None) :
    result = None
    if self.statement != None : 
      if stat == None : 
        stat = self.text
      self.statement.execute(stat)
      (resset,ks) = self.convertRowsToMaps()
      result = OclIterator.newOclIterator_Sequence(resset)
      result.columnNames = ks
    return result


  def execute(self, stat=None) :
    if self.statement != None :
      if stat == None : 
        stat = self.text 
      self.statement.execute(stat)
      if self.connection != None : 
        self.connection.commit()

  def cancel(self) :
    pass

  def getConnection(self) :
    return self.connection

  def getResultSet(self) :
    result = None
    pass
    return result

  def killSQLStatement(sqlstatement_x) :
    sqlstatement_instances = ocl.excludingSet(sqlstatement_instances, sqlstatement_x)
    free(sqlstatement_x)


class OclDatasource : 
  ocldatasource_instances = []
  ocldatasource_index = dict({})

  def __init__(self):
    self.url = ""
    self.protocol = ""
    self.host = ""
    self.file = ""
    self.port = ""
    self.name = ""
    self.passwd = ""
    self.schema = ""
    self.con = None
    OclDatasource.ocldatasource_instances.append(self)

  def getConnection(url,name,passwd) :
    result = None
    db = createOclDatasource()
    db.url = url
    db.name = name
    db.passwd = passwd
    db.con = sqlite3.connect(url)
    db.con.row_factory = sqlite3.Row
    result = db
    return result

  def newOclDatasource() :
    result = None
    db = createOclDatasource()
    result = db
    return result

  def newSocket(host,port) :
    result = None
    db = createOclDatasource()
    db.host = host
    db.port = port
    result = db
    return result

  def newURL(s) :
    result = None
    db = createOclDatasource()
    db.url = s
    result = db
    return result

  def newURL_PHF(p,h,f) :
    result = None
    db = createOclDatasource()
    db.protocol = p
    db.host = h
    db.file = f
    result = db
    return result

  def newURL_PHNF(p,h,n,f) :
    result = None
    db = createOclDatasource()
    db.protocol = p
    db.host = h
    db.port = n
    db.file = f
    result = db
    return result

  def createStatement(self) :
    result = None
    ss = createSQLStatement()
    ss.text = ""
    if self.con != None : 
      ss.statement = self.con.cursor()
      ss.connection = self.con
    result = ss
    return result

  def prepare(self, stat) :
    result = None
    ss = createSQLStatement()
    ss.text = stat
    result = ss
    return result

  def prepareStatement(self, stat) :
    result = None
    ss = createSQLStatement()
    ss.text = stat
    result = ss
    return result

  def prepareCall(self, stat) :
    result = None
    ss = createSQLStatement()
    ss.text = stat
    result = ss
    return result

  def query_String(self, stat) :
    result = None
    sqlstat = self.createStatement()
    sqlstat.text = stat
    result = sqlstat.executeQuery()
    return result

  def rawQuery(self, stat, pos) :
    result = None
    sqlstat = self.createStatement()
    sqlstat.text = stat
    result = sqlstat.executeQuery()
    return result

  def nativeSQL(self, stat) :
    result = ""
    sqlstat = self.createStatement()
    sqlstat.text = stat
    result = sqlstat.executeQuery()
    return result

  def query_String_Sequence(self, stat, cols) :
    result = None
    pass
    return result

  def execSQL(self, stat) :
    sqlstat = self.createStatement()
    sqlstat.text = stat
    sqlstat.execute()
    
  def abort(self) :
    pass

  def close(self) :
    if self.con != None : 
      self.con.close()

  def commit(self) :
    if self.con != None : 
      self.con.commit()

  def rollback(self) :
    pass

  def connect(self) :
    pass

  def openConnection(self) :
    result = None
    result = self
    return result

  def setSchema(self, s) :
    self.schema = s

  def getSchema(self) :
    result = ""
    result = self.schema
    return result

  def getInputStream(self) :
    result = None
    pass
    return result

  def getOutputStream(self) :
    result = None
    pass
    return result

  def getURL(self) :
    result = ""
    result = self.url
    return result

  def getContent(self) :
    result = None
    pass
    return result

  def getFile(self) :
    result = ""
    result = self.file
    return result

  def getHost(self) :
    result = ""
    result = self.host
    return result

  def getPort(self) :
    result = 0
    result = self.port
    return result

  def getProtocol(self) :
    result = ""
    result = self.protocol
    return result

  def killOclDatasource(ocldatasource_x) :
    ocldatasource_instances = ocl.excludingSet(ocldatasource_instances, ocldatasource_x)
    free(ocldatasource_x)

def createSQLStatement():
  sqlstatement = SQLStatement()
  return sqlstatement

def allInstances_SQLStatement():
  return SQLStatement.sqlstatement_instances


sqlstatement_OclType = createByPKOclType("SQLStatement")
sqlstatement_OclType.instance = createSQLStatement()
sqlstatement_OclType.actualMetatype = type(sqlstatement_OclType.instance)


def createOclDatasource():
  ocldatasource = OclDatasource()
  return ocldatasource

def allInstances_OclDatasource():
  return OclDatasource.ocldatasource_instances


ocldatasource_OclType = createByPKOclType("OclDatasource")
ocldatasource_OclType.instance = createOclDatasource()
ocldatasource_OclType.actualMetatype = type(ocldatasource_OclType.instance)


# db = OclDatasource.getConnection(":memory:", "", "")
# cur = db.createStatement()
# cur.execute('''create table stocks (date text, trans text, symbol text, qty real, price real)''')
# cur.execute("""insert into stocks
#           values ('2006-01-05','BUY','RHAT',100,35.14)""")
# cur.execute("""insert into stocks
#            values ('2011-01-05','BUY','QAA',200,85.14)""")
# cur.execute("""insert into stocks
#            values ('2012-01-05','BUY','GOOG',100,235.14)""")


# res = cur.executeQuery('select * from stocks')
# print(type(res))

## r = cur.fetchone()
## print(type(r))

## print(tuple(r))
## print(len(r))
## print(r[2])
## print(r.keys())
## print(r['qty'])

## for member in r:
##   print(member)

# r1 = res.next()
# while r1 != None : 
#   print(r1)
#   r1 = res.next()
