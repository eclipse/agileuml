import Foundation
import Darwin
import SQLite3

class SQLStatement
{ private static var instance : SQLStatement? = nil
  var text : String = ""
  var statement: OpaquePointer?
  var dbPointer : OpaquePointer?
  var database : OclDatasource?
  var resultSet : OclIterator = OclIterator.defaultInstance() 
    
  init() { }

  init(copyFrom: SQLStatement) {
    self.text = copyFrom.text
    self.statement = copyFrom.statement
    self.dbPointer = copyFrom.dbPointer
    self.resultSet = copyFrom.resultSet
    self.database = copyFrom.database
  }

  func copy() -> SQLStatement
  { let res : SQLStatement = SQLStatement(copyFrom: self)
    addSQLStatement(instance: res)
    return res
  }

  static func defaultInstanceSQLStatement() -> SQLStatement
  { if (instance == nil)
    { instance = createSQLStatement() }
    return instance!
  }

  deinit
  { killSQLStatement(obj: self) }

  func close() -> Void
  {
    if (statement != nil)
    { sqlite3_finalize(statement!) } 
    if (dbPointer != nil)
    { sqlite3_close(dbPointer!) } 
  }


  func closeOnCompletion() -> Void
  {

  }

/* 
func insert() {
  var insertStatement: OpaquePointer?
  // 1
  if sqlite3_prepare_v2(db, insertStatementString, -1, &insertStatement, nil) == 
      SQLITE_OK {
    let id: Int32 = 1
    let name: NSString = "Ray"
    // 2
    sqlite3_bind_int(insertStatement, 1, id)
    // 3
    sqlite3_bind_text(insertStatement, 2, name.utf8String, -1, nil)
    // 4
    if sqlite3_step(insertStatement) == SQLITE_DONE {
      print("\nSuccessfully inserted row.")
    } else {
      print("\nCould not insert row.")
    }
  } else {
    print("\nINSERT statement is not prepared.")
  }
  // 5
  sqlite3_finalize(insertStatement)
}
 */

  func setString(field : Int, value : String) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_text(statement!, field, value, -1, nil) } 
  }


  func setInt(field : Int, value : Int) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_int(statement!, field, value) }
  }


  func setByte(field : Int, value : Int) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_int(statement!, field, value) }
  }


  func setShort(field : Int, value : Int) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_int(statement!, field, value) }
  }


  func setBoolean(field : Int, value : Bool) -> Void
  { guard statement != nil 
    else 
    { return }

    if value == true 
    { sqlite3_bind_int(statement, field, 1) }
    else 
    { sqlite3_bind_int(statement, field, 0) }
  }


  func setLong(field : Int, value : Int64) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_int64(statement!, field, value) }
  }


  func setDouble(field : Int, value : Double) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_double(statement!, field, value) }
  }


  func setTimestamp(field : Int, value : OclDate) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_int64(statement!, field, value.getTime()) }
  }


  func setNull(field : Int, value : Any) -> Void
  {
    if (statement != nil) 
    { sqlite3_bind_null(statement!, field) }
  }


  func executeUpdate() -> Void
  {
    guard statement != nil
    else 
    { dbPointer.execSQL(stat: text) }

    sqlite3_step(statement!)    
  }


  func executeQuery(stat : String) throws -> OclIterator
  {
    guard dbPointer != nil
    else 
    { return OclIterator.newOclIterator_Sequence(sq: []) }

    resultSet = dbPointer.query_String(stat: stat)
    return resultSet
  }


  func executeQuery() throws -> OclIterator
  { return executeQuery(stat: text) }


  func execute(stat : String) -> Void
  {
    guard dbPointer != nil
    else 
    { return }

    dbPointer.execSQL(stat: stat)
  }


  func execute() -> Void
  {
    executeUpdate()
  }


  func cancel() -> Void
  {
    if statement != nil 
    { sqlite3_reset(statement!) }
  }


  func getConnection() -> OclDatasource
  {
    return database!
  }


  func getResultSet() -> OclIterator
  {
    return resultSet!
  }

}




var SQLStatement_allInstances : [SQLStatement] = [SQLStatement]()

func createSQLStatement() -> SQLStatement
{ let result : SQLStatement = SQLStatement()
  SQLStatement_allInstances.append(result)
  return result
}

func addSQLStatement(instance : SQLStatement)
{ SQLStatement_allInstances.append(instance) }

func killSQLStatement(obj: SQLStatement)
{ SQLStatement_allInstances = SQLStatement_allInstances.filter{ $0 !== obj } }


