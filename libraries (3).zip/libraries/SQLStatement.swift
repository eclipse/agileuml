import Foundation
import Darwin
import SQLite3

class SQLStatement
{ private static var instance : SQLStatement? = nil
  var text : String = ""
  var statement: OpaquePointer?
  var dbPointer : OpaquePointer? 
    
  init() { }

  init(copyFrom: SQLStatement) {
    self.text = copyFrom.text
  }

  func copy() -> SQLStatement
  { let res : SQLStatement = SQLStatement(copyFrom: self)
    addSQLStatement(instance: res)
    return res
  }

  static func defaultInstanceSQLStatement() -> SQLStatement
  { if (instance == nil)
    { instance = createSQLStatement() }
    return instance!
  }

  deinit
  { killSQLStatement(obj: self) }

  func close() -> Void
  {

  }


  func closeOnCompletion() -> Void
  {

  }


  func setString(field : Int, value : String) -> Void
  {

  }


  func setInt(field : Int, value : Int) -> Void
  {

  }


  func setByte(field : Int, value : Int) -> Void
  {

  }


  func setShort(field : Int, value : Int) -> Void
  {

  }


  func setBoolean(field : Int, value : Bool) -> Void
  {

  }


  func setLong(field : Int, value : Int64) -> Void
  {

  }


  func setDouble(field : Int, value : Double) -> Void
  {

  }


  func setTimestamp(field : Int, value : OclDate) -> Void
  {

  }


  func setNull(field : Int, value : Any) -> Void
  {

  }


  func executeUpdate() -> Void
  {

  }


  func executeQuery(stat : String) -> OclIterator
  {
    var result : OclIterator = nil
    return result

  }


  func executeQuery() -> OclIterator
  {
    var result : OclIterator = nil
    return result

  }


  func execute(stat : String) -> Void
  {

  }


  func execute() -> Void
  {

  }


  func cancel() -> Void
  {

  }


  func getConnection() -> Void
  {

  }


  func getResultSet() -> OclIterator
  {
    var result : OclIterator = nil
    return result

  }

}




var SQLStatement_allInstances : [SQLStatement] = [SQLStatement]()

func createSQLStatement() -> SQLStatement
{ let result : SQLStatement = SQLStatement()
  SQLStatement_allInstances.append(result)
  return result
}

func addSQLStatement(instance : SQLStatement)
{ SQLStatement_allInstances.append(instance) }

func killSQLStatement(obj: SQLStatement)
{ SQLStatement_allInstances = SQLStatement_allInstances.filter{ $0 !== obj } }


