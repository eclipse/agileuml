import Foundation
import Darwin
import SQLite3

class OclDatasource : InternetCallback
{ private static var instance : OclDatasource? = nil
  var url : String = ""
  var protocol : String = ""
  var host : String = ""
  var file : String = ""
  var port : String = ""
  var name : String = ""
  var passwd : String = ""
  var schema : String = ""
  var requestMethod : String = ""
  var dbPointer : OpaquePointer? 

  var delegate : InternetCallback? = nil

  var urlSession = URLSession.shared

  func setDelegate(d : InternetCallback)
  { delegate = d }

  init() { }

  init(copyFrom: OclDatasource) {
    self.url = copyFrom.url
    self.protocol = copyFrom.protocol
    self.host = copyFrom.host
    self.file = copyFrom.file
    self.port = copyFrom.port
    self.name = copyFrom.name
    self.passwd = copyFrom.passwd
    self.schema = copyFrom.schema
    self.requestMethod = copyFrom.requestMethod
    self.dbPointer = copyFrom.dbPointer
    self.delegate = copyFrom.delegate
    self.urlSession = copyFrom.urlSession
  }

  func copy() -> OclDatasource
  { let res : OclDatasource = OclDatasource(copyFrom: self)
    addOclDatasource(instance: res)
    return res
  }

  static func defaultInstanceOclDatasource() -> OclDatasource
  { if (instance == nil)
    { instance = createOclDatasource() }
    return instance!
  }

  deinit
  { killOclDatasource(obj: self) }


  static func getConnection(url : String, name : String, passwd : String) -> OclDatasource
  {
    var db : OclDatasource = createOclDatasource()
    db.url = url
    db.name = name
    db.passwd = passwd
    
    var dbp: OpaquePointer?
  
    if sqlite3_open(url, &dbp) == SQLITE_OK 
    { db.dbPointer = dbp }

    return db
  }


  static func newOclDatasource() -> OclDatasource
  {
    var db : OclDatasource = createOclDatasource()
    return db
  }


  static func newSocket(host : String, port : String) -> OclDatasource
  {
    var db : OclDatasource = createOclDatasource()
    db.host = host
    db.port = port
    return db
  }


  static func newURL(s : String) -> OclDatasource
  {
    var db : OclDatasource = createOclDatasource()
    db.url = s
    return db
  }


  static func newURL_PHF(p : String, h : String, f : String) -> OclDatasource
  {
    var db : OclDatasource = createOclDatasource()
    db.protocol = p
    db.host = h
    db.file = f
    return db
  }


  static func newURL_PHNF(p : String, h : String, n : Int, f : String) -> OclDatasource
  {
    var db : OclDatasource = createOclDatasource()
    db.protocol = p
    db.host = h
    db.port = n
    db.file = f
    return db
  }


  func createStatement() throws -> SQLStatement
  {
    var ss : SQLStatement = createSQLStatement()
    ss.text = ""
    ss.dbPointer = dbPointer
    ss.database = self

    var statement: OpaquePointer?
    guard sqlite3_prepare_v2(dbPointer, ss.text, -1, &statement, nil) 
        == SQLITE_OK
    else 
    { return ss }

    ss.statement = statement
    return ss
  }


  func prepare(stat : String) throws -> SQLStatement
  { var ss : SQLStatement = createSQLStatement()
    ss.text = stat
    ss.dbPointer = dbPointer
    ss.database = self

    var statement: OpaquePointer?
    guard sqlite3_prepare_v2(dbPointer, ss.text, -1, &statement, nil) 
        == SQLITE_OK
    else 
    { return ss }

    ss.statement = statement
    return ss
  }


  func prepareStatement(stat : String) throws -> SQLStatement
  {
    return prepare(stat: stat)
  }


  func prepareCall(stat : String) throws -> SQLStatement
  {
    return prepare(stat: stat)
  }


  func query_String(stat : String) throws -> OclIterator
  {
    var result : OclIterator = nil
    let sqlstat = try prepare(stat: stat)

    guard sqlstat.statement != nil 
    else 
    { return OclIterator.newOclIterator_Sequence(sq: []) }

    let queryStatement = sqlstat.statement

    var rows : [[String:Any]] = [[String:Any]]()
    var cnames : [String]

    while (sqlite3_step(queryStatement) == SQLITE_ROW)
    { let cnt = sqlite3_column_count(queryStatement)
      var colname : [String] = [String]()
      var row : [String:Any] = [String:Any]()

      for i in 0...(cnt-1) 
      { let nme = sqlite3_column_origin_name(queryStatement,i)
        colname.append(String(cString: nme))

        let cde = sqlite3_column_type(queryStatement)
        if cde == SQLITE_INTEGER  
        { guard let queryIntResult = sqlite3_column_int(queryStatement, i)
          else 
          { row[colname[i]] = 0 } 
          row[colname[i]] = queryIntResult
        }
        else if cde = SQLITE_FLOAT
        { guard let queryDoubleResult = sqlite3_column_double(queryStatement, i)
          else 
          { row[colname[i]] = 0.0 } 
          row[colname[i]] = queryDoubleResult
        } 
        else if cde = SQLITE_BLOB
        { /* array of bytes */ } 
        else if cde = SQLITE3_TEXT
        { guard let queryTextResult = sqlite3_column_text(queryStatement, i)
          else 
          { row[colname[i]] = "" } 
          row[colname[i]] = String(cString: queryTextResult)
        } 
      }  

      cnames = colname
      rows.append(row)
    } 

    result = OclIterator.newOclIterator_Sequence(sq: rows)
    result.columnNames = cnames

    sqlite3_finalize(queryStatement)
    return result
  }


  func rawQuery(stat : String, pos : [Any]) throws -> OclIterator
  {
    return query_String(stat: stat)
  }


  func nativeSQL(stat : String) -> String
  {
    var result : String = ""
    let stmt = try prepare(stat: stat)
    result = try stmt.scalar()
    return result
  }


  func query_String_Sequence(stat : String, cols : [String]) -> OclIterator
  {
    return query_String(stat: stat)
  }


  func execSQL(stat : String) -> Void
  {
    let sqlStat = try prepare(stat: stat)
    defer 
    { sqlite3_finalize(sqlStat)
    }
    sqlite3_step(sqlStat)
  }

  func abort() -> Void
  {

  }


  func close() -> Void
  {
    guard self.dbPointer != nil
    else 
    { 
      return 
    } 
    sqlite3_close(self.dbPointer)
  }


  func commit() -> Void
  {

  }


  func rollback() -> Void
  {

  }


  func connect() -> Void
  {

  }


  func openConnection() -> OclDatasource
  { if (url.count > 0)
    { self.delegate = self
      accessURL(url: url)
    } 
    return self
  }


  func setSchema(s : String) -> Void
  {
    schema = s
  }

  func setRequestMethod(method : String) -> Void
  {
    requestMethod = s
  }


  func getSchema() -> String
  {
    return schema
  }


  func getInputStream() -> OclFile
  {
    var result : OclFile = OclFile.newOclFile(nme: url)
    result.lines = Ocl.toLineSequence(str: internetFileContents)
    result.characters = Ocl.chars(str: internetFileContents)
    result.writeMode = false
    return result
  }


  func getOutputStream() -> OclFile
  {
    var result : OclFile = OclFile.defaultInstanceOclFile()
    return result
  }


  func getURL() -> String
  {
    return url
  }

  func internetAccessCompleted(response : String)
  { internetFileContents = response }

  func getContent() -> Any
  {
    return internetFileContents
  }


  func getFile() -> String
  {
    return file
  }


  func getHost() -> String
  {
    return host
  }


  func getPort() -> Int
  {
    return port
  }


  func getProtocol() -> String
  {
    return protocol
  }

  func accessURL(url : String)
  { let urlref = URL(string: url)
    let task = urlSession.dataTask(with: urlref!)
    { (data,response,error) in
      if let _ = error
      { self.delegate?.internetAccessCompleted(response: "") }
      else if let _ = response
      { var res : String = ""
        for (_,x) in data!.enumerated()
        { res = res + String(Character(Unicode.Scalar(x))) }
        
        self.delegate?.internetAccessCompleted(response: res)
      }
    }
    task.resume()
  }
}

protocol InternetCallback
{ func internetAccessCompleted(response : String) }



var OclDatasource_allInstances : [OclDatasource] = [OclDatasource]()

func createOclDatasource() -> OclDatasource
{ let result : OclDatasource = OclDatasource()
  OclDatasource_allInstances.append(result)
  return result
}

func addOclDatasource(instance : OclDatasource)
{ OclDatasource_allInstances.append(instance) }

func killOclDatasource(obj: OclDatasource)
{ OclDatasource_allInstances = OclDatasource_allInstances.filter{ $0 !== obj } }


