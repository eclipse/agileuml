import Foundation
import Darwin
import SQLite3

class OclDatasource
{ private static var instance : OclDatasource? = nil
  var url : String = ""
  var protocol : String = ""
  var host : String = ""
  var file : String = ""
  var port : String = ""
  var name : String = ""
  var passwd : String = ""
  var schema : String = ""
  var dbPointer : OpaquePointer? 

  init() { }

  init(copyFrom: OclDatasource) {
    self.url = copyFrom.url
    self.protocol = copyFrom.protocol
    self.host = copyFrom.host
    self.file = copyFrom.file
    self.port = copyFrom.port
    self.name = copyFrom.name
    self.passwd = copyFrom.passwd
    self.schema = copyFrom.schema
  }

  func copy() -> OclDatasource
  { let res : OclDatasource = OclDatasource(copyFrom: self)
    addOclDatasource(instance: res)
    return res
  }

  static func defaultInstanceOclDatasource() -> OclDatasource
  { if (instance == nil)
    { instance = createOclDatasource() }
    return instance!
  }

  deinit
  { killOclDatasource(obj: self) }


  static func getConnection(url : String, name : String, passwd : String) -> OclDatasource
  {
    var db : OclDatasource = createOclDatasource()
    db.url = url
    db.name = name
    db.passwd = passwd
    
    var dbp: OpaquePointer?
  
    if sqlite3_open(url, &dbp) == SQLITE_OK 
    { db.dbPointer = dbp }

    return db
  }


  static func newOclDatasource() -> OclDatasource
  {
    var result : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    var db : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    db = createOclDatasource()
    result = db
    return result

  }


  static func newSocket(host : String, port : String) -> OclDatasource
  {
    var result : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    var db : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    db = createOclDatasource()
    db.host = host
    db.port = port
    result = db
    return result

  }


  static func newURL(s : String) -> OclDatasource
  {
    var result : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    var db : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    db = createOclDatasource()
    db.url = s
    result = db
    return result

  }


  static func newURL(p : String, h : String, f : String) -> OclDatasource
  {
    var result : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    var db : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    db = createOclDatasource()
    db.protocol = p
    db.host = h
    db.file = f
    result = db
    return result

  }


  static func newURL(p : String, h : String, n : Int, f : String) -> OclDatasource
  {
    var result : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    var db : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    db = createOclDatasource()
    db.protocol = p
    db.host = h
    db.port = n
    db.file = f
    result = db
    return result

  }


  func createStatement() throws -> SQLStatement
  {
    var ss : SQLStatement = createSQLStatement()
    ss.text = ""
    var statement: OpaquePointer?
    if sqlite3_prepare_v2(dbPointer, ss.text, -1, &statement, nil) 
        == SQLITE_OK
    { ss.statement = statement }
    return ss
  }


  func prepare(stat : String) throws -> SQLStatement
  { var ss : SQLStatement = createSQLStatement()
    ss.text = stat
    var statement: OpaquePointer?
    if sqlite3_prepare_v2(dbPointer, ss.text, -1, &statement, nil) 
        == SQLITE_OK
    { ss.statement = statement }
    return ss
  }


  func prepareStatement(stat : String) throws -> SQLStatement
  {
    return prepare(stat: stat)
  }


  func prepareCall(stat : String) throws -> SQLStatement
  {
    return prepare(stat: stat)
  }


  func query_String(stat : String) -> OclIterator
  {
    var result : OclIterator = nil
    return result

  }


  func rawQuery(stat : String, pos : [Any]) -> OclIterator
  {
    var result : OclIterator = nil
    return result

  }


  func nativeSQL(stat : String) -> String
  {
    var result : String = String.defaultInstanceString()
    return result

  }


  func query_String_Sequence(stat : String, cols : [String]) -> OclIterator
  {
    var result : OclIterator = nil
    return result

  }


  func execSQL(stat : String) -> Void
  {

  }


  func abort() -> Void
  {

  }


  func close() -> Void
  {

  }


  func commit() -> Void
  {

  }


  func rollback() -> Void
  {

  }


  func connect() -> Void
  {

  }


  func openConnection() -> OclDatasource
  {
    var result : OclDatasource = OclDatasource.defaultInstanceOclDatasource()
    result = self
    return result

  }


  func setSchema(s : String) -> Void
  {
    schema = s

  }


  func getSchema() -> String
  {
    var result : String = String.defaultInstanceString()
    result = schema
    return result

  }


  func getInputStream() -> OclFile
  {
    var result : OclFile = OclFile.defaultInstanceOclFile()
    return result

  }


  func getOutputStream() -> OclFile
  {
    var result : OclFile = OclFile.defaultInstanceOclFile()
    return result

  }


  func getURL() -> String
  {
    var result : String = String.defaultInstanceString()
    result = url
    return result

  }


  func getContent() -> Any
  {
    var result : Any = Any.defaultInstanceAny()
    return result

  }


  func getFile() -> String
  {
    var result : String = String.defaultInstanceString()
    result = file
    return result

  }


  func getHost() -> String
  {
    var result : String = String.defaultInstanceString()
    result = host
    return result

  }


  func getPort() -> Int
  {
    var result : Int = 0
    result = Int(port)
    return result

  }


  func getProtocol() -> String
  {
    var result : String = String.defaultInstanceString()
    result = protocol
    return result

  }

}




var OclDatasource_allInstances : [OclDatasource] = [OclDatasource]()

func createOclDatasource() -> OclDatasource
{ let result : OclDatasource = OclDatasource()
  OclDatasource_allInstances.append(result)
  return result
}

func addOclDatasource(instance : OclDatasource)
{ OclDatasource_allInstances.append(instance) }

func killOclDatasource(obj: OclDatasource)
{ OclDatasource_allInstances = OclDatasource_allInstances.filter{ $0 !== obj } }


