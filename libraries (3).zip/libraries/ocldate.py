import time
import datetime

class OclDate: 
  def __init__(self,t = int(time.time())): 
    self.time = t
    self.today = datetime.datetime.today()

  def getTime(self) : 
    return self.time

  def setTime(self,t) : 
    self.time = t
    self.today = datetime.datetime.today()

  def dateAfter(self,other) : 
    return self.time > other.time

  def dateBefore(self,other) : 
    return self.time < other.time

  def getSystemTime() : 
    return int(time.time())

  def newOclDate() : 
    t = int(time.time()) 
    d = OclDate(t)
    return d

  def newOclDate_Time(t) :   
    d = OclDate(t)
    return d

  def newOclDate_YMD(t,y,m,d) :   
    dte = OclDate(t)
    dte.year = y
    dte.month = m
    dte.day = d
    return dte

  def newOclDate_YMDHMS(t,y,m,d,h,mn,s) :   
    dte = OclDate(t)
    dte.year = y
    dte.month = m
    dte.day = d
    dte.hour = h
    dte.minute = mn
    dte.second = s
    return dte

  def getYear(self) : 
    return self.today.year

  def getMonth(self) : 
    return self.today.month

  def getDate(self) : 
    return self.today.day

  def getDay(self) : 
    return self.today.weekday()

  def getHour(self) : 
    return self.today.hour

  def getHours(self) : 
    return self.today.hour

  def getMinute(self) : 
    return self.today.minute

  def getMinutes(self) : 
    return self.today.minute

  def getSecond(self) : 
    return self.today.second

  def getSeconds(self) : 
    return self.today.second

  def toString(self) : 
    return str(self.today)













