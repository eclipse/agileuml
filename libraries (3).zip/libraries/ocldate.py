import time
import datetime

class OclDate: 
  YEARS = 31536000
  MONTHS = 2628000
  DAYS = 86400
  MINUTES = 60

  # Time is stored as seconds internally.

  def __init__(self,t = int(time.time())): 
    self.time = t
    self.today = datetime.datetime.fromtimestamp(t)

  def getTime(self) : 
    return 1000*self.time

  def setTime(self,t) : 
    self.time = t/1000
    self.today = datetime.datetime.fromtimestamp(t/1000)

  def dateAfter(self,other) : 
    return self.time > other.time

  def dateBefore(self,other) : 
    return self.time < other.time

  def getSystemTime() : 
    return int(time.time())*1000

  def setSystemTime(t) : 
    pass

  def newOclDate() : 
    t = int(time.time()) 
    d = OclDate(t)
    return d

  def newOclDate_Time(t) :   
    d = OclDate(t)
    return d

  def newOclDate_YMD(y,m,d) :   
    dte = OclDate,newOclDate()
    dte.year = y
    dte.month = m
    dte.day = d
    return dte

  def newOclDate_YMDHMS(y,m,d,h,mn,s) :   
    dte = OclDate.newOclDate()
    dte.year = y
    dte.month = m
    dte.day = d
    dte.hour = h
    dte.minute = mn
    dte.second = s
    return dte

  def getYear(self) : 
    return self.today.year

  def getMonth(self) : 
    return self.today.month

  def getDate(self) : 
    return self.today.day

  def getDay(self) : 
    return self.today.weekday()

  def getHour(self) : 
    return self.today.hour

  def getHours(self) : 
    return self.today.hour

  def getMinute(self) : 
    return self.today.minute

  def getMinutes(self) : 
    return self.today.minute

  def getSecond(self) : 
    return self.today.second

  def getSeconds(self) : 
    return self.today.second

  def toString(self) : 
    return str(self.today)

  def addYears(self,y) : 
    newtime = self.time + y*OclDate.YEARS
    return OclDate.newOclDate_Time(newtime)

  def addMonths(self,mn) : 
    newtime = self.time + mn*OclDate.MONTHS
    return OclDate.newOclDate_Time(newtime)

  def addDays(self,d) : 
    newtime = self.time + mn*OclDate.DAYS
    return OclDate.newOclDate_Time(newtime)

  def addHours(self,h) : 
    newtime = self.time + h*OclDate.HOURS
    return OclDate.newOclDate_Time(newtime)

  def addMinutes(self,m) : 
    newtime = self.time + m*OclDate.MINUTES
    return OclDate.newOclDate_Time(newtime)

  def addSeconds(self,s) : 
    newtime = self.time + mn
    return OclDate.newOclDate_Time(newtime)

  def yearDifference(self,d) :
    newtime = self.time - d.time
    return newtime/OclDate.YEARS
   
  def monthDifference(self,d) :
    newtime = self.time - d.time
    return newtime/OclDate.MONTHS

  def dayDifference(self,d) :
    newtime = self.time - d.time
    return newtime/OclDate.DAYS
 
  def hourDifference(self,d) :
    newtime = self.time - d.time
    return newtime/OclDate.HOURS

  def minuteDifference(self,d) :
    newtime = self.time - d.time
    return newtime/OclDate.MINUTES

  def secondDifference(self,d) :
    newtime = self.time - d.time
    return newtime







