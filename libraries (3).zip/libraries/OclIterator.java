import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class OclIterator { static ArrayList<OclIterator> OclIterator_allInstances = new ArrayList<OclIterator>();

  OclIterator() { OclIterator_allInstances.add(this); }

  static OclIterator createOclIterator() { OclIterator result = new OclIterator();
    return result; }

   int position = 0;
  ArrayList<Object> elements = (new ArrayList());
   String ocliteratorId = ""; /* primary */
  static Map< String,OclIterator> OclIterator_index = new HashMap< String,OclIterator>();

  static OclIterator createByPKOclIterator( String ocliteratorIdx)
  { OclIterator result = OclIterator.OclIterator_index.get(ocliteratorIdx);
    if (result != null) { return result; }
    result = new OclIterator();
    OclIterator.OclIterator_index.put(ocliteratorIdx,result);
    result.ocliteratorId = ocliteratorIdx;
    return result; }

  static void killOclIterator( String ocliteratorIdx)
  { OclIterator rem = OclIterator_index.get(ocliteratorIdx);
    if (rem == null) { return; }
    ArrayList<OclIterator> remd = new ArrayList<OclIterator>();
    remd.add(rem);
    OclIterator_index.remove(ocliteratorIdx);
    OclIterator_allInstances.removeAll(remd);
  }


  public  boolean hasNext()
  {
     boolean result = false;
    if (position >= 0 && position < elements.size())
    {
      result = true;
    }
    else {
      result = false;
    }
    return result;
  }


  public  boolean hasPrevious()
  {
     boolean result = false;
    if (position > 1 && position <= elements.size() + 1)
    {
      result = true;
    }
    else {
      result = false;
    }
    return result;
  }


  public  int nextIndex()
  {
     int result = 0;
    result = position + 1;
    return result;
  }


  public  int previousIndex()
  {
     int result = 0;
    result = position - 1;
    return result;
  }


  public  void moveForward()
  {
    position = position + 1;
  }


  public  void moveBackward()
  {
    position = position - 1;
  }


  public  void moveTo( int i)
  {
    position = i;
  }


  public  void moveToStart()
  {
    position = 0;
  }


  public  void moveToEnd()
  {
    position = elements.size() + 1;
  }


  public static OclIterator newOclIterator_Sequence(ArrayList sq)
  { OclIterator ot = null;
    ot = OclIterator.createOclIterator();
    ot.elements = sq;
    ot.position = 0;
    return ot; 
  }

  public static OclIterator newOclIterator_String(String str)
  { OclIterator ot = null;
    ot = OclIterator.createOclIterator();
    ot.elements.addAll(Ocl.split(str, "[ \n\t]+"));
    ot.position = 0;
    return ot; 
  }

  public static OclIterator newOclIterator_String_String(String str, String seps)
  { OclIterator ot = null;
    ot = OclIterator.createOclIterator();
    ot.elements.addAll(Ocl.split(str, "[" + seps + "]+"));
    ot.position = 0;
    return ot; 
  }


  public static OclIterator newOclIterator_Set(Collection st)
  { ArrayList elems = new ArrayList(); 
    elems.addAll(st); 
    Collections.sort(elems); 
     OclIterator ot = null;
    ot = OclIterator.createOclIterator();
    ot.elements = elems;
    ot.position = 0;
    return ot; 
  }


  public Object getCurrent()
  {
    Object result = null;
    result = ((Object) elements.get(position - 1));
    return result;
  }


  public  void set(Object x)
  {
    elements.set(position - 1,x);
  }


  public  void insert(Object x)
  { elements.add(position-1,x); }


  public  void remove()
  { elements.remove(position - 1); }


  public Object next()
  {
    Object result = null;
    moveForward();
    return getCurrent();
  }


  public Object previous()
  {
    Object result = null;
    moveBackward();
    return getCurrent();
  }
  
}

