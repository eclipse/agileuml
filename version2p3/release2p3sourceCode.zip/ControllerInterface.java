import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

public interface ControllerInterface
{
  public void addMathLib(MathLib oo);
    public void killMathLib(MathLib mathlibxx);
  public void addTestprimes(Testprimes oo);
    public void killTestprimes(Testprimes testprimesxx);
}

