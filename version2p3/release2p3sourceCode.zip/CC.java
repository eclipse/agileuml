public class CC
{ public String oper(ASTTerm t1)
  { return "evaluated: " + t1.literalForm(); }
}

