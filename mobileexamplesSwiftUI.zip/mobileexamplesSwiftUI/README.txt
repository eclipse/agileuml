These are the SwiftUI versions of app5 and app7. For app5 you will need to define the appropriate location for the database, in ModelFacade.swift. 

