import ocl
import math


def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)


class MathLib:
  mathlib_instances = []
  mathlib_index = dict({})
  ix = 0
  iy = 0
  iz = 0

  def __init__(self):
    MathLib.mathlib_instances.append(self)
    factorial_cache = dict({})


  def pi() :
    result = 0.0
    result = 0
    result = 3.14159265
    return result

  def e() :
    result = 0.0
    result = 0
    result = math.exp(1)
    return result

  def setSeeds(x,y,z) :
    self.ix = x
    self.iy = y
    self.iz = z

  def nrandom() :
    result = 0.0
    result = 0
    self.ix = (self.ix * 171) % 30269
    self.iy = (self.iy * 172) % 30307
    self.iz = (self.iz * 170) % 30323
    result = (self.ix / 30269.0 + self.iy / 30307.0 + self.iz / 30323.0)
    return result

  def random() :
    result = 0.0
    result = 0
    r = 0.0
    r = MathLib.nrandom()
    result = (r - int(math.floor(r)))
    return result

  def combinatorial(n,m) :
    result = 0
    result = 0
    if n - m < m :
      result = ocl.prd([(i) for i in range(m + 1, n + 1)])//ocl.prd([(j) for j in range(1, n - m + 1)])
    else :
      if n - m >= m :
        result = ocl.prd([(i) for i in range(n - m + 1, n + 1)])//ocl.prd([(j) for j in range(1, m + 1)])
    return result

  def factorial(self, x) :
    if str(x) in self.factorial_cache :
      return self.factorial_cache[str(x)]
    result = self.factorial_uncached(x)
    self.factorial_cache[str(x)] = result
    return result


  def factorial_uncached(self, x) :
    result = 0
    result = 0
    if x < 2 :
      result = 1
    else :
      if x >= 2 :
        result = ocl.prd([(i) for i in range(2, x + 1)])
    return result



  def gcd(x,y) :
    l = 0
    k = 0
    l = x
    k = y
    while l != 0 and k != 0 :
      if l < k :
        k = k % l
      else :
        l = l % k
    if l == 0 :
      return k
    else :
      return l

  def lcm(x,y) :
    result = 0
    result = 0
    result = (x * y)//MathLib.gcd(x, y)
    return result

  def integrate(f,d) :
    result = 0.0
    result = 0
    result = d * ocl.sum(f[(2-1): (len(f) - 1)]) + d * ((f)[0] + (f)[-1]) / 2.0
    return result

  def asinh(x) :
    result = 0.0
    result = 0
    result = math.log((x + math.sqrt((x * x + 1))))
    return result

  def acosh(x) :
    result = 0.0
    result = 0
    result = math.log((x + math.sqrt((x * x - 1))))
    return result

  def atanh(x) :
    result = 0.0
    result = 0
    result = 0.5 * math.log(((1 + x) / (1 - x)))
    return result

  def isPrime(x) :
    if x < 2 :
      return False
    if x == 2 :
      return True
    b = int(math.floor(math.sqrt(x)))
    i = 2
    while i <= b :
      if x % i == 0 :
        return False
      else :
        i = i + 1
    return True

  def killMathLib(mathlib_x) :
    mathlib_instances = ocl.excludingSet(mathlib_instances, mathlib_x)
    free(mathlib_x)

def createMathLib():
  mathlib = MathLib()
  return mathlib

def allInstances_MathLib():
  return MathLib.mathlib_instances


def testprimes() :
  displayboolean(MathLib.isPrime(911))
  displayboolean(MathLib.isPrime(70771))





