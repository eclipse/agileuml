import inspect

class OclType : 
  ocltype_index = dict({})

  def __init__(self,nme) : 
    self.name = nme
    self.instance = None
    self.actualMetatype = None

  def getFields(self) : 
    res = []
    if self.instance == None : 
      return res
    ls = inspect.getmembers(self.instance)
    for (name,value) in ls :
      if name[0] == '_' : 
        pass
      elif inspect.ismethod(value) : 
        pass
      elif inspect.isfunction(value) : 
        pass
      else :
        res.append(name)
    return res

  def getMethods(self) :
    res = []
    if self.actualMetatype == None : 
      return res
    ls = inspect.getmembers(self.actualMetatype)
    for (name,value) in ls :
      if name[0] == '_' : 
        pass
      elif inspect.isfunction(value) : 
        res.append(name)
    return res



def getOclTypeByPK(_ex) :
  if (_ex in OclType.ocltype_index) :
    return OclType.ocltype_index[_ex]
  else :
    return None


def createByPKOclType(_value):
  result = getOclTypeByPK(_value)
  if (result != None) : 
    return result
  else :
    result = OclType(_value)
    OclType.ocltype_index[_value] = result
    return result



string_OclType = createByPKOclType("String")
string_OclType.instance = ""
string_OclType.actualMetatype = type(string_OclType.instance)

int_OclType = createByPKOclType("int")
int_OclType.instance = 0
int_OclType.actualMetatype = type(int_OclType.instance)

long_OclType = createByPKOclType("long")
long_OclType.instance = 0
long_OclType.actualMetatype = type(long_OclType.instance)

double_OclType = createByPKOclType("double")
double_OclType.instance = 0.0
double_OclType.actualMetatype = type(double_OclType.instance)

boolean_OclType = createByPKOclType("boolean")
boolean_OclType.instance = True
boolean_OclType.actualMetatype = type(boolean_OclType.instance)



 