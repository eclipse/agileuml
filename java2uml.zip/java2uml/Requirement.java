import java.io.*; 
import java.util.Vector; 
import java.util.List; 
import java.util.ArrayList; 

/* Package: Requirements */ 
/******************************
* Copyright (c) 2003--2021 Kevin Lano
* This program and the accompanying materials are made available under the
* terms of the Eclipse Public License 2.0 which is available at
* http://www.eclipse.org/legal/epl-2.0
*
* SPDX-License-Identifier: EPL-2.0
* *****************************/

public class Requirement
{ public String id = "F1"; 
  public String name = ""; 
  public String text; 
  public String requirementKind = "functional"; 
  private boolean product = true; 
  private boolean local = false; 
  private Vector scenarios = new Vector(); // of Scenario
  private List<Integer> log = new ArrayList<Integer>(); 

  public Requirement(String nme, String i, String txt, String knd)
  { id = i ; 
    text = txt; 
    requirementKind = knd; 
  }

  public String getText() 
  { return text; } 
  
  public String getKind()
  { return requirementKind; } 

  public String getScope() 
  { if (local) 
    { return "local"; } 
    return "global"; 
  } 

  public boolean isGlobal()
  { if (local) 
    { return false; }
    return true; 
  }  

  public boolean hasScenarios()
  { return scenarios.size() > 0; } 

  public Vector getScenarios()
  { return scenarios; } 

  public void setText(String txt)
  { text = txt; } 

  public void setKind(String k)
  { requirementKind = k; } 

  public void setScope(String k)
  { if ("local".equals(k))
    { local = true; } 
    else 
    { local = false; }
  } 
 

  public String toString()
  { return "Requirement: " + name + " " + id + "\n" + 
           text + "\n" + 
           requirementKind + "\n" + 
           local + "\n" + 
           scenarios; 
  } 

  public void generateJava(PrintWriter out) { } 

 
  public void saveModelData(PrintWriter out)
  { out.println(name + " : Requirement"); 
    out.println(name + ".id = \"" + id + "\""); 
    out.println(name + ".text = \"" + text + "\""); 
    out.println(name + ".requirementKind = \"" + requirementKind + "\""); 
    out.println(name + ".localScope = " + local);
     
  } 

} 