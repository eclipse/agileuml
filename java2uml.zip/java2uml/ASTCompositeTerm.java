import java.util.List; 
import java.util.ArrayList; 

public class ASTCompositeTerm extends ASTTerm
{ String tag = ""; 
  List<ASTTerm> terms = new ArrayList<ASTTerm>(); // of ASTTerm

  public ASTCompositeTerm(String t, List subtrees)
  { tag = t; 
    terms = subtrees; 
  } 

  public void addTerm(ASTTerm t) 
  { terms.add(t); } 

  public String toString()
  { String res = "(" + tag; 
    for (int i = 0; i < terms.size(); i++) 
    { res = res + " " + terms.get(i); } 
    res = res + ")"; 
    return res; 
  } 
} 