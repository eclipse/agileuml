public class ASTBasicTerm extends ASTTerm
{ String tag = ""; 
  String value = ""; 

  public ASTBasicTerm(String t, String v) 
  { tag = t; 
    value = v; 
  } 

  public void setTag(String t)
  { tag = t; } 

  public void setValue(String v)
  { value = v; } 

  public String toString()
  { String res = "(" + tag + " " + value + ")"; 
    return res; 
  } 
} 