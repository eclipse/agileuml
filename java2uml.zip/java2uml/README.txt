This program extracts the class and operation declarations from a Java class file, and translates types into their corresponding UML/OCL forms. 

The output file model.txt describes the Java application as an instance of the UML metamodel. Load this into AgileUML as the file output/model.txt, using the File menu option "Load metamodel", "load model". 

In order to extract method bodies and other behavioural content, use the Antlr JavaParser.g4 parser to extract these elements, using an option such as: 

..\grun.bat Java statement -tree

or 

..\grun.bat Java methodDeclaration -tree

The result is an AST which can be incorporated into the UML model via the "Add Code" option in the KM3 editor. 

For example, input

"void m() { return 1; }"

for methodDeclaration gives the result: 

(methodDeclaration (typeTypeOrVoid void) m (formalParameters ( )) (methodBody (block { (blockStatement (statement return (expression (primary (literal (integerLiteral 1)))) ;)) })))

and input 

"xseq.add(p);"

for statement gives: 

(statement (expression (expression (primary xseq)) . (methodCall add ( (expressionList (expression (primary p))) ))) ;)


You can also incorporate entire classes using the "Add code" option with the parsed content of a Java class using the Antlr option: 

..\grun.bat Java classDeclaration -tree

An example of parsed content is: 

(classDeclaration class Person (classBody { (classBodyDeclaration (memberDeclaration (fieldDeclaration (typeType (primitiveType int)) (variableDeclarators (variableDeclarator (variableDeclaratorId age) = (variableInitializer (expression (primary (literal (integerLiteral 0))))))) ;))) (classBodyDeclaration (memberDeclaration (fieldDeclaration (typeType (classOrInterfaceType String)) (variableDeclarators (variableDeclarator (variableDeclaratorId name) = (variableInitializer (expression (primary (literal null)))))) ;))) (classBodyDeclaration (memberDeclaration (constructorDeclaration Person (formalParameters ( (formalParameterList (formalParameter (typeType (classOrInterfaceType String)) (variableDeclaratorId nme))) )) (block { (blockStatement (statement (expression (expression (primary name)) = (expression (primary nme))) ;)) })))) }))

