

import java.lang.reflect.*;
import java.io.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.filechooser.*;



public class Java2UML
{ static ArrayList appclasses = new ArrayList();
  static ArrayList apptypes = new ArrayList(); 

  private static void saveBasicTypes(PrintWriter out) 
  { out.println("Integer : PrimitiveType"); 
    out.println("Integer.name = \"int\""); 
    out.println("Long : PrimitiveType"); 
    out.println("Long.name = \"long\""); 
    out.println("Boolean : PrimitiveType"); 
    out.println("Boolean.name = \"boolean\""); 
    out.println("Real : PrimitiveType"); 
    out.println("Real.name = \"double\""); 
    out.println("String : PrimitiveType"); 
    out.println("String.name = \"String\""); 
    out.println("void : PrimitiveType"); 
    out.println("void.name = \"void\""); 
    out.println("SetType : CollectionType"); 
    out.println("SetType.name = \"Set\""); 
    out.println("SequenceType : CollectionType"); 
    out.println("SequenceType.name = \"Sequence\""); 
    out.println("MapType : CollectionType"); 
    out.println("MapType.name = \"Map\""); 
    out.println("FunctionType : CollectionType"); 
    out.println("FunctionType.name = \"Function\""); 
    out.println(); 
  }     

  public static boolean isSystemClass(String cname)
  { if (cname.length() > 3 && "java".equals(cname.substring(0,4) + ""))
    { return true; }
    if (cname.length() > 1 && '[' == cname.charAt(0))
    { return true; }
    if (cname.length() > 8 && "interface".equals(cname.substring(0,9) + ""))
    { return true; }
    return false; 
  }

  public static String type2UML(String t, PrintWriter out)
  { if ("java.lang.String".equals(t) || "java.lang.StringBuffer".equals(t) ||
        "java.lang.StringBuilder".equals(t))
     { return "String"; }

     if ("java.util.List".equals(t) || 
         "java.util.ArrayList".equals(t) || 
         "java.util.LinkedList".equals(t) || 
         "java.util.Queue".equals(t) || 
         "java.util.PriorityQueue".equals(t) || 
         "java.util.Vector".equals(t) || 
         // t.startsWith("java.util.List") || 
         t.charAt(0) == '[')
     { return "SequenceType"; }
     
	 if ("java.util.Set".equals(t) || "java.util.SortedSet".equals(t) || 
         "java.util.TreeSet".equals(t) ||
         "java.util.HashSet".equals(t))
     { return "SetType"; }
	 
     if ("java.util.Map".equals(t) || "java.util.SortedMap".equals(t) ||
         "java.util.Hashtable".equals(t) ||
         "java.util.TreeMap".equals(t) ||
         "java.util.HashMap".equals(t))
     { return "MapType"; }
	 // and distinguish sorted sets, Maps, also Functions. 
	 
     if ("void".equals(t))
     { return "void"; }

     if ("boolean".equals(t) || "java.lang.Boolean".equals(t))
     { return "Boolean"; }

     if ("int".equals(t) || "java.lang.Integer".equals(t))
     { return "Integer"; }

     if ("byte".equals(t) || "java.lang.Byte".equals(t))
     { return "Integer"; }

     if ("short".equals(t) || "java.lang.Short".equals(t))
     { return "Integer"; }

     if ("long".equals(t) || "java.lang.Long".equals(t))
     { return "Long"; }

     if ("double".equals(t) || "java.lang.Double".equals(t))
     { return "Real"; }

     if ("float".equals(t) || "java.lang.Float".equals(t))
     { return "Real"; }

     if ("char".equals(t) || "java.lang.Character".equals(t))
     { return "String"; }

	 // replace "." by "_"

	 String tt = t.replace(".", "_"); 
	 
	 if (apptypes.contains(tt) || appclasses.contains(tt)) { } 
	 else 
	 { apptypes.add(tt);
	   out.println(tt + " : Type"); 
	   out.println(tt + ".name = \"" + tt + "\"");
	 }
	 
     return tt;
  }
  
  public static void writeParameters(String mid, Class[] ptypes, PrintWriter out)
  { for (int i = 0; i < ptypes.length; i++)
    { Class pt = ptypes[i];
      String ptname = pt.getName();
      String parname = mid + "_" + i;
      out.println(parname + " : Property");
      out.println(parname + ".name = \"" + parname + "\"");
      out.println(parname + ".type = " + type2UML(ptname,out));
      out.println(parname + " : " + mid + ".parameters"); 
      if (pt.isPrimitive() ||
          isSystemClass(ptname)) { }
      else if (appclasses.contains(ptname)) {}
      else 
      { appclasses.add(ptname); 
        inspect(pt,ptname,out);
      }
    }
  }

  public static void writeAttributes(String c, Field fields[], PrintWriter out)
  { for (int i = 0; i < fields.length; i++)
    { Field f = fields[i];
      String fname = f.getName();
      String fid = c + "_" + fname;
      Class ftype = f.getType();
      String tname = ftype.getName();
      out.println(fid + " : Property");
      out.println(fid + ".name = \"" + fname + "\"");
      out.println(fid + ".type = " + type2UML(tname,out));
      out.println(fid + " : " + c + ".ownedAttribute");

      if ("java.util.List".equals(tname) || 
          "java.util.ArrayList".equals(tname) || 
          "java.util.Vector".equals(tname) || 
          ftype.isArray())
      { out.println(fid + ".lower = 0");
        out.println(fid + ".upper = -1"); 
        out.println(fid + ".isOrdered = true");
        Class ct = ftype.getComponentType();
        if (ct == null)
        { Type tt = f.getGenericType(); 
          if (tt != null && (tt instanceof ParameterizedType))
          { ParameterizedType typ = (ParameterizedType) tt;
            Type[] typeArguments = typ.getActualTypeArguments();
            if (typeArguments.length > 0 && 
                (typeArguments[0] instanceof Class))
            { Class typeArgClass = (Class) typeArguments[0];
              String gname = typeArgClass.getName(); 
              out.println(fid + ".elementType = " + type2UML(gname,out)); 
            } 
          }
        } 
        else 
        { String ctname = ct.getName(); 
          out.println(fid + ".elementType = " + type2UML(ctname,out)); 
           // create an association, if ct a class
           // not isSystemClass(ctname)
           // not ct.isPrimitive()
           // if ctname : appclasses { }
           // else appclasses.add(ctname); 
           //   inspect(ct,ctname,out);
         } // infer element type from ops
           // addf(X x) means element type is X
      }
      else if ("java.util.Set".equals(tname) || 
         "java.util.TreeSet".equals(tname) ||
         "java.util.HashSet".equals(tname))
      { out.println(fid + ".lower = 0");
        out.println(fid + ".upper = -1"); 
        out.println(fid + ".isOrdered = false");
        Class ct = ftype.getComponentType();
        if (ct == null)
        { Type tt = f.getGenericType(); 
          if (tt != null && (tt instanceof ParameterizedType))
          { ParameterizedType typ = (ParameterizedType) tt;
            Type[] typeArguments = typ.getActualTypeArguments();
            if (typeArguments.length > 0 && 
                (typeArguments[0] instanceof Class))
            { Class typeArgClass = (Class) typeArguments[0];
              String gname = typeArgClass.getName(); 
              out.println(fid + ".elementType = " + type2UML(gname,out)); 
            } 
          }
        } 
        else 
        { String ctname = ct.getName(); 
          out.println(fid + ".elementType = " + type2UML(ctname,out)); 
           // create an association, if ct a class
           // not isSystemClass(ctname)
           // not ct.isPrimitive()
           // if ctname : appclasses { }
           // else appclasses.add(ctname); 
           //   inspect(ct,ctname,out);
         } // infer element type from ops
           // addf(X x) means element type is X
      }
      else 
      { out.println(fid + ".lower = 1");
        out.println(fid + ".upper = 1");    
        int modifs = f.getModifiers();
        if ((Modifier.STATIC & modifs) == Modifier.STATIC)
        { out.println(fid + ".isStatic = true"); } 
        if (ftype.isPrimitive() ||
             isSystemClass(tname)) { }
        else
        { // association, and inspect
          String asname = c + "_" + fname + "_" + tname; 
          out.println(asname + " : Association");
          out.println(asname + ".name = \"" + asname + "\"");
          out.println(fid + " : " + asname + ".memberEnd");  // 2nd member end
          if (appclasses.contains(tname)) {}
          else 
          { appclasses.add(tname); 
            inspect(ftype,tname,out);
          }
        }
      } 
    }
  }

  public static void writeOperations(String c, Method methods[], PrintWriter out)
  { for (int i = 0; i < methods.length; i++)
    { Method m = methods[i];
      String mid = c + "_" + m.getName();
      out.println(mid + " : BehaviouralFeature");
      out.println(mid + ".name = \"" + m.getName() + "\"");
      Class[] ptypes = m.getParameterTypes();
      writeParameters(mid, ptypes, out); 
      // System.out.println(fid + ".lower = 1");
      // System.out.println(fid + ".upper = 1");          
      Class rtype = m.getReturnType();
      String rtname = rtype.getName();
      out.println(mid + ".type = " + type2UML(rtname,out));

      out.println(mid + " : " + c + ".ownedOperation");
      int modifs = m.getModifiers();
      if ((Modifier.STATIC & modifs) == Modifier.STATIC)
      { out.println(mid + ".isStatic = true"); } 
    }
  }

  public static void inspect(Class c, String cname, PrintWriter out)
  { if (isSystemClass(cname)) { return; }
    // if (appclasses.contains(cname)) { return; }
     
    appclasses.add(cname); 

    out.println(cname + " : Entity");
    out.println(cname + ".name = \"" + cname + "\"");
    Class superclass = c.getSuperclass();
    if (superclass != null)
    { String sname = superclass.getName();   
      if (isSystemClass(sname)) {}
      else
      { if (appclasses.contains(sname)) {}
        else 
        { appclasses.add(sname); 
          inspect(superclass,sname,out);
        }
        String gname = cname + "_" + sname;
        out.println(gname + " : Generalization");
        out.println(gname + ".name = \"" + gname + "\"");
        out.println(gname + ".general = " + sname);
        out.println(gname + ".specific = " + cname); 
      } // both classes must be already listed in model.txt by now
    } 
    // Only attributes and ops of c itself, not of superclasses:
    writeAttributes(cname, c.getDeclaredFields(),out);
    writeOperations(cname, c.getDeclaredMethods(),out);
  }

  public static void main(String[] args)
  { try 
    { JFileChooser fc = new JFileChooser();
      File startingpoint = new File(".");
      fc.setCurrentDirectory(startingpoint);
      fc.setDialogTitle("Select .class file");
      // fc.addChoosableFileFilter(new TextFileFilter()); 

      File file = null; 
	  
      int returnVal = fc.showOpenDialog(null);
      if (returnVal == JFileChooser.APPROVE_OPTION)
      { file = fc.getSelectedFile(); }
      else
      { System.err.println("Load aborted");
        return; 
      }
	  
	  if (file == null) { return; }
	  
      String nme = file.getName(); 

      int i = nme.length();
      String cname = nme.substring(0,i-6);
	  System.err.println(">>> Trying to load class: " + cname); 
	  
      Class c = Class.forName(cname);
      PrintWriter out = new PrintWriter(new File("model.txt"));
      saveBasicTypes(out); 
      inspect(c,cname,out);
      out.close();
	  System.err.println(">>> Written UML model to: model.txt"); 
	  
    } catch(Exception e)
      { System.err.println("Use as: java -jar java2uml.jar"); }
  }
}

/* public class Java2UML
{ static ArrayList appclasses = new ArrayList();

  public static boolean isSystemClass(String cname)
  { if ("java".equals(cname.substring(0,4) + ""))
    { return true; }
    if ('[' == cname.charAt(0))
    { return true; }
    return false; 
  }

  public static String type2UML(String t)
  { if ("java.lang.String".equals(t))
     { return "String"; }
     if ("java.util.List".equals(t) ||
          t.charAt(0) == '[')
     { return "Sequence"; }
     return t;
  }
  
  public static void writeAttributes(String c, Field fields[], PrintWriter out)
  { for (int i = 0; i < fields.length; i++)
    { Field f = fields[i];
      String fname = f.getName();
      String fid = c + "_" + fname;
      Class ftype = f.getType();
      String tname = ftype.getName();
      out.println(fid + " : Property");
      out.println(fid + ".name = " + fname);
      out.println(fid + ".type = " + type2UML(tname));
      out.println(fid + " : " + c + ".ownedAttribute");
      if ("java.util.List".equals(tname) ||
           ftype.isArray())
      { out.println(fid + ".lower = 0");
        out.println(fid + ".upper = -1"); 
        out.println(fid + ".isOrdered = true");
        Class ct = ftype.getComponentType();
        // if (ct == null)
        // { ct = f.getGenericType(); }
        if (ct != null)
        { String ctname = ct.getName(); 
           out.println(fid + ".elementType = " + type2UML(ctname)); 
           // create an association, if ct a class
           // not isSystemClass(ctname)
           // not ct.isPrimitive()
           // if ctname : appclasses { }
           // else appclasses.add(ctname); 
           //   inspect(ct,ctname,out);
         }
      }
      else  
      { out.println(fid + ".lower = 1");
        out.println(fid + ".upper = 1");    
        if (ftype.isPrimitive() ||
             isSystemClass(tname)) { }
        else
        { // association, and inspect
          String asname = c + "_" + fname + "_" + tname; 
          out.println(asname + " : Association");
          out.println(asname + ".name = \"" + asname + "\"");
          out.println(fid + " : " + asname + ".memberEnd");  // 2nd member end
          if (appclasses.contains(tname)) {}
          else 
          { appclasses.add(tname); 
            inspect(ftype,tname,out);
          }
        }
      } 
    }
  }

  public static void writeOperations(String c, Method methods[], PrintWriter out)
  { for (int i = 0; i < methods.length; i++)
    { Method m = methods[i];
      String mid = c + "_" + m.getName();
      out.println(mid + " : BehaviouralFeature");
     out.println(mid + ".name = " + m.getName());
      // System.out.println(fid + ".lower = 1");
      // System.out.println(fid + ".upper = 1");          
     Class rtype = m.getReturnType();
     String rtname = rtype.getName();
      out.println(mid + ".type = " + type2UML(rtname));

      out.println(mid + " : " + c + ".ownedOperation");
    }
  }

  public static void inspect(Class c, String cname, PrintWriter out)
  { if (isSystemClass(cname)) { return; }

    out.println(cname + " : Entity");
    out.println(cname + ".name = \"" + cname + "\"");
    Class superclass = c.getSuperclass();
    if (superclass != null)
    { String sname = superclass.getName();   
       if (isSystemClass(sname)) {}
       else
       { 
         String gname = cname + "_" + sname;
         out.println(gname + " : Generalization");
         out.println(gname + ".name = \"" + gname + "\"");
        out.println(gname + ".general = " + sname);
        out.println(gname + ".specific = " + cname); 
        if (appclasses.contains(sname)) {}
        else 
        { appclasses.add(sname); 
          inspect(superclass,sname,out);
        }
      }
    } 
    // Only attributes and ops of c itself, not of superclasses:
    writeAttributes(cname, c.getDeclaredFields(),out);
    writeOperations(cname, c.getDeclaredMethods(),out);
  }

  public static void main(String[] args)
  { try 
    { JFileChooser fc = new JFileChooser();
      File startingpoint = new File("..");
      fc.setCurrentDirectory(startingpoint);
      fc.setDialogTitle("Select .class file");
      // fc.addChoosableFileFilter(new TextFileFilter()); 

      int returnVal = fc.showOpenDialog(this);
      if (returnVal == JFileChooser.APPROVE_OPTION)
      { file = fc.getSelectedFile(); }
      else
      { System.err.println("Load aborted");
        return; 
      }
      String nme = file.getName(); 

      int i = nme.length();
      String cname = nme.substring(0,i-6);
      Class c = Class.forName(cname);
      PrintWriter out = new PrintWriter(new File("model.txt"));
      inspect(c,cname,out);
      out.close();
    } catch(Exception e)
      { e.printStackTrace(); 
        System.err.println("Use as: java -jar java2uml.jar File.class"); }
  }
}


*/ 
