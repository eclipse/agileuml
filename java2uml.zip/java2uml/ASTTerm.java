public abstract class ASTTerm
{ String id = ""; 

  public abstract String toString(); 
} 