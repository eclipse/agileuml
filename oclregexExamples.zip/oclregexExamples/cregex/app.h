struct Oclregex {
  char* id;
};

struct Oclregex** appendOclregex(struct Oclregex* col[], struct Oclregex* ex);

struct Oclregex* createOclregex(void);

struct Oclregex** insertOclregex(struct Oclregex* col[], struct Oclregex* self);

  struct Oclregex** subrangeOclregex(struct Oclregex** col, int i, int j);
  struct Oclregex** reverseOclregex(struct Oclregex* col[]);
struct Oclregex** removeOclregex(struct Oclregex* col[], struct Oclregex* ex);
struct Oclregex** removeAllOclregex(struct Oclregex* _col1[], struct Oclregex* _col2[]);

struct Oclregex** frontOclregex(struct Oclregex* _col[]);

struct Oclregex** tailOclregex(struct Oclregex* _col[]);

void oclregex(void);

/* Header code written to app.h                          */
/* Please note that empty structs are not valid in C,    */
/* any such structs and their operations can be deleted. */

