#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <regexp.h>


#define TRUE 1
#define FALSE 0

#include "ocl.h"

#include "app.h"

struct Oclregex** oclregex_instances = NULL;
int oclregex_size = 0;

struct Oclregex** newOclregexList()
{ return (struct Oclregex**) calloc(ALLOCATIONSIZE, sizeof(struct Oclregex*)); }

struct Oclregex** appendOclregex(struct Oclregex* col[], struct Oclregex* ex)
   { struct Oclregex** result;
     int len = length((void**) col);
     if (len % ALLOCATIONSIZE == 0)
     { result = (struct Oclregex**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct Oclregex*));
       int i = 0;
       for ( ; i < len; i++) { result[i] = col[i]; }
     }
    else { result = col; }
    result[len] = ex;
    result[len+1] = NULL;
    return result;
  }

struct Oclregex* createOclregex()
{ struct Oclregex* result = (struct Oclregex*) malloc(sizeof(struct Oclregex));
  oclregex_instances = appendOclregex(oclregex_instances, result);
  oclregex_size++;
  return result;
}

struct Oclregex** insertOclregex(struct Oclregex* col[], struct Oclregex* self)
  { if (isIn((void*) self, (void**) col))
    { return col; }
    return appendOclregex(col,self);
  }

  struct Oclregex** subrangeOclregex(struct Oclregex** col, int i, int j)
  { int len = length((void**) col);
    if (i > j || j > len) { return NULL; }
    struct Oclregex** result = (struct Oclregex**) calloc(j - i + 2, sizeof(struct Oclregex*));
     int k = i-1;
     int l = 0;
     for ( ; k < j; k++, l++)
     { result[l] = col[k]; }
    result[l] = NULL;
    return result;
  }

  struct Oclregex** reverseOclregex(struct Oclregex** col)
  { int n = length((void**) col);
    struct Oclregex** result = (struct Oclregex**) calloc(n+1, sizeof(struct Oclregex*));
    int i = 0;
    int x = n-1;
    for ( ; i < n; i++, x--)
    { result[i] = col[x]; }
    result[n] = NULL;
    return result;
  }

struct Oclregex** removeOclregex(struct Oclregex* col[], struct Oclregex* ex)
{ int len = length((void**) col);
  struct Oclregex** result = (struct Oclregex**) calloc(len+1, sizeof(struct Oclregex*));
  int j = 0;
  int i = 0;
  for ( ; i < len; i++)
  { struct Oclregex* eobj = col[i];
    if (eobj == NULL)
    { result[j] = NULL;
      return result; 
    }
    if (eobj == ex) { }
    else
    { result[j] = eobj; j++; }
  }
  result[j] = NULL;
  return result;
}

struct Oclregex** removeAllOclregex(struct Oclregex* col1[], struct Oclregex* col2[])
{ int n = length((void**) col1);
  struct Oclregex** result = (struct Oclregex**) calloc(n+1, sizeof(struct Oclregex*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { struct Oclregex* ex = col1[i];
    if (isIn((void*) ex, (void**) col2)) {}
    else 
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

int** removeAllint(int* col1[], int* col2[])
{ int n = length((void**) col1);
  int** result = (int**) calloc(n+1, sizeof(int*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { int* ex = col1[i];
    if (isInint(*ex, col2)) {}
    else 
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

long** removeAlllong(long* col1[], long* col2[])
{ int n = length((void**) col1);
  long** result = (long**) calloc(n+1, sizeof(long*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { long* ex = col1[i];
    if (isInlong(*ex, col2)) {}
    else 
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

double** removeAlldouble(double* col1[], double* col2[])
{ int n = length((void**) col1);
  double** result = (double**) calloc(n+1, sizeof(double*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { double* ex = col1[i];
    if (isIndouble(*ex, col2)) {}
    else 
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

struct Oclregex** frontOclregex(struct Oclregex* col[])
{ int n = length((void**) col);
  return subrangeOclregex(col, 1, n-1); }

struct Oclregex** tailOclregex(struct Oclregex* col[])
{ int n = length((void**) col);
  return subrangeOclregex(col, 2, n); }

void oclregex(void)
{  /* displaySequence( */ 
   allMatches("a long series of identifiers, to be divided into words.\n Now is the winter of our discontent made glorious summer by this son of York.\n\nTo be or not to be, that is the question. Whether tis nobler in the heart to bear the slings and arrows of outrageous fortune, or by taking arms against a sea of troubles\n ... Alas poor Yorick, I knew him well\n ... Clear away the bodies ... a scene such as this\n becomes the field, but here denotes much amis.", "[a-zA-Z]+"); 
  /* );
  displayString(replaceAllMatches("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", "\\([^\\(\\)]*\\)", "-LRB--RRB-"));
  displayString(firstMatch("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", "\\([^\\(\\)]*\\)"));
  displayString(replaceFirstMatch("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", "\\([^\\(\\)]*\\)", "-LRB--RRB-")); */ 
}

int main(int _argc, char* _argv[])
{ int i = 0; 

  clock_t tt0  = clock();
  long time1 = (tt0/(CLOCKS_PER_SEC/1000));

  for ( ; i < 100000; i++)
  { oclregex(); } 
 
  clock_t tt  = clock();
  long time2 = (tt/(CLOCKS_PER_SEC/1000));
  printf("Time = %d\n", (time2 - time1) );

  return 0; 
}


/* Delete operations for empty structs. Maps must have 
   String domain type.                                               */
