import ocl
import math

from enum import Enum
from time import *


def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)

def displaySequence(x):
  print(x)

def displaySet(x):
  print(x)

def displayMap(x):
  print(x)


class Oclregex:
  oclregex_instances = []
  oclregex_index = dict({})

  def __init__(self):
    Oclregex.oclregex_instances.append(self)


def createOclregex():
  oclregex = Oclregex()
  return oclregex

def allInstances_Oclregex():
  return Oclregex.oclregex_instances


def oclregex() :
  d1 = time()
  for i in range(100000) : 
    ocl.allMatches("a long series of identifiers, to be divided into words.\n Now is the winter of our discontent made glorious summer by this son of York.\n\nTo be or not to be, that is the question. Whether tis nobler in the heart to bear the slings and arrows of outrageous fortune, or by taking arms against a sea of troubles\n ... Alas poor Yorick, I knew him well\n ... Clear away the bodies ... a scene such as this\n becomes the field, but here denotes much amis.", "[a-zA-Z]+")
  d2 = time()
  print(str((d2 - d1)*1000))
  

def oclregex2() : 
  d1 = time()
  for i in range(100000) : 
    ocl.replaceAllMatches("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", "\\([^\\(\\)]*\\)", "-LRB--RRB-")
  d2 = time()
  print(str((d2 - d1)*1000))

  
## displayString(ocl.firstMatch("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", "\\([^\\(\\)]*\\)"))

## displayString(ocl.replaceFirstMatch("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", "\\([^\\(\\)]*\\)", "-LRB--RRB-"))



oclregex()
oclregex2()

