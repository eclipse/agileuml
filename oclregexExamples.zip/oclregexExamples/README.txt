These folders contain the Java, Swift, C++, C#, Python and C implementations of the regex example in mm.txt

