// ConsoleApplication20.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <time.h>

// Controller.cc
#include <string>
#include <vector>
#include <set>
#include <map>
#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <regex>
#include "controller.h"

using namespace std;

Controller* Controller::inst = new Controller();



    void Oclregex::oclregex()
  { {} // No update form for: true
  }

  void Controller::loadModel()
  { ifstream infle("in.txt");
    if (infle.fail()) { cout << "No input file!" << endl; return; }
    string* str = new string("");
    vector<string>* res = new vector<string>();
    while (!infle.eof())
    { std::getline(infle,*str);
      vector<string>* words = UmlRsdsLib<string>::tokenise(res,*str);
      if (words->size() == 3 && (*words)[1] == ":")  // a : A
      { addObjectToClass((*words)[0], (*words)[2]); }
      else if (words->size() == 4 && (*words)[1] == ":") // a : b.role
      { addObjectToRole((*words)[2], (*words)[0], (*words)[3]); }
      else if (words->size() >= 4 && (*words)[2] == "=")  // a.f = val
      { int eqind = str->find("=");
        if (eqind < 0) { continue; }
        int f1ind = str->find_first_of("\"");
        int f2ind = str->find_last_of("\"");
        string value;
        if (f1ind != string::npos && f2ind != string::npos)
        { value = str->substr(f1ind, f2ind-f1ind+1); }
        else if (words->size() == 4)
        { value = (*words)[3]; }
        else if (words->size() == 5)
        { value = (*words)[3] + "." + (*words)[4]; }
        setObjectFeatureValue((*words)[0], (*words)[1], value);
      }
      res->clear();
    }
  }

  void Controller::addObjectToClass(string a, string c)
  { if (c == "Oclregex")
    { Oclregex* oclregexx = new Oclregex();
       objectmap[a] = oclregexx;
       classmap[a] = c;
       addOclregex(oclregexx);
      return;
    }
  }

  void Controller::addObjectToRole(string a, string b, string role)
  { }

  void Controller::setObjectFeatureValue(string a, string f, string val)
  { }


  void Controller::saveModel(string f)
  { ofstream outfile(f.c_str()); 
  for (int _i = 0; _i < oclregex_s->size(); _i++)
  { Oclregex* oclregexx_ = (*oclregex_s)[_i];
    outfile << "oclregexx_" << (_i+1) << " : Oclregex" << endl;
  }


  }



  void Controller::oclregex(Oclregex* oclregexx)
  {   oclregexx->oclregex();
   }

   vector<void*>* Controller::AllOclregexoclregex(vector<Oclregex*>* oclregexxs)
  { 
    vector<void*>* result = new vector<void*>();
    for (int _i = 0; _i < oclregexxs->size(); _i++)
    { Oclregex* oclregexx = (*oclregexxs)[_i];
      oclregex(oclregexx);
    }
    return result; 
  }

   vector<void*>* Controller::AllOclregexoclregex(set<Oclregex*>* oclregexxs)
  { 
    vector<void*>* result = new vector<void*>();
    for (set<Oclregex*>::iterator _i = oclregexxs->begin(); _i != oclregexxs->end(); _i++)
    { Oclregex* oclregexx = *_i;
      oclregex(oclregexx);
    }
    return result; 
  }



  void Controller::oclregex() 
  { 

      vector<string>* res = UmlRsdsLib<string>::allMatches("a long series of identifiers, to be divided into words.\n Now is the winter of our discontent made glorious summer by this son of York.\n\nTo be or not to be, that is the question. Whether tis nobler in the heart to bear the slings and arrows of outrageous fortune, or by taking arms against a sea of troubles\n ... Alas poor Yorick, I knew him well\n ... Clear away the bodies ... a scene such as this\n becomes the field, but here denotes much amis.", "[a-zA-Z]+");

	   /* for (int i = 0; i < res->size(); i++) 
	   { string vv = res->at(i); 
	     cout << vv << "; "; 
	   } 
	   cout << endl; */ 

       // UmlRsdsLib<string>::replaceAll("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses","\\([^\\(\\)]*\\)","-LRB--RRB-");

	   /*
       cout << UmlRsdsLib<string>::firstMatch("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", "\\([^\\(\\)]*\\)") << endl;

       cout << UmlRsdsLib<string>::replaceFirstMatch("sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses","\\([^\\(\\)]*\\)","-LRB--RRB-") << endl;
	   */ 

  }


int _tmain(int argc, _TCHAR* argv[])
{   Controller* c = Controller::inst;

    clock_t tt0  = clock();
    long time1 = (tt0/(CLOCKS_PER_SEC/1000));
    // printf("Time0 = %d\n", time1 );

	for (int i = 0; i < 1000; i++) 
	{ c->oclregex(); } 

	clock_t tt  = clock();
    long time2 = (tt/(CLOCKS_PER_SEC/1000));
    printf("Time = %d\n", (time2 - time1) ); 

	return 0;
}

