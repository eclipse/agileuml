//
//  ContentView.swift
//  app2swiftui
//
//  Created by Kevin Lano on 30/11/2020.
//

import SwiftUI

struct ContentView: View {
    @State var bean : ComputeBMIVO = ComputeBMIVO()
    @ObservedObject var model : ModelFacade
    
    
    var body: some View {
        TabView {
            computeBMIScreen(model: model).tabItem
          { Image(systemName: "1.square.fill")
            Text("ComputeBMI")
          }
            calorieCountScreen(model: model).tabItem
          { Image(systemName: "2.square.fill")
            Text("CalorieCount")
          }
        }.font(.headline)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(model: ModelFacade.getInstance())
    }
}
