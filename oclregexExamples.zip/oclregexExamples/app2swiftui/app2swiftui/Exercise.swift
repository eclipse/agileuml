//
//  Exercise.swift
//  app2swiftui
//
//  Created by Kevin Lano on 01/12/2020.
//

import Foundation

enum Exercise : String {   case walking
   case jogging
   case running
   case swimming
   case weights }


