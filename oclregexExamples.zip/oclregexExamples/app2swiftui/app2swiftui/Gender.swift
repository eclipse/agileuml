//
//  Gender.swift
//  app2swiftui
//
//  Created by Kevin Lano on 01/12/2020.
//

import Foundation

enum Gender : String {   case male
   case female }


