//
//  ModelFacade.swift
//  app2swiftui
//
//  Created by Kevin Lano on 30/11/2020.
//

import Foundation

import Darwin
import Combine
import SwiftUI
import CoreLocation

class ModelFacade : ObservableObject
{ static var instance : ModelFacade? = nil
  // var fileSystem : FileAccessor = FileAccessor()


  static func getInstance() -> ModelFacade
  { if instance == nil
    { instance = ModelFacade() }
    return instance! }


  init() { }

    func displayString(_ s : String)
    { print(s) }

    func displaySequence(_ s : [String])
    { print(s) }

    func test1(s1 : String, s2 : String) -> Void
    {
      displayString(_: ("Trim: " + Ocl.trim(str: s1)))
      displayString(_: ("Last index of: " + String(Ocl.lastIndexOf(s: s1, d: s2))))
      displayString(_: ("Equals ignore case: " + String(Ocl.equalsIgnoreCase(s1: s1, s2: s2))))

    }


    func test2(s1 : String, s2 : String) -> Void
    {
      displayString(_: ("Is match: " + String(Ocl.isMatch(str: s1, pattern: s2))))
      displayString(_: ("Has match: " + String(Ocl.hasMatch(str: s1, pattern: s2))))
      displayString(_: ("All matches: " + String(describing: Ocl.allMatches(str: s1, pattern: s2))))

    }


    func test3(s1 : String, s2 : String, rep : String) -> Void
    {
      displayString(_: ("Replace: " + Ocl.replace(str: s1, delim: s2, s2: rep)))

    }


    func test4(s1 : String, s2 : String, rep : String) -> Void
    {
      displayString(_: ("Split: " + String(describing: Ocl.split(str: s1, pattern: s2))))
      displayString(_: ("Replace all: " + Ocl.replaceAll(str: s1, pattern: s2, rep: rep)))

    }

    
  func cancelcomputeBMI()
  { let s = ["aa", "bb", "cc", "bb", "dd" ]
    let t = "bb"
    var result : [String] = []
    print(Ocl.indexOfSequence(sq: s, x: t))
    
    print(Ocl.lastIndexOfSequence(sq: s, x: t))
    result = Ocl.copySequence(s: Ocl.subrange(s: s, st: 4, en: 4))
    print(result)
    
    let s1 = ["aa", "bb", "cc", "bb", "cc"]
    let s2 : [String] = ["aa", "bb", "cc", "bb", "cc"]
    
    print(Ocl.indexOfSubSequence(sq: s1, sq1: s2))
    print(Ocl.lastIndexOfSubSequence(sq: s1, sq1: s2))
    
    // test1(s1: " a*long*string", s2: "string")
    // test2(s1: "a*long*string", s2: "[a-z]+")
    // test3(s1: "a long string", s2: " ", rep: "**")
    // test4(s1: "a~~long+string", s2: "[a-z]+", rep: "**")
  }

    func oclregex()
    {
      /* displaySequence(_: (
        Ocl.allMatches(str: "a long series of identifiers, to be divided into words.\n Now is the winter of our discontent made glorious summer by this son of York.\n\nTo be or not to be, that is the question. Whether tis nobler in the heart to bear the slings and arrows of outrageous fortune, or by taking arms against a sea of troubles\n ... Alas poor Yorick, I knew him well\n ... Clear away the bodies ... a scene such as this\n becomes the field, but here denotes much amis.", pattern: "[a-zA-Z]+")
         ))
      */
        
         // displayString(_:
              Ocl.replaceAll(str: "sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", pattern: "\\([^\\(\\)]*\\)", rep: "-LRB--RRB-")
        
        /* displayString(_: Ocl.firstMatch(str: "sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", pattern: "\\([^\\(\\)]*\\)") ?? "no match")
      displayString(_: Ocl.replaceFirstMatch(str: "sentence (with) (subclauses) to (be summarised), including (nested (subclauses)) and incorrect (subclauses", pattern: "\\([^\\(\\)]*\\)", rep: "-LRB--RRB-"))
        */
    }

  func computeBMI(_x : ComputeBMIVO) -> Double
  {
    /* let text = "a long piece of text88"
    let pattern = " "

    let regex = try! NSRegularExpression(pattern: pattern)

    let modText = regex.stringByReplacingMatches(in: text, options: [], range: NSRange(location: 0, length: text.count), withTemplate: "***") as NSString

    print(modText)
    */
    
    let t1 = CFAbsoluteTimeGetCurrent()

    for i in 1...100
    { oclregex() }
    
    var t2 = CFAbsoluteTimeGetCurrent()
      print(t2 - t1)
    
    
    var result : Double = 0.0
    if _x.iscomputeBMIerror()
    { return result }
    let height : Double = _x.getheight()
    let weight : Double = _x.getweight()

    result = weight / ( height*height)

    _x.setresult(_x: result)
    return result
  }

  func cancelcalorieCount() { }

  func calorieCount(_x : calorieCountVO) -> Double
  {
    var result : Double = 0.0
    if _x.iscalorieCounterror()
    { return result }
    let gender : Gender = _x.getgender()
    let exercise : Exercise = _x.getexercise()
    let time : Double = _x.gettime()

    var factor : Double = 0
    factor = 1
    if exercise == Exercise.walking
    {
      factor = 100
    }
    else {
      if exercise == Exercise.running
    {
      factor = 300
    }
    else {
      if exercise == Exercise.jogging
    {
      factor = 200
    }
    else {
      factor = 250
    }
    }
    }
    result =  factor*(time/Double(60))

    _x.setresult(_x: result)
    return result
  } 


}
