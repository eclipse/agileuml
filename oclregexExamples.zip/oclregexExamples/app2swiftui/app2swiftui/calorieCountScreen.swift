//
//  calorieCountScreen.swift
//  app2swiftui
//
//  Created by Kevin Lano on 01/12/2020.
//

import SwiftUI

struct calorieCountScreen: View {
    
    @ObservedObject var model : ModelFacade
    
    @State var bean1 : calorieCountVO = calorieCountVO()
    @State var res1 : Double = 0.0
    
    
    var body: some View {
        VStack(alignment: .leading) {
          Picker("Gender", selection: $bean1.gender) {
            Text("male").tag(Gender.male)
            Text("female").tag(Gender.female)
          }.frame(width:200, height: 100).border(Color.gray)
            
          Picker("Exercise", selection: $bean1.exercise) {
            Text("walking").tag(Exercise.walking)
            Text("jogging").tag(Exercise.jogging)
            Text("running").tag(Exercise.running)
            Text("swimming").tag(Exercise.swimming)
            Text("weights").tag(Exercise.weights)
          }.frame(width: 200, height: 100).border(Color.gray)
            
          HStack {
            Text("Time:").bold()
            Divider()
            TextField("Time", value: $bean1.time, formatter: NumberFormatter()).keyboardType(.decimalPad)
          }.frame(width:150, height: 30).border(Color.gray)
        

          HStack(spacing: 20)
          { Button(action: { self.model.cancelcalorieCount() } ) { Text("Cancel") }
            Button(action: { res1 = self.model.calorieCount(_x: bean1) } ) { Text("CalorieCount") }
          }.buttonStyle(DefaultButtonStyle())
          HStack(spacing: 20) {
            Text("Result:")
            Text(String(res1))
          }
        }.padding(.top)
        
    }
}

struct calorieCountScreen_Previews: PreviewProvider {
    static var previews: some View {
        calorieCountScreen(model: ModelFacade.getInstance())
    }
}
