package app;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

public interface ControllerInterface
{
  public void addOclregex(Oclregex oo);
    public void killOclregex(Oclregex oclregexxx);
}

