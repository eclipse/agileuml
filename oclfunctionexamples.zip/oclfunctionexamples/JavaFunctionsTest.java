import java.util.List;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

import java.lang.*;
import java.lang.reflect.*;
import java.util.StringTokenizer;
import java.io.*;



class SomeFunctions
  implements SystemTypes
{

  public SomeFunctions()
  {

  }



  public String toString()
  { String _res_ = "(SomeFunctions) ";
    return _res_;
  }

  public static SomeFunctions parseCSV(String _line)
  { if (_line == null) { return null; }
    Vector _line1vals = Set.tokeniseCSV(_line);
    SomeFunctions somefunctionsx = new SomeFunctions();
    return somefunctionsx;
  }


  public void writeCSV(PrintWriter _out)
  { SomeFunctions somefunctionsx = this;
    _out.println();
  }


    public static double quad(double x)
  {   double result = 0;
 
  result = x * x + x - 1;
    return result;
  }


    public static double xpow(double x)
  {   double result = 0;
 
  result = Math.pow(x,x) - 0.7;
    return result;
  }


    public static double secant(double rn,double rminus,double fminus,double tol,Evaluation<Double, Double> f)
  {   double result = 0;
 
  final double fn = f.evaluate(rn); 
    // System.out.println(">>> result for " + rn + " = " + fn); 
	
         if (Math.abs(fn) < tol) { result = rn; }
    else { result = SomeFunctions.secant(rn - fn * ( ( rn - rminus ) / ( fn - fminus ) ),rn,fn,tol,f); }
         return result;
  }



}



public class Controller implements SystemTypes, ControllerInterface
{
  Vector somefunctionss = new Vector();
  private static Controller uniqueInstance; 


  private Controller() { } 


  public static Controller inst() 
    { if (uniqueInstance == null) 
    { uniqueInstance = new Controller(); }
    return uniqueInstance; } 


  public static void loadModel(String file)
  {
    try
    { BufferedReader br = null;
      File f = new File(file);
      try 
      { br = new BufferedReader(new FileReader(f)); }
      catch (Exception ex) 
      { System.err.println("No file: " + file); return; }
      Class cont = Class.forName("Controller");
      java.util.Map objectmap = new java.util.HashMap();
      while (true)
      { String line1;
        try { line1 = br.readLine(); }
        catch (Exception e)
        { return; }
        if (line1 == null)
        { return; }
        line1 = line1.trim();

        if (line1.length() == 0) { continue; }
        if (line1.startsWith("//")) { continue; }
        String left;
        String op;
        String right;
        if (line1.charAt(line1.length() - 1) == '"')
        { int eqind = line1.indexOf("="); 
          if (eqind == -1) { continue; }
          else 
          { left = line1.substring(0,eqind-1).trim();
            op = "="; 
            right = line1.substring(eqind+1,line1.length()).trim();
          }
        }
        else
        { StringTokenizer st1 = new StringTokenizer(line1);
          Vector vals1 = new Vector();
          while (st1.hasMoreTokens())
          { String val1 = st1.nextToken();
            vals1.add(val1);
          }
          if (vals1.size() < 3)
          { continue; }
          left = (String) vals1.get(0);
          op = (String) vals1.get(1);
          right = (String) vals1.get(2);
        }
        if (":".equals(op))
        { int i2 = right.indexOf(".");
          if (i2 == -1)
          { Class cl;
            try { cl = Class.forName("" + right); }
            catch (Exception _x) { System.err.println("No entity: " + right); continue; }
            Object xinst = cl.newInstance();
            objectmap.put(left,xinst);
            Class[] cargs = new Class[] { cl };
            Method addC = null;
            try { addC = cont.getMethod("add" + right,cargs); }
            catch (Exception _xx) { System.err.println("No entity: " + right); continue; }
            if (addC == null) { continue; }
            Object[] args = new Object[] { xinst };
            addC.invoke(Controller.inst(),args);
          }
          else
          { String obj = right.substring(0,i2);
            String role = right.substring(i2+1,right.length());
            Object objinst = objectmap.get(obj); 
            if (objinst == null) 
            { continue; }
            Object val = objectmap.get(left);
            if (val == null) 
            { continue; }
            Class objC = objinst.getClass();
            Class typeclass = val.getClass(); 
            Object[] args = new Object[] { val }; 
            Class[] settypes = new Class[] { typeclass };
            Method addrole = Controller.findMethod(objC,"add" + role);
            if (addrole != null) 
            { addrole.invoke(objinst, args); }
            else { System.err.println("Error: cannot add to " + role); }
          }
        }
        else if ("=".equals(op))
        { int i1 = left.indexOf(".");
          if (i1 == -1) 
          { continue; }
          String obj = left.substring(0,i1);
          String att = left.substring(i1+1,left.length());
          Object objinst = objectmap.get(obj); 
          if (objinst == null) 
          { System.err.println("No object: " + obj); continue; }
          Class objC = objinst.getClass();
          Class typeclass; 
          Object val; 
          if (right.charAt(0) == '"' &&
              right.charAt(right.length() - 1) == '"')
          { typeclass = String.class;
            val = right.substring(1,right.length() - 1);
          } 
          else if ("true".equals(right) || "false".equals(right))
          { typeclass = boolean.class;
            if ("true".equals(right))
            { val = new Boolean(true); }
            else
            { val = new Boolean(false); }
          }
          else 
          { val = objectmap.get(right);
            if (val != null)
            { typeclass = val.getClass(); }
            else 
            { int i;
              long l; 
              double d;
              try 
              { i = Integer.parseInt(right);
                typeclass = int.class;
                val = new Integer(i); 
              }
              catch (Exception ee)
              { try 
                { l = Long.parseLong(right);
                  typeclass = long.class;
                  val = new Long(l); 
                }
                catch (Exception eee)
                { try
                  { d = Double.parseDouble(right);
                    typeclass = double.class;
                    val = new Double(d);
                  }
                  catch (Exception ff)
                  { continue; }
                }
              }
            }
          }
          Object[] args = new Object[] { val }; 
          Class[] settypes = new Class[] { typeclass };
          Method setatt = Controller.findMethod(objC,"set" + att);
          if (setatt != null) 
          { setatt.invoke(objinst, args); }
          else { System.err.println("No attribute: " + objC.getName() + "::" + att); }
        }
      }
    } catch (Exception e) { }
  }

  public static Method findMethod(Class c, String name)
  { Method[] mets = c.getMethods(); 
    for (int i = 0; i < mets.length; i++)
    { Method m = mets[i];
      if (m.getName().equals(name))
      { return m; }
    } 
    return null;
  }


  public static void loadCSVModel()
  { boolean __eof = false;
    String __s = "";
    Controller __cont = Controller.inst();
    BufferedReader __br = null;
    try
    { File _somefunctions = new File("SomeFunctions.csv");
      __br = new BufferedReader(new FileReader(_somefunctions));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { SomeFunctions somefunctionsx = SomeFunctions.parseCSV(__s.trim());
          if (somefunctionsx != null)
          { __cont.addSomeFunctions(somefunctionsx); }
        }
      }
    }
    catch(Exception __e) { }
  }


  public void checkCompleteness()
  {   }


  public void saveModel(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
  for (int _i = 0; _i < somefunctionss.size(); _i++)
  { SomeFunctions somefunctionsx_ = (SomeFunctions) somefunctionss.get(_i);
    out.println("somefunctionsx_" + _i + " : SomeFunctions");
  }

    out.close(); 
  }


  public static void loadXSI()
  { boolean __eof = false;
    String __s = "";
    String xmlstring = "";
    BufferedReader __br = null;
    try
    { File _classmodel = new File("in.xmi");
      __br = new BufferedReader(new FileReader(_classmodel));
      __eof = false;
      while (!__eof)
      { try { __s = __br.readLine(); }
        catch (IOException __e)
        { System.out.println("Reading failed.");
          return;
        }
        if (__s == null)
        { __eof = true; }
        else
        { xmlstring = xmlstring + __s; }
      } 
      __br.close();
    } 
    catch (Exception _x) { }
    Vector res = convertXsiToVector(xmlstring);
    File outfile = new File("_in.txt");
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    for (int i = 0; i < res.size(); i++)
    { String r = (String) res.get(i); 
      out.println(r);
    } 
    out.close();
    loadModel("_in.txt");
  }

  public static Vector convertXsiToVector(String xmlstring)
  { Vector res = new Vector();
    XMLParser comp = new XMLParser();
    comp.nospacelexicalanalysisxml(xmlstring);
    XMLNode xml = comp.parseXML();
    if (xml == null) { return res; } 
    java.util.Map instancemap = new java.util.HashMap(); // String --> Vector
    java.util.Map entmap = new java.util.HashMap();       // String --> String
    Vector entcodes = new Vector(); 
    java.util.Map allattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map stringattsmap = new java.util.HashMap(); // String --> Vector
    java.util.Map onerolesmap = new java.util.HashMap(); // String --> Vector
    java.util.Map actualtype = new java.util.HashMap(); // XMLNode --> String
    Vector eallatts = new Vector();
    instancemap.put("somefunctionss", new Vector()); 
    instancemap.put("somefunctions",new Vector()); 
    entcodes.add("somefunctionss");
    entcodes.add("somefunctions");
    entmap.put("somefunctionss","SomeFunctions");
    entmap.put("somefunctions","SomeFunctions");
    eallatts = new Vector();
    allattsmap.put("SomeFunctions", eallatts);
    eallatts = new Vector();
    stringattsmap.put("SomeFunctions", eallatts);
    eallatts = new Vector();
    onerolesmap.put("SomeFunctions", eallatts);
    eallatts = new Vector();
  Vector enodes = xml.getSubnodes();
  for (int i = 0; i < enodes.size(); i++)
  { XMLNode enode = (XMLNode) enodes.get(i);
    String cname = enode.getTag();
    Vector einstances = (Vector) instancemap.get(cname); 
    if (einstances == null) 
    { einstances = (Vector) instancemap.get(cname + "s"); }
    if (einstances != null) 
    { einstances.add(enode); }
  }
  for (int j = 0; j < entcodes.size(); j++)
  { String ename = (String) entcodes.get(j);
    Vector elems = (Vector) instancemap.get(ename);
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = enode.getAttributeValue("xsi:type"); 
      if (tname == null) 
      { tname = (String) entmap.get(ename); } 
      else 
      { int colonind = tname.indexOf(":"); 
        if (colonind >= 0)
        { tname = tname.substring(colonind + 1,tname.length()); }
      }
      res.add(ename + k + " : " + tname);
      actualtype.put(enode,tname);
    }   
  }
  for (int j = 0; j < entcodes.size(); j++) 
  { String ename = (String) entcodes.get(j); 
    Vector elems = (Vector) instancemap.get(ename); 
    for (int k = 0; k < elems.size(); k++)
    { XMLNode enode = (XMLNode) elems.get(k);
      String tname = (String) actualtype.get(enode);
      Vector tallatts = (Vector)  allattsmap.get(tname);
      Vector tstringatts = (Vector)  stringattsmap.get(tname);
      Vector toneroles = (Vector)  onerolesmap.get(tname);
      Vector atts = enode.getAttributes();
      for (int p = 0; p < atts.size(); p++) 
      { XMLAttribute patt = (XMLAttribute) atts.get(p); 
        if (patt.getName().equals("xsi:type") || patt.getName().equals("xmi:id")) {} 
        else 
        { patt.getDataDeclarationFromXsi(res,tallatts,tstringatts,toneroles,ename + k, (String) entmap.get(ename)); } 
      }
    } 
  }  
  return res; } 

  public void saveXSI(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    out.println("<UMLRSDS:model xmi:version=\"2.0\" xmlns:xmi=\"http://www.omg.org/XMI\">");
    for (int _i = 0; _i < somefunctionss.size(); _i++)
    { SomeFunctions somefunctionsx_ = (SomeFunctions) somefunctionss.get(_i);
       out.print("<somefunctionss xsi:type=\"My:SomeFunctions\"");
    out.println(" />");
  }

    out.println("</UMLRSDS:model>");
    out.close(); 
  }


  public void saveCSVModel()
  { try {
      File _somefunctions = new File("SomeFunctions.csv");
      PrintWriter _out_somefunctions = new PrintWriter(new BufferedWriter(new FileWriter(_somefunctions)));
      for (int __i = 0; __i < somefunctionss.size(); __i++)
      { SomeFunctions somefunctionsx = (SomeFunctions) somefunctionss.get(__i);
        somefunctionsx.writeCSV(_out_somefunctions);
      }
      _out_somefunctions.close();
    }
    catch(Exception __e) { }
  }



  public void addSomeFunctions(SomeFunctions oo) { somefunctionss.add(oo); }



  public SomeFunctions createSomeFunctions()
  { SomeFunctions somefunctionsx = new SomeFunctions();
    addSomeFunctions(somefunctionsx);
    return somefunctionsx;
  }





  public void killAllSomeFunctions(List somefunctionsxx)
  { for (int _i = 0; _i < somefunctionsxx.size(); _i++)
    { killSomeFunctions((SomeFunctions) somefunctionsxx.get(_i)); }
  }

  public void killSomeFunctions(SomeFunctions somefunctionsxx)
  { if (somefunctionsxx == null) { return; }
   somefunctionss.remove(somefunctionsxx);
  }


  public static void main(String[] args)
  { Date d1 = new Date(); 
    long t1 = d1.getTime(); 
	
	for (int i = 0; i < 5000; i++)
    { Evaluation<Double, Double> f = (x) -> { return SomeFunctions.quad(x); };
      double rn = 0.5; 
	  double rminus = 0.2; 
	  double fminus = f.evaluate(rminus); 
	  double tol = 0.000001;  
      SomeFunctions.secant(rn,rminus,fminus,tol,f); 
	
	  Evaluation<Double, Double> f1 = (x) -> { return SomeFunctions.xpow(x); };
      double rn1 = 0.5; 
	  double rminus1 = 0.2; 
	  double fminus1 = f1.evaluate(rminus1); 
	  double tol1 = 0.000001;  
      SomeFunctions.secant(rn1,rminus1,fminus1,tol1,f1);
	} 
	
	Date d2 = new Date(); 
    long t2 = d2.getTime(); 
	System.out.println(">> time = " + (t2 - t1)); 
  }

   
}



