import Foundation
import Darwin

class ModelFacade
{ static var instance : ModelFacade? = nil


  static func getInstance() -> ModelFacade
  { if (instance == nil)
    { instance = ModelFacade() }
    return instance! }

  init() { }

  func testFunctions()
  { 
    var rn : Double = 0.0
    rn = 0.5
    var rminus : Double = 0.0
    rminus = 0.2
    var fminus : Double = 0.0
    fminus = SomeFunctions.quad(x: rminus)
    var res : Double = 0.0
    res = SomeFunctions.secant(rn: rn, rminus: rminus, fminus: fminus, tol: 0.001, f: { (z : Double) -> Double in  z*z + z - 1 })
    displaydouble(_: res)

  }


}
