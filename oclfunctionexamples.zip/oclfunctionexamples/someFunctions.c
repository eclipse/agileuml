#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#define ALLOCATIONSIZE 10

#define TRUE 1
#define FALSE 0

#include "ocl.h"

#include "app.h"

struct SomeFunctions** somefunctions_instances = NULL;
int somefunctions_size = 0;

struct TestFunctions** testfunctions_instances = NULL;
int testfunctions_size = 0;

struct SomeFunctions** newSomeFunctionsList()
{ return (struct SomeFunctions**) calloc(ALLOCATIONSIZE, sizeof(struct SomeFunctions*)); }

struct TestFunctions** newTestFunctionsList()
{ return (struct TestFunctions**) calloc(ALLOCATIONSIZE, sizeof(struct TestFunctions*)); }

struct SomeFunctions** appendSomeFunctions(struct SomeFunctions* col[], struct SomeFunctions* ex)
   { struct SomeFunctions** result;
     int len = length((void**) col);
     if (len % ALLOCATIONSIZE == 0)
     { result = (struct SomeFunctions**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct SomeFunctions*));
       int i = 0;
       for ( ; i < len; i++) { result[i] = col[i]; }
     }
    else { result = col; }
    result[len] = ex;
    result[len+1] = NULL;
    return result;
  }

struct TestFunctions** appendTestFunctions(struct TestFunctions* col[], struct TestFunctions* ex)
   { struct TestFunctions** result;
     int len = length((void**) col);
     if (len % ALLOCATIONSIZE == 0)
     { result = (struct TestFunctions**) calloc(len + ALLOCATIONSIZE + 1, sizeof(struct TestFunctions*));
       int i = 0;
       for ( ; i < len; i++) { result[i] = col[i]; }
     }
    else { result = col; }
    result[len] = ex;
    result[len+1] = NULL;
    return result;
  }

struct SomeFunctions* createSomeFunctions()
{ struct SomeFunctions* result = (struct SomeFunctions*) malloc(sizeof(struct SomeFunctions));
  somefunctions_instances = appendSomeFunctions(somefunctions_instances, result);
  somefunctions_size++;
  return result;
}

struct TestFunctions* createTestFunctions()
{ struct TestFunctions* result = (struct TestFunctions*) malloc(sizeof(struct TestFunctions));
  testfunctions_instances = appendTestFunctions(testfunctions_instances, result);
  testfunctions_size++;
  return result;
}

struct SomeFunctions** insertSomeFunctions(struct SomeFunctions* col[], struct SomeFunctions* self)
  { if (isIn((void*) self, (void**) col))
    { return col; }
    return appendSomeFunctions(col,self);
  }

struct TestFunctions** insertTestFunctions(struct TestFunctions* col[], struct TestFunctions* self)
  { if (isIn((void*) self, (void**) col))
    { return col; }
    return appendTestFunctions(col,self);
  }

  struct SomeFunctions** subrangeSomeFunctions(struct SomeFunctions** col, int i, int j)
  { int len = length((void**) col);
    if (i > j || j > len) { return NULL; }
    struct SomeFunctions** result = (struct SomeFunctions**) calloc(j - i + 2, sizeof(struct SomeFunctions*));
     int k = i-1;
     int l = 0;
     for ( ; k < j; k++, l++)
     { result[l] = col[k]; }
    result[l] = NULL;
    return result;
  }

  struct TestFunctions** subrangeTestFunctions(struct TestFunctions** col, int i, int j)
  { int len = length((void**) col);
    if (i > j || j > len) { return NULL; }
    struct TestFunctions** result = (struct TestFunctions**) calloc(j - i + 2, sizeof(struct TestFunctions*));
     int k = i-1;
     int l = 0;
     for ( ; k < j; k++, l++)
     { result[l] = col[k]; }
    result[l] = NULL;
    return result;
  }

  struct SomeFunctions** reverseSomeFunctions(struct SomeFunctions** col)
  { int n = length((void**) col);
    struct SomeFunctions** result = (struct SomeFunctions**) calloc(n+1, sizeof(struct SomeFunctions*));
    int i = 0;
    int x = n-1;
    for ( ; i < n; i++, x--)
    { result[i] = col[x]; }
    result[n] = NULL;
    return result;
  }

  struct TestFunctions** reverseTestFunctions(struct TestFunctions** col)
  { int n = length((void**) col);
    struct TestFunctions** result = (struct TestFunctions**) calloc(n+1, sizeof(struct TestFunctions*));
    int i = 0;
    int x = n-1;
    for ( ; i < n; i++, x--)
    { result[i] = col[x]; }
    result[n] = NULL;
    return result;
  }

struct SomeFunctions** removeSomeFunctions(struct SomeFunctions* col[], struct SomeFunctions* ex)
{ int len = length((void**) col);
  struct SomeFunctions** result = (struct SomeFunctions**) calloc(len+1, sizeof(struct SomeFunctions*));
  int j = 0;
  int i = 0;
  for ( ; i < len; i++)
  { struct SomeFunctions* eobj = col[i];
    if (eobj == NULL)
    { result[j] = NULL;
      return result; 
    }
    if (eobj == ex) { }
    else
    { result[j] = eobj; j++; }
  }
  result[j] = NULL;
  return result;
}

struct TestFunctions** removeTestFunctions(struct TestFunctions* col[], struct TestFunctions* ex)
{ int len = length((void**) col);
  struct TestFunctions** result = (struct TestFunctions**) calloc(len+1, sizeof(struct TestFunctions*));
  int j = 0;
  int i = 0;
  for ( ; i < len; i++)
  { struct TestFunctions* eobj = col[i];
    if (eobj == NULL)
    { result[j] = NULL;
      return result; 
    }
    if (eobj == ex) { }
    else
    { result[j] = eobj; j++; }
  }
  result[j] = NULL;
  return result;
}

struct SomeFunctions** removeAllSomeFunctions(struct SomeFunctions* col1[], struct SomeFunctions* col2[])
{ int n = length((void**) col1);
  struct SomeFunctions** result = (struct SomeFunctions**) calloc(n+1, sizeof(struct SomeFunctions*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { struct SomeFunctions* ex = col1[i];
    if (isIn((void*) ex, (void**) col2)) {}
    else 
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

struct TestFunctions** removeAllTestFunctions(struct TestFunctions* col1[], struct TestFunctions* col2[])
{ int n = length((void**) col1);
  struct TestFunctions** result = (struct TestFunctions**) calloc(n+1, sizeof(struct TestFunctions*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { struct TestFunctions* ex = col1[i];
    if (isIn((void*) ex, (void**) col2)) {}
    else 
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

struct SomeFunctions** frontSomeFunctions(struct SomeFunctions* col[])
{ int n = length((void**) col);
  return subrangeSomeFunctions(col, 1, n-1); }

struct TestFunctions** frontTestFunctions(struct TestFunctions* col[])
{ int n = length((void**) col);
  return subrangeTestFunctions(col, 1, n-1); }

struct SomeFunctions** tailSomeFunctions(struct SomeFunctions* col[])
{ int n = length((void**) col);
  return subrangeSomeFunctions(col, 2, n); }

struct TestFunctions** tailTestFunctions(struct TestFunctions* col[])
{ int n = length((void**) col);
  return subrangeTestFunctions(col, 2, n); }

double op_4(double z)
{  return (z * z + z - 1);
}

double quad(double x)
{ double result = 0;
  result = x * x + x - 1;
  return result;
}

double xpow(double x)
{ double result = 0;
  result = pow(x, x) - 0.7;
  return result;
}

double secant(double rn, double rminus, double fminus, double tol, double (*f)(double))
{ double result = 0;
 double fn = 0;
  fn = f(rn);
  if (fabs(fn) < tol)
  {  result = rn;
  }
  else 
  {  result = secant(rn - fn * ((rn - rminus) / (fn - fminus)), rn, fn, tol, f);
  }
  return result;
}

void killSomeFunctions(struct SomeFunctions* somefunctions_x)
{  somefunctions_instances = removeSomeFunctions(somefunctions_instances, somefunctions_x);
  free(somefunctions_x);
}

void testFunctions(void)
{ double rn = 0;
  rn = 0.5;
 double rminus = 0;
  rminus = 0.2;
 double fminus = 0;
  fminus = quad(rminus);
 double res = 0;
  res = secant(rn, rminus, fminus, 0.001, op_4);
  displaydouble(res);
}

int main(int _argc, char* _argv[]) { return 0; }
/* Delete operations for empty structs. Currently, sequences & sets of 
   basic values (numerics, booleans) are not supported. Maps must have 
   String domain type.                                               */
