struct SomeFunctions {
};

struct TestFunctions {
};

struct SomeFunctions** appendSomeFunctions(struct SomeFunctions* col[], struct SomeFunctions* ex);

struct TestFunctions** appendTestFunctions(struct TestFunctions* col[], struct TestFunctions* ex);

struct SomeFunctions* createSomeFunctions(void);

struct TestFunctions* createTestFunctions(void);

struct SomeFunctions** insertSomeFunctions(struct SomeFunctions* col[], struct SomeFunctions* self);

struct TestFunctions** insertTestFunctions(struct TestFunctions* col[], struct TestFunctions* self);

  struct SomeFunctions** subrangeSomeFunctions(struct SomeFunctions** col, int i, int j);
  struct TestFunctions** subrangeTestFunctions(struct TestFunctions** col, int i, int j);
  struct SomeFunctions** reverseSomeFunctions(struct SomeFunctions* col[]);
  struct TestFunctions** reverseTestFunctions(struct TestFunctions* col[]);
struct SomeFunctions** removeSomeFunctions(struct SomeFunctions* col[], struct SomeFunctions* ex);
struct TestFunctions** removeTestFunctions(struct TestFunctions* col[], struct TestFunctions* ex);
struct SomeFunctions** removeAllSomeFunctions(struct SomeFunctions* _col1[], struct SomeFunctions* _col2[]);

struct TestFunctions** removeAllTestFunctions(struct TestFunctions* _col1[], struct TestFunctions* _col2[]);

struct SomeFunctions** frontSomeFunctions(struct SomeFunctions* _col[]);

struct TestFunctions** frontTestFunctions(struct TestFunctions* _col[]);

struct SomeFunctions** tailSomeFunctions(struct SomeFunctions* _col[]);

struct TestFunctions** tailTestFunctions(struct TestFunctions* _col[]);

double quad(double x);

double xpow(double x);

double secant(double rn, double rminus, double fminus, double tol, double (*f)(double));

void killSomeFunctions(struct SomeFunctions* somefunctions_x);

void testFunctions(void);

/* Header code written to app.h                          */
/* Please note that empty structs are not valid in C,    */
/* any such structs and their operations can be deleted. */
