import ocl
import math

from enum import Enum
from time import *

def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)


class SomeFunctions:
  somefunctions_instances = []
  somefunctions_index = dict({})

  def __init__(self):
    SomeFunctions.somefunctions_instances.append(self)


  def quad(x) :
    result = 0.0
    result = x * x + x - 1
    return result

  def xpow(x) :
    result = 0.0
    result = math.pow(x, x) - 0.7
    return result

  def secant(rn,rminus,fminus,tol,f) :
    result = 0.0
    fn = 0.0
    fn = f(rn)
    if math.fabs(fn) < tol :
      result = rn
    else :
      result = SomeFunctions.secant(rn - fn * (rn - rminus)/(fn - fminus), rn, fn, tol, f)
    return result

  def killSomeFunctions(somefunctions_x) :
    somefunctions_instances = ocl.excludingSet(somefunctions_instances, somefunctions_x)
    free(somefunctions_x)

class TestFunctions:
  testfunctions_instances = []
  testfunctions_index = dict({})

  def __init__(self):
    TestFunctions.testfunctions_instances.append(self)


def createSomeFunctions():
  somefunctions = SomeFunctions()
  return somefunctions

def allInstances_SomeFunctions():
  return SomeFunctions.somefunctions_instances


def createTestFunctions():
  testfunctions = TestFunctions()
  return testfunctions

def allInstances_TestFunctions():
  return TestFunctions.testfunctions_instances


def testFunctions() :
  pass
  rn = 0.0
  rn = 0.5
  rminus = 0.0
  rminus = 0.2
  fminus = 0.0
  fminus = SomeFunctions.quad(rminus)
  res = 0.0
  res = SomeFunctions.secant(rn, rminus, fminus, 0.001, lambda z : z * z + z - 1)
  ## displaydouble(res)



startTime = time()
for x in range(0,33333) : 
  testFunctions()
endTime = time()
print("Time taken = " + str(endTime - startTime))








