import Foundation
import Darwin

class SomeFunctions
{ static var instance : SomeFunctions? = nil

  init() { }

  static func defaultInstance() -> SomeFunctions
  { if (instance == nil)
    { instance = createSomeFunctions() }
    return instance!  }


  static func quad(x : Double) -> Double
  {
    var result : Double = 0.0
    result =  x*x + x - 1
    return result

  }


  static func xpow(x : Double) -> Double
  {
    var result : Double = 0.0
    result = pow(_: x, _: x) - 0.7
    return result

  }


  static func secant(rn : Double, rminus : Double, fminus : Double, tol : Double, f : (Double)->Double) -> Double
  {
    var result : Double = 0.0
    var fn : Double = 0.0
    fn = f(_: rn)
    if abs(_: fn) < tol
    {
      result = rn
    }
    else {
      result = SomeFunctions.secant(rn: rn -  fn*((rn - rminus) / (fn - fminus)), rminus: rn, fminus: fn, tol: tol, f: f)
    }
    return result

  }
    
    func test()
    { // print(SomeFunctions.quad(x: 0.5))
      // print(SomeFunctions.xpow(x: 0.5))
       
        let text = "a long piece of text88"
        let pattern = "[a-z]+"

        let regex = try! NSRegularExpression(pattern: pattern)

        let modText = regex.stringByReplacingMatches(in: text, options: [], range: NSRange(location: 0, length: text.count), withTemplate: "***") as NSString

        print(modText)
        
        /* var t1 = CFAbsoluteTimeGetCurrent()
        for i in 1...10000
        {
         let f = { (x : Double) -> Double in return SomeFunctions.quad(x: x) }
         let rn = 0.5
         let rminus = 0.2
         let fminus = f(rminus)
         let tol = 0.000001
        SomeFunctions.secant(rn: rn,rminus: rminus, fminus: fminus, tol: tol, f: f)
        
        let f1 = { (x : Double) -> Double in return SomeFunctions.xpow(x: x) }
        let rn1 = 0.5
        let rminus1 = 0.2
        let fminus1 = f1(rminus1)
        let tol1 = 0.000001
        SomeFunctions.secant(rn: rn1,rminus: rminus1, fminus: fminus1, tol: tol1, f: f1)
        }
        var t2 = CFAbsoluteTimeGetCurrent()
          print(t2 - t1)
        
        */
    }

}

var SomeFunctions_allInstances : [SomeFunctions] = [SomeFunctions]()

func createSomeFunctions() -> SomeFunctions
{ let result : SomeFunctions = SomeFunctions()
  SomeFunctions_allInstances.append(result)
  return result }


