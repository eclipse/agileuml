import ocl
import math

from enum import Enum

def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)


class FTest2:
  ftest2_instances = []
  ftest2_index = dict({})

  def __init__(self):
    self.f = None
    FTest2.ftest2_instances.append(self)


  def killFTest2(ftest2_x) :
    ftest2_instances = ocl.excludingSet(ftest2_instances, ftest2_x)
    free(ftest2_x)

def createFTest2():
  ftest2 = FTest2()
  return ftest2

def allInstances_FTest2():
  return FTest2.ftest2_instances

obj = FTest2()
obj.f = lambda x : x**4
print(obj.f(2))
