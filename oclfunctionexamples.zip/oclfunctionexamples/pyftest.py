import ocl
import math

from enum import Enum

def free(x):
  del x


def displayint(x):
  print(str(x))

def displaylong(x):
  print(str(x))

def displaydouble(x):
  print(str(x))

def displayboolean(x):
  print(str(x))

def displayString(x):
  print(x)


class FunctionTest:
  functiontest_instances = []
  functiontest_index = dict({})

  def __init__(self):
    FunctionTest.functiontest_instances.append(self)


  def findRoot(self, f) :
    result = 0.0
    result = f(0.5)
    return result

  def testCall(self) :
    result = 0.0
    result = self.findRoot(lambda x : (x * x + x + 1))
    return result

  def killFunctionTest(functiontest_x) :
    functiontest_instances = ocl.excludingSet(functiontest_instances, functiontest_x)
    free(functiontest_x)

def createFunctionTest():
  functiontest = FunctionTest()
  return functiontest

def allInstances_FunctionTest():
  return FunctionTest.functiontest_instances

obj = FunctionTest()
print(obj.testCall())
