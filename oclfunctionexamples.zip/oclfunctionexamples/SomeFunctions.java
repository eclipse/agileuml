import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;

class SomeFunctions { static ArrayList<SomeFunctions> SomeFunctions_allInstances = new ArrayList<SomeFunctions>();

  SomeFunctions() { SomeFunctions_allInstances.add(this); }

  static SomeFunctions createSomeFunctions() { SomeFunctions result = new SomeFunctions();
    return result; }

  String somefunctionsId = ""; /* primary */
  static Map<String,SomeFunctions> SomeFunctions_index = new HashMap<String,SomeFunctions>();

  static SomeFunctions createByPKSomeFunctions(String somefunctionsIdx)
  { SomeFunctions result = SomeFunctions.SomeFunctions_index.get(somefunctionsIdx);
    if (result != null) { return result; }
    result = new SomeFunctions();
    SomeFunctions.SomeFunctions_index.put(somefunctionsIdx,result);
    result.somefunctionsId = somefunctionsIdx;
    return result; }

  static void killSomeFunctions(String somefunctionsIdx)
  { SomeFunctions rem = SomeFunctions_index.get(somefunctionsIdx);
    if (rem == null) { return; }
    ArrayList<SomeFunctions> remd = new ArrayList<SomeFunctions>();
    remd.add(rem);
    SomeFunctions_index.remove(somefunctionsIdx);
    SomeFunctions_allInstances.removeAll(remd);
  }


  public static double quad(double x)
  {
    double result = 0.0;
    result = x * x + x - 1;
    return result;
  }


  public static double xpow(double x)
  {
    double result = 0.0;
    result = Math.pow(x,x) - 0.7;
    return result;
  }


  public static double secant(double rn, double rminus, double fminus, double tol, Evaluation<Double,Double> f)
  {
    double result = 0.0;
    double fn = 0.0;
    fn = f.evaluate(rn);
    if (Math.abs(fn) < tol)
    {
      result = rn;
    }
    else {
      result = SomeFunctions.secant(rn - fn * ((rn - rminus) / (fn - fminus)), rn, fn, tol, f);
    }
    return result;
  }

}

