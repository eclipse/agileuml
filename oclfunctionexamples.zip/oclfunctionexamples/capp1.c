/* --- The following code comes from C:\lcc\lib\wizard\textmode.tpl. */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <time.h>

#define _CRT_SECURE_NO_WARNINGS 1
// #define _CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES 1
#pragma warning( disable : 4996 )

#include "ocl.h"

int** removeAllint(int* col1[], int* col2[])
{ int n = length((void**) col1);
  int** result = (int**) calloc(n+1, sizeof(int*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { int* ex = col1[i];
    if (isInint(*ex, col2)) {}
    else
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

long** removeAlllong(long* col1[], long* col2[])
{ int n = length((void**) col1);
  long** result = (long**) calloc(n+1, sizeof(long*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { long* ex = col1[i];
    if (isInlong(*ex, col2)) {}
    else
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}

double** removeAlldouble(double* col1[], double* col2[])
{ int n = length((void**) col1);
  double** result = (double**) calloc(n+1, sizeof(double*));
  int i = 0; int j = 0;
  for ( ; i < n; i++)
  { double* ex = col1[i];
    if (isIndouble(*ex, col2)) {}
    else
    { result[j] = ex; j++; }
  }
  result[j] = NULL;
  return result;
}


unsigned char op_0(char* x)
{  return (strlen(x) > 2);
}

struct ocltnode* filterMap(struct ocltnode* m)
{  return oclSelectMap(m, op_0);
}

struct ocltnode* defineMap(struct ocltnode* m1)
{  return oclUnionMap(m1, insertIntoMap(NULL, "a", "1")); 
}

struct FTest {
  char* data; /* ONE */
  char* (*f)(char*); /* ONE */
};


char* getFTest_data(struct FTest* self)
{ return self->data; } 

char* (*getFTest_f(struct FTest* self))(char*) 
{ return self->f; }

void setFTest_data(struct FTest* self, char* _value)
{ self->data = _value; } 

void setFTest_f(struct FTest* self, char* (*_value)(char*))
{ self->f = _value; } 



unsigned char selector(int* x)
{ if (*x > 0)
  { return TRUE; } 
  return FALSE; 
}

double quad(double x)
{ double result = 0;  result = x * x + x - 1;
  return result;
 }

double xpow(double x)
{ double result = 0;  
  result = pow(x, x) - 0.7;
  return result;
 }

double secant(double rn, double rminus, double fminus, double tol, double (*f)(double))
{ double result = 0;
  double fn = 0;  
  fn = f(rn);
  if (fabs(fn) < tol)
  {   result = rn;
 }
  else 
  {   result = secant(rn - fn * ((rn - rminus) / (fn - fminus)), rn, fn, tol, f);
 }
  return result;
 }

/* struct ocltnode* wordCount(char** sq)
{ struct ocltnode* result;
  result = NULL;
  int ind_boundedloopstatement_24 = 0;
  for ( ; ind_boundedloopstatement_24 < length((void**) sq); ind_boundedloopstatement_24++)
  { char* x = (sq)[ind_boundedloopstatement_24];
    int v = count((void*) x, (void**) sq); 
    result = insertIntoMap(result, x, &v);
  }
  return result;
} */

struct ocltnode* wordCount(char** sq)
{ struct ocltnode* result;
  result = NULL;
  int ind_boundedloopstatement_24 = 0;
  for ( ; ind_boundedloopstatement_24 < length((void**) sq); ind_boundedloopstatement_24++)
  { char* x = (sq)[ind_boundedloopstatement_24];
      result = insertIntoMapint(result, x, count((void*) x, (void**) sq));

  }
  return result;
}

int** testIntSequences(void)
{ int** xs = NULL;
  xs = appendint(xs, 1);
  xs = appendint(xs, 2);
  displayint(length((void**) xs));
  return xs; 
}

int main(int argc,char *argv[])
{ int** rx = testIntSequences(); 

  int** lx = newintList(); 
  int pp = 0; 
  for ( ; pp < 100; pp++) 
  { lx = appendint(lx,pp); } 

  displayboolean(isInint(5,lx)); 
  displayboolean(isInint(200,lx)); 

  displayboolean(isInint(1,lx)); 
  displayboolean(isInint(2,lx)); 


  lx = removeAllint(lx, rx); 

  displayboolean(isInint(1,lx)); 
  displayboolean(isInint(2,lx)); 

  printf("%d\n", length(lx)); 

  printf("%d, %d\n", *lx[3], *lx[19]);  

  char** tchrs = newStringList(); 
  tchrs = appendString(tchrs, "aa"); 
  tchrs = appendString(tchrs, "bb"); 
  tchrs = appendString(tchrs, "cc"); 
  tchrs = appendString(tchrs, "dd"); 
  tchrs = appendString(tchrs, "ee"); 

  displayboolean(isInString("bb",tchrs)); 
  displayboolean(isInString("dd",tchrs)); 

  printf("%d\n", length(tchrs)); 
  

  char** xchrs = newStringList();
  xchrs = appendString(xchrs, "bb");
  xchrs = appendString(xchrs, "dd");
  xchrs = appendString(xchrs, "ff"); 
 
  char** ychrs = removeAtString(tchrs,3); 

  printf("%d\n", length(ychrs)); 

  printf("%s, %s, %s\n", ychrs[0], ychrs[1], ychrs[2]);  

 /* int kk = 0; 
  time_t starttime = time(NULL); 
  for ( ; kk < 100; kk++)   // 1000000 takes 1 second. 
  { double fminus = xpow(0.2); 
    secant(0.5, 0.2, fminus, 0.00001, xpow);

    double fminus1 = quad(0.2); 
    secant(0.5, 0.2, fminus1, 0.00001, quad);
  } 
  
    time_t endtime = time(NULL); 

    printf("Time taken: %d\n", (endtime - starttime)); */ 

   /* FILE* infile = fopen("./in.txt", "r");
    if (infile == NULL) 
    { printf("Error in file"); 
      return 1; 
    } 

    char* line = "";
    while (line != NULL)
    { printf(line); 
      line = fgets(line, 1000, infile);
    }
    fclose(infile); */ 

  /*  int* arr = intSubrange(3,7);
 
    int i = 0; 
    for ( ; i < 5; i++) 
    { printf("%d\n", arr[i]); } 

    printf("%d %d\n", (-5/3), (-5)%3); 
    printf("%d %d\n", (-5/-3), (-5)%(-3)); */ 

    
    char** result = (char**) calloc(1000,sizeof(char*));
    
    int i = 0; 
    for ( ; i < 333; i++) 
    { // result[i] = (char*) malloc(maxtokens*sizeof(char)); 
      result[i] = "aa"; 
    }
    for ( ; i < 666; i++) 
    { // alist[i]->value = "bb"; 
      result[i] = "bb"; 
    }
    for ( ; i < 999; i++) 
    { // alist[i]->value = "cc";
      result[i] = "cc"; 
    }

    int j = 0; 

    // printf("%d\n", countString("aa", result)); 
    // printf("%d\n", countString("bb", result)); 
    // printf("%d\n", countString("cc", result)); 

    struct ocltnode* newnode = NULL; 
    int k = 0; 

    // time_t starttime = time(NULL); 

  clock_t tt0  = clock();
  long time1 = (tt0/(CLOCKS_PER_SEC/1000));
  printf("Time0 = %d\n", time1 );

 
    /*  for ( ; k < 999; k++) 
    { char* c = result[k];
      int x = countString(c, result); 
      newnode = insertIntoMap(newnode, c, &x);
    }  */ 

    newnode = wordCount(result); 


  clock_t tt  = clock();
  long time2 = (tt/(CLOCKS_PER_SEC/1000));
  printf("Time = %d\n", (time2 - time1) );

   displayboolean(includesKey(newnode, "bb")); 
   displayboolean(excludesKey(newnode, "dd")); 

    int sz = oclSize(newnode); 



    printf("%d\n", sz);
    void* g = lookupInMap(newnode,"aa");  
    if (g != NULL)
    { printf("%d\n", *((int*) g)); } 
    void* gg = lookupInMap(newnode,"bb");  
    if (gg != NULL)
    { printf("%d\n", *((int*) gg)); } 

    struct ocltnode* t1 = NULL; 
    struct ocltnode* t2 = NULL; 
    t1 = insertIntoMap(t1,"a", "aa"); 
    t1 = insertIntoMap(t1,"b", "bb"); 
    t2 = oclComposeMaps(t1,newnode); 

    void* g1 = lookupInMap(t2,"a");  
    if (g1 != NULL)
    { printf("%d\n", *((int*) g1)); } 

    void* g2 = lookupInMap(t2,"b");  
    if (g2 != NULL)
    { printf("%d\n", *((int*) g2)); } 

/*    int x = 1; 
    int y = -2; 
    int z = 3; 
    newnode = insertIntoMap(newnode,"a", &x); 
    newnode = insertIntoMap(newnode,"b", &y); 
    newnode = insertIntoMap(newnode,"c", &z); 
    newnode = insertIntoMap(newnode,"d", &z); 


    char** r = oclKeyset(newnode); 
    int** v = (int**) oclValues(newnode); 

    // struct ocltnode* sel = oclSelectMap(newnode, (unsigned char (*)(void*)) selector); 


    int rr = length(r);
    int u = 0; 
    for ( ; u < rr; u++) 
    { displayString(r[u]); 
      printf("%d\n", *v[u]); 
    }

    printf("\n");

    struct ocltnode* sel = oclReverse(newnode); 

    char** r1 = oclKeyset(sel); 
    int** v1 = (int**) oclValues(sel); 

    int rr1 = length(r1);
    int u1 = 0; 
    for ( ; u1 < rr1; u1++) 
    { displayString(r1[u1]); 
      printf("%d\n", *v1[u1]); 
    }

    char** arr = (char**) calloc(3,sizeof(char*));

    arr[0] = "a";
    arr[1] = "b"; 
    arr[2] = NULL; 

    int x1 = 5; 
    int y1 = -6; 
    int z1 = 7; 
    struct ocltnode* ux = NULL; 
    ux = insertIntoMap(ux,"a", &x); 
    ux = insertIntoMap(ux,"e", &y1); 
    // newnode = insertIntoMap(newnode,"c", &z); 

    // struct ocltnode* map2 = oclUnionMap(newnode,ux); 
    struct ocltnode* map2 = oclIntersectionMap(newnode,ux); 

    char** r2 = oclKeyset(map2); 
    int** v2 = (int**) oclValues(map2); 

    printf("\n");

    int rr2 = length(r2);
    int u2 = 0; 
    for ( ; u2 < rr2; u2++) 
    { displayString(r2[u2]); 
      printf("%d\n", *v2[u2]); 
    } */ 

	return 0;
}
