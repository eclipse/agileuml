
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModelFacade
{ 
  static ModelFacade instance = null; 

  public static ModelFacade getInstance()
  { if (instance == null) 
    { instance = new ModelFacade(); }
    return instance;
  }


  private ModelFacade()
  { }

  public void testFunctions()
  { 
    double rn = 0.0;
    rn = 0.5;
    double rminus = 0.0;
    rminus = 0.2;
    double fminus = 0.0;
    fminus = SomeFunctions.quad(rminus);
    double res = 0.0;
    res = SomeFunctions.secant(rn, rminus, fminus, 0.001, (z) -> { return z * z + z - 1; });
    System.out.println(res);

  }
  
  public static void main(String[] args)
  { ModelFacade mf = ModelFacade.getInstance(); 
    mf.testFunctions(); 
  }

}
